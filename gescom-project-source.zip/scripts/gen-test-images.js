// Génération d'images de test : logo PNG transparent + "photo" d'élevage avicole
const sharp = require('sharp')

async function main() {
  // Logo : monogramme doré sur fond transparent (comme un vrai logo d'entreprise)
  const logoSvg = `<svg width="600" height="600" xmlns="http://www.w3.org/2000/svg">
    <circle cx="300" cy="300" r="270" fill="none" stroke="#D4A72C" stroke-width="26"/>
    <text x="300" y="390" font-family="DejaVu Sans" font-size="230" font-weight="bold" fill="#D4A72C" text-anchor="middle">AK</text>
    <text x="300" y="480" font-family="DejaVu Sans" font-size="54" fill="#FFFFFF" text-anchor="middle">ABALOVI</text>
  </svg>`
  await sharp(Buffer.from(logoSvg)).png().toFile('/tmp/test-logo.png')

  // Image d'illustration : paysage d'élevage stylisé (ciel, poulailler, herbe)
  const coverSvg = `<svg width="1600" height="1200" xmlns="http://www.w3.org/2000/svg">
    <rect width="1600" height="1200" fill="#7FB3D5"/>
    <circle cx="1300" cy="200" r="110" fill="#F9E79F"/>
    <rect y="700" width="1600" height="500" fill="#7DCEA0"/>
    <rect x="150" y="430" width="700" height="330" fill="#B03A2E"/>
    <polygon points="120,440 500,240 880,440" fill="#922B21"/>
    <rect x="260" y="540" width="120" height="120" fill="#FDEBD0"/>
    <rect x="480" y="540" width="120" height="120" fill="#FDEBD0"/>
    <rect x="700" y="540" width="120" height="120" fill="#FDEBD0"/>
    <rect x="1050" y="560" width="380" height="200" fill="#6E2C00"/>
    <polygon points="1020,570 1240,430 1460,570" fill="#513608"/>
    <circle cx="1150" cy="850" r="42" fill="#FFFFFF"/>
    <circle cx="1150" cy="850" r="18" fill="#E74C3C"/>
    <circle cx="1280" cy="880" r="42" fill="#FFFFFF"/>
    <circle cx="1280" cy="880" r="18" fill="#E74C3C"/>
    <circle cx="1400" cy="860" r="42" fill="#FFFFFF"/>
    <circle cx="1400" cy="860" r="18" fill="#E74C3C"/>
  </svg>`
  await sharp(Buffer.from(coverSvg)).jpeg({ quality: 90 }).toFile('/tmp/test-cover.jpg')

  for (const f of ['/tmp/test-logo.png', '/tmp/test-cover.jpg']) {
    const m = await sharp(f).metadata()
    console.log(f, m.format, `${m.width}x${m.height}`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
