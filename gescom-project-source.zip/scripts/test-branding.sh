#!/bin/bash
# Test E2E de la fonctionnalité identité visuelle + exports
set -u
BASE="http://localhost:3000"
PROJ="cmvwtexn20002p7hazh482ekj"  # projet démo Ferme avicole

# 1. Login
TOKEN=$(curl -s -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d '{"email":"demo@gescom.pro","password":"demo2026"}' | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))")
if [ -z "$TOKEN" ]; then echo "LOGIN FAILED"; exit 1; fi
echo "== LOGIN OK (${TOKEN:0:12}...)"

AUTH="Authorization: Bearer $TOKEN"

# 2. Générer une image de test (logo PNG + couverture JPEG)
python3 - <<'EOF'
from PIL import Image
img = Image.new('RGB', (600, 400), (212, 167, 44))
for x in range(600):
    for y in range(400):
        if (x//50 + y//50) % 2 == 0:
            img.putpixel((x,y),(15,23,42))
img.save('/tmp/test-cover.jpg', 'JPEG')
logo = Image.new('RGBA', (300, 300), (0,0,0,0))
for x in range(300):
    for y in range(300):
        if (x-150)**2 + (y-150)**2 < 100**2:
            logo.putpixel((x,y),(212,167,44,255))
logo.save('/tmp/test-logo.png', 'PNG')
print("images OK")
EOF

# 3. Upload cover
echo "== UPLOAD COVER =="
curl -s -X POST "$BASE/api/projects/$PROJ/assets" -H "$AUTH" \
  -F "kind=cover" -F "file=@/tmp/test-cover.jpg;type=image/jpeg" | head -c 400; echo

# 4. Upload logo
echo "== UPLOAD LOGO =="
curl -s -X POST "$BASE/api/projects/$PROJ/assets" -H "$AUTH" \
  -F "kind=logo" -F "file=@/tmp/test-logo.png;type=image/png" | head -c 400; echo

# 5. Lister les assets
echo "== LIST ASSETS =="
curl -s "$BASE/api/projects/$PROJ/assets" -H "$AUTH" | head -c 600; echo

# 6. GET cover bytes
echo "== GET COVER BYTES =="
curl -s -o /tmp/cover-get.jpg -w "%{http_code} %{content_type} %{size_download}\n" \
  "$BASE/api/projects/$PROJ/assets/cover" -H "$AUTH"

# 7. Export PDF
echo "== EXPORT PDF =="
curl -s -o /tmp/export-test.pdf -w "http=%{http_code} type=%{content_type} size=%{size_download}\n" \
  -X POST "$BASE/api/projects/$PROJ/export" -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"format":"PDF"}'
file /tmp/export-test.pdf 2>/dev/null | head -c 200; echo
if command -v pdfinfo >/dev/null; then pdfinfo /tmp/export-test.pdf 2>&1 | head -12; fi

# 8. Export PPTX
echo "== EXPORT PPTX =="
curl -s -o /tmp/export-test.pptx -w "http=%{http_code} type=%{content_type} size=%{size_download}\n" \
  -X POST "$BASE/api/projects/$PROJ/export" -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"format":"PPTX","audience":"INVESTOR"}'
file /tmp/export-test.pptx 2>/dev/null | head -c 200; echo
unzip -l /tmp/export-test.pptx 2>/dev/null | grep -i media || echo "AUCUNE IMAGE DANS LE PPTX"

# 9. Export DOCX
echo "== EXPORT DOCX =="
curl -s -o /tmp/export-test.docx -w "http=%{http_code} size=%{size_download}\n" \
  -X POST "$BASE/api/projects/$PROJ/export" -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"format":"DOCX"}'
file /tmp/export-test.docx 2>/dev/null | head -c 200; echo
unzip -l /tmp/export-test.docx 2>/dev/null | grep -i media || echo "AUCUNE IMAGE DANS LE DOCX"
