// Test du format Excel à séparateur « . » forcé (demande utilisateur)
// Rendu attendu : 6500000 -> 6.500.000 ; -12345 -> -12.345 ; 500 -> 500
const ExcelJS = require('/home/z/my-project/node_modules/exceljs')

const FMT = '[>=1000]#"."##0"."##0;[<=-1000]-#"."##0"."##0;0'
const VALUES = [6500000, 999, 12345, -12345, -500, 123456789, 1234567890, 0, -0.4]

async function main() {
  const wb = new ExcelJS.Workbook()
  const ws = wb.addWorksheet('Test')
  ws.getCell(1, 1).value = 'Valeur brute'
  ws.getCell(1, 2).value = 'Format point forcé'
  ws.getCell(1, 3).value = 'Format standard #,##0'
  VALUES.forEach((v, i) => {
    const r = i + 2
    ws.getCell(r, 1).value = v
    const c = ws.getCell(r, 2)
    c.value = v
    c.numFmt = FMT
    const s = ws.getCell(r, 3)
    s.value = v
    s.numFmt = '#,##0'
  })
  ws.getColumn(1).width = 16
  ws.getColumn(2).width = 22
  ws.getColumn(3).width = 22
  await wb.xlsx.writeFile('/tmp/test-format.xlsx')
  console.log('OK écrit /tmp/test-format.xlsx')
}
main().catch((e) => { console.error(e); process.exit(1) })
