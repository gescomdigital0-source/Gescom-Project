import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  // Supprime les documents de test créés à 22:22:27 sur le projet de l'utilisateur
  const target = new Date('2026-10-31T22:22:00Z')
  const docs = await db.generatedDocument.findMany({
    where: { createdAt: { gte: target }, projectId: 'cmvwubz66003ip7has7s58syh' },
  })
  for (const d of docs) {
    await db.generatedDocument.delete({ where: { id: d.id } })
    console.log('doc supprimé:', d.format, d.name)
  }

  // Supprime l'utilisateur + projet de test
  const tu = await db.user.findUnique({ where: { email: 'test-export@gescom.test' } })
  if (tu) {
    await db.session.deleteMany({ where: { userId: tu.id } })
    const projs = await db.project.findMany({ where: { userId: tu.id } })
    for (const p of projs) {
      await db.generatedDocument.deleteMany({ where: { projectId: p.id } })
      await db.task.deleteMany({ where: { projectId: p.id } })
      await db.activity.deleteMany({ where: { projectId: p.id } })
      await db.project.delete({ where: { id: p.id } })
      console.log('projet test supprimé:', p.name)
    }
    await db.activity.deleteMany({ where: { userId: tu.id } })
    await db.loginEvent.deleteMany({ where: { email: tu.email } })
    await db.user.delete({ where: { id: tu.id } })
    console.log('utilisateur test supprimé')
  }
  await db.$disconnect()
}

main()
