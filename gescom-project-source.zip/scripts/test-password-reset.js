// Test E2E du parcours « mot de passe oublié » – GESCOM PROJECT
const BASE = 'http://localhost:3000'
const EMAIL = 'reset.test@gescom.pro'

async function api(path, body) {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  return { status: res.status, data }
}

function log(label, r, extra = '') {
  console.log(`${label} -> HTTP ${r.status} ${extra}`.trim())
  return r
}

;(async () => {
  // A. Inscription + activation du compte de test
  let r = await api('/api/auth/register', {
    email: EMAIL, password: 'ancien2026a', firstName: 'Reset', lastName: 'Test',
  })
  log('A1 inscription', r, r.data.devCode ? `(code ${r.data.devCode})` : '(réinscription)')
  const c1 = r.data.devCode
  if (c1) {
    r = await api('/api/auth/verify', { email: EMAIL, code: c1 })
    log('A2 activation', r)
  } else {
    console.log('A2 activation : compte déjà existant, on continue')
  }

  // Attendre la fin du délai anti-spam de 60 s (code SIGNUP vient d'être envoyé)
  console.log('Pause 61 s (anti-spam)…')
  await new Promise((s) => setTimeout(s, 61000))

  // B. Mot de passe oublié
  r = await api('/api/auth/password/forgot', { email: EMAIL })
  log('B oubli de mot de passe', r, `(code ${r.data.devCode})`)
  const c2 = r.data.devCode
  if (!c2) { console.error('Devcode manquant : test impossible'); process.exit(1) }

  // C. Code faux
  r = await api('/api/auth/password/reset', { email: EMAIL, code: '999999', password: 'nouveau2026a' })
  log('C code faux (400 attendu)', r, `« ${r.data.error} »`)

  // D. Mot de passe trop faible
  r = await api('/api/auth/password/reset', { email: EMAIL, code: c2, password: 'court' })
  log('D mot de passe faible (400 attendu)', r, `« ${r.data.error} »`)

  // E. Réinitialisation avec le bon code
  r = await api('/api/auth/password/reset', { email: EMAIL, code: c2, password: 'nouveau2026a' })
  log('E réinitialisation (200 attendu)', r, r.data.message ? `« ${r.data.message} »` : '')

  // F. Ancien mot de passe refusé
  r = await api('/api/auth/login', { email: EMAIL, password: 'ancien2026a' })
  log('F ancien mot de passe (400 attendu)', r, `« ${r.data.error} »`)

  // G. Nouveau mot de passe accepté
  r = await api('/api/auth/login', { email: EMAIL, password: 'nouveau2026a' })
  log('G nouveau mot de passe (200 attendu)', r, r.data.user ? `(session ${r.data.user.email})` : '')

  // H. Adresse inconnue : réponse générique anti-énumération
  r = await api('/api/auth/password/forgot', { email: 'personne@nullepart.com' })
  log('H adresse inconnue (200 générique attendu)', r, `« ${(r.data.message || '').slice(0, 60)}… »`)
})().catch((e) => { console.error(e); process.exit(1) })
