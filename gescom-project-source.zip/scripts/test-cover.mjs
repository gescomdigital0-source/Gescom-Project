// Reproduction du bug prepareCover : la photo disparaît sous le voile
import sharp from 'sharp'

const COVER_W = 1240
const COVER_H = 1754
const OPACITY = 0.78

// Recréer une image test : damier brun (comme /tmp/test_cover.jpg)
async function makeTestInput() {
  const svg = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">` +
    `<rect width="800" height="600" fill="rgb(180,120,60)"/>` +
    `<rect x="0" y="0" width="400" height="300" fill="rgb(140,90,40)"/>` +
    `<rect x="400" y="300" width="400" height="300" fill="rgb(140,90,40)"/>` +
    `</svg>`)
  return sharp(svg).jpeg().toBuffer()
}

async function analyze(name, buf) {
  const { data, info } = await sharp(buf).raw().toBuffer({ resolveWithObject: true })
  let min = [255,255,255], max = [0,0,0]
  const sums = [0,0,0]; const n = info.width * info.height
  for (let i = 0; i < data.length; i += info.channels) {
    for (let c = 0; c < 3; c++) {
      const v = data[i + c]
      if (v < min[c]) min[c] = v
      if (v > max[c]) max[c] = v
      sums[c] += v
    }
  }
  const mean = sums.map(s => (s / n).toFixed(1))
  console.log(`${name}: min=[${min}] max=[${max}] mean=[${mean}]`)
}

const input = await makeTestInput()
await analyze('input (damier brun)        ', input)

// --- Variante A : exactement le code actuel (SVG sans xmlns, fill-opacity) ---
const veilA = Buffer.from(
  `<svg width="${COVER_W}" height="${COVER_H}">` +
  `<rect width="${COVER_W}" height="${COVER_H}" fill="#0F172A" fill-opacity="${OPACITY}"/>` +
  `</svg>`)
try {
  const outA = await sharp(input).resize(COVER_W, COVER_H, { fit: 'cover', position: 'centre' })
    .composite([{ input: veilA }]).jpeg({ quality: 88 }).toBuffer()
  await analyze('A: code actuel (sans xmlns) ', outA)
} catch (e) { console.log('A a échoué:', e.message) }

// --- Variante B : SVG AVEC xmlns ---
const veilB = Buffer.from(
  `<svg xmlns="http://www.w3.org/2000/svg" width="${COVER_W}" height="${COVER_H}">` +
  `<rect width="${COVER_W}" height="${COVER_H}" fill="#0F172A" fill-opacity="${OPACITY}"/>` +
  `</svg>`)
try {
  const outB = await sharp(input).resize(COVER_W, COVER_H, { fit: 'cover', position: 'centre' })
    .composite([{ input: veilB }]).jpeg({ quality: 88 }).toBuffer()
  await analyze('B: avec xmlns               ', outB)
} catch (e) { console.log('B a échoué:', e.message) }

// --- Variante C : voile calculé en pixels (fiable, sans SVG) ---
async function veilPixel(inputBuf) {
  const base = await sharp(inputBuf).resize(COVER_W, COVER_H, { fit: 'cover', position: 'centre' }).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const d = base.data
  const navy = [15, 23, 42]
  for (let i = 0; i < d.length; i += 3) {
    d[i]     = Math.round(navy[0] * OPACITY + d[i]     * (1 - OPACITY))
    d[i + 1] = Math.round(navy[1] * OPACITY + d[i + 1] * (1 - OPACITY))
    d[i + 2] = Math.round(navy[2] * OPACITY + d[i + 2] * (1 - OPACITY))
  }
  return sharp(d, { raw: { width: base.info.width, height: base.info.height, channels: 3 } }).jpeg({ quality: 88 }).toBuffer()
}
const outC = await veilPixel(input)
await analyze('C: voile calculé en pixels  ', outC)

// Attendu pour référence : 0.78*navy + 0.22*photo
console.log('attendu théorique ≈ [46.9, 44.3, 46.0] (les zones sombres du damier descendront un peu plus)')
