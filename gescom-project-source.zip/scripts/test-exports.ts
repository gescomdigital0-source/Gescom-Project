// Test de vérification des 4 générateurs d'export
import { buildDossier } from '../src/lib/exports/content'
import { generatePdf } from '../src/lib/exports/pdf'
import { generateDocx } from '../src/lib/exports/docx'
import { generateXlsx } from '../src/lib/exports/xlsx'
import { generatePptx } from '../src/lib/exports/pptx'
import {
  DEMO_ANALYSIS, DEMO_DOCPREFS, DEMO_FINANCE, DEMO_OVERVIEW, DEMO_PROJECT, DEMO_TASKS,
} from '../src/lib/demo-data'
import type { Project, Task } from '@prisma/client'

const now = new Date()
const project = {
  id: 'test',
  userId: 'test',
  name: DEMO_PROJECT.name,
  idea: DEMO_PROJECT.idea,
  description: DEMO_PROJECT.description,
  sector: DEMO_PROJECT.sector,
  type: DEMO_PROJECT.type,
  country: DEMO_PROJECT.country,
  region: DEMO_PROJECT.region,
  currency: DEMO_PROJECT.currency,
  status: DEMO_PROJECT.status,
  objectives: JSON.stringify(DEMO_PROJECT.objectives),
  overview: JSON.stringify(DEMO_OVERVIEW),
  analysis: JSON.stringify(DEMO_ANALYSIS),
  finance: JSON.stringify(DEMO_FINANCE),
  docPrefs: JSON.stringify(DEMO_DOCPREFS),
  createdAt: now,
  updatedAt: now,
} as unknown as Project

const tasks = DEMO_TASKS.map((t, i) => ({
  id: `t${i}`, projectId: 'test', createdAt: now,
  phase: t.phase, title: t.title, responsible: t.responsible,
  startDate: t.startDate, endDate: t.endDate, status: t.status, progress: t.progress, order: i,
})) as unknown as Task[]

const dossier = buildDossier({ project, tasks })
console.log('Dossier :', dossier.sections.length, 'sections,', dossier.sections.reduce((s, x) => s + x.blocks.length, 0), 'blocs')

import fs from 'fs'
const out = '/tmp/exports-test'
fs.mkdirSync(out, { recursive: true })

const pdf = await generatePdf(dossier, {
  footerText: 'Généré avec GESCOM PROJECT',
  headerText: 'Awa Farms & Co – Ferme avicole moderne',
  includeCover: true,
  includeToc: true,
})
fs.writeFileSync(`${out}/test.pdf`, pdf)
console.log('PDF :', (pdf.length / 1024).toFixed(0), 'Ko')

const docx = await generateDocx(dossier, { headerText: 'GESCOM', footerText: 'Généré avec GESCOM PROJECT' })
fs.writeFileSync(`${out}/test.docx`, docx)
console.log('DOCX :', (docx.length / 1024).toFixed(0), 'Ko')

const xlsx = await generateXlsx(project, tasks)
fs.writeFileSync(`${out}/test.xlsx`, xlsx)
console.log('XLSX :', (xlsx.length / 1024).toFixed(0), 'Ko')

const pptx = await generatePptx(dossier, {
  audience: 'INVESTOR', themePrimary: '0F172A', themeAccent: 'D4A72C',
  author: 'Awa Nkeng', organization: 'Awa Farms & Co',
})
fs.writeFileSync(`${out}/test.pptx`, pptx)
console.log('PPTX :', (pptx.length / 1024).toFixed(0), 'Ko')

// Vérification des fichiers (magic bytes)
const files = fs.readdirSync(out)
for (const f of files) {
  const fd = fs.openSync(`${out}/${f}`, 'r')
  const buf = Buffer.alloc(4)
  fs.readSync(fd, buf, 0, 4, 0)
  fs.closeSync(fd)
  console.log(`${f} → signature: ${buf.toString('hex')}`)
}
console.log('Signatures attendues : PDF=25504446, DOCX/XLSX/PPTX=504b0304 (zip)')
