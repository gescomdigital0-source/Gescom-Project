# Génère une image de couverture réaliste (scène d'élevage avicole stylisée)
# et un logo d'entreprise propre, pour la validation E2E du branding.
from PIL import Image, ImageDraw, ImageFilter

W, H = 1600, 1200
img = Image.new('RGB', (W, H))
d = ImageDraw.Draw(img)

# Ciel dégradé (bleu clair -> crème à l'horizon)
for y in range(H):
    t = y / H
    if t < 0.55:
        k = t / 0.55
        r = int(125 - 40 * k); g = int(185 - 25 * k); b = int(230 - 25 * k)
    else:
        k = (t - 0.55) / 0.45
        r = int(85 + 90 * k); g = int(160 + 40 * k); b = int(90 - 20 * k)
    d.line([(0, y), (W, y)], fill=(r, g, b))

# Soleil
d.ellipse([1180, 80, 1330, 230], fill=(255, 220, 120))

# Sol vert
d.rectangle([0, 720, W, H], fill=(92, 140, 60))

# Poulailler (bâtiment)
d.polygon([(180, 720), (180, 480), (420, 380), (660, 480), (660, 720)], fill=(178, 132, 86))
d.polygon([(160, 490), (420, 375), (680, 490)], fill=(120, 78, 48))
d.rectangle([260, 560, 340, 720], fill=(90, 58, 34))      # porte
d.rectangle([500, 540, 580, 620], fill=(210, 230, 245))   # fenêtre

# Clôture
for x in range(40, W, 90):
    d.rectangle([x, 760, x + 12, 880], fill=(110, 80, 50))
d.rectangle([0, 780, W, 794], fill=(110, 80, 50))
d.rectangle([0, 850, W, 864], fill=(110, 80, 50))

# Poulets stylisés
for cx, cy, s in [(760, 950, 1.0), (950, 1020, 1.15), (1150, 930, 0.9), (1330, 1040, 1.1), (880, 880, 0.8)]:
    body_w, body_h = int(70 * s), int(55 * s)
    d.ellipse([cx, cy, cx + body_w, cy + body_h], fill=(245, 242, 235))
    d.ellipse([cx + body_w - int(28 * s), cy - int(22 * s), cx + body_w + int(16 * s), cy + int(14 * s)], fill=(245, 242, 235))
    d.polygon([(cx + body_w - 6, cy - int(20 * s)), (cx + body_w + 2, cy - int(38 * s)), (cx + body_w + 8, cy - int(18 * s))], fill=(210, 60, 40))
    d.ellipse([cx + body_w + 4, cy - int(12 * s), cx + body_w + 12, cy - int(4 * s)], fill=(30, 30, 30))
    d.line([cx + int(18 * s), cy + body_h, cx + int(18 * s), cy + body_h + int(16 * s)], fill=(220, 150, 60), width=4)
    d.line([cx + int(44 * s), cy + body_h, cx + int(44 * s), cy + body_h + int(16 * s)], fill=(220, 150, 60), width=4)

img = img.filter(ImageFilter.GaussianBlur(0.6))
img.save('/tmp/farm_cover.jpg', quality=92)
print('cover réaliste:', img.size)

# Logo : cercle or + poulet stylisé + texte
LW, LH = 800, 400
logo = Image.new('RGBA', (LW, LH), (0, 0, 0, 0))
ld = ImageDraw.Draw(logo)
ld.ellipse([20, 40, 340, 360], fill=(15, 23, 42, 255), outline=(212, 167, 44, 255), width=8)
ld.ellipse([110, 170, 230, 260], fill=(245, 242, 235, 255))
ld.ellipse([200, 150, 258, 205], fill=(245, 242, 235, 255))
ld.polygon([(228, 158), (240, 128), (250, 160)], fill=(210, 60, 40, 255))
ld.ellipse([236, 168, 250, 182], fill=(30, 30, 30, 255))
ld.rectangle([150, 258, 158, 290], fill=(220, 150, 60, 255))
ld.rectangle([190, 258, 198, 290], fill=(220, 150, 60, 255))
ld.text((370, 150), 'ABALOVI', fill=(15, 23, 42, 255))
ld.text((370, 210), 'FARMS', fill=(176, 136, 15, 255))
ld.rectangle([370, 260, 620, 266], fill=(212, 167, 44, 255))
logo.save('/tmp/farm_logo.png')
print('logo:', logo.size)
