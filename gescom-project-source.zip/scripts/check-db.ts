import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  const events = await db.loginEvent.findMany({ orderBy: { createdAt: 'desc' }, take: 10 })
  console.log('--- LoginEvents (10 dernières) ---')
  for (const e of events) console.log(e.createdAt.toISOString(), e.email, 'success:', e.success, e.reason || '')

  const sessions = await db.session.findMany({
    orderBy: { createdAt: 'desc' },
    take: 8,
    include: { user: true },
  })
  console.log('--- Sessions (8 dernières) ---')
  for (const s of sessions) {
    console.log(
      s.createdAt.toISOString(),
      '→ expire', s.expiresAt.toISOString(),
      s.user.email,
      'EXPIRÉE:', s.expiresAt < new Date(),
    )
  }

  const users = await db.user.findMany({ select: { email: true, createdAt: true } })
  console.log('--- Utilisateurs ---')
  for (const u of users) console.log(u.createdAt.toISOString(), u.email)

  const docs = await db.generatedDocument.findMany({
    orderBy: { createdAt: 'desc' },
    take: 30,
    select: { createdAt: true, format: true, projectId: true, size: true },
  })
  console.log('--- Documents générés (30 derniers) ---')
  for (const d of docs) console.log(d.createdAt.toISOString(), d.format, d.size, d.projectId)

  await db.$disconnect()
}

main()
