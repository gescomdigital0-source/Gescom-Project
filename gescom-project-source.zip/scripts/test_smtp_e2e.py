#!/usr/bin/env python3
# GESCOM PROJECT – Test E2E de l'envoi RÉEL des e-mails via SMTP.
#
# Principe : on configure le SMTP de l'application vers un serveur de capture
# local (127.0.0.1:1025, lancé via scripts/dev_smtp_server.py) puis on déroule
# le parcours complet d'un nouvel utilisateur :
#   1. Connexion administrateur + état SMTP initial
#   2. Enregistrement de la configuration SMTP de test (PUT /api/admin/smtp)
#   3. E-mail de test administrateur (POST /api/admin/smtp)
#   4. Inscription d'un nouveau compte → AUCUN devCode dans la réponse
#   5. Le code à 6 chiffres est retrouvé dans l'e-mail capturé (.eml)
#   6. Activation du compte avec ce code (POST /api/auth/verify) + connexion
#   7. Mot de passe oublié → code de réinitialisation reçu par e-mail
#   8. Changement de mot de passe avec ce code (POST /api/auth/password/reset)
#   9. Effacement de la configuration (retour au mode démonstration)
import glob
import json
import os
import re
import time
import urllib.error
import urllib.request
from email import policy
from email.parser import BytesParser

BASE = 'http://localhost:3000'
CAP = '/tmp/smtp_capture'
STAMP = int(time.time())
EMAIL = f'smtp-e2e-{STAMP}@gescom.pro'
PASSWORD = 'Gescom2026!'
NEW_PASSWORD = 'Nouveau2026!'
results = []


def check(label, ok, detail=''):
    results.append((label, ok))
    print(f"  {'✅' if ok else '❌'} {label}" + (f' — {detail}' if detail else ''))


def call(method, path, payload=None, token=None):
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={
            'Content-Type': 'application/json',
            **({'Authorization': f'Bearer {token}'} if token else {}),
        },
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')


def captured():
    return sorted(glob.glob(os.path.join(CAP, '*.eml')))


def wait_new_message(before, needle, timeout=15):
    """Attend qu'un nouveau .eml contenant `needle` apparaisse dans la capture."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        for path in captured():
            if path in before:
                continue
            try:
                msg = BytesParser(policy=policy.default).parsebytes(open(path, 'rb').read())
            except Exception:
                continue
            to = str(msg.get('To', ''))
            subject = str(msg.get('Subject', ''))
            if needle.lower() in to.lower() or needle.lower() in subject.lower():
                return path, msg
        time.sleep(0.5)
    return None, None


def message_text(msg):
    parts = []
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() in ('text/plain', 'text/html'):
                try:
                    parts.append(part.get_content())
                except Exception:
                    pass
    else:
        try:
            parts.append(msg.get_content())
        except Exception:
            pass
    return '\n'.join(parts)


def extract_code(msg):
    subject = str(msg.get('Subject', ''))
    m = re.search(r'(\d{6})', subject)
    if m:
        return m.group(1)
    m = re.search(r'code à 6 chiffres\s*:\s*(\d{6})', message_text(msg))
    return m.group(1) if m else None


print('== Étape 0 : connexion administrateur ==')
st, d = call('POST', '/api/auth/login', {'email': 'admin@gescom.pro', 'password': 'admin2026'})
TOKEN = d.get('token')
check('Connexion administrateur', st == 200 and bool(TOKEN), f'status {st}')

print('== Étape 1 : état SMTP initial (mode démonstration attendu) ==')
st, d = call('GET', '/api/admin/smtp', token=TOKEN)
check('État SMTP lisible', st == 200, f'status {st}')
initial_configured = bool(d.get('configured'))
print(f"  (configuré au départ : {initial_configured} — source : {d.get('source')})")

print('== Étape 2 : enregistrement du SMTP de test (127.0.0.1:1025) ==')
SMTP = {
    'host': '127.0.0.1',
    'port': 1025,
    'user': 'no-reply@gescom.pro',
    'pass': 'test-local-123',
    'from': 'GESCOM PROJECT <no-reply@gescom.pro>',
}
st, d = call('PUT', '/api/admin/smtp', SMTP, token=TOKEN)
check('Configuration SMTP enregistrée', st == 200 and d.get('configured') is True, f'status {st}')

print('== Étape 3 : e-mail de test administrateur ==')
before = captured()
st, d = call('POST', '/api/admin/smtp', {**SMTP, 'to': 'demo@gescom.pro'}, token=TOKEN)
check('E-mail de test accepté par le serveur', st == 200 and d.get('ok') is True, f'status {st} {d if st != 200 else ""}')
path, msg = wait_new_message(before, 'demo@gescom.pro')
check('E-mail de test capturé dans la boîte locale', msg is not None)
if msg:
    check(
        'Contenu « Configuration e-mail validée » présent',
        'Configuration e-mail validée' in message_text(msg),
        os.path.basename(path),
    )

print('== Étape 4 : inscription d’un nouveau compte (envoi réel) ==')
before = captured()
st, d = call('POST', '/api/auth/register', {
    'email': EMAIL, 'password': PASSWORD,
    'firstName': 'Test', 'lastName': 'E2E',
    'organization': 'Gescom QA',
})
check('Inscription acceptée', st == 200 and d.get('needsVerification') is True, f'status {st}')
check('E-mail réellement envoyé (delivered:true)', d.get('delivered') is True)
check('AUCUN code secret dans la réponse HTTP (sécurité)', not d.get('devCode'))
path, msg = wait_new_message(before, EMAIL)
check('E-mail de vérification capturé', msg is not None)
code = extract_code(msg) if msg else None
check('Code à 6 chiffres trouvé dans l’e-mail', bool(code), f'code {code}')
if msg:
    subj = str(msg.get('Subject', ''))
    check('Objet conforme (code de vérification)', 'code de vérification' in subj.lower(), subj[:60])

print('== Étape 5 : activation du compte avec le code reçu par e-mail ==')
st, d = call('POST', '/api/auth/verify', {'email': EMAIL, 'code': code})
check('Compte activé (code accepté)', st == 200, f'status {st} {d}')
st, d = call('POST', '/api/auth/login', {'email': EMAIL, 'password': PASSWORD})
check('Connexion du compte nouvellement activé', st == 200 and bool(d.get('token')), f'status {st}')

print('== Étape 6 : mot de passe oublié (envoi réel du code de réinitialisation) ==')
before = captured()
st, d = call('POST', '/api/auth/password/forgot', {'email': EMAIL})
check('Demande acceptée', st == 200 and d.get('ok') is True, f'status {st}')
check('AUCUN code secret dans la réponse HTTP (sécurité)', not d.get('devCode'))
path, msg = wait_new_message(before, EMAIL)
check('E-mail de réinitialisation capturé', msg is not None)
reset_code = extract_code(msg) if msg else None
check('Code de réinitialisation trouvé dans l’e-mail', bool(reset_code), f'code {reset_code}')

print('== Étape 7 : changement de mot de passe avec le code reçu ==')
st, d = call('POST', '/api/auth/password/reset', {'email': EMAIL, 'code': reset_code, 'password': NEW_PASSWORD})
check('Mot de passe réinitialisé', st == 200, f'status {st} {d}')
st, d = call('POST', '/api/auth/login', {'email': EMAIL, 'password': NEW_PASSWORD})
check('Connexion avec le nouveau mot de passe', st == 200 and bool(d.get('token')), f'status {st}')

print('== Étape 8 : retour au mode démonstration (effacement de la config) ==')
st, d = call('DELETE', '/api/admin/smtp', token=TOKEN)
check('Configuration SMTP effacée', st == 200 and d.get('configured') is False, f'status {st}')

print()
failed = [label for label, ok in results if not ok]
print(f"BILAN : {len(results) - len(failed)}/{len(results)} vérifications réussies")
if failed:
    print('ÉCHECS :', ' | '.join(failed))
    raise SystemExit(1)
print('BILAN : ENVOI RÉEL DES E-MAILS TOTALEMENT OPÉRATIONNEL ✅')
