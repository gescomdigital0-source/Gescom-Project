#!/usr/bin/env python3
# GESCOM PROJECT – Serveur SMTP local de capture (tests E2E de l'envoi réel).
# Écoute sur 127.0.0.1:1025 et sauvegarde chaque message reçu dans
# /tmp/smtp_capture/*.eml — permet de prouver que l'application envoie
# réellement les e-mails (code de vérification, e-mail de test…)
# sans identifiants SMTP externes.
import os
import time
from aiosmtpd.controller import Controller

CAP = '/tmp/smtp_capture'
os.makedirs(CAP, exist_ok=True)


class Capture:
    n = 0

    async def handle_DATA(self, server, session, envelope):
        Capture.n += 1
        path = os.path.join(CAP, f'msg-{Capture.n:03d}-{int(time.time())}.eml')
        with open(path, 'wb') as f:
            f.write(envelope.original_content)
        print(
            f'[smtp-capture] Message #{Capture.n} : de {envelope.mail_from} '
            f'vers {", ".join(envelope.rcpt_tos)} -> {path}',
            flush=True,
        )
        return '250 Message accepted for delivery'


if __name__ == '__main__':
    controller = Controller(Capture(), hostname='127.0.0.1', port=1025)
    controller.start()
    print('[smtp-capture] Serveur SMTP de capture en écoute sur 127.0.0.1:1025', flush=True)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        controller.stop()
