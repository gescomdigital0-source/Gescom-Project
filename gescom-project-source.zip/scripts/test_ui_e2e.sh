#!/bin/bash
# Test E2E UI complet : login → projet → Documents → génération PDF → bibliothèque
cd /home/z/my-project
set -u

echo "=== 1. Démarrage serveur ==="
rm -f dev.log
npm run dev > /dev/null 2>&1 &
for i in $(seq 1 60); do
  curl -s -o /dev/null --max-time 2 http://localhost:3000/ && break
  sleep 1
done
curl -s -o /dev/null --max-time 3 http://localhost:3000/ && echo "SERVEUR: PRET" || { echo "SERVEUR: ECHEC"; exit 1; }

echo "=== 2. Login démo ==="
agent-browser open http://localhost:3000 > /dev/null 2>&1
agent-browser wait --load networkidle > /dev/null 2>&1
agent-browser find text "Compte démonstration" click > /dev/null 2>&1
sleep 5
agent-browser find text "Ferme avicole moderne" click 2>&1 | tail -1
sleep 3
echo "--- ouverture module Documents ---"
agent-browser find role button click --name "Documents" 2>&1 | tail -1
sleep 3
agent-browser snapshot -i 2>&1 | grep -E "Bibliothèque|PDF|Dossier finalisé|badge" | head -8

echo "=== 3. Génération PDF via l'interface ==="
agent-browser find text "Dossier finalisé prêt à imprimer" click 2>&1 | tail -1
sleep 12

echo "=== 4. Vérification bibliothèque après génération ==="
agent-browser snapshot -i 2>&1 | grep -E "Bibliothèque|dossier-|\.pdf|Télécharger" | head -8
agent-browser screenshot /tmp/e2e_3_documents.png > /dev/null 2>&1
echo "--- erreurs console ---"
agent-browser errors 2>&1 | tail -5
echo "--- notifications ---"
agent-browser snapshot 2>&1 | grep -iE "généré|succès|réussi|erreur|échec" | head -5

echo "=== 5. Arrêt ==="
agent-browser close > /dev/null 2>&1
pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 2
echo "TEST_UI_TERMINÉ"
exit 0
