const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();
async function main() {
  const emails = ['bibo.test@gescom.pro','test.impasse@gescom.pro','test.flux@gescom.pro','test.bug@gescom.pro'];
  for (const email of emails) {
    const u = await db.user.findUnique({ where: { email } });
    if (u) { await db.user.delete({ where: { email } }); console.log('supprimé:', email); }
    else console.log('absent:', email);
  }
  await db.emailVerification.deleteMany({});
  console.log('codes en attente purgés');
  const users = await db.user.findMany({ select: { email: true, emailVerified: true } });
  console.log('comptes restants:', JSON.stringify(users));
}
main().finally(() => db.$disconnect());
