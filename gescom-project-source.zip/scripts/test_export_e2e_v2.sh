#!/bin/bash
# Validation E2E v2 : auto-réparation readonly (recréation client Prisma) + exports 4 formats
cd /home/z/my-project
set -u

echo "=== 1. Démarrage du serveur ==="
rm -f dev.log
npm run dev > /dev/null 2>&1 &
NPM_PID=$!

READY=0
for i in $(seq 1 60); do
  if curl -s -o /dev/null --max-time 2 http://localhost:3000/; then READY=1; break; fi
  sleep 1
done
[ "$READY" = "1" ] && echo "SERVEUR: PRET" || { echo "SERVEUR: ECHEC"; exit 1; }

echo "=== 2. Baseline : écritures avant panne ==="
EMAIL="e2e$(date +%s)@gescom.test"
R1=$(curl -s -X POST http://localhost:3000/api/auth/register -H "Content-Type: application/json" \
  -d "{\"firstName\":\"E2E\",\"lastName\":\"Test\",\"email\":\"$EMAIL\",\"password\":\"Test1234!\"}")
T1=$(echo "$R1" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
[ -n "$T1" ] && echo "REGISTER: OK" || { echo "REGISTER: ECHEC"; echo "$R1" | head -c 300; }

LOGIN=$(curl -s -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"demo@gescom.pro","password":"demo2026"}')
TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
DEMO_PID=$(python3 -c "
import sqlite3
con = sqlite3.connect('db/custom.db')
row = con.execute(\"SELECT id FROM Project WHERE name LIKE 'Ferme avicole moderne%'\").fetchone()
print(row[0] if row else '')
con.close()")
echo "LOGIN_DEMO: OK, PROJET=$DEMO_PID"

echo "=== 3. Simulation panne sandbox (nouvel inode) ==="
I1=$(stat -c %i db/custom.db)
cp db/custom.db /tmp/db_sync_backup.db
rm db/custom.db && cp /tmp/db_sync_backup.db db/custom.db
I2=$(stat -c %i db/custom.db)
echo "inode $I1 -> $I2"

echo "=== 4. Auto-réparation : écriture après panne ==="
C1=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" -d '{"email":"demo@gescom.pro","password":"demo2026"}')
echo "LOGIN_APRES_PANNE: HTTP $C1 $([ "$C1" = "200" ] && echo '✓ AUTO-RÉPARÉ' || echo '✗ ÉCHEC')"

R2=$(curl -s -X POST http://localhost:3000/api/auth/register -H "Content-Type: application/json" \
  -d "{\"firstName\":\"Post\",\"lastName\":\"Panne\",\"email\":\"post$(date +%s)@gescom.test\",\"password\":\"Test1234!\"}")
T2=$(echo "$R2" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
[ -n "$T2" ] && echo "REGISTER_APRES_PANNE: ✓ OK" || { echo "REGISTER_APRES_PANNE: ✗ ECHEC"; echo "$R2" | head -c 200; }

P2=$(curl -s -X POST http://localhost:3000/api/projects -H "Authorization: Bearer $T2" \
  -H "Content-Type: application/json" \
  -d '{"name":"Projet post-panne","idea":"Test","sector":"Agriculture","country":"Cameroun","currency":"FCFA","type":"CREATION"}')
PID2=$(echo "$P2" | python3 -c "import sys,json; print(json.load(sys.stdin).get('project',{}).get('id',''))" 2>/dev/null)
[ -n "$PID2" ] && echo "CREATE_PROJECT_APRES_PANNE: ✓ OK ($PID2)" || { echo "CREATE_PROJECT: ✗ ECHEC"; echo "$P2" | head -c 200; }

echo "=== 5. Exports 4 formats (projet démo + projet neuf) ==="
mkdir -p /tmp/exports && rm -f /tmp/exports/*
for TARGET in "$DEMO_PID:demo:$TOKEN" "$PID2:neuf:$T2"; do
  PID=$(echo "$TARGET" | cut -d: -f1); TAG=$(echo "$TARGET" | cut -d: -f2); TK=$(echo "$TARGET" | cut -d: -f3)
  [ -z "$PID" ] || [ -z "$TK" ] && continue
  for FMT in PDF DOCX XLSX PPTX; do
    F="/tmp/exports/${TAG}_${FMT}"
    HTTP=$(curl -s -o "$F" -w "%{http_code}" -X POST "http://localhost:3000/api/projects/$PID/export" \
      -H "Authorization: Bearer $TK" -H "Content-Type: application/json" -d "{\"format\":\"$FMT\"}")
    SIZE=$(stat -c %s "$F" 2>/dev/null || echo 0)
    MAGIC=$(python3 -c "print(open('$F','rb').read(4))" 2>/dev/null)
    echo "  [$TAG] $FMT: HTTP=$HTTP taille=${SIZE}o magic=$MAGIC"
  done
done

echo "=== 6. Bibliothèque de documents (stockage) ==="
python3 -c "
import sqlite3
con = sqlite3.connect('db/custom.db')
n_demo = con.execute(\"SELECT COUNT(*) FROM GeneratedDocument WHERE projectId=?\", ('$DEMO_PID',)).fetchone()[0]
n_new = con.execute(\"SELECT COUNT(*) FROM GeneratedDocument WHERE projectId=?\", ('$PID2',)).fetchone()[0]
print(f'docs démo={n_demo} docs projet neuf={n_new}')
con.close()"

echo "=== 7. Journal auto-réparation ==="
grep "recréation du client" dev.log | head -3
grep -c "recréation du client" dev.log | xargs echo "nb auto-réparations:"

echo "=== 8. Nettoyage + arrêt ==="
curl -s -o /dev/null -X DELETE "http://localhost:3000/api/projects/$PID2" -H "Authorization: Bearer $T2" 2>/dev/null
pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 2
echo "VALIDATION_V2_TERMINÉE"
exit 0
