#!/bin/bash
# Validation E2E : auto-réparation SQLite readonly + exports des 4 formats
cd /home/z/my-project
set -u

echo "=== 1. Démarrage du serveur ==="
rm -f dev.log
npm run dev > /dev/null 2>&1 &
NPM_PID=$!

READY=0
for i in $(seq 1 60); do
  if curl -s -o /dev/null --max-time 2 http://localhost:3000/; then READY=1; break; fi
  sleep 1
done
[ "$READY" = "1" ] && echo "SERVEUR: PRET" || { echo "SERVEUR: ECHEC DEMARRAGE"; exit 1; }

echo "=== 2. Connexion démo ==="
LOGIN=$(curl -s -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"demo@gescom.pro","password":"demo2026"}')
TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
if [ -z "$TOKEN" ]; then echo "LOGIN: ECHEC"; echo "$LOGIN" | head -c 300; exit 1; fi
echo "LOGIN: OK (token ${#TOKEN} car.)"
DEMO_PID=$(echo "$LOGIN" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(d.get('projects', [{}])[0].get('id', ''))
" 2>/dev/null)
# Fallback : lire l'id du projet démo dans la BDD
if [ -z "$DEMO_PID" ]; then
  DEMO_PID=$(python3 -c "
import sqlite3
con = sqlite3.connect('db/custom.db')
row = con.execute(\"SELECT id FROM Project WHERE name LIKE 'Ferme avicole moderne%'\").fetchone()
print(row[0] if row else '')
con.close()")
fi
echo "PROJET_DEMO=$DEMO_PID"

echo "=== 3. Simulation de la panne (remplacement du fichier BDD, nouvel inode) ==="
INODE_AVANT=$(stat -c %i db/custom.db)
cp db/custom.db /tmp/db_sync_backup.db
rm db/custom.db
cp /tmp/db_sync_backup.db db/custom.db
INODE_APRES=$(stat -c %i db/custom.db)
echo "inode avant=$INODE_AVANT après=$INODE_APRES $([ "$INODE_AVANT" != "$INODE_APRES" ] && echo '(CHANGÉ comme le sandbox)')"

echo "=== 4. Écriture APRÈS la panne (auto-réparation attendue) ==="
LOGIN2=$(curl -s -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"demo@gescom.pro","password":"demo2026"}')
CODE2=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"demo@gescom.pro","password":"demo2026"}')
echo "LOGIN_APRES_PANNE: HTTP $CODE2 $([ "$CODE2" = "200" ] && echo '✓ AUTO-RÉPARATION FONCTIONNE' || echo '✗ TOUJOURS EN ÉCHEC')"

echo "=== 5. Exports des 4 formats sur le projet démo ==="
mkdir -p /tmp/exports
OK=0
for FMT in PDF DOCX XLSX PPTX; do
  HTTP=$(curl -s -o /tmp/exports/test.$(echo $FMT | tr 'A-Z' 'a-z') -w "%{http_code}" \
    -X POST "http://localhost:3000/api/projects/$DEMO_PID/export" \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d "{\"format\":\"$FMT\"}")
  SIZE=$(stat -c %s /tmp/exports/test.$(echo $FMT | tr 'A-Z' 'a-z') 2>/dev/null || echo 0)
  MAGIC=$(head -c 4 /tmp/exports/test.$(echo $FMT | tr 'A-Z' 'a-z') 2>/dev/null | xxd -p)
  echo "EXPORT $FMT: HTTP=$HTTP taille=${SIZE}o magic=$MAGIC"
  [ "$HTTP" = "200" ] && OK=$((OK+1))
done
echo "EXPORTS_REUSSIS: $OK/4"

echo "=== 6. Journal de l'auto-réparation ==="
grep -c "reconnexion" dev.log 2>/dev/null | xargs echo "reconnexions auto:"
grep "readonly" dev.log 2>/dev/null | head -2

echo "=== 7. Arrêt du serveur ==="
pkill -f "next dev" 2>/dev/null
pkill -f "next-server" 2>/dev/null
sleep 2
echo "VALIDATION_TERMINÉE exports=$OK/4 selfheal=$CODE2"
exit 0
