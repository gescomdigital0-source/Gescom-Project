#!/usr/bin/env python3
# Prépare les images du logo GESCOM DIGITAL SERVICES pour le site :
#  - public/logo.png    : 512×512, fond blanc d'origine conservé (UI + apple-touch-icon)
#  - public/favicon.png : 256×256 avec coins arrondis (favicon onglet navigateur)
from PIL import Image, ImageDraw

SRC = '/home/z/my-project/upload/pasted_image_1793569999673.png'
LOGO = '/home/z/my-project/public/logo.png'
FAVICON = '/home/z/my-project/public/favicon.png'

# --- logo.png : 512×512, simple redimensionnement haute qualité ---
img = Image.open(SRC).convert('RGB')
img512 = img.resize((512, 512), Image.LANCZOS)
img512.save(LOGO, 'PNG', optimize=True)
print('logo.png', img512.size)

# --- favicon.png : 256×256, coins arrondis + transparence ---
size = 256
img256 = img.resize((size, size), Image.LANCZOS).convert('RGBA')
radius = int(size * 0.18)
mask = Image.new('L', (size, size), 0)
d = ImageDraw.Draw(mask)
d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
img256.putalpha(mask)
img256.save(FAVICON, 'PNG', optimize=True)
print('favicon.png', img256.size)
