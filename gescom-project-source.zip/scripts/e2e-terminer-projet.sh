#!/bin/bash
# E2E – Terminer un projet (statut COMPLETED) via l'interface GESCOM PROJECT
cd /home/z/my-project

echo "=== 1. Serveur ==="
pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 1
setsid nohup npm run dev > dev.log 2>&1 < /dev/null &
CODE=000
for i in $(seq 1 45); do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null || echo 000)
  [ "$CODE" = "200" ] && break
  sleep 1
done
echo "Serveur: HTTP $CODE"
if [ "$CODE" != "200" ]; then echo "ECHEC DEMARRAGE"; tail -5 dev.log; exit 1; fi

echo "=== 2. Session démo (API) ==="
LOGIN=$(curl -s -X POST http://localhost:3000/api/auth/login -H 'Content-Type: application/json' -d '{"email":"demo@gescom.pro","password":"demo2026"}')
TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
if [ -z "$TOKEN" ]; then echo "ECHEC LOGIN: $LOGIN"; exit 1; fi
echo "Token OK (${#TOKEN} caractères)"

read -r PID PNAME PSTATUS <<< $(curl -s http://localhost:3000/api/projects -H "Authorization: Bearer $TOKEN" | python3 -c "
import sys, json
d = json.load(sys.stdin)
p = [x for x in d['projects'] if x['id'] == 'cmvwtexn20002p7hazh482ekj'][0]
print(p['id'], p['name'], p['status'])
")
echo "Projet démo: $PNAME | statut initial = $PSTATUS"

echo "=== 3. Navigateur : connexion avec le token ==="
agent-browser close >/dev/null 2>&1 || true
agent-browser open http://localhost:3000 >/dev/null 2>&1
agent-browser storage local set gescom_session_token "$TOKEN" >/dev/null
agent-browser reload >/dev/null 2>&1
sleep 3
agent-browser wait --load networkidle >/dev/null 2>&1 || true
echo "Erreurs page (chargement): $(agent-browser errors 2>/dev/null | head -3 | tr '\n' ' ')"

echo "=== 4. Mes projets → filtrer sur le projet démo ==="
agent-browser find text "Mes projets" click >/dev/null 2>&1
sleep 2
agent-browser find first "input[placeholder^='Rechercher']" fill "$PNAME" >/dev/null 2>&1
sleep 1.5
agent-browser snapshot -i -c > /tmp/snap_p.txt 2>&1
echo "--- Carte projet visible ---"
grep -i -m3 "Terminé\|En cours\|Actions du projet" /tmp/snap_p.txt | head -5

echo "=== 5. Ouvrir le projet → bandeau ==="
agent-browser find first ".group button" click >/dev/null 2>&1
sleep 2.5
BADGE1=$(agent-browser eval "document.querySelector('button[aria-label=\"Changer le statut du projet\"]')?.textContent?.trim()" 2>/dev/null)
echo "Badge statut dans le bandeau avant: $BADGE1"

echo "=== 6. Menu statut → Terminé ==="
agent-browser find role button click --name "Changer le statut du projet" >/dev/null 2>&1
sleep 1
agent-browser screenshot /tmp/menu_statut.png >/dev/null 2>&1 && echo "Capture: /tmp/menu_statut.png"
agent-browser eval '[...document.querySelectorAll("[role=menuitem]")].map(m=>m.textContent.trim()).join(" | ")' 2>/dev/null
agent-browser eval '[...document.querySelectorAll("[role=menuitem]")].find(m=>m.textContent.trim()==="Terminé")?.click()' >/dev/null 2>&1
sleep 2
BADGE2=$(agent-browser eval "document.querySelector('button[aria-label=\"Changer le statut du projet\"]')?.textContent?.trim()" 2>/dev/null)
echo "Badge statut après: $BADGE2"
echo "Requêtes PATCH côté serveur:"
grep "PATCH /api/projects" dev.log | tail -3
STATUT_API=$(curl -s "http://localhost:3000/api/projects/$PID" -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json;print(json.load(sys.stdin)['project']['status'])" 2>/dev/null)
echo "Statut API après clic: $STATUT_API (attendu COMPLETED)"

echo "=== 7. Liste des projets → menu « Remettre en cours » ==="
agent-browser find text "Mes projets" click >/dev/null 2>&1
sleep 2
agent-browser find first "input[placeholder^='Rechercher']" fill "$PNAME" >/dev/null 2>&1
sleep 1.5
agent-browser find first 'button[aria-label="Actions du projet"]' click >/dev/null 2>&1
sleep 1
agent-browser screenshot /tmp/menu_liste.png >/dev/null 2>&1 && echo "Capture: /tmp/menu_liste.png"
echo "Items du menu projet:"
agent-browser eval '[...document.querySelectorAll("[role=menuitem]")].map(m=>m.textContent.trim()).join(" | ")' 2>/dev/null
agent-browser eval '[...document.querySelectorAll("[role=menuitem]")].find(m=>m.textContent.includes("Remettre"))?.click()' >/dev/null 2>&1
sleep 2
STATUT_FIN=$(curl -s "http://localhost:3000/api/projects/$PID" -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json;print(json.load(sys.stdin)['project']['status'])" 2>/dev/null)
echo "Statut API final: $STATUT_FIN (attendu $PSTATUS)"

echo "=== 8. Console ==="
agent-browser errors 2>/dev/null | head -5
agent-browser close >/dev/null 2>&1
echo "=== FIN E2E ==="
