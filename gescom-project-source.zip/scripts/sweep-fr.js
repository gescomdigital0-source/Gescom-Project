// Balaye le DOM et liste les nœuds de texte qui semblent encore en français
(() => {
  const STOP = /^(le|la|les|un|une|des|du|de|et|ou|en|vous|votre|vos|projet|est|sont|pour|par|avec|aux|au|cette|ce|que|qui|pas|plus|tout|tous|ajouter|choisir|rechercher|montant|prix|total|date|phase|année|mois|an|fcfa)$/i
  const hasAccent = (s) => /[àâäéèêëîïôöùûüçœÀ-ÿ’]/.test(s)
  const out = new Set()
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
  let n
  while ((n = walker.nextNode())) {
    const p = n.parentElement
    if (!p || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(p.tagName)) continue
    const t = (n.nodeValue || '').replace(/\s+/g, ' ').trim()
    if (!t || t.length < 3) continue
    if (/^[\d\s.,%€$+()-]+$/.test(t)) continue
    if (/^(FCFA|XAF|XOF|EUR|USD|CAD|CHF|MAD|AN|EN|FR|G)$/.test(t)) continue
    if (hasAccent(t) || STOP.test(t.split(' ')[0])) out.add(t)
  }
  // attributs traduisibles
  for (const el of document.querySelectorAll('*')) {
    for (const a of ['placeholder', 'aria-label', 'title']) {
      const v = el.getAttribute && el.getAttribute(a)
      if (v && (hasAccent(v) || STOP.test(v.replace(/\s+/g, ' ').trim().split(' ')[0]))) {
        out.add('[' + a + '] ' + v.replace(/\s+/g, ' ').trim())
      }
    }
  }
  return [...out].slice(0, 60).join('\n') || '— rien de français visible —'
})()
