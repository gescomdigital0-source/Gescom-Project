// Extracteur de chaînes UI françaises → candidats au dictionnaire FR→EN
// Sortie : /tmp/ui-strings.json (dédupliqué, normalisé comme le DOM rendu)
import fs from 'fs'
import path from 'path'

const ROOT = '/home/z/my-project/src'

function walk(dir, exts, acc = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name)
    if (e.isDirectory()) walk(p, exts, acc)
    else if (exts.some((x) => e.name.endsWith(x))) acc.push(p)
  }
  return acc
}

function decode(s) {
  return s
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/\\u2019/g, '\u2019')
    .replace(/\\u00E9/g, 'é')
    .replace(/\\u00e8/g, 'è')
    .replace(/\\u00E0/g, 'à')
    .replace(/\\n/g, ' ')
}

// Normalisation identique à celle du traducteur runtime (espaces compressés)
const norm = (s) => s.replace(/\s+/g, ' ').trim()

const results = new Map() // string -> Set(fichiers)

function add(raw, file) {
  const s = norm(decode(raw))
  if (!s) return
  if (!results.has(s)) results.set(s, new Set())
  results.get(s).add(path.basename(file))
}

const FRENCH_WORD =
  /\b(le|la|les|un|une|des|du|de|et|ou|en|vous|votre|vos|projet|projets|est|sont|sur|pour|par|avec|dans|aux|au|aux|cette|ce|que|qui|ne|pas|plus|tout|tous|montant|montants|période|vente|ventes|analyse|analyses|plan|document|documents|données|chiffre|affaires|total|cliquez|choisir|choisissez|ajouter|supprimer|enregistrer|modifier|rechercher|aucun|aucune|créer|générer|export|abonnement|paiement|précédent|continuer|terminer|nom|date|mois|an|année|jour|semaine|fcfa|taux|coût|coûts|prix|bénéfice|perte|revenu|revenus|détails|résumé|objectif|objectifs|risque|risques|marché|client|clients|produit|produits|journalier|mensuel|annuel|trésorerie|amortissement|investissement|financement|emprunt|apport|subvention|fonds|roulement|exploitation|salaires|charges|impôts|tva|résultat|rentabilité|valeur|actualisée|interne|rentabilité|seuil|rentable|scénario|scénarios|optimiste|pessimiste|réaliste|graphique|graphiques|tableau|tableaux|bord|avancement|tâche|tâches|phase|phases|responsable|échéance|retard|calendrier|page|garde|couverture|logo|en-tête|pied|police|taille|couleur|thème|mode|aperçu|imprim|télécharg|télévers|fichier|format|pdf|excel|word|powerpoint|word|diapositive|diapositives|slide|slides|présentation|audience|investisseur|investisseurs|banque|banques|partenaire|partenaires|académique|soutenance)\b/i

const hasAccent = (s) => /[àâäéèêëíìîïóòôöùûüçœÀÂÄÉÈÊËÎÏÔÖÙÛÜÇŒ’]/.test(s)

function looksFrench(s) {
  if (!/[a-zA-ZÀ-ÿ]/.test(s)) return false
  if (hasAccent(s)) return true
  return FRENCH_WORD.test(s)
}

const EXCLUDE = [
  /^use client$/, /^use server$/, /^\/api\//, /^https?:\/\//, /^[A-Z0-9_]+$/,
  /^#[0-9a-fA-F]{3,8}/, /^\d+$/, /^[-.#]+$/, /^[\w-]+$/, /^\d+(\.\d+)*$/,
  /^[a-z]+-[a-z-]+$/, /^(px|py|pt|pb|pl|pr|mt|mb|ml|mr|w|h)-/, /className/, /fa-[a-z]+/,
]

for (const file of walk(ROOT, ['.tsx', '.ts'])) {
  if (file.includes('/ui/') || file.includes('/exports/')) continue // composants shadcn + exports (documents) hors périmètre
  const src = fs.readFileSync(file, 'utf8')

  // 1) Texte JSX entre balises (mono-ligne)
  for (const m of src.matchAll(/>\s*([^<>{}]{2,300}?)\s*</g)) add(m[1], file)

  // 2) Attributs littéraux usuels
  for (const m of src.matchAll(/\b(placeholder|title|aria-label|label|description|name)="([^"]{2,300})"/g)) add(m[2], file)

  // 3) Littéraux de chaînes '…' et "…" et `…` (sans expressions)
  for (const m of src.matchAll(/'([^'\\\n]{2,300})'/g)) add(m[1], file)
  for (const m of src.matchAll(/"([^"\\\n]{2,300})"/g)) add(m[1], file)
  for (const m of src.matchAll(/`([^`\\]{2,300})`/g)) add(m[1], file)
}

const out = []
for (const [s, files] of results) {
  if (EXCLUDE.some((re) => re.test(s))) continue
  if (!looksFrench(s)) continue
  if (s.length < 2) continue
  out.push({ s, files: [...files] })
}
out.sort((a, b) => a.s.localeCompare(b.s, 'fr'))
fs.writeFileSync('/tmp/ui-strings.json', JSON.stringify(out, null, 1), 'utf8')
console.log('Total candidats :', out.length)
