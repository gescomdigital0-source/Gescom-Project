// Mock FedaPay pour tests d'intégration – imite l'API v1 utilisée par GESCOM :
//   POST /v1/transactions            création de transaction
//   POST /v1/transactions/:id/token  génération du lien de paiement
//   GET  /v1/transactions/:id        statut de la transaction
//   POST /_test/approve/:id          (test) valide le paiement client
//   POST /_test/decline/:id          (test) refuse le paiement
//   GET  /_test/reset                (test) vide le magasin
const http = require('http')

const store = new Map() // id -> { id, status, amount, reference, custom_metadata }
let nextId = 7450

function readBody(req) {
  return new Promise((resolve) => {
    let data = ''
    req.on('data', (c) => (data += c))
    req.on('end', () => resolve(data))
  })
}

function json(res, code, body) {
  res.writeHead(code, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify(body))
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost')
  const path = url.pathname
  const method = req.method

  // Création de transaction (enveloppe « v1/transaction », comme l'API réelle)
  if (method === 'POST' && path === '/v1/transactions') {
    const body = JSON.parse((await readBody(req)) || '{}')
    const id = nextId++
    const tx = {
      id,
      reference: String(1530800000000 + id),
      status: 'pending',
      amount: body.amount,
      description: body.description,
      callback_url: body.callback_url,
      custom_metadata: body.custom_metadata || {},
    }
    store.set(String(id), tx)
    return json(res, 201, { 'v1/transaction': tx })
  }

  // Lien de paiement
  const tokenMatch = path.match(/^\/v1\/transactions\/(\d+)\/token$/)
  if (method === 'POST' && tokenMatch) {
    const tx = store.get(tokenMatch[1])
    if (!tx) return json(res, 404, { message: 'Transaction introuvable.' })
    return json(res, 200, { 'v1/token': { token: `tok_${tx.id}`, url: `http://localhost:9091/pay/${tx.id}` } })
  }

  // Statut de transaction
  const txMatch = path.match(/^\/v1\/transactions\/(\d+)$/)
  if (method === 'GET' && txMatch) {
    const tx = store.get(txMatch[1])
    if (!tx) return json(res, 404, { message: 'Transaction introuvable.' })
    return json(res, 200, { 'v1/transaction': tx })
  }

  // Helpers de test : simuler l'action du client sur la page FedaPay
  const approveMatch = path.match(/^\/_test\/(approve|decline)\/(\d+)$/)
  if (method === 'POST' && approveMatch) {
    const tx = store.get(approveMatch[2])
    if (!tx) return json(res, 404, { message: 'Transaction introuvable.' })
    tx.status = approveMatch[1] === 'approve' ? 'approved' : 'declined'
    return json(res, 200, { ok: true, status: tx.status })
  }

  if (method === 'GET' && path === '/_test/reset') {
    store.clear()
    return json(res, 200, { ok: true })
  }

  json(res, 404, { message: `Route mock inconnue : ${method} ${path}` })
})

server.listen(9091, () => console.log('Mock FedaPay prêt sur http://localhost:9091'))
