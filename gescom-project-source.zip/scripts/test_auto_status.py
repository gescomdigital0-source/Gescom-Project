#!/usr/bin/env python3
# GESCOM PROJECT – Test E2E du cycle complet de la règle de statut automatique
#  1. Projet temporaire conforme (données copiées de la Ferme avicole) + 5 tâches
#  2. Validation → doit être VALIDE et auto-confirmé « Terminé »
#  3. Introduction d'une anomalie (suppression d'une tâche → plan d'action < 5)
#  4. Revalidation → doit être A_CORRIGER et rétrogradé « En cours »
#  5. Nettoyage (suppression du projet temporaire)
import json
import urllib.request

BASE = 'http://localhost:3000'
TOKEN = open('/tmp/gtk.txt').read().strip()
FERME = 'cmvwtexn20002p7hazh482ekj'


def call(method, path, payload=None, raw=False):
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Authorization': f'Bearer {TOKEN}', 'Content-Type': 'application/json'},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            body = r.read()
            return r.status, (body if raw else json.loads(body) if body else {})
    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, (body if raw else json.loads(body) if body else {})


print('== Étape 0 : récupération des données de la Ferme avicole (projet conforme) ==')
st, data = call('GET', f'/api/projects/{FERME}/data')
assert st == 200, f'lecture données Ferme: {st}'
sections = {k: json.loads(data[k]) for k in ('overview', 'objectives', 'analysis', 'finance')}
print('  OK – overview/analysis/finance récupérés')

print("== Étape 1 : création du projet temporaire 'TEST AUTO – cycle validation' ==")
st, proj = call('POST', '/api/projects', {
    'name': 'TEST AUTO – cycle validation',
    'idea': 'Projet temporaire de test du cycle validation/statut (supprimé automatiquement).',
    'description': 'Test automatique.',
    'sector': 'Elevage',
    'country': 'Cameroun',
    'currency': 'XAF',
})
assert st in (200, 201), f'création projet: {st} {proj}'
pid = proj.get('project', proj).get('id') if isinstance(proj, dict) else None
pid = proj['project']['id'] if 'project' in proj else proj['id']
print(f'  OK – id {pid}, statut initial :', (proj.get('project') or proj).get('status'))

print('== Étape 2 : copie des sections conformes ==')
st, r = call('PATCH', f'/api/projects/{pid}/data', {
    'overview': sections['overview'],
    'objectives': sections['objectives'],
    'analysis': sections['analysis'],
    'finance': sections['finance'],
})
assert st == 200, f'copie sections: {st} {r}'
print('  OK – autoCompleted (après copie) :', r.get('autoCompleted'), '| autoDemoted :', r.get('autoDemoted'))

print('== Étape 3 : passage « En cours » + ajout de 5 tâches ==')
st, _ = call('PATCH', f'/api/projects/{pid}', {'status': 'ONGOING'})
assert st == 200, f'statut ONGOING: {st}'
task_ids = []
for i in range(1, 6):
    st, t = call('POST', f'/api/projects/{pid}/tasks', {'title': f'Activité {i} – installation et suivi', 'phase': 'Mise en place'})
    assert st in (200, 201), f'création tâche {i}: {st}'
    task_ids.append((t.get('task') or t)['id'])
print('  OK – 5 tâches créées')

print('== Étape 4 : validation → attendu VALIDE + auto « Terminé » ==')
st, v = call('GET', f'/api/projects/{pid}/validation')
print(f"  statut: {v['report']['status']} | anomalies: {v['report']['counts']['anomalies']} "
      f"| autoCompleted: {v.get('autoCompleted')} | projectStatus: {v.get('projectStatus')}")
ok1 = v['report']['status'] == 'VALIDE' and v.get('autoCompleted') is True and v.get('projectStatus') == 'COMPLETED'
print('  →', '✅ RÈGLE RESPECTÉE : projet validé ⇒ Terminé automatiquement' if ok1 else '❌ ÉCHEC')

print("== Étape 5 : introduction d'une anomalie (suppression d'une tâche → plan d'action < 5) ==")
st, _ = call('DELETE', f'/api/tasks/{task_ids[0]}')
assert st == 200, f'suppression tâche: {st}'
st, v = call('GET', f'/api/projects/{pid}/validation')
print(f"  statut: {v['report']['status']} | anomalies: {v['report']['counts']['anomalies']} "
      f"| autoDemoted: {v.get('autoDemoted')} | projectStatus: {v.get('projectStatus')}")
ok2 = v['report']['status'] != 'VALIDE' and v.get('autoDemoted') is True and v.get('projectStatus') == 'ONGOING'
print('  →', '✅ RÈGLE RESPECTÉE : anomalie ⇒ ni validé ni Terminé (retour En cours)' if ok2 else '❌ ÉCHEC')

print("== Étape 6 : tentative manuelle « Terminé » sur projet à anomalie (attendu 403) ==")
st, r = call('PATCH', f'/api/projects/{pid}', {'status': 'COMPLETED'})
print(f"  HTTP {st} | validation: {r.get('validation', {}).get('status')}")
ok3 = st == 403
print('  →', '✅ RÈGLE RESPECTÉE : confirmation manuelle refusée' if ok3 else '❌ ÉCHEC')

print('== Étape 7 : nettoyage (suppression du projet temporaire) ==')
st, _ = call('DELETE', f'/api/projects/{pid}')
print(f'  suppression : HTTP {st}')

print()
print('BILAN :', 'TOUT EST CONFORME ✅' if (ok1 and ok2 and ok3) else 'DES TESTS ONT ÉCHOUÉ ❌')
