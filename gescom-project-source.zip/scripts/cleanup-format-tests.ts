import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  // Supprime les documents générés après 22:25 UTC (mes tests de formatage)
  const cutoff = new Date('2026-10-31T22:25:00Z')
  const docs = await db.generatedDocument.findMany({ where: { createdAt: { gte: cutoff } } })
  for (const d of docs) {
    await db.generatedDocument.delete({ where: { id: d.id } })
    console.log('supprimé:', d.format, d.name, d.createdAt.toISOString())
  }
  await db.$disconnect()
}

main()
