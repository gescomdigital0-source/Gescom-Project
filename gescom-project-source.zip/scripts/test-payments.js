// GESCOM PROJECT – Test E2E du flux d'encaissement Mobile Money (FedaPay mock)
// Pré-requis : mock sur :9091, Next sur :3000 avec FEDAPAY_SECRET_KEY +
// FEDAPAY_BASE_URL=http://localhost:9091/v1, compte demo@gescom.pro.
const BASE = 'http://localhost:3000'
const MOCK = 'http://localhost:9091'

let token = ''
let failures = 0

async function api(path, method = 'GET', body) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: body ? JSON.stringify(body) : undefined,
  })
  return { status: res.status, data: await res.json().catch(() => ({})) }
}

function check(label, cond, extra = '') {
  console.log(`${cond ? '✓' : '✗'} ${label}${extra ? ' — ' + extra : ''}`)
  if (!cond) failures++
}

async function login() {
  const res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'demo@gescom.pro', password: 'demo2026' }),
  })
  token = (await res.json()).token
}

async function newCheckout(billing) {
  const r = await api('/api/account/plan/checkout', 'POST', { billing })
  return r.data
}

async function webhook(txId) {
  const res = await fetch(`${BASE}/api/payments/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'transaction.approved', data: { id: txId } }),
  })
  return res.json()
}

async function txIdFromRef() {
  // Le mock lie référence interne → id de transaction via custom_metadata ;
  // on récupère l'id depuis l'historique (providerRef) après création.
  const hist = await api('/api/account/plan/payments')
  const p = hist.data.payments[0]
  return { paymentId: p.id, providerRef: p.status === 'PENDING' ? await providerRefOf(p.reference) : p.reference }
}

// Petit utilitaire : lit le providerRef via la route de vérification (POST)
async function providerRefOf(reference) {
  const r = await api('/api/account/plan/payments', 'POST', { reference })
  return r.data.payment?.providerRef ?? null
}

const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function setDb(fn) {
  await fn(prisma)
}

;(async () => {
  await login()

  // ---- 1. Paiement refusé : webhook declined → FAILED ----
  {
    const co = await newCheckout('MONTHLY')
    const tx = co.paymentUrl.split('/').pop()
    await fetch(`${MOCK}/_test/decline/${tx}`, { method: 'POST' })
    const out = await webhook(tx)
    check('Paiement refusé marqué FAILED', out.outcome === 'failed', JSON.stringify(out))
  }

  // ---- 2. Montant incohérent → mismatch, pas d'activation ----
  {
    const co = await newCheckout('MONTHLY')
    const tx = co.paymentUrl.split('/').pop()
    // Décale le montant attendu côté GESCOM (simulation d'une erreur de config)
    await setDb((p) => p.payment.update({ where: { reference: co.reference }, data: { amount: 1 } }))
    await fetch(`${MOCK}/_test/approve/${tx}`, { method: 'POST' })
    const out = await webhook(tx)
    check('Montant incohérent rejeté (mismatch)', out.outcome === 'mismatch', JSON.stringify(out))
    const me = await api('/api/auth/me')
    check('Pas d\'activation sur mismatch', me.data.user.plan !== 'PREMIUM' || me.data.user.planExpiresAt)
  }

  // ---- 3. Activation au retour navigateur SANS webhook ----
  {
    const co = await newCheckout('MONTHLY')
    const tx = co.paymentUrl.split('/').pop()
    await fetch(`${MOCK}/_test/approve/${tx}`, { method: 'POST' })
    const r = await api('/api/account/plan/payments', 'POST', { reference: co.reference })
    check('Retour navigateur → activation directe', r.data.outcome === 'activated', JSON.stringify(r.data.outcome))
    check('Session upgrade après retour', r.data.user.plan === 'PREMIUM' && !!r.data.user.planExpiresAt)
    const me = await api('/api/auth/me')
    check('Plan effectif = PREMIUM', me.data.user.plan === 'PREMIUM', `expires ${me.data.user.planExpiresAt}`)
  }

  // ---- 4. Expiration passée → plan effectif FREE ----
  {
    await setDb((p) => p.user.update({ where: { email: 'demo@gescom.pro' }, data: { planExpiresAt: new Date(Date.now() - 86_400_000) } }))
    const me = await api('/api/auth/me')
    check('Premium expiré → plan effectif FREE', me.data.user.plan === 'FREE' && me.data.user.planExpiresAt === null, `plan=${me.data.user.plan}`)
    // Remet un Premium actif pour le prochain test
    await setDb((p) => p.user.update({ where: { email: 'demo@gescom.pro' }, data: { planExpiresAt: new Date(Date.now() + 30 * 86_400_000) } }))
    const me2 = await api('/api/auth/me')
    check('Premium actif → plan effectif PREMIUM', me2.data.user.plan === 'PREMIUM', `expires ${me2.data.user.planExpiresAt}`)
  }

  // ---- 5. Vérification de durée : checkout annuel → expires +12 mois ----
  {
    const co = await newCheckout('YEARLY')
    const tx = co.paymentUrl.split('/').pop()
    await fetch(`${MOCK}/_test/approve/${tx}`, { method: 'POST' })
    const out = await webhook(tx)
    check('Checkout annuel activé', out.outcome === 'activated', JSON.stringify(out))
    const me = await api('/api/auth/me')
    const year = me.data.user.planExpiresAt?.slice(0, 4)
    check('Abonnement annuel prolongé en 2027', me.data.user.plan === 'PREMIUM' && year === '2027', `expires ${me.data.user.planExpiresAt}`)
  }

  // ---- 6. Gating toujours actif avec plan effectif ----
  {
    const me = await api('/api/auth/me')
    const plan = me.data.user.plan
    check('Plan effectif cohérent avant test gating', plan === 'PREMIUM')
  }

  console.log(failures === 0 ? '\nTous les tests sont passés.' : `\n${failures} test(s) en échec.`)
  await prisma.$disconnect()
  process.exit(failures === 0 ? 0 : 1)
})()
