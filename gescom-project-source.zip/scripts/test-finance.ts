// Test de vérification du moteur financier GESCOM PROJECT
import { computeFinance, loanAnnuity } from '../src/lib/finance'
import type { FinanceData } from '../src/lib/types'

const demo: FinanceData = {
  investments: [
    { id: '1', label: 'Construction poulailler', category: 'BATIMENT', amount: 3000000, depreciable: true, depYears: 10 },
    { id: '2', label: 'Équipements d’élevage', category: 'EQUIPEMENT', amount: 900000, depreciable: true, depYears: 5 },
    { id: '3', label: 'Forage et réservoir', category: 'EQUIPEMENT', amount: 700000, depreciable: true, depYears: 10 },
    { id: '4', label: 'Groupe électrogène', category: 'EQUIPEMENT', amount: 500000, depreciable: true, depYears: 5 },
    { id: '5', label: 'Petit matériel', category: 'MATERIEL', amount: 250000, depreciable: true, depYears: 5 },
    { id: '6', label: 'Installation électrique', category: 'EQUIPEMENT', amount: 300000, depreciable: true, depYears: 5 },
    { id: '7', label: 'Frais d’établissement', category: 'FRAIS_ETABLISSEMENT', amount: 350000, depreciable: true, depYears: 2 },
  ],
  workingCapital: 11828000,
  financing: [
    { id: '1', source: 'Apport personnel', type: 'EQUITY', amount: 7828000, rate: 0, termYears: 0 },
    { id: '2', source: 'Prêt bancaire', type: 'LOAN', amount: 10000000, rate: 12, termYears: 5 },
  ],
  assumptions: {
    horizonYears: 5,
    discountRate: 12,
    taxRate: 25,
    products: [
      { id: '1', label: 'Vente poulets de chair', unit: 'poulet', unitPrice: 6600, qty: 11280, volumeGrowth: 0, priceGrowth: 2 },
      { id: '2', label: 'Vente de fumier', unit: 'sac', unitPrice: 1000, qty: 2400, volumeGrowth: 0, priceGrowth: 0 },
    ],
    variableCosts: [
      { id: '1', label: 'Poussins', mode: 'QTY', unitPrice: 500, qty: 12000, pct: 0, annualAmount: 0, growth: 2 },
      { id: '2', label: 'Aliment (tonnes)', mode: 'QTY', unitPrice: 430000, qty: 50.4, pct: 0, annualAmount: 0, growth: 2 },
      { id: '3', label: 'Santé & vaccination', mode: 'QTY', unitPrice: 125, qty: 12000, pct: 0, annualAmount: 0, growth: 2 },
      { id: '4', label: 'Transport & commercialisation', mode: 'QTY', unitPrice: 400, qty: 11280, pct: 0, annualAmount: 0, growth: 2 },
      { id: '5', label: 'Litière & énergie par bande', mode: 'QTY', unitPrice: 300, qty: 6000, pct: 0, annualAmount: 0, growth: 2 },
    ],
    fixedCosts: [
      { id: '1', label: 'Eau & électricité', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 240000, growth: 2 },
      { id: '2', label: 'Assurance', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 300000, growth: 0 },
      { id: '3', label: 'Entretien & maintenance', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 400000, growth: 2 },
      { id: '4', label: 'Divers & imprévus', mode: 'QTY', unitPrice: 0, pct: 0, qty: 0, annualAmount: 200000, growth: 2 },
    ],
    staff: [
      { id: '1', role: 'Gérant', count: 1, monthlySalary: 100000, annualGrowth: 3 },
      { id: '2', role: 'Gardien / ouvrier', count: 1, monthlySalary: 70000, annualGrowth: 3 },
    ],
  },
}

const r = computeFinance(demo)
console.log('=== VÉRIFICATION MOTEUR FINANCIER ===')
console.log('Investissement total :', r.totalInvestment, '(attendu 6 000 000)')
console.log('Besoins totaux :', r.totalNeeds, '(attendu 17 828 000)')
console.log('Financement :', r.totalFinancing, 'Écart :', r.financingGap, '(attendu 0)')
console.log('')
console.log('Annuité emprunt 10M @12% / 5 ans :', Math.round(loanAnnuity(10000000, 12, 5)), '(attendu 2 774 100)')
console.log('')
const y1 = r.years[0]
console.log('--- Année 1 ---')
console.log('CA :', Math.round(y1.revenue))
console.log('Charges variables :', Math.round(y1.variableCosts))
console.log('Charges fixes (exploit. + personnel) :', Math.round(y1.fixedCosts))
console.log('EBE :', Math.round(y1.ebitda))
console.log('Amortissements :', Math.round(y1.depreciation))
console.log('Intérêts :', Math.round(y1.interest))
console.log('Résultat avant impôt :', Math.round(y1.ebt))
console.log('IS :', Math.round(y1.tax))
console.log('Résultat net :', Math.round(y1.netIncome))
console.log('CAF :', Math.round(y1.caf))
console.log('Remboursement capital :', Math.round(y1.principalRepayment))
console.log('Flux net :', Math.round(y1.freeCashFlow))
console.log('')
console.log('--- Contrôles arithmétiques année 1 ---')
const checkEBE = y1.revenue - y1.variableCosts - y1.fixedCosts
console.log('EBE re-calculé =', Math.round(checkEBE), '→', Math.abs(checkEBE - y1.ebitda) < 1 ? 'OK' : 'ERREUR')
const checkNet = y1.ebitda - y1.depreciation - y1.interest - y1.tax
console.log('Net re-calculé =', Math.round(checkNet), '→', Math.abs(checkNet - y1.netIncome) < 1 ? 'OK' : 'ERREUR')
const checkFlux = y1.netIncome + y1.depreciation - y1.principalRepayment
console.log('Flux re-calculé =', Math.round(checkFlux), '→', Math.abs(checkFlux - y1.freeCashFlow) < 1 ? 'OK' : 'ERREUR')
console.log('')
console.log('--- Indicateurs ---')
console.log('VAN @12% :', Math.round(r.ratios.npv))
console.log('TRI :', r.ratios.irr !== null ? r.ratios.irr.toFixed(2) + ' %' : 'n/a')
console.log('Payback :', r.ratios.payback !== null ? r.ratios.payback.toFixed(2) + ' ans' : 'n/a')
console.log('Seuil de rentabilité :', Math.round(r.ratios.breakEvenRevenue), 'année', r.ratios.breakEvenYear)
console.log('Marge nette :', r.ratios.netMargin.toFixed(1), '%')
console.log('ROI moyen :', r.ratios.roi.toFixed(1), '%')
console.log('DSCR :', r.ratios.dscr !== null ? r.ratios.dscr.toFixed(2) : 'n/a')
console.log('')
console.log('--- Scénarios ---')
for (const s of r.scenarios) {
  console.log(`${s.name} : CA1=${Math.round(s.revenue1)} Net1=${Math.round(s.netIncome1)} VAN=${Math.round(s.npv)} Payback=${s.payback !== null ? s.payback.toFixed(2) : 'n/a'}`)
}
console.log('')
console.log('--- Flux cumulés (5 ans) ---')
r.years.forEach((y) => {
  console.log(`An ${y.year} : flux=${Math.round(y.freeCashFlow)} cumulé=${Math.round(y.cumulativeFCF)}`)
})
console.log('')
console.log('Échéancier emprunt (3 premières années) :')
r.loanSchedule.filter((l) => l.year <= 3).forEach((l) => {
  console.log(`An ${l.year} : solde début=${Math.round(l.openingBalance)} intérêts=${Math.round(l.interest)} capital=${Math.round(l.principal)} annuité=${Math.round(l.annuity)} solde fin=${Math.round(l.closingBalance)}`)
})
const totalPaid = r.loanSchedule.reduce((s, l) => s + l.annuity, 0)
const expected5 = loanAnnuity(10000000, 12, 5) * 5
console.log('Total annuités 5 ans :', Math.round(totalPaid), 'attendu :', Math.round(expected5), '→', Math.abs(totalPaid - expected5) < 10 ? 'OK' : 'ATTENTION (solde restant après 5 ans)')
