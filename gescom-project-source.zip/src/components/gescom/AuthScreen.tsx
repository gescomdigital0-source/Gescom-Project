'use client'

// GESCOM PROJECT – Écran de connexion / inscription / vérification e-mail /
// mot de passe oublié
//
// Parcours d'inscription en 2 étapes :
//  1. « register » : le compte est créé inactif et un code à 6 chiffres est
//     envoyé à l'adresse renseignée (valable 10 minutes) ;
//  2. « verify » : l'utilisateur recopie le code reçu dans sa boîte mail ;
//     le compte est activé et la session ouverte.
//
// Parcours « mot de passe oublié » en 2 étapes :
//  1. « forgot » : un code à 6 chiffres est envoyé à l'adresse du compte ;
//  2. « reset » : code + nouveau mot de passe, puis retour à la connexion.
import { useEffect, useRef, useState } from 'react'
import { apiSend, setToken, ApiError } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import type { SessionUser } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp'
import { useToast } from '@/hooks/use-toast'
import {
  Loader2, Lock, Mail, MailCheck, User, Building2, Sparkles, FileText,
  Calculator, Presentation, ClipboardList, Copy, RotateCw, ShieldCheck, TriangleAlert,
  KeyRound,
} from 'lucide-react'

type AuthMode = 'login' | 'register' | 'verify' | 'forgot' | 'reset'

function passwordIssueClient(pw: string): string | null {
  if (!pw || pw.length < 8) return 'Le mot de passe doit contenir au moins 8 caractères.'
  if (!/[a-zA-Z]/.test(pw)) return 'Le mot de passe doit contenir au moins une lettre.'
  if (!/[0-9]/.test(pw)) return 'Le mot de passe doit contenir au moins un chiffre.'
  return null
}

export function AuthScreen() {
  const { setUser } = useApp()
  const { toast } = useToast()
  const [mode, setMode] = useState<AuthMode>('login')
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    organization: '',
    jobTitle: '',
  })

  // Étapes avec code e-mail (vérification d'inscription et réinitialisation)
  const [verifyEmail, setVerifyEmail] = useState('')
  const [code, setCode] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [resetting, setResetting] = useState(false)
  const [resetPw, setResetPw] = useState('')
  const [resetConfirm, setResetConfirm] = useState('')
  const [verifyError, setVerifyError] = useState<string | null>(null)
  const [devCode, setDevCode] = useState<string | null>(null) // code affiché en mode démo (SMTP non configuré)
  const [resending, setResending] = useState(false)
  const [cooldown, setCooldown] = useState(0)
  const [formError, setFormError] = useState<{ message: string; accountExists: boolean } | null>(null)
  const verifyingRef = useRef(false)

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }))

  // Compte à rebours du renvoi (anti-spam 60 s)
  useEffect(() => {
    if (cooldown <= 0) return
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000)
    return () => clearTimeout(t)
  }, [cooldown])

  // En mode démonstration (delivered:false) aucun e-mail ne part : le code
  // est régénéré à chaque demande côté serveur, on autorise donc un renvoi
  // quasi immédiat. Avec un vrai SMTP, le délai anti-spam de 60 s s'applique.
  function cooldownFor(delivered?: boolean): number {
    return delivered === false ? 5 : 60
  }

  function enterVerify(email: string, codeStr?: string, delivered?: boolean) {
    setVerifyEmail(email)
    setDevCode(codeStr ?? null)
    setCode('')
    setVerifyError(null)
    setFormError(null)
    setCooldown(cooldownFor(delivered))
    setMode('verify')
  }

  function enterReset(email: string, codeStr?: string, delivered?: boolean) {
    setVerifyEmail(email)
    setDevCode(codeStr ?? null)
    setCode('')
    setResetPw('')
    setResetConfirm('')
    setVerifyError(null)
    setFormError(null)
    setCooldown(cooldownFor(delivered))
    setMode('reset')
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setFormError(null)
    try {
      if (mode === 'login') {
        const data = await apiSend<{ user: SessionUser; token?: string }>('/api/auth/login', 'POST', {
          email: form.email,
          password: form.password,
        })
        setToken(data.token)
        setUser(data.user)
        toast({ title: 'Bienvenue !', description: 'Connexion réussie à GESCOM PROJECT.' })
      } else {
        const data = await apiSend<{
          needsVerification: boolean
          email: string
          delivered?: boolean
          devCode?: string
          message?: string
        }>('/api/auth/register', 'POST', form)
        // Aucune session : le compte attend la vérification du code e-mail.
        enterVerify(data.email || form.email, data.devCode, data.delivered)
        toast({
          title: 'Code de vérification envoyé',
          description:
            data.delivered === false
              ? 'Mode démonstration : votre code est affiché à l\'écran.'
              : `Un code à 6 chiffres a été envoyé à ${data.email}. Valable 10 minutes.`,
        })
      }
    } catch (err) {
      // Compte existant mais jamais vérifié : on l'emmène vers l'écran de vérification.
      if (err instanceof ApiError && err.payload?.needsVerification) {
        const payload = err.payload as { email?: string; devCode?: string; delivered?: boolean }
        enterVerify(payload.email || form.email, payload.devCode, payload.delivered)
        toast({
          title: 'Compte non vérifié',
          description: 'Saisissez le code à 6 chiffres envoyé à votre adresse e-mail pour l\'activer.',
        })
        return
      }
      // Compte déjà existant : erreur affichée dans le formulaire, avec des
      // actions directes (connexion ou mot de passe oublié) plutôt qu'un
      // simple message bloquant.
      if (err instanceof ApiError && err.payload?.accountExists) {
        setFormError({
          message:
            err.message ||
            'Un compte existe déjà avec cette adresse e-mail.',
          accountExists: true,
        })
        return
      }
      setFormError({
        message: err instanceof Error ? err.message : 'Une erreur est survenue.',
        accountExists: false,
      })
    } finally {
      setLoading(false)
    }
  }

  async function submitForgot(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setFormError(null)
    try {
      const data = await apiSend<{
        ok: boolean
        needsVerification?: boolean
        email?: string
        delivered?: boolean
        devCode?: string
        message?: string
      }>('/api/auth/password/forgot', 'POST', { email: form.email })
      if (data.needsVerification) {
        // Compte jamais activé : on l'oriente vers la vérification d'inscription.
        enterVerify(data.email || form.email, data.devCode, data.delivered)
        toast({ title: 'Compte non activé', description: data.message || 'Un code d\'activation vous a été envoyé.' })
        return
      }
      enterReset(form.email, data.devCode, data.delivered)
      toast({
        title: 'Code de réinitialisation envoyé',
        description:
          data.devCode
            ? 'Mode démonstration : votre code est affiché à l\'écran.'
            : data.message || 'Vérifiez votre boîte mail : un code à 6 chiffres vous a été envoyé.',
      })
    } catch (err) {
      setFormError({
        message: err instanceof Error ? err.message : 'Une erreur est survenue.',
        accountExists: false,
      })
    } finally {
      setLoading(false)
    }
  }

  async function doVerify() {
    if (verifyingRef.current || code.length !== 6) return
    verifyingRef.current = true
    setVerifying(true)
    setVerifyError(null)
    setFormError(null)
    try {
      const data = await apiSend<{ user: SessionUser; token: string }>('/api/auth/verify', 'POST', {
        email: verifyEmail,
        code,
      })
      setToken(data.token)
      setUser(data.user)
      toast({
        title: 'Compte activé ✅',
        description: `Merci ${data.user.firstName} ! Votre adresse e-mail a été vérifiée. Bienvenue sur GESCOM PROJECT.`,
      })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Vérification impossible.'
      setVerifyError(msg)
      setCode('')
    } finally {
      setVerifying(false)
      verifyingRef.current = false
    }
  }

  // Validation automatique dès que les 6 chiffres sont saisis (inscription)
  useEffect(() => {
    if (mode === 'verify' && code.length === 6) void doVerify()
     
  }, [code, mode])

  async function doReset() {
    if (resetting || code.length !== 6) return
    const issue = passwordIssueClient(resetPw)
    if (issue) {
      setVerifyError(issue)
      return
    }
    if (resetPw !== resetConfirm) {
      setVerifyError('Les deux mots de passe ne correspondent pas.')
      return
    }
    setResetting(true)
    setVerifyError(null)
    try {
      const data = await apiSend<{ ok: boolean; message: string }>('/api/auth/password/reset', 'POST', {
        email: verifyEmail,
        code,
        password: resetPw,
      })
      toast({ title: 'Mot de passe réinitialisé ✅', description: data.message || 'Connectez-vous avec votre nouveau mot de passe.' })
      setForm((f) => ({ ...f, email: verifyEmail, password: '' }))
      setCode('')
      setResetPw('')
      setResetConfirm('')
      setMode('login')
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Réinitialisation impossible.'
      setVerifyError(msg)
      // Code refusé : on le vide pour forcer une nouvelle saisie complète.
      if (/code/i.test(msg)) setCode('')
    } finally {
      setResetting(false)
    }
  }

  async function resendCode() {
    if (cooldown > 0 || resending) return
    const purpose = mode === 'reset' ? 'PASSWORD_RESET' : 'SIGNUP'
    setResending(true)
    try {
      const data = await apiSend<{ delivered: boolean; message: string; devCode?: string }>(
        '/api/auth/resend',
        'POST',
        { email: verifyEmail, purpose },
      )
      if (data.devCode) setDevCode(data.devCode)
      setCooldown(cooldownFor(data.delivered))
      toast({ title: 'Code renvoyé', description: data.message })
    } catch (err) {
      const retry =
        err instanceof ApiError && typeof err.payload?.retryAfterSeconds === 'number'
          ? (err.payload.retryAfterSeconds as number)
          : null
      if (retry) setCooldown(retry)
      toast({
        title: 'Renvoi impossible',
        description: err instanceof Error ? err.message : 'Une erreur est survenue.',
        variant: 'destructive',
      })
    } finally {
      setResending(false)
    }
  }

  function copyDevCode() {
    if (!devCode) return
    try {
      void navigator.clipboard.writeText(devCode)
      toast({ title: 'Code copié', description: `Le code ${devCode} est copié dans le presse-papiers.` })
    } catch {
      // presse-papiers indisponible : le code reste affiché
    }
  }

  async function loginDemo(email: string, password: string) {
    setForm((f) => ({ ...f, email, password }))
    setLoading(true)
    try {
      const data = await apiSend<{ user: SessionUser; token?: string }>('/api/auth/login', 'POST', { email, password })
      setToken(data.token)
      setUser(data.user)
      toast({ title: 'Mode démonstration', description: 'Projet complet pré-rempli : explorez tous les modules.' })
    } catch (err) {
      toast({
        title: 'Erreur',
        description: err instanceof Error ? err.message : 'Connexion impossible.',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const codeModes = mode === 'verify' || mode === 'reset'

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background">
      {/* Panneau de présentation */}
      <div className="relative lg:w-[55%] gescom-gradient text-white flex flex-col justify-between p-8 lg:p-14 overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, #d4a72c 0%, transparent 40%), radial-gradient(circle at 80% 70%, #d4a72c 0%, transparent 35%)' }}
        />
        <div className="relative flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-white flex items-center justify-center shadow-lg overflow-hidden shrink-0">
            <img src="/logo.png" alt="Logo GESCOM DIGITAL SERVICES" className="h-full w-full object-contain" />
          </div>
          <div>
            <div className="font-bold text-lg tracking-tight">GESCOM PROJECT</div>
            <div className="text-xs text-slate-400">Gestion • Analyse • Structuration de projets</div>
          </div>
        </div>

        <div className="relative max-w-xl animate-fade-up">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-[#d4a72c]/40 bg-[#d4a72c]/10 px-3.5 py-1.5 text-xs font-semibold text-[#f5c542]">
            <Sparkles className="h-3.5 w-3.5" />
            Inscription gratuite — créez votre compte en 1 minute
          </div>
          <h1 className="text-3xl lg:text-[2.6rem] font-bold leading-tight tracking-tight">
            Votre idée mérite un <span className="text-gradient-gold">grand avenir</span>&nbsp;!
          </h1>
          <p className="mt-5 text-slate-300 leading-relaxed">
            Concevez facilement un Business Plan complet, structuré et professionnel, de l&apos;idée
            initiale jusqu&apos;aux prévisions financières. Avec Gescom Project, entreprenez avec
            méthode, confiance et ambition.
          </p>
          <div className="mt-8 grid grid-cols-2 gap-4">
            {[
              { icon: ClipboardList, title: 'Assistant guidé', text: 'Création pas-à-pas avec sauvegarde automatique' },
              { icon: Calculator, title: 'Finances fiables', text: 'VAN, TRI, seuil de rentabilité, scénarios vérifiés' },
              { icon: FileText, title: 'Documents pro', text: 'Exports PDF, Word, Excel (formules) et PowerPoint' },
              { icon: Presentation, title: 'Présentations', text: 'Slides investisseurs, banques, partenaires' },
            ].map((f) => (
              <div key={f.title} className="rounded-xl bg-white/5 border border-white/10 p-4 backdrop-blur-sm">
                <f.icon className="h-5 w-5 text-[#d4a72c] mb-2" />
                <div className="font-semibold text-sm">{f.title}</div>
                <div className="text-xs text-slate-400 mt-1 leading-relaxed">{f.text}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative text-xs text-slate-500">
          © {new Date().getFullYear()} GESCOM PROJECT — Les données de démonstration sont illustratives et à remplacer par vos propres chiffres.
        </div>
      </div>

      {/* Colonne de droite : connexion / inscription / vérification / mot de passe oublié */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-10">
        {codeModes ? (
          <div className="w-full max-w-md animate-fade-up">
            <div className="rounded-2xl border bg-card shadow-sm p-8">
              <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center mb-4">
                {mode === 'verify' ? <MailCheck className="h-6 w-6 text-[#0f172a]" /> : <KeyRound className="h-6 w-6 text-[#0f172a]" />}
              </div>
              <h2 className="text-xl font-bold">
                {mode === 'verify' ? 'Vérifiez votre adresse e-mail' : 'Choisissez un nouveau mot de passe'}
              </h2>
              <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">
                {mode === 'verify' ? (
                  <>
                    Un code à 6 chiffres a été envoyé à{' '}
                    <span className="font-semibold text-foreground">{verifyEmail}</span>.
                    Ouvrez votre boîte mail, recopiez le code ci-dessous pour activer votre compte.
                  </>
                ) : (
                  <>
                    Saisissez le code à 6 chiffres reçu à{' '}
                    <span className="font-semibold text-foreground">{verifyEmail}</span>,
                    puis choisissez votre nouveau mot de passe.
                  </>
                )}
              </p>

              {/* Mode démonstration : SMTP non configuré sur ce serveur */}
              {devCode && (
                <div className="mt-4 rounded-xl border border-amber-300 bg-amber-50 p-3.5">
                  <div className="flex items-start gap-2">
                    <TriangleAlert className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                    <div className="text-xs text-amber-800 leading-relaxed">
                      <span className="font-semibold">Mode démonstration</span> — aucun serveur d&apos;envoi d&apos;e-mails
                      n&apos;est encore branché (l&apos;administrateur peut le configurer depuis
                      Paramètres&nbsp;→&nbsp;E-mail). Votre code de vérification est :
                      <div className="mt-2 flex items-center gap-2">
                        <span className="font-mono font-bold text-base tracking-[0.3em] text-amber-900">{devCode}</span>
                        <Button type="button" size="sm" variant="outline" className="h-7 px-2 text-xs" onClick={copyDevCode}>
                          <Copy className="h-3 w-3 mr-1" /> Copier
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 flex flex-col items-center gap-4">
                <InputOTP maxLength={6} value={code} onChange={setCode} disabled={verifying || resetting}>
                  <InputOTPGroup className="gap-2">
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot
                        key={i}
                        index={i}
                        className="h-12 w-11 text-lg font-semibold rounded-lg border shadow-sm data-[active=true]:border-[#d4a72c] data-[active=true]:ring-[#d4a72c]/30"
                      />
                    ))}
                  </InputOTPGroup>
                </InputOTP>

                {mode === 'reset' && (
                  <div className="w-full space-y-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="newPassword">Nouveau mot de passe</Label>
                      <div className="relative">
                        <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="newPassword"
                          type="password"
                          className="pl-8"
                          value={resetPw}
                          onChange={(e) => setResetPw(e.target.value)}
                          placeholder="••••••••"
                          autoComplete="new-password"
                        />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe</Label>
                      <div className="relative">
                        <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="confirmPassword"
                          type="password"
                          className="pl-8"
                          value={resetConfirm}
                          onChange={(e) => setResetConfirm(e.target.value)}
                          placeholder="••••••••"
                          autoComplete="new-password"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">8 caractères minimum, avec au moins une lettre et un chiffre.</p>
                    </div>
                  </div>
                )}

                {verifyError && (
                  <p className="text-xs text-destructive text-center leading-relaxed">{verifyError}</p>
                )}

                {mode === 'verify' ? (
                  <Button type="button" className="w-full h-11" onClick={doVerify} disabled={verifying || code.length !== 6}>
                    {verifying ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <ShieldCheck className="h-4 w-4 mr-2" />}
                    {verifying ? 'Vérification…' : 'Vérifier et activer mon compte'}
                  </Button>
                ) : (
                  <Button
                    type="button"
                    className="w-full h-11"
                    onClick={doReset}
                    disabled={resetting || code.length !== 6 || !resetPw || !resetConfirm}
                  >
                    {resetting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <KeyRound className="h-4 w-4 mr-2" />}
                    {resetting ? 'Réinitialisation…' : 'Réinitialiser mon mot de passe'}
                  </Button>
                )}
              </div>

              <div className="mt-5 flex items-center justify-between text-sm">
                <button
                  type="button"
                  className="text-muted-foreground underline-offset-4 hover:underline"
                  onClick={() => {
                    if (mode === 'verify') {
                      setForm((f) => ({ ...f, email: verifyEmail }))
                      setMode('register')
                    } else {
                      setForm((f) => ({ ...f, email: verifyEmail }))
                      setMode('forgot')
                    }
                  }}
                >
                  Modifier l&apos;adresse
                </button>
                <button
                  type="button"
                  className="text-primary font-semibold underline-offset-4 hover:underline inline-flex items-center gap-1.5 disabled:opacity-50 disabled:pointer-events-none"
                  onClick={resendCode}
                  disabled={cooldown > 0 || resending}
                >
                  {resending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCw className="h-3.5 w-3.5" />}
                  {cooldown > 0 ? `Renvoyer le code (${cooldown} s)` : 'Renvoyer le code'}
                </button>
              </div>
            </div>
          </div>
        ) : mode === 'forgot' ? (
          <div className="w-full max-w-md animate-fade-up">
            <div className="rounded-2xl border bg-card shadow-sm p-8">
              <div className="h-12 w-12 rounded-xl gold-gradient flex items-center justify-center mb-4">
                <KeyRound className="h-6 w-6 text-[#0f172a]" />
              </div>
              <h2 className="text-xl font-bold">Mot de passe oublié&nbsp;?</h2>
              <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">
                Indiquez l&apos;adresse e-mail de votre compte : nous vous enverrons un code à
                6 chiffres qui vous permettra de choisir un nouveau mot de passe.
              </p>

              <form onSubmit={submitForgot} className="mt-6 space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="forgotEmail">Adresse e-mail</Label>
                  <div className="relative">
                    <Mail className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="forgotEmail" type="email" className="pl-8" value={form.email} onChange={set('email')} placeholder="vous@exemple.com" required />
                  </div>
                </div>
                {formError && (
                  <p className="text-xs text-destructive leading-relaxed">{formError.message}</p>
                )}
                <Button type="submit" className="w-full h-11" disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <MailCheck className="h-4 w-4 mr-2" />}
                  Envoyer le code de réinitialisation
                </Button>
              </form>

              <div className="mt-5 text-center text-sm">
                <button className="text-primary underline-offset-4 hover:underline" onClick={() => { setFormError(null); setMode('login') }} type="button">
                  <span className="font-semibold">Retour à la connexion</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-md animate-fade-up">
            <div className="rounded-2xl border bg-card shadow-sm p-8">
              <h2 className="text-xl font-bold">{mode === 'login' ? 'Connexion' : 'Créer un compte'}</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {mode === 'login'
                  ? 'Accédez à vos projets.'
                  : 'Créez votre compte gratuitement, en moins d\'une minute.'}
              </p>
              {mode === 'register' && (
                <div className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-emerald-300 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                  <Sparkles className="h-3.5 w-3.5" />
                  Inscription 100&nbsp;% gratuite — aucun paiement requis
                </div>
              )}

              <form onSubmit={submit} className="mt-6 space-y-4">
                {mode === 'register' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="firstName">Prénom</Label>
                      <div className="relative">
                        <User className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input id="firstName" className="pl-8" value={form.firstName} onChange={set('firstName')} placeholder="Awa" required />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="lastName">Nom</Label>
                      <Input id="lastName" value={form.lastName} onChange={set('lastName')} placeholder="Nkeng" required />
                    </div>
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="email">Adresse e-mail</Label>
                  <div className="relative">
                    <Mail className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="email" type="email" className="pl-8" value={form.email} onChange={set('email')} placeholder="vous@exemple.com" required />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password">Mot de passe</Label>
                  <div className="relative">
                    <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="password" type="password" className="pl-8" value={form.password} onChange={set('password')} placeholder="••••••••" required minLength={8} />
                  </div>
                  {mode === 'register' && (
                    <p className="text-xs text-muted-foreground">8 caractères minimum, avec au moins une lettre et un chiffre.</p>
                  )}
                </div>
                {mode === 'login' && (
                  <div className="text-right -mt-2">
                    <button
                      type="button"
                      className="text-xs text-primary font-medium underline-offset-4 hover:underline"
                      onClick={() => { setFormError(null); setMode('forgot') }}
                    >
                      Mot de passe oublié&nbsp;?
                    </button>
                  </div>
                )}
                {mode === 'register' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="organization">Organisation</Label>
                      <div className="relative">
                        <Building2 className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input id="organization" className="pl-8" value={form.organization} onChange={set('organization')} placeholder="Awa Farms & Co" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="jobTitle">Fonction</Label>
                      <Input id="jobTitle" value={form.jobTitle} onChange={set('jobTitle')} placeholder="Entrepreneure" />
                    </div>
                  </div>
                )}
                {formError && (
                  <div
                    className="rounded-xl border p-3.5"
                    role="alert"
                    style={{ borderColor: 'rgb(252 165 165)', background: 'rgb(254 242 242)' }}
                  >
                    <div className="flex items-start gap-2">
                      <TriangleAlert className="h-4 w-4 text-red-600 mt-0.5 shrink-0" />
                      <div className="text-xs leading-relaxed text-red-800">
                        {formError.message}
                        {formError.accountExists && (
                          <div className="mt-2.5 flex flex-wrap gap-2">
                            <Button
                              type="button"
                              size="sm"
                              className="h-7 px-2.5 text-xs"
                              onClick={() => {
                                setFormError(null)
                                setMode('login')
                              }}
                            >
                              <Lock className="h-3 w-3 mr-1" /> Se connecter
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              className="h-7 px-2.5 text-xs"
                              onClick={() => {
                                setFormError(null)
                                setMode('forgot')
                              }}
                            >
                              <KeyRound className="h-3 w-3 mr-1" /> Mot de passe oublié&nbsp;?
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
                <Button type="submit" className="w-full h-11" disabled={loading}>
                  {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  {mode === 'login' ? 'Se connecter' : 'Créer mon compte gratuitement'}
                </Button>
                {mode === 'register' && (
                  <p className="text-xs text-muted-foreground text-center leading-relaxed">
                    Après inscription, un code à 6 chiffres vous sera envoyé par e-mail :
                    recopiez-le dans l&apos;écran suivant pour activer votre compte.
                  </p>
                )}
              </form>

              <div className="mt-5 text-center text-sm">
                {mode === 'login' ? (
                  <button className="text-primary underline-offset-4 hover:underline" onClick={() => { setFormError(null); setMode('register') }} type="button">
                    Pas encore de compte&nbsp;? L&apos;inscription est gratuite — <span className="font-semibold">créer un compte</span>
                  </button>
                ) : (
                  <button className="text-primary underline-offset-4 hover:underline" onClick={() => { setFormError(null); setMode('login') }} type="button">
                    Déjà inscrit&nbsp;? <span className="font-semibold">Se connecter</span>
                  </button>
                )}
              </div>
            </div>

            {/* Comptes de démonstration */}
            <div className="mt-4 rounded-2xl border border-dashed bg-accent/40 p-5">
              <div className="flex items-center gap-2 text-sm font-semibold text-accent-foreground">
                <Sparkles className="h-4 w-4" />
                Explorer avec un compte de démonstration
              </div>
              <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
                Un projet complet est pré-rempli (ferme avicole au Cameroun) : analyse, finances chiffrées,
                plan d&apos;action, documents. Idéal pour découvrir la plateforme.
              </p>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Button variant="outline" size="sm" disabled={loading} onClick={() => loginDemo('demo@gescom.pro', 'demo2026')}>
                  Compte démonstration
                </Button>
                <Button variant="outline" size="sm" disabled={loading} onClick={() => loginDemo('admin@gescom.pro', 'admin2026')}>
                  Compte administrateur
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
