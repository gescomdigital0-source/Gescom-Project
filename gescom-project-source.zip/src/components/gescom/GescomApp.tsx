'use client'

// GESCOM PROJECT – Composant racine : authentification + navigation SPA
import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { apiGet, setToken } from '@/lib/client-api'
import type { SessionUser } from '@/lib/types'
import { AuthScreen } from '@/components/gescom/AuthScreen'
import { AppShell } from '@/components/gescom/AppShell'
import { CheckoutDialog } from '@/components/gescom/billing/CheckoutDialog'
import LanguageLayer from '@/components/gescom/LanguageLayer'
import { Loader2 } from 'lucide-react'

export function GescomApp() {
  const { user, setUser } = useApp()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        // Prépare les données de démonstration (idempotent) puis vérifie la session
        await fetch('/api/demo/ensure', { method: 'POST' }).catch(() => null)
        const data = await apiGet<{ user: SessionUser | null; token?: string | null }>('/api/auth/me')
        if (!cancelled) {
          if (data.token) setToken(data.token)
          setUser(data.user)
        }
      } catch {
        if (!cancelled) setUser(null)
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [setUser])

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-3">
        <div className="h-12 w-12 rounded-xl bg-white flex items-center justify-center shadow-lg overflow-hidden">
          <img src="/logo.png" alt="Logo GESCOM" className="h-full w-full object-contain" />
        </div>
        <div className="flex items-center gap-2 text-muted-foreground text-sm">
          <Loader2 className="h-4 w-4 animate-spin" />
          Chargement de GESCOM PROJECT…
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Traduction de l'interface (FR par défaut, EN seconde langue) */}
      <LanguageLayer />
      {user ? <AppShell /> : <AuthScreen />}
      {/* Tunnel d'abonnement Premium : un seul exemplaire, ouvert depuis
          tous les boutons « Passer à Premium » (store openCheckout). */}
      {user && <CheckoutDialog />}
    </>
  )
}
