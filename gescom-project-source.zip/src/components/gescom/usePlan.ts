'use client'

// GESCOM PROJECT – Hook d'activation de l'abonnement Premium
//
// Deux modes, transparents pour les composants :
//  • Encaissement réel (FedaPay configuré sur le serveur) : crée la
//    transaction et redirige le navigateur vers la page de paiement Mobile
//    Money (MTN MoMo, Moov Money, Wave…). La confirmation arrive par le
//    webhook + la vérification au retour.
//  • Mode démonstration (aucune clé configurée) : activation immédiate,
//    paiement simulé, durée limitée à la période choisie.
import { useCallback, useState } from 'react'
import { apiGet, apiSend } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import type { SessionUser } from '@/lib/types'
import type { BillingPeriod } from '@/lib/plans'

export function usePlanUpgrade() {
  const setUser = useApp((s) => s.setUser)
  const [upgrading, setUpgrading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const upgrade = useCallback(async (billing: BillingPeriod = 'MONTHLY'): Promise<boolean> => {
    setUpgrading(true)
    setError(null)
    try {
      const status = await apiGet<{ configured: boolean }>('/api/account/plan/payments')
      if (status.configured) {
        // Paiement réel : redirection vers la page FedaPay (Mobile Money)
        const res = await apiSend<{ paymentUrl: string }>('/api/account/plan/checkout', 'POST', { billing })
        window.location.href = res.paymentUrl
        return true
      }
      // Mode démonstration : activation immédiate (paiement simulé)
      const res = await apiSend<{ user: SessionUser }>('/api/account/plan', 'POST', { plan: 'PREMIUM', billing })
      setUser(res.user)
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Activation impossible. Réessayez.')
      return false
    } finally {
      setUpgrading(false)
    }
  }, [setUser])

  return { upgrade, upgrading, error }
}
