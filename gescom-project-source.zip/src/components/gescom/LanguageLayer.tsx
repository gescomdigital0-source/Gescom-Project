'use client'

// GESCOM PROJECT – Couche de langue de l'interface (FR par défaut, EN seconde langue)
//
// Principe : un observateur de mutations DOM traduit à la volée les nœuds de
// texte et attributs usuels (placeholder, title, aria-label) via le
// dictionnaire FR→EN.
//  • couverture totale (vues, modules, dialogues, toasts, portails Radix) ;
//  • aucun composant métier à modifier, aucun risque de régression logique ;
//  • repli gracieux : toute chaîne absente du dictionnaire reste en français.
//
// Algorithme volontairement SANS ÉTAT (auto-réparateur) :
//  • le texte courant est cherché tel quel dans le dictionnaire (clé FR) ;
//  • s'il correspond à une traduction EN (valeur), le dictionnaire inverse
//    restitue le français — sans mémoire par nœud, donc sans dérive possible.

import { useEffect } from 'react'
import { Globe, Check } from 'lucide-react'
import { DICT } from '@/lib/i18n-dict'
import { MODULES_DICT } from '@/lib/i18n-dict-modules'
import { getLocale, setLocale, useLocale } from '@/lib/i18n'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

const ALL_DICT: Record<string, string> = { ...DICT, ...MODULES_DICT }

// Dictionnaire inverse (EN → FR) pour le retour au français.
// Une valeur anglaise identique à une clé française ferait une boucle :
// elle est exclue (la première écriture gagne).
const REV_DICT: Record<string, string> = {}
for (const [fr, en] of Object.entries(ALL_DICT)) {
  if (en === fr) continue
  if (en in ALL_DICT) continue // collision clé/valeur : on ne traduit pas dans les deux sens
  if (!(en in REV_DICT)) REV_DICT[en] = fr
}

const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'CODE', 'PRE', 'IFRAME', 'OBJECT'])
const TRANSLATED_ATTRS = ['placeholder', 'title', 'aria-label', 'aria-description'] as const

const norm = (s: string): string => s.replace(/\s+/g, ' ').trim()

// Traduit un texte brut en conservant les espaces de bord éventuels.
// Renvoie null s'il n'y a rien à changer.
function translate(raw: string, locale: string): string | null {
  const key = norm(raw)
  if (!key) return null
  if (locale === 'en') {
    const hit = ALL_DICT[key]
    if (!hit || hit === key) return null
  } else {
    const back = REV_DICT[key]
    if (!back || back === key) return null
  }
  const target = locale === 'en' ? ALL_DICT[key] : REV_DICT[key]
  const trimmed = raw.trim()
  return trimmed ? raw.replace(trimmed, target) : target
}

function processTextNode(node: Text, locale: string): void {
  const parent = node.parentElement
  if (!parent || SKIP_TAGS.has(parent.tagName)) return
  const cur = node.nodeValue ?? ''
  if (!cur.trim()) return
  const target = translate(cur, locale)
  if (target !== null && target !== cur) node.nodeValue = target
}

function processAttribute(el: Element, attr: string, locale: string): void {
  const cur = el.getAttribute(attr) ?? ''
  if (!cur.trim()) return
  const target = translate(cur, locale)
  if (target !== null && target !== cur) el.setAttribute(attr, target)
}

function processTree(root: Document | Element, locale: string): void {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
  let node = walker.nextNode() as Text | null
  while (node) {
    processTextNode(node, locale)
    node = walker.nextNode() as Text | null
  }
  if ((root as Element).querySelectorAll) {
    for (const el of (root as Element).querySelectorAll('*')) {
      for (const attr of TRANSLATED_ATTRS) {
        if (el.hasAttribute(attr)) processAttribute(el, attr, locale)
      }
    }
  }
}

function LanguageLayer() {
  useEffect(() => {
    let scheduled = false
    const run = () => {
      scheduled = false
      processTree(document.body, getLocale())
    }
    const schedule = () => {
      if (scheduled) return
      scheduled = true
      requestAnimationFrame(run)
    }

    // Passe initiale (arbre déjà monté) + langue du document cohérente
    document.documentElement.lang = getLocale() === 'en' ? 'en' : 'fr'
    run()

    const observer = new MutationObserver(schedule)
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: [...TRANSLATED_ATTRS],
    })

    const onLocale = () => run()
    window.addEventListener('gescom:locale', onLocale)
    return () => {
      observer.disconnect()
      window.removeEventListener('gescom:locale', onLocale)
    }
  }, [])
  return null
}

// Sélecteur compact pour la barre supérieure
export function LanguageMenu() {
  const [locale] = useLocale()
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="h-9 gap-1.5 px-2.5 text-xs font-medium" aria-label="Language / Langue">
          <Globe className="h-4 w-4" aria-hidden />
          {locale === 'fr' ? 'FR' : 'EN'}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-40">
        <DropdownMenuItem onClick={() => setLocale('fr')} className="gap-2">
          <span className="flex-1">Français</span>
          {locale === 'fr' && <Check className="h-4 w-4 text-[#d4a72c]" aria-hidden />}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLocale('en')} className="gap-2">
          <span className="flex-1">English</span>
          {locale === 'en' && <Check className="h-4 w-4 text-[#d4a72c]" aria-hidden />}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

// Sélecteur pour Paramètres → Préférences
export function LanguageSelect() {
  const [locale] = useLocale()
  return (
    <Select value={locale} onValueChange={(v) => setLocale(v === 'en' ? 'en' : 'fr')}>
      <SelectTrigger><SelectValue /></SelectTrigger>
      <SelectContent>
        <SelectItem value="fr">Français</SelectItem>
        <SelectItem value="en">English</SelectItem>
      </SelectContent>
    </Select>
  )
}

export default LanguageLayer
