'use client'

// GESCOM PROJECT – Tableau de bord
import { useEffect, useState } from 'react'
import { apiGet } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import { fmtDate } from '@/lib/format'
import { PROJECT_STATUS_LABELS, PROJECT_STATUS_BADGE } from '@/lib/constants'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from 'recharts'
import {
  FolderKanban, Rocket, CheckCircle2, FilePlus2, ArrowRight,
  AlertTriangle, Activity as ActivityIcon, FolderPlus, ChartPie, Calculator,
} from 'lucide-react'

interface DashboardData {
  stats: { total: number; ongoing: number; completed: number; drafts: number; archived: number }
  recentProjects: Array<{ id: string; name: string; status: string; sector: string; progress: number; updatedAt: string; currency: string }>
  bySector: Record<string, number>
  activities: Array<{ id: string; type: string; message: string; createdAt: string; projectName: string | null }>
  overdueTasks: Array<{ id: string; title: string; endDate: string; projectId: string; projectName: string; status: string }>
}

export function DashboardView() {
  const { navigate, openProject, user } = useApp()
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const d = await apiGet<DashboardData>('/api/dashboard')
        if (!cancelled) setData(d)
      } catch {
        if (!cancelled) setData(null)
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const firstName = user?.firstName || ''
  const statusPie = data
    ? [
        { name: 'En cours', value: data.stats.ongoing, color: '#D4A72C' },
        { name: 'Terminés', value: data.stats.completed, color: '#0F172A' },
        { name: 'Brouillons', value: data.stats.drafts, color: '#94A3B8' },
      ].filter((x) => x.value > 0)
    : []
  const sectorData = data
    ? Object.entries(data.bySector)
        .map(([name, count]) => ({ name: name.length > 18 ? `${name.slice(0, 17)}…` : name, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 6)
    : []

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* En-tête */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Bonjour {firstName} 👋</h2>
          <p className="text-muted-foreground text-sm mt-1">
            Voici un aperçu de votre activité sur GESCOM PROJECT.
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => navigate('new-project')}>
            <FolderPlus className="h-4 w-4 mr-2" /> Nouveau projet
          </Button>
          <Button variant="outline" onClick={() => navigate('projects')}>
            Mes projets <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>

      {/* Cartes statistiques */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {loading || !data ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          <>
            <StatCard icon={FolderKanban} label="Projets au total" value={data.stats.total} tone="navy" />
            <StatCard icon={Rocket} label="En cours" value={data.stats.ongoing} tone="gold" />
            <StatCard icon={CheckCircle2} label="Terminés" value={data.stats.completed} tone="green" />
            <StatCard icon={FilePlus2} label="Brouillons" value={data.stats.drafts} tone="slate" />
          </>
        )}
      </div>

      {/* Alertes de retard */}
      {!loading && data && data.overdueTasks.length > 0 && (
        <Card className="border-red-200 bg-red-50/50 dark:bg-red-950/20 dark:border-red-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2 text-red-700 dark:text-red-400">
              <AlertTriangle className="h-[18px] w-[18px]" />
              Tâches en retard ({data.overdueTasks.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {data.overdueTasks.map((t) => (
              <div key={t.id} className="flex items-center justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <span className="font-medium truncate">{t.title}</span>
                  <span className="text-muted-foreground"> — {t.projectName}</span>
                </div>
                <Button variant="outline" size="sm" className="shrink-0" onClick={() => openProject(t.projectId, 'action-plan')}>
                  Échéance : {fmtDate(t.endDate)}
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Avancement des projets récents */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Projets récents & avancement</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12" />)
            ) : data && data.recentProjects.length > 0 ? (
              data.recentProjects.map((p) => (
                <button key={p.id} onClick={() => openProject(p.id)} className="w-full text-left group" type="button">
                  <div className="flex items-center justify-between gap-3 mb-1.5">
                    <div className="min-w-0">
                      <span className="font-medium text-sm group-hover:underline truncate block">{p.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {p.sector || 'Sans secteur'} · modifié le {fmtDate(p.updatedAt)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge variant="outline" className={PROJECT_STATUS_BADGE[p.status]}>
                        {PROJECT_STATUS_LABELS[p.status] || p.status}
                      </Badge>
                      <span className="text-xs font-semibold w-9 text-right">{Math.round(p.progress)} %</span>
                    </div>
                  </div>
                  <Progress value={p.progress} className="h-2" />
                </button>
              ))
            ) : (
              <div className="text-center py-10 text-muted-foreground text-sm">
                Aucun projet pour le moment. Cliquez sur « Nouveau projet » pour commencer.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Répartition par statut */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Répartition des projets</CardTitle>
          </CardHeader>
          <CardContent>
            {statusPie.length > 0 ? (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={statusPie} dataKey="value" nameKey="name" innerRadius={50} outerRadius={75} paddingAngle={3}>
                      {statusPie.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number) => [`${v} projet(s)`, '']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">Aucune donnée</div>
            )}
            <div className="flex flex-wrap justify-center gap-3 mt-2">
              {statusPie.map((s) => (
                <span key={s.name} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                  {s.name} ({s.value})
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Projets par secteur */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Projets par secteur</CardTitle>
          </CardHeader>
          <CardContent>
            {sectorData.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sectorData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-12} textAnchor="end" height={50} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip formatter={(v: number) => [`${v} projet(s)`, '']} />
                    <Bar dataKey="count" fill="#0F172A" radius={[6, 6, 0, 0]} maxBarSize={46} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">Aucune donnée</div>
            )}
          </CardContent>
        </Card>

        {/* Activités récentes */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <ActivityIcon className="h-4 w-4" /> Activité récente
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data && data.activities.length > 0 ? (
              <ul className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {data.activities.map((a) => (
                  <li key={a.id} className="flex gap-2.5 text-sm">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#d4a72c] shrink-0" />
                    <div className="min-w-0">
                      <p className="leading-snug">{a.message}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{fmtDate(a.createdAt)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-sm py-6 text-center">Aucune activité enregistrée.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Accès rapides */}
      <div className="grid sm:grid-cols-3 gap-4">
        <QuickCard icon={ChartPie} title="Analyse stratégique" text="SWOT, PESTEL, marché, risques" onClick={() => navigate('analysis')} />
        <QuickCard icon={Calculator} title="Études financières" text="Investissement, financement, rentabilité" onClick={() => navigate('finance')} />
        <QuickCard icon={FolderKanban} title="Documents & exports" text="Dossier PDF, Word, Excel, PowerPoint" onClick={() => navigate('documents')} />
      </div>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, tone }: { icon: typeof FolderKanban; label: string; value: number; tone: 'navy' | 'gold' | 'green' | 'slate' }) {
  const tones: Record<string, string> = {
    navy: 'bg-[#0f172a] text-white',
    gold: 'gold-gradient text-[#0f172a]',
    green: 'bg-emerald-600 text-white',
    slate: 'bg-slate-200 text-slate-700',
  }
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-5 flex items-center gap-4">
        <div className={`h-11 w-11 rounded-xl flex items-center justify-center shrink-0 ${tones[tone]}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-2xl font-bold leading-none">{value}</div>
          <div className="text-xs text-muted-foreground mt-1">{label}</div>
        </div>
      </CardContent>
    </Card>
  )
}

function QuickCard({ icon: Icon, title, text, onClick }: { icon: typeof ChartPie; title: string; text: string; onClick: () => void }) {
  return (
    <button onClick={onClick} type="button" className="text-left rounded-xl border bg-card p-5 hover:border-[#d4a72c]/60 hover:shadow-md transition-all group">
      <Icon className="h-5 w-5 text-[#d4a72c] mb-2 group-hover:scale-110 transition-transform" />
      <div className="font-semibold text-sm">{title}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{text}</div>
    </button>
  )
}
