'use client'

// GESCOM PROJECT – Espace de travail projet (analyse, finance, plan d'action,
// documents, présentation). Si aucun projet n'est ouvert, un sélecteur est
// proposé.
import { useEffect, useState } from 'react'
import { apiGet } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import { useProjectData } from '@/components/gescom/useProjectData'
import { fmtDate } from '@/lib/format'
import { PROJECT_STATUS_LABELS, PROJECT_STATUS_BADGE } from '@/lib/constants'
import { cn } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { AnalysisModule } from '@/components/gescom/modules/AnalysisModule'
import { FinanceModule } from '@/components/gescom/modules/FinanceModule'
import { ActionPlanModule } from '@/components/gescom/modules/ActionPlanModule'
import { ValidationModule } from '@/components/gescom/modules/ValidationModule'
import { DocumentsModule } from '@/components/gescom/modules/DocumentsModule'
import { PresentationModule } from '@/components/gescom/modules/PresentationModule'
import { Check, ChevronDown, Cloud, CloudOff, FolderOpen, Loader2, ShieldAlert, ShieldCheck, TriangleAlert } from 'lucide-react'
import type { View } from '@/lib/store'

interface ProjectListItem {
  id: string
  name: string
  sector: string
  status: string
  progress: number
  updatedAt: string
}

// Badge cliquable de statut projet (Brouillon / En cours / Terminé / Archivé)
function StatusMenu({ status, onChange }: { status: string; onChange: (s: string) => void }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Changer le statut du projet"
          title="Changer le statut du projet"
          className="rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#d4a72c]"
        >
          <Badge
            variant="outline"
            className={cn('cursor-pointer gap-1 hover:opacity-80', PROJECT_STATUS_BADGE[status])}
          >
            {PROJECT_STATUS_LABELS[status] || status}
            <ChevronDown className="h-3 w-3" />
          </Badge>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        <DropdownMenuLabel className="text-xs text-muted-foreground">Statut du projet</DropdownMenuLabel>
        {Object.entries(PROJECT_STATUS_LABELS).map(([k, label]) => (
          <DropdownMenuItem
            key={k}
            disabled={k === status}
            onClick={() => onChange(k)}
            className={cn('gap-2', k === 'COMPLETED' && 'text-emerald-700 focus:text-emerald-700')}
          >
            <Check className={cn('h-3.5 w-3.5', k === status ? 'opacity-100' : 'opacity-0')} />
            <span className="flex flex-col">
              <span>{label}</span>
              {k === 'COMPLETED' && (
                <span className="text-[10px] text-muted-foreground font-normal">Validation Gescom Project requise</span>
              )}
            </span>
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <div className="px-2 py-1.5 text-[10px] leading-snug text-muted-foreground flex items-start gap-1.5">
          <ShieldCheck className="h-3 w-3 mt-0.5 shrink-0 text-[#d4a72c]" />
          Seul un projet validé par Gescom Project peut être confirmé « Terminé ». Sinon, il reste « En cours ».
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export function ProjectWorkspace({ view }: { view: View }) {
  const { activeProjectId, openProject, navigate } = useApp()
  const [projects, setProjects] = useState<ProjectListItem[] | null>(null)
  const data = useProjectData(activeProjectId)

  useEffect(() => {
    if (projects !== null) return
    let cancelled = false
    ;(async () => {
      try {
        const d = await apiGet<{ projects: ProjectListItem[] }>('/api/projects')
        if (!cancelled) setProjects(d.projects)
      } catch {
        if (!cancelled) setProjects([])
      }
    })()
    return () => {
      cancelled = true
    }
  }, [projects])

  if (!activeProjectId) {
    return (
      <div className="p-4 lg:p-8 max-w-3xl mx-auto">
        <Card>
          <CardContent className="p-8">
            <h2 className="text-lg font-bold">Ouvrir un projet</h2>
            <p className="text-sm text-muted-foreground mt-1 mb-5">
              Choisissez un projet pour accéder à ses données. Chaque module (analyse, finance, plan
              d&apos;action…) travaille sur les données réelles du projet ouvert.
            </p>
            {projects === null ? (
              <div className="space-y-3">
                {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-14" />)}
              </div>
            ) : projects.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground mb-4">Vous n&apos;avez encore aucun projet.</p>
                <Button onClick={() => navigate('new-project')}>
                  <FolderOpen className="h-4 w-4 mr-2" /> Créer mon premier projet
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => openProject(p.id, view)}
                    className="w-full text-left rounded-lg border p-4 hover:border-[#d4a72c]/60 hover:bg-accent/30 transition-colors flex items-center gap-4"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-sm truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.sector || 'Sans secteur'} · modifié le {fmtDate(p.updatedAt)}</div>
                    </div>
                    <div className="w-28 shrink-0">
                      <Progress value={p.progress} className="h-1.5" />
                      <div className="text-[10px] text-muted-foreground mt-1 text-right">{Math.round(p.progress)} % complété</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  if (data.loading && !data.project) {
    return (
      <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-24" />
        <Skeleton className="h-96" />
      </div>
    )
  }

  if (data.error || !data.project) {
    return (
      <div className="p-4 lg:p-8 max-w-2xl mx-auto">
        <Card>
          <CardContent className="p-8 text-center">
            <CloudOff className="h-8 w-8 text-destructive mx-auto mb-3" />
            <p className="font-medium">{data.error || 'Projet introuvable.'}</p>
            <Button variant="outline" className="mt-4" onClick={() => void data.reload()}>
              Réessayer
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto space-y-5">
      {/* Bandeau projet */}
      <div className="rounded-xl border bg-card p-4 lg:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-bold text-lg leading-tight">{data.project.name}</h2>
              <StatusMenu status={data.project.status} onChange={(s) => void data.updateStatus(s)} />
              <Badge variant="secondary">{data.project.sector || 'Sans secteur'}</Badge>
              <Badge variant="outline">{data.project.currency}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Avancement global : {Math.round(data.project.progress)} % · {data.tasks.length} tâche(s) · dernière modification {fmtDate(data.project.updatedAt)}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-32">
              <Progress value={data.project.progress} className="h-2" />
            </div>
            <span className="text-xs flex items-center gap-1.5 text-muted-foreground">
              {data.saving ? (
                <><Cloud className="h-3.5 w-3.5 text-[#d4a72c] animate-pulse" /> Enregistrement…</>
              ) : data.saveError ? (
                <button
                  type="button"
                  onClick={() => data.retryFailedSaves()}
                  className="flex items-center gap-1.5 text-amber-700 hover:text-amber-800 font-medium"
                  title="Relancer l'enregistrement"
                >
                  <TriangleAlert className="h-3.5 w-3.5" /> Non synchronisé — réessayer
                </button>
              ) : data.savedAt ? (
                <><Cloud className="h-3.5 w-3.5 text-emerald-600" /> Enregistré</>
              ) : (
                <><Cloud className="h-3.5 w-3.5" /> Synchronisé</>
              )}
            </span>
            <Button variant="outline" size="sm" onClick={() => navigate('projects')}>
              Changer de projet
            </Button>
          </div>
        </div>
      </div>

      {/* Échec de sauvegarde : bandeau non bloquant — la saisie reste à l'écran */}
      {data.saveError && (
        <div className="rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center gap-2 sm:justify-between">
          <span className="flex items-start gap-2 leading-relaxed">
            <TriangleAlert className="h-4 w-4 shrink-0 mt-0.5" />
            {data.saveError}
          </span>
          <Button size="sm" variant="outline" className="shrink-0 border-amber-300 text-amber-900 hover:bg-amber-100" onClick={() => data.retryFailedSaves()}>
            Réessayer maintenant
          </Button>
        </div>
      )}

      {/* Refus de confirmation « Terminé » : le projet n'est pas validé par Gescom
          Project. On affiche le rapport synthétique et le chemin de correction. */}
      <Dialog open={!!data.statusBlock} onOpenChange={(o) => { if (!o) data.clearStatusBlock() }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-amber-600" />
              Confirmation « Terminé » impossible
            </DialogTitle>
            <DialogDescription className="text-left">
              {data.statusBlock?.report.decision}
            </DialogDescription>
          </DialogHeader>

          {data.statusBlock && (
            <div className="space-y-3 text-sm">
              <div className="rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40 px-3 py-2.5 text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2">
                <TriangleAlert className="h-4 w-4 shrink-0" />
                <span>
                  Statut de validation : <strong>{data.statusBlock.report.statusLabel}</strong>
                  {' — '}« {data.project.name} » reste <strong>En cours</strong> tant que la validation n&apos;est pas obtenue.
                </span>
              </div>

              {data.statusBlock.report.problems.length > 0 && (
                <div>
                  <p className="font-medium text-xs mb-1.5">
                    {data.statusBlock.report.counts.correctionsRestantes > 0
                      ? `Corrections obligatoires restantes : ${data.statusBlock.report.counts.correctionsRestantes} — principales à traiter :`
                      : 'Corrections principales à traiter :'}
                  </p>
                  <ul className="space-y-1.5 text-xs text-muted-foreground">
                    {data.statusBlock.report.problems
                      .slice(0, 4)
                      .map((pr) => (
                        <li key={pr.code} className="flex items-start gap-1.5">
                          <span className="mt-1 h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0" />
                          <span><strong className="text-foreground">{pr.problem}</strong> — {pr.recommendation}</span>
                        </li>
                      ))}
                  </ul>
                </div>
              )}

              <p className="text-xs text-muted-foreground">
                Une fois le dossier complet et rentable (VAN, TRI, IP), relancez la validation :
                Gescom Project confirmera le projet et vous pourrez le marquer « Terminé ».
              </p>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => data.clearStatusBlock()}>
              Plus tard
            </Button>
            <Button
              className="bg-[#0F172A] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0F172A] dark:hover:bg-[#e0b53f]"
              onClick={() => { data.clearStatusBlock(); navigate('validation') }}
            >
              Corriger dans la validation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Module actif */}
      {view === 'analysis' && (
        <AnalysisModule
          project={data.project}
          overview={data.overview}
          objectives={data.objectives}
          analysis={data.analysis}
          saveOverview={(v, immediate) => data.saveSection('overview', v, immediate)}
          saveObjectives={(v, immediate) => data.saveSection('objectives', v, immediate)}
          saveAnalysis={(v, immediate) => data.saveSection('analysis', v, immediate)}
        />
      )}
      {view === 'finance' && (
        <FinanceModule
          project={data.project}
          finance={data.finance}
          overview={data.overview}
          save={(v, immediate) => data.saveSection('finance', v, immediate)}
        />
      )}
      {view === 'action-plan' && (
        <ActionPlanModule
          project={data.project}
          tasks={data.tasks}
          setTasks={data.setTasks}
          reload={data.reload}
        />
      )}
      {view === 'validation' && (
        <ValidationModule project={data.project} onAutoCompleted={() => void data.reload()} />
      )}
      {view === 'documents' && (
        <DocumentsModule
          project={data.project}
          docPrefs={data.docPrefs}
          saveDocPrefs={(v) => data.saveSection('docPrefs', v)}
          hasFinance={data.finance.assumptions.products.length > 0}
        />
      )}
      {view === 'presentation' && (
        <PresentationModule
          project={data.project}
          docPrefs={data.docPrefs}
          analysis={data.analysis}
          finance={data.finance}
          saveDocPrefs={(v) => data.saveSection('docPrefs', v)}
        />
      )}
    </div>
  )
}

export { Loader2 }
