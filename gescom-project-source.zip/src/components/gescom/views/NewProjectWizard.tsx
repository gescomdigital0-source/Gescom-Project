'use client'

// GESCOM PROJECT – Assistant intelligent de création de projet (pas-à-pas)
import { useEffect, useState } from 'react'
import { apiSend } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import { SECTORS, PROJECT_TYPES, COUNTRIES, CURRENCIES, REGIONS } from '@/lib/constants'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  Lightbulb, Target, Globe2, FolderKanban, CheckCircle2, ArrowLeft, ArrowRight, Loader2, Plus, X, Sparkles,
} from 'lucide-react'
import { AiImproveButton } from '@/components/gescom/ai/AiImprove'

const STEPS = [
  { key: 'idea', label: 'Idée du projet', icon: Lightbulb },
  { key: 'sector', label: 'Secteur & type', icon: Target },
  { key: 'location', label: 'Localisation & devise', icon: Globe2 },
  { key: 'objectives', label: 'Objectifs', icon: CheckCircle2 },
  { key: 'summary', label: 'Récapitulatif', icon: FolderKanban },
]

const STORAGE_KEY = 'gescom-wizard-draft'

interface WizardData {
  name: string
  idea: string
  description: string
  sector: string
  type: string
  country: string
  region: string
  currency: string
  objectives: string[]
}

export function NewProjectWizard() {
  const { navigate, openProject, user } = useApp()
  const { toast } = useToast()
  const [step, setStep] = useState(0)
  const [creating, setCreating] = useState(false)
  const [data, setData] = useState<WizardData>({
    name: '',
    idea: '',
    description: '',
    sector: '',
    type: '',
    country: user?.prefs?.country || 'Cameroun',
    region: '',
    currency: user?.prefs?.currency || 'XAF',
    objectives: [''],
  })

  // Reprise d'un brouillon interrompu
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved) as WizardData & { _step?: number }
        setData((d) => ({ ...d, ...parsed }))
        if (typeof parsed._step === 'number') setStep(Math.min(parsed._step, STEPS.length - 1))
      }
    } catch {
      // pas de brouillon
    }
  }, [])

  // Sauvegarde automatique du brouillon
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...data, _step: step }))
  }, [data, step])

  const set = <K extends keyof WizardData>(k: K, v: WizardData[K]) => setData((d) => ({ ...d, [k]: v }))

  const canContinue = (() => {
    switch (STEPS[step].key) {
      case 'idea': return data.name.trim().length > 1 && data.idea.trim().length > 10
      case 'sector': return data.sector && data.type
      case 'location': return data.country && data.currency
      case 'objectives': return data.objectives.some((o) => o.trim().length > 3)
      default: return true
    }
  })()

  async function create() {
    setCreating(true)
    try {
      const res = await apiSend<{ project: { id: string; name: string } }>('/api/projects', 'POST', {
        ...data,
        objectives: data.objectives.filter((o) => o.trim()),
      })
      localStorage.removeItem(STORAGE_KEY)
      toast({ title: 'Projet créé 🎉', description: `${res.project.name} est prêt. Complétez son analyse et ses finances.` })
      openProject(res.project.id, 'analysis')
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Création impossible.', variant: 'destructive' })
    } finally {
      setCreating(false)
    }
  }

  const regions = REGIONS[data.country] || []

  return (
    <div className="p-4 lg:p-8 max-w-3xl mx-auto">
      {/* Fil d'étapes */}
      <div className="mb-6">
        <div className="flex items-center justify-between gap-1">
          {STEPS.map((s, i) => {
            const Icon = s.icon
            const done = i < step
            const active = i === step
            return (
              <button
                key={s.key}
                type="button"
                onClick={() => i <= step && setStep(i)}
                className={cn(
                  'flex flex-col items-center gap-1.5 flex-1 min-w-0',
                  i <= step ? 'cursor-pointer' : 'cursor-default',
                )}
              >
                <span
                  className={cn(
                    'h-10 w-10 rounded-full flex items-center justify-center border-2 transition-colors',
                    done && 'bg-[#0f172a] border-[#0f172a] text-white',
                    active && 'border-[#d4a72c] text-[#b0880f] bg-[#fdf6e3]',
                    !done && !active && 'border-border text-muted-foreground bg-card',
                  )}
                >
                  <Icon className="h-4.5 w-4.5 h-[18px] w-[18px]" />
                </span>
                <span className={cn('text-[11px] text-center leading-tight hidden sm:block', active ? 'font-semibold text-foreground' : 'text-muted-foreground')}>
                  {s.label}
                </span>
              </button>
            )
          })}
        </div>
        <Progress value={(step / (STEPS.length - 1)) * 100} className="h-1.5 mt-4" />
        <p className="text-xs text-muted-foreground mt-2">
          <Sparkles className="h-3 w-3 inline mr-1 text-[#d4a72c]" />
          Sauvegarde automatique : votre saisie est conservée, vous pouvez reprendre plus tard.
        </p>
      </div>

      <Card>
        <CardContent className="p-6 lg:p-8">
          {/* Étape 1 : Idée */}
          {STEPS[step].key === 'idea' && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h3 className="text-lg font-bold">Décrivez votre idée de projet</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Donnez un nom clair à votre projet et formulez l&apos;idée en quelques phrases.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="p-name">Nom du projet *</Label>
                <Input id="p-name" value={data.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex. Ferme avicole moderne – 2 000 poulets de chair" />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <Label htmlFor="p-idea">L&apos;idée en une phrase *</Label>
                  <AiImproveButton
                    target="idea"
                    value={data.idea}
                    context={{ name: data.name, sector: data.sector, type: data.type, country: data.country, region: data.region, currency: data.currency }}
                    onApply={(v) => set('idea', v as string)}
                    className="h-7"
                  />
                </div>
                <Textarea id="p-idea" rows={3} value={data.idea} onChange={(e) => set('idea', e.target.value)} placeholder="Ex. Produire et vendre 12 000 poulets de chair par an pour approvisionner les restaurants et ménages de ma ville." />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <Label>Description détaillée</Label>
                  <AiImproveButton
                    target="description"
                    value={data.description}
                    context={{ name: data.name, sector: data.sector, type: data.type, country: data.country, region: data.region, currency: data.currency }}
                    onApply={(v) => set('description', v as string)}
                    className="h-7"
                  />
                </div>
                <Textarea rows={5} value={data.description} onChange={(e) => set('description', e.target.value)} placeholder="Activité, produits/services, clients visés, mode de fonctionnement…" />
                <p className="text-xs text-muted-foreground">Ces textes alimentent directement la section « Présentation générale » de votre dossier.</p>
              </div>
            </div>
          )}

          {/* Étape 2 : Secteur & type */}
          {STEPS[step].key === 'sector' && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h3 className="text-lg font-bold">Secteur d&apos;activité et type de projet</h3>
                <p className="text-sm text-muted-foreground mt-1">Cela permet d&apos;adapter les analyses et le vocabulaire du dossier.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Secteur d&apos;activité *</Label>
                <Select value={data.sector} onValueChange={(v) => set('sector', v)}>
                  <SelectTrigger><SelectValue placeholder="Choisir un secteur" /></SelectTrigger>
                  <SelectContent>
                    {SECTORS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Type de projet *</Label>
                <Select value={data.type} onValueChange={(v) => set('type', v)}>
                  <SelectTrigger><SelectValue placeholder="Choisir un type" /></SelectTrigger>
                  <SelectContent>
                    {PROJECT_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Étape 3 : Localisation */}
          {STEPS[step].key === 'location' && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h3 className="text-lg font-bold">Localisation et devise</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  La devise est utilisée dans toutes les analyses financières et les documents générés.
                </p>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Pays *</Label>
                  <Select value={data.country} onValueChange={(v) => { set('country', v); set('region', '') }}>
                    <SelectTrigger><SelectValue placeholder="Choisir un pays" /></SelectTrigger>
                    <SelectContent>
                      {COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Région / ville</Label>
                  {regions.length > 0 ? (
                    <Select value={data.region} onValueChange={(v) => set('region', v)}>
                      <SelectTrigger><SelectValue placeholder="Choisir une région" /></SelectTrigger>
                      <SelectContent>
                        {regions.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input value={data.region} onChange={(e) => set('region', e.target.value)} placeholder="Ex. Région de Dakar" />
                  )}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Devise *</Label>
                <Select value={data.currency} onValueChange={(v) => set('currency', v)}>
                  <SelectTrigger><SelectValue placeholder="Choisir une devise" /></SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map((c) => <SelectItem key={c.code} value={c.code}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Étape 4 : Objectifs */}
          {STEPS[step].key === 'objectives' && (
            <div className="space-y-5 animate-fade-up">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div>
                  <h3 className="text-lg font-bold">Objectifs du projet</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Listez 2 à 5 objectifs mesurables (quantités, délais, chiffre d&apos;affaires…).
                  </p>
                </div>
                <AiImproveButton
                  target="objectives"
                  value={data.objectives.filter((o) => o.trim())}
                  context={{ name: data.name, sector: data.sector, type: data.type, country: data.country, region: data.region, currency: data.currency, idea: data.idea }}
                  onApply={(v) => set('objectives', (v as string[]).length > 0 ? (v as string[]) : data.objectives)}
                  className="h-7"
                />
              </div>
              <div className="space-y-3">
                {data.objectives.map((o, i) => (
                  <div key={i} className="flex gap-2">
                    <Input
                      value={o}
                      onChange={(e) => {
                        const arr = [...data.objectives]
                        arr[i] = e.target.value
                        set('objectives', arr)
                      }}
                      placeholder={`Objectif ${i + 1} — ex. Atteindre 6 bandes de production par an`}
                    />
                    {data.objectives.length > 1 && (
                      <Button variant="ghost" size="icon" onClick={() => set('objectives', data.objectives.filter((_, j) => j !== i))} aria-label="Supprimer cet objectif">
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => set('objectives', [...data.objectives, ''])}>
                  <Plus className="h-4 w-4 mr-1.5" /> Ajouter un objectif
                </Button>
              </div>
            </div>
          )}

          {/* Étape 5 : Récapitulatif */}
          {STEPS[step].key === 'summary' && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h3 className="text-lg font-bold">Récapitulatif avant création</h3>
                <p className="text-sm text-muted-foreground mt-1">Vérifiez les informations. Vous pourrez tout modifier ensuite.</p>
              </div>
              <dl className="rounded-xl border divide-y text-sm">
                {[
                  ['Nom du projet', data.name],
                  ['Idée', data.idea],
                  ['Secteur', data.sector],
                  ['Type', data.type],
                  ['Localisation', [data.region, data.country].filter(Boolean).join(', ')],
                  ['Devise', data.currency],
                  ['Objectifs', data.objectives.filter((o) => o.trim()).length + ' objectif(s)'],
                ].map(([k, v]) => (
                  <div key={k as string} className="flex gap-4 px-4 py-3">
                    <dt className="w-36 shrink-0 text-muted-foreground">{k}</dt>
                    <dd className="min-w-0 whitespace-pre-wrap">{v || '—'}</dd>
                  </div>
                ))}
              </dl>
              <p className="text-xs text-muted-foreground">
                Après la création, vous serez guidé vers le module <strong>Analyse</strong> pour enrichir le projet.
              </p>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-8 pt-5 border-t">
            <Button variant="ghost" onClick={() => (step === 0 ? navigate('dashboard') : setStep(step - 1))}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> {step === 0 ? 'Annuler' : 'Précédent'}
            </Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={() => setStep(step + 1)} disabled={!canContinue}>
                Continuer <ArrowRight className="h-4 w-4 ml-1.5" />
              </Button>
            ) : (
              <Button onClick={create} disabled={creating} className="gold-gradient text-[#0f172a] hover:opacity-90">
                {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Créer le projet
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
