'use client'

// GESCOM PROJECT – Paramètres : profil, préférences, personnalisation,
// sécurité, abonnement, notifications, données, aide, administration
import { useEffect, useState } from 'react'
import { apiGet, apiSend } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import type { SessionUser, UserPrefs } from '@/lib/types'
import { COUNTRIES, CURRENCIES } from '@/lib/constants'
import { fmtDateTime, fmtNumber } from '@/lib/format'
import {
  PLAN_LABELS, PLAN_FEATURES, PREMIUM_PRICE_MONTHLY, PREMIUM_PRICE_YEARLY,
  normalizePlan, isPremium, PLAN_PRICING, formatEur,
  type BillingPeriod,
} from '@/lib/plans'
import type { PaymentRecord } from '@/lib/types'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { useTheme } from 'next-themes'
import { LanguageSelect } from '@/components/gescom/LanguageLayer'
import {
  User, SlidersHorizontal, Palette, ShieldCheck, CreditCard, Bell,
  Database, LifeBuoy, Users, Loader2, MonitorSmartphone, Download, Trash2, LogOut, Crown,
  Check, Lock, Smartphone, Clock3, CheckCircle2, XCircle, Info, MailCheck,
} from 'lucide-react'

type SmtpStatus = {
  configured: boolean
  source: 'db' | 'env' | null
  host: string
  port: number
  secure: string
  user: string
  from: string
  hasPassword: boolean
}

export function SettingsView() {
  const { user, setUser } = useApp()
  const openCheckout = useApp((st) => st.openCheckout)
  const { toast } = useToast()
  const { theme, setTheme } = useTheme()

  // ----- Configuration e-mail (SMTP) – rôle ADMIN -----
  const [smtp, setSmtp] = useState<SmtpStatus | null>(null)
  const [smtpForm, setSmtpForm] = useState({ host: '', port: '587', user: '', pass: '', from: '' })
  const [smtpTestTo, setSmtpTestTo] = useState('')
  const [smtpBusy, setSmtpBusy] = useState<'save' | 'test' | 'clear' | null>(null)

  // ----- Abonnement (encaissement Mobile Money via FedaPay) -----
  const [changingPlan, setChangingPlan] = useState(false)
  const [billingInfo, setBillingInfo] = useState<{
    payments: PaymentRecord[]
    configured: boolean
    currency: string
    pricing: { MONTHLY: number; YEARLY: number }
  } | null>(null)

  // Retour de paiement (?payment=return&ref=…) : suit la confirmation puis
  // rafraîchit l'abonnement. L'URL est nettoyée après lecture.
  const [pendingReturnRef] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('payment') === 'return') {
      const ref = params.get('ref')
      window.history.replaceState(null, '', window.location.pathname)
      return ref
    }
    return null
  })
  const [pollingRef, setPollingRef] = useState<string | null>(pendingReturnRef)

  async function loadBillingInfo() {
    try {
      setBillingInfo(await apiGet('/api/account/plan/payments'))
    } catch {
      setBillingInfo({ payments: [], configured: false, currency: 'XOF', pricing: { MONTHLY: PREMIUM_PRICE_MONTHLY, YEARLY: PREMIUM_PRICE_YEARLY } })
    }
  }

  async function changePlan(plan: 'FREE' | 'PREMIUM', billing?: BillingPeriod) {
    setChangingPlan(true)
    try {
      const res = await apiSend<{ user: SessionUser }>('/api/account/plan', 'POST', { plan, billing })
      setUser(res.user)
      toast({
        title: plan === 'PREMIUM' ? 'Abonnement Premium activé' : 'Abonnement repassé en Gratuit',
        description: plan === 'PREMIUM'
          ? 'Tout le contenu de vos projets est désormais accessible.'
          : 'Vos données restent enregistrées et réapparaîtront après réactivation.',
      })
      void loadBillingInfo()
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Action impossible.', variant: 'destructive' })
    } finally {
      setChangingPlan(false)
    }
  }

  // Après paiement : vérifie la confirmation (webhook ou re-vérification
  // directe de FedaPay côté serveur) toutes les 3 s pendant 2 minutes.
  useEffect(() => {
    if (!pollingRef) return
    let cancelled = false
    let attempts = 0
    const check = async () => {
      if (cancelled) return
      try {
        const res = await apiSend<{ outcome: string; user: SessionUser }>('/api/account/plan/payments', 'POST', { reference: pollingRef })
        if (cancelled) return
        if (res.outcome === 'activated' || res.user?.plan === 'PREMIUM') {
          setUser(res.user)
          setPollingRef(null)
          toast({ title: 'Paiement confirmé 🎉', description: 'Votre abonnement Premium est actif. Merci !' })
          void loadBillingInfo()
          return
        }
        if (res.outcome === 'failed' || res.outcome === 'mismatch') {
          setPollingRef(null)
          void loadBillingInfo()
          return
        }
        if (res.outcome === 'unknown') {
          setPollingRef(null)
          return
        }
      } catch { /* réseau : on retentera */ }
      attempts += 1
      if (attempts < 40 && !cancelled) {
        setTimeout(check, 3000)
      } else if (!cancelled) {
        setPollingRef(null)
      }
    }
    void check()
    return () => { cancelled = true }
  }, [pollingRef])

  // ----- Profil -----
  const [profile, setProfile] = useState({
    firstName: '', lastName: '', phone: '', jobTitle: '', organization: '',
  })
  const [savingProfile, setSavingProfile] = useState(false)

  // ----- Préférences -----
  const [prefs, setPrefs] = useState<UserPrefs>({
    language: 'fr', country: 'Cameroun', currency: 'XAF',
    dateFormat: 'DD/MM/YYYY', timezone: 'Africa/Douala', theme: 'light',
    notifInApp: true, notifEmail: false, notifDeadlines: true,
  })

  // ----- Sécurité -----
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' })
  const [changingPw, setChangingPw] = useState(false)
  const [sessions, setSessions] = useState<Array<{ id: string; userAgent: string; createdAt: string; current: boolean }> | null>(null)
  const [logins, setLogins] = useState<Array<{ id: string; email: string; success: boolean; createdAt: string; userAgent: string }> | null>(null)

  // ----- Admin -----
  const [adminUsers, setAdminUsers] = useState<Array<{ id: string; email: string; firstName: string; lastName: string; role: string; plan: string; projectsCount: number; createdAt: string }> | null>(null)
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false)

  useEffect(() => {
    if (user) {
      setProfile({
        firstName: user.firstName, lastName: user.lastName,
        phone: user.phone || '', jobTitle: user.jobTitle || '', organization: user.organization || '',
      })
      setPrefs((p) => ({ ...p, ...user.prefs }))
    }
  }, [user])

  useEffect(() => {
    void apiGet<{ sessions: Array<{ id: string; userAgent: string; createdAt: string; current: boolean }>; logins: Array<{ id: string; email: string; success: boolean; createdAt: string; userAgent: string }> }>('/api/auth/sessions')
      .then((d) => { setSessions(d.sessions); setLogins(d.logins) })
      .catch(() => { setSessions([]); setLogins([]) })
    if (user?.role === 'ADMIN') {
      void apiGet<{ users: typeof adminUsers }>('/api/admin/users')
        .then((d) => setAdminUsers(d.users))
        .catch(() => setAdminUsers([]))
      void apiGet<SmtpStatus>('/api/admin/smtp')
        .then((s) => {
          setSmtp(s)
          setSmtpForm((f) => ({ ...f, host: s.host || '', port: String(s.port || 587), user: s.user || '', from: s.from || '' }))
        })
        .catch(() => setSmtp(null))
    }
    void loadBillingInfo()
  }, [])

  async function saveSmtp() {
    setSmtpBusy('save')
    try {
      const s = await apiSend<SmtpStatus>('/api/admin/smtp', 'PUT', {
        host: smtpForm.host,
        port: Number(smtpForm.port),
        user: smtpForm.user,
        pass: smtpForm.pass,
        from: smtpForm.from,
      })
      setSmtp(s)
      setSmtpForm((f) => ({ ...f, pass: '' }))
      toast({
        title: 'Configuration e-mail enregistrée',
        description: 'Les codes d\'activation et de réinitialisation partiront désormais directement dans la boîte mail des utilisateurs.',
      })
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Enregistrement impossible.', variant: 'destructive' })
    } finally {
      setSmtpBusy(null)
    }
  }

  async function testSmtp() {
    setSmtpBusy('test')
    try {
      const d = await apiSend<{ ok: boolean; to: string }>('/api/admin/smtp', 'POST', {
        host: smtpForm.host,
        port: Number(smtpForm.port),
        user: smtpForm.user,
        pass: smtpForm.pass,
        from: smtpForm.from,
        to: smtpTestTo || undefined,
      })
      toast({ title: 'E-mail de test envoyé ✓', description: `Vérifiez la boîte ${d.to} (et le dossier spam).` })
    } catch (err) {
      toast({ title: 'Test en échec', description: err instanceof Error ? err.message : 'Envoi impossible.', variant: 'destructive' })
    } finally {
      setSmtpBusy(null)
    }
  }

  async function clearSmtp() {
    setSmtpBusy('clear')
    try {
      const s = await apiSend<SmtpStatus>('/api/admin/smtp', 'DELETE')
      setSmtp(s)
      toast({ title: 'Configuration supprimée', description: 'Retour au mode démonstration : le code est affiché à l\'écran.' })
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Suppression impossible.', variant: 'destructive' })
    } finally {
      setSmtpBusy(null)
    }
  }

  async function saveProfile() {
    setSavingProfile(true)
    try {
      const d = await apiSend<{ user: SessionUser }>('/api/settings/profile', 'PATCH', profile)
      setUser(d.user)
      toast({ title: 'Profil enregistré' })
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Enregistrement impossible.', variant: 'destructive' })
    } finally {
      setSavingProfile(false)
    }
  }

  async function savePrefs(next: Partial<UserPrefs>) {
    const merged = { ...prefs, ...next }
    setPrefs(merged)
    if (next.theme) setTheme(next.theme)
    try {
      const d = await apiSend<{ user: SessionUser }>('/api/settings/prefs', 'PATCH', merged)
      setUser(d.user)
    } catch {
      toast({ title: 'Erreur', description: 'Préférences non enregistrées.', variant: 'destructive' })
    }
  }

  async function changePassword() {
    if (pw.next !== pw.confirm) {
      toast({ title: 'Erreur', description: 'Les deux mots de passe ne correspondent pas.', variant: 'destructive' })
      return
    }
    setChangingPw(true)
    try {
      await apiSend('/api/auth/password', 'POST', { currentPassword: pw.current, newPassword: pw.next })
      toast({ title: 'Mot de passe modifié', description: 'Veuillez vous reconnecter avec votre nouveau mot de passe.' })
      setTimeout(() => window.location.reload(), 1500)
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Changement impossible.', variant: 'destructive' })
    } finally {
      setChangingPw(false)
    }
  }

  async function revokeSession(id: string) {
    try {
      await apiSend('/api/auth/sessions', 'DELETE', { id })
      toast({ title: 'Session révoquée' })
      const d = await apiGet<{ sessions: typeof sessions; logins: typeof logins }>('/api/auth/sessions')
      setSessions(d.sessions); setLogins(d.logins)
    } catch {
      toast({ title: 'Erreur', description: 'Révocation impossible.', variant: 'destructive' })
    }
  }

  async function revokeOthers() {
    try {
      await apiSend('/api/auth/sessions', 'DELETE', { others: true })
      toast({ title: 'Autres sessions révoquées' })
      const d = await apiGet<{ sessions: typeof sessions; logins: typeof logins }>('/api/auth/sessions')
      setSessions(d.sessions); setLogins(d.logins)
    } catch {
      toast({ title: 'Erreur', description: 'Action impossible.', variant: 'destructive' })
    }
  }

  async function deleteAllProjects() {
    try {
      const d = await apiGet<{ projects: Array<{ id: string }> }>('/api/projects')
      for (const p of d.projects) {
        await apiSend(`/api/projects/${p.id}`, 'DELETE')
      }
      toast({ title: 'Tous vos projets ont été supprimés' })
      setConfirmDeleteAll(false)
    } catch {
      toast({ title: 'Erreur', description: 'Suppression impossible.', variant: 'destructive' })
    }
  }

  const initials = user ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`.toUpperCase() : 'GP'

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto">
      <Tabs defaultValue={pendingReturnRef ? 'billing' : 'profile'} className="space-y-5">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted/60 p-1">
          <TabsTrigger value="profile" className="gap-1.5"><User className="h-3.5 w-3.5" /> Profil</TabsTrigger>
          <TabsTrigger value="prefs" className="gap-1.5"><SlidersHorizontal className="h-3.5 w-3.5" /> Préférences</TabsTrigger>
          <TabsTrigger value="security" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Sécurité</TabsTrigger>
          <TabsTrigger value="billing" className="gap-1.5"><CreditCard className="h-3.5 w-3.5" /> Abonnement</TabsTrigger>
          <TabsTrigger value="data" className="gap-1.5"><Database className="h-3.5 w-3.5" /> Données</TabsTrigger>
          <TabsTrigger value="help" className="gap-1.5"><LifeBuoy className="h-3.5 w-3.5" /> Aide</TabsTrigger>
          {user?.role === 'ADMIN' && <TabsTrigger value="admin" className="gap-1.5"><Users className="h-3.5 w-3.5" /> Administration</TabsTrigger>}
          {user?.role === 'ADMIN' && <TabsTrigger value="email" className="gap-1.5"><MailCheck className="h-3.5 w-3.5" /> E-mail</TabsTrigger>}
        </TabsList>

        {/* -------- Profil -------- */}
        <TabsContent value="profile" className="space-y-5">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Informations personnelles</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full gold-gradient flex items-center justify-center text-xl font-black text-[#0f172a]">
                  {initials}
                </div>
                <div>
                  <div className="font-semibold">{user?.firstName} {user?.lastName}</div>
                  <div className="text-sm text-muted-foreground">{user?.email}</div>
                  <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                    <Badge variant="secondary">{user?.role === 'ADMIN' ? 'Administrateur' : 'Utilisateur'}</Badge>
                    {user?.emailVerified ? (
                      <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-100">
                        <MailCheck className="h-3 w-3 mr-1" /> E-mail vérifié
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-amber-700 border-amber-300 bg-amber-50">E-mail non vérifié</Badge>
                    )}
                  </div>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Prénom</Label>
                  <Input value={profile.firstName} onChange={(e) => setProfile({ ...profile, firstName: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Nom</Label>
                  <Input value={profile.lastName} onChange={(e) => setProfile({ ...profile, lastName: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Téléphone</Label>
                  <Input value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} placeholder="+237 6 90 00 00 00" />
                </div>
                <div className="space-y-1.5">
                  <Label>Fonction</Label>
                  <Input value={profile.jobTitle} onChange={(e) => setProfile({ ...profile, jobTitle: e.target.value })} />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label>Organisation</Label>
                  <Input value={profile.organization} onChange={(e) => setProfile({ ...profile, organization: e.target.value })} />
                </div>
              </div>
              <Button onClick={saveProfile} disabled={savingProfile}>
                {savingProfile && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Enregistrer
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* -------- Préférences -------- */}
        <TabsContent value="prefs" className="space-y-5">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Préférences générales</CardTitle></CardHeader>
            <CardContent className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Langue de l&apos;interface</Label>
                <LanguageSelect />
                <p className="text-[11px] text-muted-foreground">L&apos;anglais est disponible en seconde langue ; d&apos;autres langues suivront.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Pays par défaut</Label>
                <Select value={prefs.country} onValueChange={(v) => savePrefs({ country: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Devise par défaut</Label>
                <Select value={prefs.currency} onValueChange={(v) => savePrefs({ currency: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CURRENCIES.map((c) => <SelectItem key={c.code} value={c.code}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Format de date</Label>
                <Select value={prefs.dateFormat} onValueChange={(v) => savePrefs({ dateFormat: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DD/MM/YYYY">JJ/MM/AAAA</SelectItem>
                    <SelectItem value="MM/DD/YYYY">MM/JJ/AAAA</SelectItem>
                    <SelectItem value="YYYY-MM-DD">AAAA-MM-JJ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Fuseau horaire</Label>
                <Select value={prefs.timezone} onValueChange={(v) => savePrefs({ timezone: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Africa/Douala', 'Africa/Lagos', 'Africa/Abidjan', 'Europe/Paris', 'America/Montreal'].map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Thème de l&apos;interface</Label>
                <Select value={theme === 'dark' ? 'dark' : 'light'} onValueChange={(v) => savePrefs({ theme: v as UserPrefs['theme'] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Clair</SelectItem>
                    <SelectItem value="dark">Sombre</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><Bell className="h-4 w-4" /> Notifications</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <PrefSwitch
                label="Notifications dans l'application"
                desc="Confirmations, alertes et confirmations d'enregistrement"
                checked={prefs.notifInApp}
                onChange={(v) => savePrefs({ notifInApp: v })}
              />
              <PrefSwitch
                label="Rappels d'échéances du plan d'action"
                desc="Signale les tâches en retard dans le tableau de bord"
                checked={prefs.notifDeadlines}
                onChange={(v) => savePrefs({ notifDeadlines: v })}
              />
              <PrefSwitch
                label="Notifications par e-mail"
                desc="Bientôt disponible — fonctionnalité en préparation"
                checked={prefs.notifEmail}
                onChange={(v) => savePrefs({ notifEmail: v })}
                disabled
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* -------- Sécurité -------- */}
        <TabsContent value="security" className="space-y-5">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Changer le mot de passe</CardTitle></CardHeader>
            <CardContent className="space-y-4 max-w-md">
              <div className="space-y-1.5">
                <Label>Mot de passe actuel</Label>
                <Input type="password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Nouveau mot de passe</Label>
                <Input type="password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
                <p className="text-xs text-muted-foreground">8 caractères minimum, une lettre et un chiffre.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Confirmer le nouveau mot de passe</Label>
                <Input type="password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
              </div>
              <Button onClick={changePassword} disabled={changingPw || !pw.current || !pw.next}>
                {changingPw && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Modifier le mot de passe
              </Button>
              <p className="text-xs text-muted-foreground">Après modification, toutes vos sessions sont révoquées par sécurité.</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><MonitorSmartphone className="h-4 w-4" /> Sessions actives</CardTitle>
              {sessions && sessions.length > 1 && (
                <Button variant="outline" size="sm" className="ml-auto" onClick={revokeOthers}>
                  <LogOut className="h-3.5 w-3.5 mr-1.5" /> Révoquer les autres
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {sessions === null ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <ul className="divide-y">
                  {sessions.map((s) => (
                    <li key={s.id} className="flex items-center gap-3 py-3">
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate">{s.userAgent || 'Appareil inconnu'}</div>
                        <div className="text-xs text-muted-foreground">Connecté le {fmtDateTime(s.createdAt)}</div>
                      </div>
                      {s.current ? (
                        <Badge variant="outline" className="border-emerald-300 text-emerald-700 bg-emerald-50">Session actuelle</Badge>
                      ) : (
                        <Button variant="outline" size="sm" onClick={() => revokeSession(s.id)}>Révoquer</Button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Historique des connexions (10 dernières)</CardTitle></CardHeader>
            <CardContent>
              {logins === null ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : logins.length === 0 ? (
                <p className="text-sm text-muted-foreground">Aucun événement enregistré.</p>
              ) : (
                <ul className="divide-y">
                  {logins.map((l) => (
                    <li key={l.id} className="flex items-center gap-3 py-2.5 text-sm">
                      <Badge variant="outline" className={l.success ? 'border-emerald-300 text-emerald-700' : 'border-red-300 text-red-700'}>
                        {l.success ? 'Réussie' : 'Échec'}
                      </Badge>
                      <span className="text-muted-foreground">{l.email}</span>
                      <span className="ml-auto text-xs text-muted-foreground">{fmtDateTime(l.createdAt)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* -------- Abonnement -------- */}
        <TabsContent value="billing" className="space-y-5">
          {/* Suivi d'un paiement en cours (retour de la page FedaPay) */}
          {pollingRef && (
            <Alert className="border-[#d4a72c]/50 bg-[#d4a72c]/10">
              <Loader2 className="h-4 w-4 animate-spin text-[#d4a72c]" />
              <AlertDescription className="text-sm">
                <span className="font-medium">Confirmation de votre paiement en cours…</span>
                <br />Dès que FedaPay valide la transaction (réf. {pollingRef}), votre abonnement Premium s&apos;active automatiquement. Cette page peut être fermée et rouverte sans risque.
              </AlertDescription>
            </Alert>
          )}

          {/* Abonnement actuel */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Crown className="h-4 w-4 text-[#d4a72c]" /> Mon abonnement</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-xl border border-[#d4a72c]/40 bg-accent/40 p-5 flex items-center justify-between flex-wrap gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-lg">{PLAN_LABELS[normalizePlan(user?.plan)]}</span>
                    <Badge className={isPremium(user?.plan) ? 'gold-gradient text-[#0f172a] border-0' : ''}>
                      {isPremium(user?.plan) ? 'Actif' : 'Gratuit — 0 FCFA'}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground mt-0.5">
                    {isPremium(user?.plan)
                      ? user?.planExpiresAt
                        ? `Accès complet jusqu'au ${fmtDateTime(user.planExpiresAt).split(' ')[0]} inclus — pensez à renouveler avant cette date pour conserver vos avantages.`
                        : 'Vous avez accès à tout le contenu : risques, financement, ventes, compte de résultat, indicateurs, scénarios et exports complets.'
                      : 'Vous utilisez le plan Gratuit. Passez au Premium pour débloquer tout le contenu de vos projets.'}
                  </div>
                </div>
                {!isPremium(user?.plan) && (
                  <Button
                    className="bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
                    onClick={() => openCheckout('MONTHLY')}
                  >
                    <Crown className="h-4 w-4 mr-1.5" /> Passer à Premium
                  </Button>
                )}
              </div>
              {isPremium(user?.plan) && (
                <div>
                  <Button variant="outline" size="sm" onClick={() => void changePlan('FREE')} disabled={changingPlan}>
                    Revenir au plan Gratuit
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2">Vos données restent enregistrées : elles réapparaîtront si vous réactivez Premium.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Paiement Mobile Money (encaissement réel via FedaPay) */}
          {!isPremium(user?.plan) && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2"><Smartphone className="h-4 w-4 text-[#0f172a] dark:text-[#d4a72c]" /> Informations et paiement</CardTitle>
                <p className="text-xs text-muted-foreground font-normal">
                  Formulaire de renseignement puis page de paiement sécurisée (FedaPay) : Mobile Money de votre pays
                  (MTN MoMo, Moov, Orange Money, Wave, T-Money, Airtel, M-Pesa…) ou carte bancaire Visa/Mastercard
                  depuis l&apos;Europe. Montants affichés en FCFA et en euro.
                </p>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid sm:grid-cols-2 gap-3">
                  {(['MONTHLY', 'YEARLY'] as BillingPeriod[]).map((period) => {
                    const amount = billingInfo?.pricing?.[period] ?? PLAN_PRICING[period].amount
                    return (
                      <div key={period} className={period === 'YEARLY' ? 'rounded-xl border border-[#d4a72c]/50 p-4 relative' : 'rounded-xl border p-4 relative'}>
                        {period === 'YEARLY' && (
                          <div className="absolute top-0 right-0 bg-[#d4a72c] text-[#0f172a] text-[10px] font-bold px-2.5 py-1 rounded-bl-lg">2 MOIS OFFERTS</div>
                        )}
                        <div className="text-sm font-medium">{PLAN_PRICING[period].label}</div>
                        <div className="text-xl font-bold mt-1">{fmtNumber(amount)} FCFA
                          <span className="text-xs font-normal text-muted-foreground ml-1">≈ {formatEur(amount)}</span>
                          <span className="text-xs font-normal text-muted-foreground ml-1">{period === 'MONTHLY' ? '/ mois' : '/ an'}</span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">{PLAN_PRICING[period].detail}</div>
                        <Button
                          className="mt-3 w-full bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
                          onClick={() => openCheckout(period)}
                        >
                          <><Smartphone className="h-4 w-4 mr-1.5" /> Renseigner et payer</>
                        </Button>
                      </div>
                    )
                  })}
                </div>
                {!billingInfo?.configured && (
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription className="text-xs leading-relaxed">
                      Pour encaisser réellement, ajoutez la clé secrète FedaPay sur le serveur (variable <code className="font-mono text-[11px] bg-muted px-1 rounded">FEDAPAY_SECRET_KEY</code>)
                      et configurez le webhook <code className="font-mono text-[11px] bg-muted px-1 rounded">/api/payments/webhook</code> dans le tableau de bord FedaPay.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Historique des paiements */}
          {billingInfo && billingInfo.payments.length > 0 && (
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Historique des paiements</CardTitle></CardHeader>
              <CardContent>
                <ul className="divide-y text-sm">
                  {billingInfo.payments.map((p) => (
                    <li key={p.id} className="flex items-center gap-3 py-2.5">
                      {p.status === 'SUCCEEDED'
                        ? <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                        : p.status === 'FAILED'
                          ? <XCircle className="h-4 w-4 text-red-500 shrink-0" />
                          : <Clock3 className="h-4 w-4 text-muted-foreground shrink-0" />}
                      <div className="min-w-0">
                        <div className="font-medium">Premium {p.billing === 'YEARLY' ? 'annuel' : 'mensuel'} — {fmtNumber(p.amount)} FCFA</div>
                        <div className="text-xs text-muted-foreground">Réf. {p.reference} · {fmtDateTime(p.createdAt)}</div>
                      </div>
                      <Badge
                        variant="outline"
                        className={p.status === 'SUCCEEDED' ? 'ml-auto border-emerald-300 text-emerald-700' : p.status === 'FAILED' ? 'ml-auto border-red-300 text-red-700' : 'ml-auto border-muted-foreground/30 text-muted-foreground'}
                      >
                        {p.status === 'SUCCEEDED' ? 'Payé' : p.status === 'FAILED' ? 'Échoué' : 'En attente'}
                      </Badge>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Comparatif des deux plans */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className={isPremium(user?.plan) ? '' : 'border-[#d4a72c]/50'}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Gratuit</CardTitle>
                <div className="text-2xl font-bold">0 FCFA <span className="text-xs font-normal text-muted-foreground">pour toujours</span></div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  {PLAN_FEATURES.map((f) => (
                    <li key={f.label} className="flex items-start gap-2">
                      {f.free
                        ? <Check className="h-4 w-4 mt-0.5 text-emerald-600 shrink-0" />
                        : <Lock className="h-3.5 w-3.5 mt-1 text-muted-foreground/60 shrink-0" />}
                      <span className={f.free ? '' : 'text-muted-foreground'}>{f.label}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-[#d4a72c]/60 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-[#d4a72c] text-[#0f172a] text-[10px] font-bold px-2.5 py-1 rounded-bl-lg">TOUT LE CONTENU</div>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-1.5"><Crown className="h-4 w-4 text-[#d4a72c]" /> Premium</CardTitle>
                <div className="text-2xl font-bold">
                  {fmtNumber(PREMIUM_PRICE_MONTHLY)} FCFA <span className="text-xs font-normal text-muted-foreground">/ mois</span>
                </div>
                <div className="text-xs text-muted-foreground">ou {fmtNumber(PREMIUM_PRICE_YEARLY)} FCFA / an ≈ {formatEur(PREMIUM_PRICE_YEARLY)} (2 mois offerts)</div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  {PLAN_FEATURES.map((f) => (
                    <li key={f.label} className="flex items-start gap-2">
                      <Check className="h-4 w-4 mt-0.5 text-emerald-600 shrink-0" />
                      <span>{f.label}</span>
                    </li>
                  ))}
                </ul>
                {!isPremium(user?.plan) && (
                  <Button
                    className="mt-4 w-full bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
                    onClick={() => openCheckout('MONTHLY')}
                  >
                    <><Smartphone className="h-4 w-4 mr-1.5" /> Choisir mon moyen de paiement</>
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* -------- Données -------- */}
        <TabsContent value="data" className="space-y-5">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Export & portabilité</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Téléchargez l&apos;intégralité de vos données (projets, analyses, finances, tâches) au format JSON.
              </p>
              <Button variant="outline" onClick={() => { window.location.href = '/api/settings/export-data' }}>
                <Download className="h-4 w-4 mr-2" /> Exporter mes données (JSON)
              </Button>
            </CardContent>
          </Card>
          <Card className="border-red-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-red-700">Zone sensible</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Supprimer définitivement <strong>tous vos projets</strong> (analyses, finances, tâches et
                documents générés). Cette action est irréversible : exportez vos données avant.
              </p>
              <Button variant="destructive" onClick={() => setConfirmDeleteAll(true)}>
                <Trash2 className="h-4 w-4 mr-2" /> Supprimer tous mes projets
              </Button>
            </CardContent>
          </Card>

          <AlertDialog open={confirmDeleteAll} onOpenChange={setConfirmDeleteAll}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Supprimer tous vos projets ?</AlertDialogTitle>
                <AlertDialogDescription>
                  Toutes vos données de projets seront définitivement effacées. Cette action est
                  irréversible.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annuler</AlertDialogCancel>
                <AlertDialogAction onClick={deleteAllProjects} className="bg-destructive text-white hover:bg-destructive/90">
                  Tout supprimer définitivement
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </TabsContent>

        {/* -------- Aide -------- */}
        <TabsContent value="help" className="space-y-5">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Centre d'aide</CardTitle></CardHeader>
            <CardContent className="space-y-4 text-sm">
              <HelpItem q="Par où commencer ?">
                Créez un projet via « Nouveau projet » (5 étapes guidées), puis enrichissez-le module par
                module : Analyse → Finance → Plan d'action → Documents. Le compte de démonstration
                (demo@gescom.pro) contient un projet complet à explorer.
              </HelpItem>
              <HelpItem q="Comment sont calculés la VAN et le TRI ?">
                Les flux du projet (avant financement) sont actualisés au taux que vous définissez dans
                Finance → Exploitation. Le TRI est résolu par dichotomie ; le délai de récupération est
                interpolé sur les flux cumulés. Les mêmes calculs alimentent les exports PDF, Word, Excel
                et PowerPoint : impossible d'avoir des chiffres contradictoires.
              </HelpItem>
              <HelpItem q="Mes données de marché sont-elles fiables ?">
                GESCOM PROJECT n'insère jamais de statistiques inventées. Les données de démonstration
                sont explicitement illustratives. Renseignez vos propres chiffres et validez-les par une
                enquête terrain avant de présenter votre dossier.
              </HelpItem>
              <HelpItem q="Le fichier Excel garde-t-il les formules ?">
                Oui : hypothèses, compte de résultat, flux, VAN (=NPV) et TRI (=IRR) sont des formules
                Excel natives. Modifiez les hypothèses dans les feuilles et tout se recalcule.
              </HelpItem>
              <HelpItem q="Comment signaler un problème ?">
                Décrivez le problème depuis la page de contact de votre organisation, ou notez-le dans vos
                retours produits. Le journal d'activité (Tableau de bord) aide à reproduire les étapes.
              </HelpItem>
            </CardContent>
          </Card>
        </TabsContent>

        {/* -------- E-mail (configuration SMTP, rôle ADMIN) -------- */}
        {user?.role === 'ADMIN' && (
          <TabsContent value="email" className="space-y-5">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between gap-2 flex-wrap">
                  <span>Envoi des codes d'activation par e-mail</span>
                  <Badge
                    variant="secondary"
                    className={
                      smtp === null
                        ? ''
                        : smtp.configured
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                    }
                  >
                    {smtp === null ? 'Chargement…' : smtp.configured
                      ? (smtp.source === 'db' ? 'Configuré (via cette page)' : 'Configuré (via le serveur)')
                      : 'Mode démonstration'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Renseignez ici un compte d'envoi SMTP (Gmail avec mot de passe d'application, Brevo, etc.).
                  Dès qu'une configuration valide est enregistrée, les codes d'activation et de réinitialisation
                  partent <strong>directement dans la boîte mail des utilisateurs</strong> — le bandeau « mode
                  démonstration » disparaît. Astuce : testez l'envoi <strong>avant</strong> d'enregistrer.
                </p>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="smtpHost">Serveur SMTP</Label>
                    <Input
                      id="smtpHost"
                      placeholder="smtp.gmail.com"
                      value={smtpForm.host}
                      onChange={(e) => setSmtpForm((f) => ({ ...f, host: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="smtpPort">Port et chiffrement</Label>
                    <Select value={smtpForm.port} onValueChange={(v) => setSmtpForm((f) => ({ ...f, port: v }))}>
                      <SelectTrigger id="smtpPort"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="465">465 — TLS direct (recommandé)</SelectItem>
                        <SelectItem value="587">587 — STARTTLS</SelectItem>
                        <SelectItem value="25">25 — non chiffré (déconseillé)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="smtpUser">Identifiant (adresse d'envoi)</Label>
                    <Input
                      id="smtpUser"
                      type="email"
                      placeholder="no-reply@votredomaine.com"
                      value={smtpForm.user}
                      onChange={(e) => setSmtpForm((f) => ({ ...f, user: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="smtpPass">Mot de passe d'application</Label>
                    <Input
                      id="smtpPass"
                      type="password"
                      placeholder={smtp?.hasPassword ? '•••••••• (inchangé si vide)' : '16 caractères pour Gmail'}
                      value={smtpForm.pass}
                      onChange={(e) => setSmtpForm((f) => ({ ...f, pass: e.target.value }))}
                      autoComplete="new-password"
                    />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="smtpFrom">Expéditeur affiché (optionnel)</Label>
                    <Input
                      id="smtpFrom"
                      placeholder={`GESCOM PROJECT <${smtpForm.user || 'no-reply@votredomaine.com'}>`}
                      value={smtpForm.from}
                      onChange={(e) => setSmtpForm((f) => ({ ...f, from: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="smtpTestTo">Envoyer l'e-mail de test à (optionnel — votre adresse par défaut)</Label>
                    <Input
                      id="smtpTestTo"
                      type="email"
                      placeholder={user?.email}
                      value={smtpTestTo}
                      onChange={(e) => setSmtpTestTo(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    onClick={testSmtp}
                    disabled={smtpBusy !== null || !smtpForm.host || !smtpForm.user}
                  >
                    {smtpBusy === 'test' ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <MailCheck className="h-4 w-4 mr-2" />}
                    Envoyer un e-mail de test
                  </Button>
                  <Button
                    onClick={saveSmtp}
                    disabled={smtpBusy !== null || !smtpForm.host || !smtpForm.user}
                    className="gold-gradient text-[#0f172a] hover:opacity-90 border-0"
                  >
                    {smtpBusy === 'save' ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                    Enregistrer la configuration
                  </Button>
                  {smtp?.source === 'db' && (
                    <Button
                      variant="ghost"
                      onClick={clearSmtp}
                      disabled={smtpBusy !== null}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      {smtpBusy === 'clear' ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Trash2 className="h-4 w-4 mr-2" />}
                      Revenir au mode démonstration
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Quel compte d'envoi choisir&nbsp;?</CardTitle></CardHeader>
              <CardContent className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                <div className="rounded-lg border p-4 space-y-1.5">
                  <div className="font-semibold text-foreground">Option 1 — Gmail (gratuit, rapide)</div>
                  <p>
                    Activez la validation en deux étapes sur le compte Google d'envoi, puis créez un «&nbsp;mot de
                    passe d'application&nbsp;» (myaccount.google.com → Sécurité → Mots de passe d'application).
                    Saisissez&nbsp;: serveur <code className="font-mono text-xs bg-muted px-1 rounded">smtp.gmail.com</code>,
                    port <code className="font-mono text-xs bg-muted px-1 rounded">465</code>, identifiant = votre
                    adresse Gmail, mot de passe = le mot de passe d'application à 16 caractères.
                  </p>
                </div>
                <div className="rounded-lg border p-4 space-y-1.5">
                  <div className="font-semibold text-foreground">Option 2 — Brevo (300 e-mails/jour gratuits)</div>
                  <p>
                    Créez un compte sur brevo.com, validez votre expéditeur, puis copiez votre clé SMTP
                    (SMTP&nbsp;&amp;&nbsp;API → Clés SMTP). Saisissez&nbsp;: serveur{' '}
                    <code className="font-mono text-xs bg-muted px-1 rounded">smtp-relay.brevo.com</code>, port{' '}
                    <code className="font-mono text-xs bg-muted px-1 rounded">587</code>, identifiant = votre e-mail
                    Brevo, mot de passe = la clé SMTP.
                  </p>
                </div>
                <p className="text-xs">
                  Astuce délivrabilité&nbsp;: après enregistrement, ajoutez un enregistrement SPF sur le domaine de
                  l'expéditeur pour éviter que les codes n'arrivent dans les spams.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* -------- Administration -------- */}
        {user?.role === 'ADMIN' && (
          <TabsContent value="admin" className="space-y-5">
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Gestion des utilisateurs</CardTitle></CardHeader>
              <CardContent>
                {adminUsers === null ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b text-left text-xs text-muted-foreground">
                          <th className="py-2 pr-3">Utilisateur</th>
                          <th className="py-2 pr-3">Rôle</th>
                          <th className="py-2 pr-3">Abonnement</th>
                          <th className="py-2 pr-3">Projets</th>
                          <th className="py-2">Inscription</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {adminUsers.map((u) => (
                          <tr key={u.id}>
                            <td className="py-2.5 pr-3">
                              <div className="font-medium">{u.firstName} {u.lastName}</div>
                              <div className="text-xs text-muted-foreground">{u.email}</div>
                            </td>
                            <td className="py-2.5 pr-3">
                              {u.id === user.id ? (
                                <Badge variant="secondary">{u.role === 'ADMIN' ? 'Administrateur' : 'Utilisateur'}</Badge>
                              ) : (
                                <Select value={u.role} onValueChange={async (v) => {
                                  try {
                                    await apiSend('/api/admin/users', 'PATCH', { id: u.id, role: v })
                                    setAdminUsers((list) => list && list.map((x) => x.id === u.id ? { ...x, role: v } : x))
                                    toast({ title: 'Rôle mis à jour' })
                                  } catch (err) {
                                    toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Action impossible.', variant: 'destructive' })
                                  }
                                }}>
                                  <SelectTrigger className="h-8 w-[150px] text-xs"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="USER">Utilisateur</SelectItem>
                                    <SelectItem value="ADMIN">Administrateur</SelectItem>
                                  </SelectContent>
                                </Select>
                              )}
                            </td>
                            <td className="py-2.5 pr-3">
                              <Select value={normalizePlan(u.plan)} onValueChange={async (v) => {
                                try {
                                  await apiSend('/api/admin/users', 'PATCH', { id: u.id, plan: v })
                                  setAdminUsers((list) => list && list.map((x) => x.id === u.id ? { ...x, plan: v } : x))
                                  toast({ title: v === 'PREMIUM' ? 'Abonnement Premium accordé' : 'Abonnement repassé en Gratuit' })
                                } catch (err) {
                                  toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Action impossible.', variant: 'destructive' })
                                }
                              }}>
                                <SelectTrigger className="h-8 w-[130px] text-xs"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="FREE">Gratuit</SelectItem>
                                  <SelectItem value="PREMIUM">Premium</SelectItem>
                                </SelectContent>
                              </Select>
                            </td>
                            <td className="py-2.5 pr-3">{u.projectsCount}</td>
                            <td className="py-2.5 text-xs text-muted-foreground">{fmtDateTime(u.createdAt)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}

function PrefSwitch({ label, desc, checked, onChange, disabled }: {
  label: string; desc: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} disabled={disabled} />
    </div>
  )
}

function HelpItem({ q, children }: { q: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border p-4">
      <div className="font-semibold text-sm">{q}</div>
      <p className="text-muted-foreground mt-1.5 leading-relaxed">{children}</p>
    </div>
  )
}
