'use client'

// GESCOM PROJECT – Liste des projets
import { useEffect, useMemo, useState } from 'react'
import { apiGet, apiSend, ApiError } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import { fmtDate } from '@/lib/format'
import { PROJECT_STATUS_LABELS, PROJECT_STATUS_BADGE } from '@/lib/constants'
import type { ValidationReport } from '@/lib/validation'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { useToast } from '@/hooks/use-toast'
import {
  Search, MoreVertical, FolderPlus, Copy, Archive, Trash2, FolderOpen, ChartPie, Loader2,
  CheckCircle2, RotateCcw, ShieldAlert, TriangleAlert,
} from 'lucide-react'

interface ProjectListItem {
  id: string
  name: string
  idea: string
  sector: string
  type: string
  country: string
  currency: string
  status: string
  updatedAt: string
  tasksCount: number
  docsCount: number
  progress: number
}

const statusColor: Record<string, string> = PROJECT_STATUS_BADGE

export function ProjectsView() {
  const { navigate, openProject } = useApp()
  const { toast } = useToast()
  const [projects, setProjects] = useState<ProjectListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [sectorFilter, setSectorFilter] = useState('ALL')
  const [sort, setSort] = useState('UPDATED_DESC')
  const [deleteTarget, setDeleteTarget] = useState<ProjectListItem | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  // Refus de « Terminé » : projet non validé par Gescom Project ⇒
  // on affiche le rapport de validation et le chemin de correction.
  const [blockedCompletion, setBlockedCompletion] = useState<{ project: ProjectListItem; report: ValidationReport } | null>(null)

  async function load() {
    setLoading(true)
    try {
      const d = await apiGet<{ projects: ProjectListItem[] }>('/api/projects')
      setProjects(d.projects)
    } catch {
      toast({ title: 'Erreur', description: 'Impossible de charger les projets.', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void load()
  }, [])

  const sectors = useMemo(() => Array.from(new Set(projects.map((p) => p.sector).filter(Boolean))), [projects])

  const filtered = useMemo(() => {
    let list = [...projects]
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter((p) => p.name.toLowerCase().includes(q) || p.idea.toLowerCase().includes(q) || p.sector.toLowerCase().includes(q))
    }
    if (statusFilter !== 'ALL') list = list.filter((p) => p.status === statusFilter)
    if (sectorFilter !== 'ALL') list = list.filter((p) => p.sector === sectorFilter)
    switch (sort) {
      case 'UPDATED_DESC': list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); break
      case 'UPDATED_ASC': list.sort((a, b) => a.updatedAt.localeCompare(b.updatedAt)); break
      case 'NAME_ASC': list.sort((a, b) => a.name.localeCompare(b.name)); break
      case 'PROGRESS_DESC': list.sort((a, b) => b.progress - a.progress); break
    }
    return list
  }, [projects, search, statusFilter, sectorFilter, sort])

  async function duplicate(p: ProjectListItem) {
    setBusy(p.id)
    try {
      await apiSend(`/api/projects/${p.id}/duplicate`, 'POST')
      toast({ title: 'Projet dupliqué', description: `${p.name} (copie) a été créé.` })
      await load()
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Duplication impossible.', variant: 'destructive' })
    } finally {
      setBusy(null)
    }
  }

  async function toggleArchive(p: ProjectListItem) {
    setBusy(p.id)
    try {
      const next = p.status === 'ARCHIVED' ? 'ONGOING' : 'ARCHIVED'
      await apiSend(`/api/projects/${p.id}`, 'PATCH', { status: next })
      toast({ title: next === 'ARCHIVED' ? 'Projet archivé' : 'Projet désarchivé' })
      await load()
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Action impossible.', variant: 'destructive' })
    } finally {
      setBusy(null)
    }
  }

  // Marquer un projet comme terminé — ou le remettre « en cours ».
  // Règle Gescom Project : « Terminé » est réservé aux projets VALIDÉS ;
  // en cas de refus serveur (403 + rapport), on ouvre la boîte de dialogue
  // des corrections et le projet reste « En cours ».
  async function toggleCompleted(p: ProjectListItem) {
    setBusy(p.id)
    const next = p.status === 'COMPLETED' ? 'ONGOING' : 'COMPLETED'
    try {
      await apiSend(`/api/projects/${p.id}`, 'PATCH', { status: next })
      toast({
        title: next === 'COMPLETED' ? 'Projet terminé 🎉' : 'Projet remis en cours',
        description: next === 'COMPLETED'
          ? `« ${p.name} » est validé par Gescom Project et confirmé « Terminé ».`
          : `« ${p.name} » est maintenant « ${PROJECT_STATUS_LABELS[next]} ».`,
      })
      await load()
    } catch (err) {
      if (err instanceof ApiError && err.status === 403 && err.payload?.validation) {
        setBlockedCompletion({ project: p, report: err.payload.validation as ValidationReport })
      } else {
        toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Action impossible.', variant: 'destructive' })
      }
    } finally {
      setBusy(null)
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return
    setBusy(deleteTarget.id)
    try {
      await apiSend(`/api/projects/${deleteTarget.id}`, 'DELETE')
      toast({ title: 'Projet supprimé' })
      setDeleteTarget(null)
      await load()
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Suppression impossible.', variant: 'destructive' })
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="p-4 lg:p-8 space-y-5 max-w-7xl mx-auto">
      {/* Barre d'outils */}
      <div className="flex flex-col lg:flex-row gap-3 lg:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Rechercher un projet, une idée, un secteur…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]"><SelectValue placeholder="Statut" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous les statuts</SelectItem>
              {Object.entries(PROJECT_STATUS_LABELS).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sectorFilter} onValueChange={setSectorFilter}>
            <SelectTrigger className="w-[170px]"><SelectValue placeholder="Secteur" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous les secteurs</SelectItem>
              {sectors.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-[170px]"><SelectValue placeholder="Tri" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="UPDATED_DESC">Modifié récemment</SelectItem>
              <SelectItem value="UPDATED_ASC">Modifié anciennement</SelectItem>
              <SelectItem value="NAME_ASC">Nom (A → Z)</SelectItem>
              <SelectItem value="PROGRESS_DESC">Avancement</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => navigate('new-project')}>
            <FolderPlus className="h-4 w-4 mr-2" /> Nouveau
          </Button>
        </div>
      </div>

      {/* Liste */}
      {loading ? (
        <div className="grid md:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}><CardContent className="h-40 animate-pulse bg-muted/50 rounded-xl" /></Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <FolderPlus className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-medium">Aucun projet trouvé</p>
            <p className="text-sm text-muted-foreground mt-1 mb-4">
              {projects.length === 0 ? 'Créez votre premier projet pour démarrer.' : 'Ajustez vos filtres de recherche.'}
            </p>
            {projects.length === 0 && (
              <Button onClick={() => navigate('new-project')}>
                <FolderPlus className="h-4 w-4 mr-2" /> Créer mon premier projet
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((p) => (
            <Card key={p.id} className="group hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <button onClick={() => openProject(p.id)} className="text-left min-w-0" type="button">
                    <h3 className="font-semibold leading-snug group-hover:text-[#b0880f] transition-colors truncate">{p.name}</h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {p.idea || 'Aucune description pour le moment.'}
                    </p>
                  </button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8" disabled={busy === p.id} aria-label="Actions du projet">
                        {busy === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreVertical className="h-4 w-4" />}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openProject(p.id)}>
                        <FolderOpen className="h-4 w-4 mr-2" /> Ouvrir
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openProject(p.id, 'analysis')}>
                        <ChartPie className="h-4 w-4 mr-2" /> Analyse
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => duplicate(p)}>
                        <Copy className="h-4 w-4 mr-2" /> Dupliquer
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toggleCompleted(p)}>
                        {p.status === 'COMPLETED' ? (
                          <>
                            <RotateCcw className="h-4 w-4 mr-2" /> Remettre « en cours »
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="h-4 w-4 mr-2 text-emerald-600" /> Marquer comme terminé
                          </>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toggleArchive(p)}>
                        <Archive className="h-4 w-4 mr-2" /> {p.status === 'ARCHIVED' ? 'Désarchiver' : 'Archiver'}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setDeleteTarget(p)} className="text-destructive focus:text-destructive">
                        <Trash2 className="h-4 w-4 mr-2" /> Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
                  <Badge variant="outline" className={statusColor[p.status]}>{PROJECT_STATUS_LABELS[p.status] || p.status}</Badge>
                  {p.sector && <Badge variant="secondary">{p.sector}</Badge>}
                  {p.country && <Badge variant="secondary">{p.country}</Badge>}
                  <span className="text-muted-foreground ml-auto">Modifié le {fmtDate(p.updatedAt)}</span>
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <Progress value={p.progress} className="h-2 flex-1" />
                  <span className="text-xs font-semibold w-10 text-right">{Math.round(p.progress)} %</span>
                </div>
                <div className="mt-2 text-[11px] text-muted-foreground">
                  {p.tasksCount} tâche(s) · {p.docsCount} document(s)
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Refus de confirmation « Terminé » : projet non validé par Gescom Project */}
      <Dialog open={blockedCompletion !== null} onOpenChange={(o) => { if (!o) setBlockedCompletion(null) }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-amber-600" />
              Impossible de confirmer « Terminé »
            </DialogTitle>
            <DialogDescription className="text-left">
              Le projet « {blockedCompletion?.project.name} » n&apos;est pas encore validé par Gescom Project.
              Il reste <strong>En cours</strong> tant que la validation n&apos;est pas obtenue.
            </DialogDescription>
          </DialogHeader>

          {blockedCompletion && (
            <div className="space-y-3 text-sm">
              <div className="rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40 px-3 py-2.5 text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2">
                <TriangleAlert className="h-4 w-4 shrink-0" />
                <span>
                  Statut de validation : <strong>{blockedCompletion.report.statusLabel}</strong>
                  {blockedCompletion.report.counts.correctionsRestantes > 0 && (
                    <> — {blockedCompletion.report.counts.correctionsRestantes} correction(s) obligatoire(s) restante(s)</>
                  )}
                </span>
              </div>

              {blockedCompletion.report.problems.length > 0 && (
                <ul className="space-y-1.5 text-xs text-muted-foreground">
                  {blockedCompletion.report.problems
                    .slice(0, 4)
                    .map((pr) => (
                      <li key={pr.code} className="flex items-start gap-1.5">
                        <span className="mt-1 h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0" />
                        <span><strong className="text-foreground">{pr.problem}</strong> — {pr.recommendation}</span>
                      </li>
                    ))}
                </ul>
              )}

              <p className="text-xs text-muted-foreground">
                Complétez le dossier et obtenez la validation (VAN, TRI, IP) : vous pourrez alors
                confirmer le projet comme « Terminé ».
              </p>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setBlockedCompletion(null)}>
              Plus tard
            </Button>
            <Button
              className="bg-[#0F172A] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0F172A] dark:hover:bg-[#e0b53f]"
              onClick={() => {
                if (blockedCompletion) openProject(blockedCompletion.project.id, 'validation')
                setBlockedCompletion(null)
              }}
            >
              Corriger dans la validation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation de suppression */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce projet ?</AlertDialogTitle>
            <AlertDialogDescription>
              Le projet « {deleteTarget?.name} » et l&apos;ensemble de ses données (analyses, finances, tâches,
              documents générés) seront définitivement supprimés. Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-white hover:bg-destructive/90">
              Supprimer définitivement
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
