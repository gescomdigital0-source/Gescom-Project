'use client'

// GESCOM PROJECT – Identité visuelle du projet
// Upload du logo de l'entreprise (intégré à la présentation PowerPoint /
// Business Plan) et de l'image d'illustration de l'activité (fond de la
// page de couverture des documents PDF & Word).
import { useCallback, useEffect, useRef, useState } from 'react'
import { apiGet, apiSend, authHeaders } from '@/lib/client-api'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { fmtBytes } from '@/lib/format'
import { Building2, ImagePlus, Loader2, Presentation, Trash2 } from 'lucide-react'

interface AssetInfo {
  kind: string
  url: string
  mimeType: string
  size: number
  updatedAt: string
}

interface Assets {
  logo: AssetInfo | null
  cover: AssetInfo | null
}

type Kind = 'logo' | 'cover'

export function VisualIdentity({ projectId }: { projectId: string }) {
  const { toast } = useToast()
  const [assets, setAssets] = useState<Assets | null>(null)
  const [previews, setPreviews] = useState<Partial<Record<Kind, string>>>({})
  const [busy, setBusy] = useState<Kind | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await apiGet<{ assets: Assets }>(`/api/projects/${projectId}/assets`)
      setAssets(d.assets)
    } catch {
      setAssets({ logo: null, cover: null })
    }
  }, [projectId])

  useEffect(() => {
    void load()
  }, [load])

  // Aperçus : chargés via fetch authentifié (Bearer), puis convertis en URL
  // locale — plus fiable qu'un <img src> direct quand les cookies sont bloqués.
  useEffect(() => {
    const revoked: string[] = []
    let cancelled = false
    async function loadPreview(kind: Kind, url: string) {
      try {
        const res = await fetch(url, { credentials: 'include', headers: authHeaders() })
        if (!res.ok) return
        const blob = await res.blob()
        if (cancelled) return
        const objUrl = URL.createObjectURL(blob)
        revoked.push(objUrl)
        setPreviews((p) => ({ ...p, [kind]: objUrl }))
      } catch {
        // aperçu indisponible : le placeholder reste affiché
      }
    }
    if (assets?.logo?.url) void loadPreview('logo', assets.logo.url)
    if (assets?.cover?.url) void loadPreview('cover', assets.cover.url)
    return () => {
      cancelled = true
      for (const u of revoked) URL.revokeObjectURL(u)
    }
  }, [assets?.logo?.url, assets?.cover?.url])

  async function upload(kind: Kind, file: File) {
    setBusy(kind)
    try {
      const form = new FormData()
      form.append('file', file)
      form.append('kind', kind)
      const res = await fetch(`/api/projects/${projectId}/assets`, {
        method: 'POST',
        credentials: 'include',
        headers: authHeaders(),
        body: form,
      })
      const isJson = res.headers.get('content-type')?.includes('application/json')
      const data = isJson ? await res.json() : null
      if (!res.ok) throw new Error(data?.error || `Erreur ${res.status}`)
      setPreviews((p) => ({ ...p, [kind]: undefined }))
      await load()
      toast({
        title: kind === 'logo' ? 'Logo enregistré ✅' : 'Image d\'illustration enregistrée ✅',
        description: kind === 'logo'
          ? 'Il sera intégré à la prochaine présentation PowerPoint générée.'
          : 'Elle deviendra le fond de la page de couverture des prochains documents PDF et Word.',
      })
    } catch (err) {
      toast({
        title: 'Échec de l\'envoi',
        description: err instanceof Error ? err.message : 'Réessayez.',
        variant: 'destructive',
      })
    } finally {
      setBusy(null)
    }
  }

  async function remove(kind: Kind) {
    setBusy(kind)
    try {
      await apiSend(`/api/projects/${projectId}/assets?kind=${kind}`, 'DELETE')
      setPreviews((p) => ({ ...p, [kind]: undefined }))
      await load()
      toast({ title: kind === 'logo' ? 'Logo supprimé' : 'Image d\'illustration supprimée' })
    } catch (err) {
      toast({
        title: 'Erreur',
        description: err instanceof Error ? err.message : 'Suppression impossible.',
        variant: 'destructive',
      })
    } finally {
      setBusy(null)
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Identité visuelle</CardTitle>
        <p className="text-xs text-muted-foreground font-normal">
          Votre image de marque, intégrée automatiquement aux documents générés.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <AssetUploader
          kind="logo"
          title="Logo de l'entreprise"
          usageBadge={{ label: 'Présentation PowerPoint', icon: Presentation }}
          hint="PNG, JPG ou WebP — 5 Mo max. Un PNG à fond transparent s'intègre élégamment sur les bandeaux colorés."
          placeholderIcon={Building2}
          placeholderText="Aucun logo"
          asset={assets?.logo ?? null}
          preview={previews.logo}
          previewClass="object-contain"
          busy={busy === 'logo'}
          disabled={busy !== null && busy !== 'logo'}
          onPick={(f) => void upload('logo', f)}
          onRemove={() => void remove('logo')}
        />
        <AssetUploader
          kind="cover"
          title="Image d'illustration de l'activité"
          usageBadge={{ label: 'Couverture PDF & Word', icon: ImagePlus }}
          hint="Photo de votre activité (atelier, cultures, boutique…). Elle est recadrée au format page et assombrie d'un voile bleu nuit pour que le titre reste lisible."
          placeholderIcon={ImagePlus}
          placeholderText="Aucune image"
          asset={assets?.cover ?? null}
          preview={previews.cover}
          previewClass="object-cover"
          busy={busy === 'cover'}
          disabled={busy !== null && busy !== 'cover'}
          onPick={(f) => void upload('cover', f)}
          onRemove={() => void remove('cover')}
        />
      </CardContent>
    </Card>
  )
}

function AssetUploader({
  kind, title, usageBadge, hint, placeholderIcon: Placeholder, placeholderText,
  asset, preview, previewClass, busy, disabled, onPick, onRemove,
}: {
  kind: Kind
  title: string
  usageBadge: { label: string; icon: typeof Presentation }
  hint: string
  placeholderIcon: typeof Building2
  placeholderText: string
  asset: AssetInfo | null
  preview?: string
  previewClass?: string
  busy: boolean
  disabled: boolean
  onPick: (file: File) => void
  onRemove: () => void
}) {
  const BadgeIcon = usageBadge.icon
  const inputEl = useRef<HTMLInputElement | null>(null)
  return (
    <div className={cn('rounded-xl border p-3 space-y-2.5', disabled && 'opacity-60')}>
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-sm font-medium">{title}</span>
        <Badge variant="secondary" className="gap-1 text-[10px]">
          <BadgeIcon className="h-3 w-3" /> {usageBadge.label}
        </Badge>
      </div>
      <div className="h-28 rounded-lg border bg-muted/30 flex items-center justify-center overflow-hidden">
        {busy ? (
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        ) : preview ? (
          <img src={preview} alt={title} className={cn('w-full h-full', previewClass)} />
        ) : (
          <div className="flex flex-col items-center gap-1 text-muted-foreground">
            <Placeholder className="h-6 w-6" />
            <span className="text-xs">{placeholderText}</span>
          </div>
        )}
      </div>
      <p className="text-[11px] leading-snug text-muted-foreground">{hint}</p>
      <div className="flex items-center gap-2">
        <input
          ref={inputEl}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            e.target.value = '' // permet de re-sélectionner le même fichier
            if (f) onPick(f)
          }}
        />
        <Button
          variant="outline"
          size="sm"
          disabled={disabled || busy}
          onClick={() => inputEl.current?.click()}
        >
          <ImagePlus className="h-3.5 w-3.5 mr-1.5" />
          {asset ? 'Remplacer' : 'Choisir un fichier'}
        </Button>
        {asset && (
          <Button variant="ghost" size="icon" className="h-8 w-8" disabled={disabled || busy} aria-label="Supprimer l'image" onClick={onRemove}>
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
        {asset && (
          <span className="text-[11px] text-muted-foreground ml-auto">{fmtBytes(asset.size)}</span>
        )}
      </div>
    </div>
  )
}

// Composant de chargement réutilisable (état initial du module)
export function VisualIdentitySkeleton() {
  return (
    <Card>
      <CardHeader className="pb-3"><Skeleton className="h-5 w-40" /></CardHeader>
      <CardContent className="space-y-4">
        {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-44" />)}
      </CardContent>
    </Card>
  )
}
