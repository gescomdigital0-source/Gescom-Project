'use client'

// GESCOM PROJECT – Module Documents : génération du dossier complet
// (PDF, DOCX, XLSX, PPTX) + bibliothèque des documents générés
import { useCallback, useEffect, useState } from 'react'
import { apiDownload, apiGet, apiSend, authHeaders, ApiError } from '@/lib/client-api'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import type { DocPrefs } from '@/lib/types'
import type { ValidationReport } from '@/lib/validation'
import { EXPORT_SECTIONS } from '@/lib/constants'
import { isPremium, PREMIUM_EXPORT_SECTIONS } from '@/lib/plans'
import { useApp } from '@/lib/store'
import { Lock } from 'lucide-react'
import { fmtBytes, fmtDateTime, groupNumber } from '@/lib/format'
import { VisualIdentity } from '@/components/gescom/modules/VisualIdentity'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  FileText, FileType, FileSpreadsheet, Presentation, Download, Trash2, Loader2, FileCheck2,
  FileSearch, ShieldAlert, ShieldCheck, ArrowRight,
} from 'lucide-react'

interface DocRecord {
  id: string
  name: string
  format: string
  audience: string
  size: number
  createdAt: string
}

const FORMAT_META: Record<string, { icon: typeof FileText; label: string; desc: string; cls: string }> = {
  PDF: { icon: FileText, label: 'PDF', desc: 'Dossier finalisé prêt à imprimer', cls: 'hover:border-red-300' },
  DOCX: { icon: FileType, label: 'Word', desc: 'Document éditable structuré', cls: 'hover:border-sky-300' },
  XLSX: { icon: FileSpreadsheet, label: 'Excel', desc: 'Tableurs financiers avec formules actives', cls: 'hover:border-emerald-300' },
  PPTX: { icon: Presentation, label: 'PowerPoint', desc: 'Voir l\'onglet Présentation', cls: 'hover:border-amber-300' },
  DIAGNOSTIC: { icon: FileSearch, label: 'Diagnostic', desc: 'Rapport de validation & corrections (PDF)', cls: 'hover:border-violet-300' },
}

export function DocumentsModule({ project, docPrefs, saveDocPrefs, hasFinance }: {
  project: ProjectRecord
  docPrefs: DocPrefs
  saveDocPrefs: (v: DocPrefs) => void
  hasFinance: boolean
}) {
  const { toast } = useToast()
  const navigate = useApp((s) => s.navigate)
  const [selected, setSelected] = useState<string[]>(EXPORT_SECTIONS.map((s) => s.id))
  const [generating, setGenerating] = useState<string | null>(null)
  const [docs, setDocs] = useState<DocRecord[] | null>(null)
  // Rapport de validation : conditionne l'impression définitive (PDF / Word)
  const [validation, setValidation] = useState<ValidationReport | null>(null)
  // Plan gratuit : les sections Premium restent visibles mais décochées et
  // désactivées (le serveur filtre de toute façon en dernière instance).
  const premium = isPremium(useApp((s) => s.user?.plan))
  const sectionLocked = (id: string) => !premium && PREMIUM_EXPORT_SECTIONS.has(id)

  const set = <K extends keyof DocPrefs>(k: K, v: DocPrefs[K]) => saveDocPrefs({ ...docPrefs, [k]: v })

  const loadDocs = useCallback(async () => {
    try {
      const d = await apiGet<{ documents: DocRecord[] }>(`/api/projects/${project.id}/documents`)
      setDocs(d.documents)
    } catch {
      setDocs([])
    }
  }, [project.id])

  // Chargement du rapport de validation (statut + anomalies éventuelles)
  const loadValidation = useCallback(async () => {
    try {
      const d = await apiGet<{ report: ValidationReport }>(`/api/projects/${project.id}/validation`)
      setValidation(d.report)
    } catch {
      setValidation(null)
    }
  }, [project.id])

  useEffect(() => {
    void loadDocs()
    void loadValidation()
  }, [loadDocs, loadValidation])

  async function generate(format: 'PDF' | 'DOCX' | 'XLSX' | 'DIAGNOSTIC') {
    if (format === 'XLSX' && !hasFinance) {
      toast({
        title: 'Données financières manquantes',
        description: 'Renseignez d\'abord vos hypothèses dans le module Finance.',
        variant: 'destructive',
      })
      return
    }
    setGenerating(format)
    try {
      const name = await apiDownload(
        `/api/projects/${project.id}/export`,
        { format, sections: selected },
        `document.${format === 'DIAGNOSTIC' ? 'pdf' : format.toLowerCase()}`,
      )
      toast({ title: 'Document généré ✅', description: `${name} a été téléchargé et ajouté à la bibliothèque.` })
      await loadDocs()
      if (format === 'DIAGNOSTIC') await loadValidation()
    } catch (err) {
      // Blocage d'impression (403) : le serveur renvoie le rapport de validation
      // complet — on l'affiche pour guider les corrections.
      if (err instanceof ApiError && err.status === 403 && err.payload?.validation) {
        setValidation(err.payload.validation as ValidationReport)
      }
      toast({ title: 'Impression impossible', description: err instanceof Error ? err.message : 'Réessayez.', variant: 'destructive' })
    } finally {
      setGenerating(null)
    }
  }

  async function reDownload(doc: DocRecord) {
    try {
      const res = await fetch(`/api/documents/${doc.id}`, { credentials: 'include', headers: authHeaders() })
      if (!res.ok) throw new Error('Document indisponible.')
      const blob = await res.blob()
      const href = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = href
      a.download = doc.name
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(href), 4000)
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Téléchargement impossible.', variant: 'destructive' })
    }
  }

  async function deleteDoc(id: string) {
    try {
      await apiSend(`/api/documents/${id}`, 'DELETE')
      await loadDocs()
      toast({ title: 'Document supprimé' })
    } catch {
      toast({ title: 'Erreur', description: 'Suppression impossible.', variant: 'destructive' })
    }
  }

  const toggleSection = (id: string) => {
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))
  }

  return (
    <div className="grid lg:grid-cols-3 gap-5">
      {/* Colonne gauche : personnalisation */}
      <div className="space-y-4">
        <VisualIdentity projectId={project.id} />
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Page de garde & en-têtes</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">Personnalisez le document avant génération.</p>
          </CardHeader>
          <CardContent className="space-y-3.5">
            <div className="space-y-1.5">
              <Label>Titre du dossier</Label>
              <Input value={docPrefs.coverTitle} onChange={(e) => set('coverTitle', e.target.value)} placeholder={`Dossier de projet – ${project.name}`} />
            </div>
            <div className="space-y-1.5">
              <Label>Sous-titre</Label>
              <Input value={docPrefs.coverSubtitle} onChange={(e) => set('coverSubtitle', e.target.value)} placeholder="Business plan & étude de faisabilité" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Auteur</Label>
                <Input value={docPrefs.author} onChange={(e) => set('author', e.target.value)} placeholder="Nom du porteur" />
              </div>
              <div className="space-y-1.5">
                <Label>Organisation</Label>
                <Input value={docPrefs.organization} onChange={(e) => set('organization', e.target.value)} placeholder="Nom de l'organisation" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Texte d&apos;en-tête (pages intérieures)</Label>
              <Input value={docPrefs.headerText} onChange={(e) => set('headerText', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Texte de pied de page</Label>
              <Input value={docPrefs.footerText} onChange={(e) => set('footerText', e.target.value)} placeholder="Généré avec GESCOM PROJECT" />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm font-normal">Inclure la page de garde</Label>
              <Switch checked={docPrefs.includeCover} onCheckedChange={(v) => set('includeCover', v)} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm font-normal">Inclure la table des matières</Label>
              <Switch checked={docPrefs.includeToc} onCheckedChange={(v) => set('includeToc', v)} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Colonne centrale : sections + génération */}
      <div className="space-y-4 lg:col-span-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Sections du dossier</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">
              Sélectionnez les sections à inclure. Les données proviennent des modules réellement remplis.
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {EXPORT_SECTIONS.map((s) => {
                const locked = sectionLocked(s.id)
                return (
                  <label
                    key={s.id}
                    className={cn(
                      'flex items-center gap-2.5 rounded-lg border p-2.5 transition-colors',
                      locked ? 'opacity-60 cursor-not-allowed bg-muted/30' : 'cursor-pointer hover:bg-accent/40',
                    )}
                    title={locked ? 'Réservé à l\'abonnement Premium' : undefined}
                  >
                    <Checkbox
                      checked={selected.includes(s.id) && !locked}
                      disabled={locked}
                      onCheckedChange={() => toggleSection(s.id)}
                    />
                    <span className="text-sm leading-tight flex-1">{s.label}</span>
                    {locked && <Lock className="h-3.5 w-3.5 shrink-0 text-[#d4a72c]" aria-label="Réservé Premium" />}
                  </label>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base">Générer & télécharger</CardTitle></CardHeader>
          <CardContent>
            {/* Bandeau de validation : condition d'impression du dossier définitif */}
            {validation && (
              validation.canExport ? (
                <div className="mb-3 rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 px-3.5 py-2.5 text-xs text-emerald-900 dark:text-emerald-200 flex items-start gap-2">
                  <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">
                    <span className="font-semibold">Projet validé ✅</span> — l&apos;impression de la version définitive (PDF, Word) est autorisée par GESCOM PROJECT.
                  </span>
                </div>
              ) : (
                <div className="mb-3 rounded-lg border border-amber-300 dark:border-amber-900 bg-amber-50/70 dark:bg-amber-950/20 px-3.5 py-3 text-xs text-amber-900 dark:text-amber-200">
                  <div className="flex items-start gap-2">
                    <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
                    <div className="leading-relaxed flex-1">
                      <span className="font-semibold">Impression définitive bloquée : {validation.statusLabel.toLowerCase()}.</span>{' '}
                      {validation.counts.correctionsRestantes > 0
                        ? `${groupNumber(validation.counts.correctionsRestantes)} correction(s) obligatoire(s) restante(s) sur ${groupNumber(validation.counts.anomalies)} anomalie(s) détectée(s).`
                        : 'Le rapport de diagnostic détaille les informations manquantes.'}
                      <div className="mt-1.5">Seuls le rapport de diagnostic, le classeur Excel et la présentation restent téléchargeables.</div>
                    </div>
                    <Button size="sm" variant="outline" className="shrink-0 h-7 border-amber-300 text-amber-900 hover:bg-amber-100 dark:border-amber-800 dark:text-amber-200" onClick={() => navigate('validation')}>
                      Voir la validation <ArrowRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                  {validation.problems.length > 0 && (
                    <ul className="mt-2 space-y-1 ml-6">
                      {validation.problems.slice(0, 4).map((p) => (
                        <li key={p.code} className="leading-snug">• {p.sectionLabel} — {p.problem}</li>
                      ))}
                      {validation.problems.length > 4 && (
                        <li className="ml-3.5">… et {groupNumber(validation.problems.length - 4)} autre(s) : voir le module Validation.</li>
                      )}
                    </ul>
                  )}
                </div>
              )
            )}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(['DIAGNOSTIC', 'PDF', 'DOCX', 'XLSX'] as const).map((f) => {
                const meta = FORMAT_META[f]
                const Icon = meta.icon
                return (
                  <button
                    key={f}
                    type="button"
                    onClick={() => generate(f)}
                    disabled={generating !== null}
                    className={cn(
                      'rounded-xl border p-4 text-left transition-all hover:shadow-md disabled:opacity-60',
                      meta.cls,
                    )}
                  >
                    <Icon className="h-6 w-6 text-[#b0880f] mb-2" />
                    <div className="font-semibold text-sm">{meta.label}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 leading-snug">{meta.desc}</div>
                    {generating === f && <Loader2 className="h-4 w-4 animate-spin mt-2" />}
                  </button>
                )
              })}
            </div>
            <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1.5">
              <FileCheck2 className="h-3.5 w-3.5 mt-0.5 shrink-0 text-emerald-600" />
              Les documents sont générés à partir des données enregistrées. L&apos;impression du dossier final (PDF, Word)
              est conditionnée à la validation automatique du projet ; le rapport de diagnostic reste toujours disponible.
            </p>
          </CardContent>
        </Card>

        {/* Bibliothèque */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Bibliothèque de documents</CardTitle>
            <Badge variant="secondary" className="ml-auto">{docs?.length ?? 0}</Badge>
          </CardHeader>
          <CardContent>
            {docs === null ? (
              <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
            ) : docs.length === 0 ? (
              <p className="text-sm text-muted-foreground py-6 text-center">
                Aucun document généré pour ce projet. Lancez une génération ci-dessus.
              </p>
            ) : (
              <ul className="divide-y">
                {docs.map((d) => (
                  <li key={d.id} className="flex items-center gap-3 py-3">
                    <span className={cn(
                      'h-9 w-9 rounded-lg flex items-center justify-center text-[10px] font-bold shrink-0',
                      d.format === 'PDF' && 'bg-red-100 text-red-700',
                      d.format === 'DOCX' && 'bg-sky-100 text-sky-700',
                      d.format === 'XLSX' && 'bg-emerald-100 text-emerald-700',
                      d.format === 'PPTX' && 'bg-amber-100 text-amber-700',
                      d.format === 'DIAGNOSTIC' && 'bg-violet-100 text-violet-700',
                    )}>
                      {d.format === 'DIAGNOSTIC' ? 'DIAG' : d.format}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{d.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {fmtDateTime(d.createdAt)} · {fmtBytes(d.size)}
                      </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => reDownload(d)}>
                      <Download className="h-3.5 w-3.5 mr-1.5" /> Télécharger
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer" onClick={() => deleteDoc(d.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
