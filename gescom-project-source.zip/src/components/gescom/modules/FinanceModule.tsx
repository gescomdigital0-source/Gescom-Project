'use client'

// GESCOM PROJECT – Module Finance : investissement, financement,
// hypothèses d'exploitation, résultats, indicateurs, scénarios, graphiques
import { useMemo, useState } from 'react'
import { computeFinance } from '@/lib/finance'
import { fmtCurrency, fmtPct, fmtNumber } from '@/lib/format'
import type { CostLine, FinanceData, InvestmentLine, FinancingLine, ProductLine, StaffLine } from '@/lib/types'
import { uid } from '@/lib/types'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import { INVESTMENT_CATEGORIES } from '@/lib/constants'
import { AiImproveButton } from '@/components/gescom/ai/AiImprove'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import {
  BarChart, Bar, LineChart, Line, ComposedChart, Area, AreaChart, XAxis, YAxis,
  ResponsiveContainer, Tooltip, CartesianGrid, Legend, PieChart, Pie, Cell,
} from 'recharts'
import {
  Building2, Banknote, SlidersHorizontal, FileBarChart, Gauge, GitCompareArrows,
  ChartLine, Plus, X, Info, TriangleAlert, Lock,
} from 'lucide-react'
import { CHART_COLORS } from '@/lib/constants'
import { useApp } from '@/lib/store'
import { isFeatureLocked } from '@/lib/plans'
import { LockedPanel } from '@/components/gescom/LockedPanel'

interface Props {
  project: ProjectRecord
  finance: FinanceData
  overview?: unknown
  save: (v: FinanceData, immediate?: boolean) => void
}

export function FinanceModule({ project, finance, save }: Props) {
  const cur = project.currency || 'XAF'
  const comp = useMemo(() => computeFinance(finance), [finance])
  const [tab, setTab] = useState('investment')

  const setFinance = (patch: Partial<FinanceData>) => save({ ...finance, ...patch })
  const setAssumptions = (patch: Partial<FinanceData['assumptions']>) =>
    save({ ...finance, assumptions: { ...finance.assumptions, ...patch } })

  const nYears = Math.max(1, Math.min(10, finance.assumptions.horizonYears || 5))
  const years = Array.from({ length: nYears }, (_, i) => i + 1)
  const hasData = finance.assumptions.products.length > 0

  // Abonnement : contenus réservés au plan Premium
  const plan = useApp((s) => s.user?.plan)
  const openCheckout = useApp((s) => s.openCheckout)
  const financingLocked = isFeatureLocked(plan, 'financing')
  const salesLocked = isFeatureLocked(plan, 'sales')
  const financialsLocked = isFeatureLocked(plan, 'financials')
  const indicatorsLocked = isFeatureLocked(plan, 'indicators')
  const scenariosLocked = isFeatureLocked(plan, 'scenarios')
  const chartsLocked = isFeatureLocked(plan, 'charts')

  return (
    <Tabs value={tab} onValueChange={setTab} className="space-y-4">
      <TabsList className="flex flex-wrap h-auto gap-1 bg-muted/60 p-1">
        <TabsTrigger value="investment" className="gap-1.5"><Building2 className="h-3.5 w-3.5" /> Investissement</TabsTrigger>
        <TabsTrigger value="financing" className="gap-1.5"><Banknote className="h-3.5 w-3.5" /> Financement{financingLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}</TabsTrigger>
        <TabsTrigger value="assumptions" className="gap-1.5"><SlidersHorizontal className="h-3.5 w-3.5" /> Exploitation{salesLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Prévision des ventes réservée Premium" />}</TabsTrigger>
        <TabsTrigger value="results" className="gap-1.5"><FileBarChart className="h-3.5 w-3.5" /> Résultats{financialsLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}</TabsTrigger>
        <TabsTrigger value="indicators" className="gap-1.5"><Gauge className="h-3.5 w-3.5" /> Indicateurs{indicatorsLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}</TabsTrigger>
        <TabsTrigger value="scenarios" className="gap-1.5"><GitCompareArrows className="h-3.5 w-3.5" /> Scénarios{scenariosLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}</TabsTrigger>
        <TabsTrigger value="charts" className="gap-1.5"><ChartLine className="h-3.5 w-3.5" /> Graphiques{chartsLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}</TabsTrigger>
      </TabsList>

      {/* ------------------------------------------------ Investissement */}
      <TabsContent value="investment" className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <CardTitle className="text-base">Programme d&apos;investissement</CardTitle>
                <p className="text-xs text-muted-foreground font-normal">
                  Biens durables nécessaires au démarrage. Les durées d&apos;amortissement alimentent le compte de résultat.
                </p>
              </div>
              <AiImproveButton
                projectId={project.id}
                target="finance.investments"
                value={finance.investments.map((i) => ({ label: i.label, category: i.category, amount: i.amount }))}
                onApply={(v) => {
                  const rows = v as Array<{ label: string; category: string; amount: number }>
                  if (rows.length) setFinance({ investments: rows.map((r) => ({ id: uid(), label: r.label, category: r.category, amount: r.amount, depreciable: r.category !== 'TERRAIN', depYears: r.category === 'BATIMENT' ? 10 : 5 })) })
                }}
              />
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="overflow-x-auto">
              <Table className="min-w-[760px]">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[38%]">Rubrique</TableHead>
                    <TableHead>Catégorie</TableHead>
                    <TableHead className="text-right">Montant</TableHead>
                    <TableHead className="text-center">Amortissable</TableHead>
                    <TableHead className="text-right">Durée (ans)</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {finance.investments.map((line) => (
                    <TableRow key={line.id}>
                      <TableCell>
                        <Input className="h-8 text-sm" value={line.label}
                          onChange={(e) => setFinance({ investments: finance.investments.map((i) => i.id === line.id ? { ...i, label: e.target.value } : i) })} />
                      </TableCell>
                      <TableCell>
                        <Select value={line.category} onValueChange={(v) => setFinance({ investments: finance.investments.map((i) => i.id === line.id ? { ...i, category: v } : i) })}>
                          <SelectTrigger className="h-8 w-[170px] text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {INVESTMENT_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input type="number" className="num-input h-8 text-sm" value={line.amount || ''}
                          onChange={(e) => setFinance({ investments: finance.investments.map((i) => i.id === line.id ? { ...i, amount: Number(e.target.value) || 0 } : i) })} />
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch checked={line.depreciable} className="mx-auto"
                          onCheckedChange={(v) => setFinance({ investments: finance.investments.map((i) => i.id === line.id ? { ...i, depreciable: v } : i) })} />
                      </TableCell>
                      <TableCell>
                        <Input type="number" className="num-input h-8 text-sm w-20" disabled={!line.depreciable} value={line.depreciable ? line.depYears : ''}
                          onChange={(e) => setFinance({ investments: finance.investments.map((i) => i.id === line.id ? { ...i, depYears: Number(e.target.value) || 1 } : i) })} />
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer"
                          onClick={() => setFinance({ investments: finance.investments.filter((i) => i.id !== line.id) })}>
                          <X className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {finance.investments.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">Aucun investissement saisi.</TableCell></TableRow>
                  )}
                  <TableRow className="font-semibold bg-muted/40">
                    <TableCell colSpan={2}>Total investissements</TableCell>
                    <TableCell className="text-right">{fmtCurrency(comp.totalInvestment, cur)}</TableCell>
                    <TableCell colSpan={3} />
                  </TableRow>
                </TableBody>
              </Table>
            </div>
            <Button variant="outline" size="sm"
              onClick={() => setFinance({ investments: [...finance.investments, { id: uid(), label: '', category: 'EQUIPEMENT', amount: 0, depreciable: true, depYears: 5 } as InvestmentLine] })}>
              <Plus className="h-4 w-4 mr-1.5" /> Ajouter une ligne
            </Button>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm">Fonds de roulement (BFR)</CardTitle></CardHeader>
            <CardContent>
              <Input type="number" className="num-input" value={finance.workingCapital || ''}
                onChange={(e) => setFinance({ workingCapital: Number(e.target.value) || 0 })} />
              <p className="text-xs text-muted-foreground mt-2">Trésorerie nécessaire pour financer le cycle d&apos;exploitation avant encaissements (stocks, premiers achats…).</p>
            </CardContent>
          </Card>
          <Card className="md:col-span-2">
            <CardHeader className="pb-2"><CardTitle className="text-sm">Besoin total de financement</CardTitle></CardHeader>
            <CardContent className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">{fmtCurrency(comp.totalNeeds, cur)}</div>
                <div className="text-xs text-muted-foreground">Investissements {fmtCurrency(comp.totalInvestment, cur)} + BFR {fmtCurrency(comp.totalWorkingCapital, cur)}</div>
              </div>
              {comp.financingGap > 0 && (
                <Badge variant="outline" className="border-amber-300 text-amber-800 bg-amber-50">Écart à financer : {fmtCurrency(comp.financingGap, cur)}</Badge>
              )}
              {comp.financingGap <= 0 && comp.totalNeeds > 0 && (
                <Badge variant="outline" className="border-emerald-300 text-emerald-700 bg-emerald-50">Financement couvert</Badge>
              )}
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      {/* ------------------------------------------------ Financement */}
      <TabsContent value="financing" className="space-y-4">
        {financingLocked ? (
          <LockedPanel
            title="Plan de financement réservé à l'abonnement Premium"
            description="Structurez vos sources de financement (fonds propres, emprunts, subventions), calculez l'écart à financer et générez les échéanciers de remboursement automatiques."
            features={['Sources : fonds propres, emprunts, subventions', 'Échéanciers de remboursement automatiques', "Alerte sur l'écart à financer"]}
            onUpgrade={() => openCheckout()}
          />
        ) : (<>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <CardTitle className="text-base">Structure de financement</CardTitle>
                <p className="text-xs text-muted-foreground font-normal">
                  Fonds propres, emprunts (annuités constantes calculées automatiquement) et subventions.
                </p>
              </div>
              <AiImproveButton
                projectId={project.id}
                target="finance.financing"
                value={finance.financing.map((f) => ({ source: f.source, type: f.type, amount: f.amount, rate: f.rate, termYears: f.termYears }))}
                onApply={(v) => {
                  const rows = v as Array<{ source: string; type: string; amount: number; rate: number; termYears: number }>
                  if (rows.length) setFinance({ financing: rows.map((r) => ({ id: uid(), source: r.source, type: r.type as FinancingLine['type'], amount: r.amount, rate: r.type === 'LOAN' ? r.rate : 0, termYears: r.type === 'LOAN' ? r.termYears : 0 })) })
                }}
              />
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="overflow-x-auto">
              <Table className="min-w-[720px]">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[32%]">Source</TableHead>
                    <TableHead>Nature</TableHead>
                    <TableHead className="text-right">Montant</TableHead>
                    <TableHead className="text-right">Taux annuel (%)</TableHead>
                    <TableHead className="text-right">Durée (ans)</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {finance.financing.map((line) => (
                    <TableRow key={line.id}>
                      <TableCell>
                        <Input className="h-8 text-sm" value={line.source}
                          onChange={(e) => setFinance({ financing: finance.financing.map((f) => f.id === line.id ? { ...f, source: e.target.value } : f) })} />
                      </TableCell>
                      <TableCell>
                        <Select value={line.type} onValueChange={(v) => setFinance({ financing: finance.financing.map((f) => f.id === line.id ? { ...f, type: v as FinancingLine['type'] } : f) })}>
                          <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="EQUITY">Fonds propres</SelectItem>
                            <SelectItem value="LOAN">Emprunt</SelectItem>
                            <SelectItem value="GRANT">Subvention</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input type="number" className="num-input h-8 text-sm" value={line.amount || ''}
                          onChange={(e) => setFinance({ financing: finance.financing.map((f) => f.id === line.id ? { ...f, amount: Number(e.target.value) || 0 } : f) })} />
                      </TableCell>
                      <TableCell>
                        <Input type="number" step="0.1" className="num-input h-8 text-sm w-24" disabled={line.type !== 'LOAN'} value={line.type === 'LOAN' ? line.rate : ''}
                          onChange={(e) => setFinance({ financing: finance.financing.map((f) => f.id === line.id ? { ...f, rate: Number(e.target.value) || 0 } : f) })} />
                      </TableCell>
                      <TableCell>
                        <Input type="number" className="num-input h-8 text-sm w-20" disabled={line.type !== 'LOAN'} value={line.type === 'LOAN' ? line.termYears : ''}
                          onChange={(e) => setFinance({ financing: finance.financing.map((f) => f.id === line.id ? { ...f, termYears: Number(e.target.value) || 1 } : f) })} />
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer"
                          onClick={() => setFinance({ financing: finance.financing.filter((f) => f.id !== line.id) })}>
                          <X className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button variant="outline" size="sm"
              onClick={() => setFinance({ financing: [...finance.financing, { id: uid(), source: '', type: 'EQUITY', amount: 0, rate: 0, termYears: 0 } as FinancingLine] })}>
              <Plus className="h-4 w-4 mr-1.5" /> Ajouter une source
            </Button>

            <div className="grid sm:grid-cols-4 gap-3 pt-2">
              <MiniStat label="Fonds propres" value={fmtCurrency(comp.totalEquity, cur)} />
              <MiniStat label="Emprunts" value={fmtCurrency(comp.totalLoans, cur)} />
              <MiniStat label="Subventions" value={fmtCurrency(comp.totalGrants, cur)} />
              <MiniStat label="Autonomie financière" value={fmtPct(comp.ratios.autonomyRate)} />
            </div>
          </CardContent>
        </Card>

        {comp.loanSchedule.length > 0 && (
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Échéancier de remboursement</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table className="min-w-[680px]">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Année</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead className="text-right">Capital début</TableHead>
                      <TableHead className="text-right">Intérêts</TableHead>
                      <TableHead className="text-right">Capital remboursé</TableHead>
                      <TableHead className="text-right">Annuité</TableHead>
                      <TableHead className="text-right">Capital fin</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {comp.loanSchedule.map((l, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{l.year}</TableCell>
                        <TableCell className="text-sm">{l.source}</TableCell>
                        <TableCell className="text-right">{fmtCurrency(l.openingBalance, cur)}</TableCell>
                        <TableCell className="text-right">{fmtCurrency(l.interest, cur)}</TableCell>
                        <TableCell className="text-right">{fmtCurrency(l.principal, cur)}</TableCell>
                        <TableCell className="text-right">{fmtCurrency(l.annuity, cur)}</TableCell>
                        <TableCell className="text-right">{fmtCurrency(l.closingBalance, cur)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}
        </>)}
      </TabsContent>

      {/* ------------------------------------------------ Exploitation */}
      <TabsContent value="assumptions" className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Paramètres généraux</CardTitle>
          </CardHeader>
          <CardContent className="grid sm:grid-cols-4 gap-4">
            <div className="space-y-1.5">
              <Label>Horizon (années)</Label>
              <Select value={String(finance.assumptions.horizonYears)} onValueChange={(v) => setAssumptions({ horizonYears: Number(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => <SelectItem key={n} value={String(n)}>{n} an{ n > 1 ? 's' : ''}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Taux d&apos;actualisation (%)</Label>
              <Input type="number" step="0.5" className="num-input" value={finance.assumptions.discountRate}
                onChange={(e) => setAssumptions({ discountRate: Number(e.target.value) || 0 })} />
            </div>
            <div className="space-y-1.5">
              <Label>Taux d&apos;impôt (%)</Label>
              <Input type="number" step="1" className="num-input" value={finance.assumptions.taxRate}
                onChange={(e) => setAssumptions({ taxRate: Number(e.target.value) || 0 })} />
            </div>
          </CardContent>
        </Card>

        {/* Produits — prévision des ventes (Premium) */}
        {salesLocked ? (
          <LockedPanel
            compact
            title="Prévision des ventes réservée à l'abonnement Premium"
            description="Déclarez vos produits ou services (quantités, prix, croissances annuelles) pour construire le chiffre d'affaires prévisionnel et débloquer tout le module financier."
            onUpgrade={() => openCheckout()}
          />
        ) : (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <CardTitle className="text-base">Produits — chiffre d&apos;affaires prévisionnel</CardTitle>
                <p className="text-xs text-muted-foreground font-normal">Quantités et prix de l&apos;année 1, avec croissances annuelles.</p>
              </div>
              <AiImproveButton
                projectId={project.id}
                target="finance.products"
                value={finance.assumptions.products.map((p) => ({ label: p.label, unit: p.unit, unitPrice: p.unitPrice, qty: p.qty, volumeGrowth: p.volumeGrowth, priceGrowth: p.priceGrowth }))}
                onApply={(v) => {
                  const rows = v as Array<{ label: string; unit: string; unitPrice: number; qty: number; volumeGrowth: number; priceGrowth: number }>
                  if (rows.length) setAssumptions({ products: rows.map((r) => ({ id: uid(), ...r })) })
                }}
              />
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="overflow-x-auto">
              <Table className="min-w-[760px]">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[36%]">Produit / service</TableHead>
                    <TableHead>Unité</TableHead>
                    <TableHead className="text-right">Qté an 1</TableHead>
                    <TableHead className="text-right">Prix unitaire</TableHead>
                    <TableHead className="text-right">Volume %/an</TableHead>
                    <TableHead className="text-right">Prix %/an</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {finance.assumptions.products.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell><Input className="h-8 text-sm" value={p.label} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, label: e.target.value } : x) })} /></TableCell>
                      <TableCell><Input className="h-8 text-sm w-24" value={p.unit} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, unit: e.target.value } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-24" value={p.qty || ''} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, qty: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-28" value={p.unitPrice || ''} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, unitPrice: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-20" value={p.volumeGrowth || ''} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, volumeGrowth: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-20" value={p.priceGrowth || ''} onChange={(e) => setAssumptions({ products: finance.assumptions.products.map((x) => x.id === p.id ? { ...x, priceGrowth: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer" onClick={() => setAssumptions({ products: finance.assumptions.products.filter((x) => x.id !== p.id) })}><X className="h-4 w-4" /></Button></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button variant="outline" size="sm" onClick={() => setAssumptions({ products: [...finance.assumptions.products, { id: uid(), label: '', unit: 'unité', unitPrice: 0, qty: 0, volumeGrowth: 0, priceGrowth: 0 } as ProductLine] })}>
              <Plus className="h-4 w-4 mr-1.5" /> Ajouter un produit
            </Button>
            <p className="text-sm text-right font-medium">CA année 1 : {fmtCurrency(comp.years[0]?.revenue ?? 0, cur)}</p>
          </CardContent>
        </Card>
        )}

        {/* Charges variables */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Charges variables</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">Proportionnelles au volume (qté × prix) ou au chiffre d&apos;affaires (%).</p>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="overflow-x-auto">
              <Table className="min-w-[760px]">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[34%]">Charge</TableHead>
                    <TableHead>Mode</TableHead>
                    <TableHead className="text-right">Qté an 1</TableHead>
                    <TableHead className="text-right">Prix unitaire</TableHead>
                    <TableHead className="text-right">% du CA</TableHead>
                    <TableHead className="text-right">Croissance %/an</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {finance.assumptions.variableCosts.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell><Input className="h-8 text-sm" value={c.label} onChange={(e) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, label: e.target.value } : x) })} /></TableCell>
                      <TableCell>
                        <Select value={c.mode} onValueChange={(v) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, mode: v as CostLine['mode'] } : x) })}>
                          <SelectTrigger className="h-8 w-[120px] text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="QTY">Qté × prix</SelectItem>
                            <SelectItem value="PCT">% du CA</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-24" disabled={c.mode !== 'QTY'} value={c.mode === 'QTY' ? c.qty : ''} onChange={(e) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, qty: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-28" disabled={c.mode !== 'QTY'} value={c.mode === 'QTY' ? c.unitPrice : ''} onChange={(e) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, unitPrice: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" step="0.1" className="num-input h-8 text-sm w-20" disabled={c.mode !== 'PCT'} value={c.mode === 'PCT' ? c.pct : ''} onChange={(e) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, pct: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Input type="number" className="num-input h-8 text-sm w-20" disabled={c.mode !== 'QTY'} value={c.mode === 'QTY' ? c.growth : ''} onChange={(e) => setAssumptions({ variableCosts: finance.assumptions.variableCosts.map((x) => x.id === c.id ? { ...x, growth: Number(e.target.value) || 0 } : x) })} /></TableCell>
                      <TableCell><Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer" onClick={() => setAssumptions({ variableCosts: finance.assumptions.variableCosts.filter((x) => x.id !== c.id) })}><X className="h-4 w-4" /></Button></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button variant="outline" size="sm" onClick={() => setAssumptions({ variableCosts: [...finance.assumptions.variableCosts, { id: uid(), label: '', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 0, growth: 0 } as CostLine] })}>
              <Plus className="h-4 w-4 mr-1.5" /> Ajouter une charge variable
            </Button>
          </CardContent>
        </Card>

        {/* Charges fixes + personnel */}
        <div className="grid lg:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Charges fixes</CardTitle>
              <p className="text-xs text-muted-foreground font-normal">Indépendantes du volume (loyer, assurance, énergie de base…).</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {finance.assumptions.fixedCosts.map((c) => (
                <div key={c.id} className="flex gap-2">
                  <Input className="h-8 text-sm flex-1" placeholder="Libellé" value={c.label}
                    onChange={(e) => setAssumptions({ fixedCosts: finance.assumptions.fixedCosts.map((x) => x.id === c.id ? { ...x, label: e.target.value } : x) })} />
                  <Input type="number" className="num-input h-8 text-sm w-32" placeholder="Montant/an" value={c.annualAmount || ''}
                    onChange={(e) => setAssumptions({ fixedCosts: finance.assumptions.fixedCosts.map((x) => x.id === c.id ? { ...x, annualAmount: Number(e.target.value) || 0 } : x) })} />
                  <Input type="number" className="num-input h-8 text-sm w-20" placeholder="%/an" value={c.growth || ''}
                    onChange={(e) => setAssumptions({ fixedCosts: finance.assumptions.fixedCosts.map((x) => x.id === c.id ? { ...x, growth: Number(e.target.value) || 0 } : x) })} />
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" aria-label="Supprimer" onClick={() => setAssumptions({ fixedCosts: finance.assumptions.fixedCosts.filter((x) => x.id !== c.id) })}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => setAssumptions({ fixedCosts: [...finance.assumptions.fixedCosts, { id: uid(), label: '', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 0, growth: 0 } as CostLine] })}>
                <Plus className="h-4 w-4 mr-1.5" /> Ajouter une charge fixe
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Personnel</CardTitle>
              <p className="text-xs text-muted-foreground font-normal">Inclus dans les charges fixes du compte de résultat.</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {finance.assumptions.staff.map((s) => (
                <div key={s.id} className="flex gap-2">
                  <Input className="h-8 text-sm flex-1" placeholder="Poste" value={s.role}
                    onChange={(e) => setAssumptions({ staff: finance.assumptions.staff.map((x) => x.id === s.id ? { ...x, role: e.target.value } : x) })} />
                  <Input type="number" className="num-input h-8 text-sm w-16" placeholder="Nb" value={s.count || ''}
                    onChange={(e) => setAssumptions({ staff: finance.assumptions.staff.map((x) => x.id === s.id ? { ...x, count: Number(e.target.value) || 0 } : x) })} />
                  <Input type="number" className="num-input h-8 text-sm w-28" placeholder="Salaire/mois" value={s.monthlySalary || ''}
                    onChange={(e) => setAssumptions({ staff: finance.assumptions.staff.map((x) => x.id === s.id ? { ...x, monthlySalary: Number(e.target.value) || 0 } : x) })} />
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" aria-label="Supprimer" onClick={() => setAssumptions({ staff: finance.assumptions.staff.filter((x) => x.id !== s.id) })}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => setAssumptions({ staff: [...finance.assumptions.staff, { id: uid(), role: '', count: 1, monthlySalary: 0, annualGrowth: 0 } as StaffLine] })}>
                <Plus className="h-4 w-4 mr-1.5" /> Ajouter un poste
              </Button>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      {/* ------------------------------------------------ Résultats */}
      <TabsContent value="results" className="space-y-4">
        {financialsLocked ? (
          <LockedPanel
            title="Compte de résultat réservé à l'abonnement Premium"
            description="Visualisez le compte de résultat prévisionnel sur tout l'horizon (CA, marge, EBE, résultat net) ainsi que les flux de trésorerie année par année."
            features={["Compte de résultat sur 1 à 10 ans", "Flux de trésorerie et CAF", "Inclus dans les documents exportés"]}
            onUpgrade={() => openCheckout()}
          />
        ) : (
        !hasData ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Renseignez d&apos;abord vos produits et charges dans l&apos;onglet « Exploitation ».
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Compte de résultat prévisionnel</CardTitle></CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table className="min-w-[640px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Rubrique</TableHead>
                        {years.map((y) => <TableHead key={y} className="text-right">Année {y}</TableHead>)}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {([
                        ['Chiffre d\'affaires', (r: typeof comp.years[0]) => r.revenue, true],
                        ['Charges variables', (r: typeof comp.years[0]) => -r.variableCosts, false],
                        ['Marge sur coûts variables', (r: typeof comp.years[0]) => r.revenue - r.variableCosts, false],
                        ['Charges fixes (exploit. + personnel)', (r: typeof comp.years[0]) => -r.fixedCosts, false],
                        ['Excédent brut d\'exploitation', (r: typeof comp.years[0]) => r.ebitda, true],
                        ['Amortissements', (r: typeof comp.years[0]) => -r.depreciation, false],
                        ['Intérêts sur emprunts', (r: typeof comp.years[0]) => -r.interest, false],
                        ['Résultat avant impôt', (r: typeof comp.years[0]) => r.ebt, false],
                        ['Impôt sur les sociétés', (r: typeof comp.years[0]) => -r.tax, false],
                        ['RÉSULTAT NET', (r: typeof comp.years[0]) => r.netIncome, true],
                      ] as const).map(([label, get, bold]) => (
                        <TableRow key={label} className={bold ? 'font-semibold bg-muted/40' : ''}>
                          <TableCell>{label}</TableCell>
                          {comp.years.map((r) => (
                            <TableCell key={r.year} className="text-right">
                              {fmtCurrency(get(r), cur)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Flux de trésorerie</CardTitle>
                <p className="text-xs text-muted-foreground font-normal">
                  CAF = résultat net + amortissements. Flux net = CAF − remboursement du capital emprunté.
                </p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table className="min-w-[640px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Rubrique</TableHead>
                        {years.map((y) => <TableHead key={y} className="text-right">Année {y}</TableHead>)}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {([
                        ['Capacité d\'autofinancement (CAF)', (r: typeof comp.years[0]) => r.caf, false],
                        ['Remboursement du capital', (r: typeof comp.years[0]) => -r.principalRepayment, false],
                        ['Flux net de trésorerie', (r: typeof comp.years[0]) => r.freeCashFlow, true],
                        ['Flux cumulé (avec mise de fonds)', (r: typeof comp.years[0]) => r.cumulativeFCF, true],
                      ] as const).map(([label, get, bold]) => (
                        <TableRow key={label} className={bold ? 'font-semibold bg-muted/40' : ''}>
                          <TableCell>{label}</TableCell>
                          {comp.years.map((r) => (
                            <TableCell key={r.year} className={`text-right ${get(r) < 0 ? 'text-destructive' : ''}`}>
                              {fmtCurrency(get(r), cur)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </>
        )
        )}
      </TabsContent>

      {/* ------------------------------------------------ Indicateurs */}
      <TabsContent value="indicators" className="space-y-4">
        {indicatorsLocked ? (
          <LockedPanel
            title="Indicateurs de rentabilité réservés à l'abonnement Premium"
            description="VAN, TRI, délai de récupération, seuil de rentabilité, marges et DSCR : les indicateurs qui convainquent banquiers et investisseurs."
            features={['VAN, TRI, délai de récupération', 'Seuil de rentabilité et marges', 'DSCR (capacité de remboursement)']}
            onUpgrade={() => openCheckout()}
          />
        ) : (
        <>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <IndicatorCard
            title="VAN" value={fmtCurrency(comp.ratios.npv, cur)}
            sub={`Taux d'actualisation ${finance.assumptions.discountRate} %`}
            positive={comp.ratios.npv >= 0}
            tooltip="Valeur actuelle nette des flux du projet. Positive : le projet crée de la valeur."
          />
          <IndicatorCard
            title="TRI" value={comp.ratios.irr !== null ? `${comp.ratios.irr.toFixed(1)} %` : '—'}
            sub={`vs coût du capital ${finance.assumptions.discountRate} %`}
            positive={comp.ratios.irr !== null && comp.ratios.irr > finance.assumptions.discountRate}
            tooltip="Taux de rentabilité interne : rendement annuel implicite du projet."
          />
          <IndicatorCard
            title="Délai de récupération" value={comp.ratios.payback !== null ? `${comp.ratios.payback.toFixed(1)} an${comp.ratios.payback >= 2 ? 's' : ''}` : '—'}
            sub="Mise de fonds initiale récupérée"
            positive={comp.ratios.payback !== null && comp.ratios.payback <= 3}
            tooltip="Nombre d'années nécessaires pour retrouver la mise de fonds initiale."
          />
          <IndicatorCard
            title="Seuil de rentabilité" value={fmtCurrency(comp.ratios.breakEvenRevenue, cur)}
            sub={comp.ratios.breakEvenYear === 1 ? 'Atteint dès l\'année 1' : comp.ratios.breakEvenYear > 0 ? `Atteint en année ${comp.ratios.breakEvenYear}` : 'Non atteint sur l\'horizon'}
            positive={comp.ratios.breakEvenYear === 1}
            tooltip="Chiffre d'affaires minimum couvrant toutes les charges (année 1)."
          />
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <MiniStat label="Marge nette (an 1)" value={fmtPct(comp.ratios.netMargin)} />
          <MiniStat label="Marge d'EBE (an 1)" value={fmtPct(comp.ratios.ebitdaMargin)} />
          <MiniStat label="ROI moyen" value={fmtPct(comp.ratios.roi)} />
          <MiniStat label="DSCR (an 1)" value={comp.ratios.dscr !== null ? `${comp.ratios.dscr.toFixed(2)}×` : '—'} />
        </div>
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs leading-relaxed">
            VAN, TRI et délai de récupération sont calculés sur les <strong>flux du projet</strong> (avant
            financement) avec récupération du BFR en fin d&apos;horizon. Le DSCR mesure la capacité de
            remboursement : EBE / (intérêts + capital remboursé) de l&apos;année 1. Tous ces calculs sont
            identiques dans les documents exportés.
          </AlertDescription>
        </Alert>
        </>)}
      </TabsContent>

      {/* ------------------------------------------------ Scénarios */}
      <TabsContent value="scenarios" className="space-y-4">
        {scenariosLocked ? (
          <LockedPanel
            title="Analyse de scénarios réservée à l'abonnement Premium"
            description="Testez la robustesse de votre projet : scénario pessimiste, réaliste et optimiste avec impact direct sur le CA, le résultat net et la VAN."
            features={['Scénarios pessimiste / réaliste / optimiste', "Comparaison CA, résultat net et VAN", 'Tableau comparatif exportable']}
            onUpgrade={() => openCheckout()}
          />
        ) : (<>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Analyse de sensibilité</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">
              Le moteur recalcule intégralement les prévisions selon trois hypothèses de volume et de prix.
            </p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table className="min-w-[640px]">
                <TableHeader>
                  <TableRow>
                    <TableHead>Scénario</TableHead>
                    <TableHead className="text-right">CA (an 1)</TableHead>
                    <TableHead className="text-right">Résultat net (an 1)</TableHead>
                    <TableHead className="text-right">Résultat net moyen</TableHead>
                    <TableHead className="text-right">Récupération</TableHead>
                    <TableHead className="text-right">VAN</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {comp.scenarios.map((s) => (
                    <TableRow key={s.name} className={s.name === 'REALISTIC' ? 'bg-muted/40 font-medium' : ''}>
                      <TableCell>
                        {s.name === 'OPTIMISTIC' ? 'Optimiste' : s.name === 'PESSIMISTIC' ? 'Pessimiste' : 'Réaliste'}
                        <span className="block text-[11px] text-muted-foreground">{s.label}</span>
                      </TableCell>
                      <TableCell className="text-right">{fmtCurrency(s.revenue1, cur)}</TableCell>
                      <TableCell className="text-right">{fmtCurrency(s.netIncome1, cur)}</TableCell>
                      <TableCell className="text-right">{fmtCurrency(s.netIncomeAvg, cur)}</TableCell>
                      <TableCell className="text-right">{s.payback !== null ? `${s.payback.toFixed(1)} an(s)` : '—'}</TableCell>
                      <TableCell className={`text-right ${s.npv < 0 ? 'text-destructive' : ''}`}>{fmtCurrency(s.npv, cur)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        {comp.scenarios.length > 0 && (
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Résultat net moyen par scénario</CardTitle></CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={comp.scenarios.map((s) => ({ name: s.name === 'OPTIMISTIC' ? 'Optimiste' : s.name === 'PESSIMISTIC' ? 'Pessimiste' : 'Réaliste', net: Math.round(s.netIncomeAvg), npv: Math.round(s.npv) }))}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => fmtNumber(Number(v) / 1_000_000) + ' M'} />
                    <Tooltip formatter={(v: number) => fmtCurrency(v, cur)} />
                    <Legend />
                    <Bar dataKey="net" name="Résultat net moyen" fill="#D4A72C" radius={[6, 6, 0, 0]} maxBarSize={50} />
                    <Bar dataKey="npv" name="VAN" fill="#0F172A" radius={[6, 6, 0, 0]} maxBarSize={50} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
        </>)}
      </TabsContent>

      {/* ------------------------------------------------ Graphiques */}
      <TabsContent value="charts" className="space-y-4">
        {chartsLocked ? (
          <LockedPanel
            title="Graphiques financiers réservés à l'abonnement Premium"
            description="Suivez l'évolution de votre chiffre d'affaires, de votre EBE et de votre résultat net avec des graphiques clairs, prêts à présenter."
            features={['Évolution du CA et du résultat', "Structure des charges", 'Répartition du financement']}
            onUpgrade={() => openCheckout()}
          />
        ) : (
        !hasData ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>Renseignez vos hypothèses dans l&apos;onglet « Exploitation » pour afficher les graphiques.</AlertDescription>
          </Alert>
        ) : (
          <>
            <div className="grid lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-base">CA, charges et résultat net</CardTitle></CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={comp.years.map((y) => ({
                        name: `An ${y.year}`,
                        CA: Math.round(y.revenue),
                        Charges: Math.round(y.variableCosts + y.fixedCosts),
                        'Résultat net': Math.round(y.netIncome),
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => fmtNumber(Number(v) / 1_000_000) + ' M'} />
                        <Tooltip formatter={(v: number) => fmtCurrency(v, cur)} />
                        <Legend />
                        <Bar dataKey="CA" fill="#0F172A" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="Charges" fill="#94A3B8" radius={[4, 4, 0, 0]} />
                        <Line type="monotone" dataKey="Résultat net" stroke="#D4A72C" strokeWidth={2.5} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-base">Flux de trésorerie cumulés</CardTitle></CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={comp.years.map((y) => ({ name: `An ${y.year}`, Cumulé: Math.round(y.cumulativeFCF) }))}>
                        <defs>
                          <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#D4A72C" stopOpacity={0.5} />
                            <stop offset="100%" stopColor="#D4A72C" stopOpacity={0.05} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => fmtNumber(Number(v) / 1_000_000) + ' M'} />
                        <Tooltip formatter={(v: number) => fmtCurrency(v, cur)} />
                        <Area type="monotone" dataKey="Cumulé" stroke="#0F172A" strokeWidth={2} fill="url(#goldGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Structure des coûts (année 1)</CardTitle></CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-6 items-center">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Charges variables', value: Math.round(comp.years[0]?.variableCosts ?? 0) },
                          { name: 'Charges fixes', value: Math.round(comp.years[0]?.fixedCosts ?? 0) },
                          { name: 'Amortissements', value: Math.round(comp.years[0]?.depreciation ?? 0) },
                          { name: 'Intérêts', value: Math.round(comp.years[0]?.interest ?? 0) },
                          { name: 'Impôts', value: Math.round(comp.years[0]?.tax ?? 0) },
                        ].filter((d) => d.value > 0)}
                        dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2}
                      >
                        {CHART_COLORS.map((c, i) => <Cell key={i} fill={c} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => fmtCurrency(v, cur)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ul className="space-y-2 text-sm">
                  {[
                    ['Charges variables', comp.years[0]?.variableCosts ?? 0],
                    ['Charges fixes (exploit. + personnel)', comp.years[0]?.fixedCosts ?? 0],
                    ['Amortissements', comp.years[0]?.depreciation ?? 0],
                    ['Intérêts d\'emprunt', comp.years[0]?.interest ?? 0],
                    ['Impôts', comp.years[0]?.tax ?? 0],
                  ].map(([label, v], i) => (
                    <li key={label as string} className="flex items-center gap-2.5">
                      <span className="h-3 w-3 rounded-sm shrink-0" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                      <span className="flex-1">{label}</span>
                      <span className="font-medium">{fmtCurrency(v as number, cur)}</span>
                      <span className="text-muted-foreground w-14 text-right">
                        {comp.years[0] && (comp.years[0].revenue > 0 ? `${((v as number) / comp.years[0].revenue * 100).toFixed(1)} %` : '—')}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {comp.financingGap > 0 && (
              <Alert variant="destructive">
                <TriangleAlert className="h-4 w-4" />
                <AlertDescription>
                  Le financement prévu ({fmtCurrency(comp.totalFinancing, cur)}) ne couvre pas le besoin total
                  ({fmtCurrency(comp.totalNeeds, cur)}). Complétez le plan de financement.
                </AlertDescription>
              </Alert>
            )}
          </>
        )
        )}
      </TabsContent>
    </Tabs>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-muted/30 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-semibold mt-0.5">{value}</div>
    </div>
  )
}

function IndicatorCard({ title, value, sub, positive, tooltip }: {
  title: string; value: string; sub: string; positive: boolean | null; tooltip: string
}) {
  return (
    <Card className="hover:shadow-md transition-shadow" title={tooltip}>
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-muted-foreground">{title}</span>
          {positive !== null && (
            <span className={`h-2 w-2 rounded-full ${positive ? 'bg-emerald-500' : 'bg-amber-500'}`} />
          )}
        </div>
        <div className="text-xl font-bold mt-1.5 leading-none">{value}</div>
        <div className="text-[11px] text-muted-foreground mt-1.5">{sub}</div>
      </CardContent>
    </Card>
  )
}

export { Progress }
