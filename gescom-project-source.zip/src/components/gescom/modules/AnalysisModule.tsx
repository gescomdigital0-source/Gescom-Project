'use client'

// GESCOM PROJECT – Module Analyse : aperçu, SWOT, PESTEL, marché,
// concurrence, besoins, risques, faisabilité, synthèse
import { useState } from 'react'
import type {
  AnalysisData, Competitor, FeasibilityData, MarketData, NeedItem,
  OverviewData, PestelData, RiskItem, SwotItem,
} from '@/lib/types'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import { LEGAL_FORMS, REGIONS } from '@/lib/constants'
import { uid } from '@/lib/types'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { cn } from '@/lib/utils'
import { sectorExamples, insertExample, PESTEL_QUESTIONS, OVERVIEW_TEMPLATES, SYNTHESIS_TEMPLATE, RECOMMENDATIONS_TEMPLATE, type SectorExamples } from '@/lib/analysis-examples'
import { AiImproveButton } from '@/components/gescom/ai/AiImprove'
import { CountryResearch } from '@/components/gescom/ai/CountryResearch'
import { useApp } from '@/lib/store'
import { isFeatureLocked } from '@/lib/plans'
import { LockedPanel } from '@/components/gescom/LockedPanel'
import {
  FileText, ChartPie, Globe, Users, Sword, ShieldAlert, Scale, MessageSquare,
  Plus, X, TrendingUp, TrendingDown, ThumbsUp, ThumbsDown, Lightbulb, Sparkles, Info, Check, Lock,
} from 'lucide-react'

interface Props {
  project: ProjectRecord
  overview: OverviewData
  objectives: string[]
  analysis: AnalysisData
  saveOverview: (v: OverviewData, immediate?: boolean) => void
  saveObjectives: (v: string[], immediate?: boolean) => void
  saveAnalysis: (v: AnalysisData, immediate?: boolean) => void
}

export function AnalysisModule({ project, overview, objectives, analysis, saveOverview, saveObjectives, saveAnalysis }: Props) {
  const ex = sectorExamples(project.sector)
  const plan = useApp((s) => s.user?.plan)
  const openCheckout = useApp((s) => s.openCheckout)
  const risksLocked = isFeatureLocked(plan, 'risks')
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-sky-200 bg-sky-50/60 dark:bg-sky-950/20 dark:border-sky-900 p-3.5 text-xs text-sky-900 dark:text-sky-200 leading-relaxed flex gap-2.5">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <div>
          <strong>Comment remplir cette partie :</strong> suivez les onglets de gauche à droite
          (Aperçu → SWOT → PESTEL → Marché → Concurrence → Risques → Faisabilité → Synthèse).
          Sur chaque champ, le bouton <Lightbulb className="inline h-3 w-3 mx-0.5 -mt-0.5" /><strong>Exemple</strong> insère
          un texte adapté à votre secteur (« {project.sector} ») : remplacez les éléments entre [crochets] par vos
          propres observations et chiffres. Tout est enregistré automatiquement.
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
      <TabsList className="flex flex-wrap h-auto gap-1 bg-muted/60 p-1">
        <TabsTrigger value="overview" className="gap-1.5"><FileText className="h-3.5 w-3.5" /> Aperçu général</TabsTrigger>
        <TabsTrigger value="swot" className="gap-1.5"><ChartPie className="h-3.5 w-3.5" /> SWOT</TabsTrigger>
        <TabsTrigger value="pestel" className="gap-1.5"><Globe className="h-3.5 w-3.5" /> PESTEL</TabsTrigger>
        <TabsTrigger value="market" className="gap-1.5"><Users className="h-3.5 w-3.5" /> Marché</TabsTrigger>
        <TabsTrigger value="competition" className="gap-1.5"><Sword className="h-3.5 w-3.5" /> Concurrence</TabsTrigger>
        <TabsTrigger value="risks" className="gap-1.5">
          <ShieldAlert className="h-3.5 w-3.5" /> Risques
          {risksLocked && <Lock className="h-3 w-3 text-[#d4a72c]" aria-label="Réservé Premium" />}
        </TabsTrigger>
        <TabsTrigger value="feasibility" className="gap-1.5"><Scale className="h-3.5 w-3.5" /> Faisabilité</TabsTrigger>
        <TabsTrigger value="synthesis" className="gap-1.5"><MessageSquare className="h-3.5 w-3.5" /> Synthèse</TabsTrigger>
      </TabsList>

      <TabsContent value="overview"><OverviewTab project={project} overview={overview} objectives={objectives} saveOverview={saveOverview} saveObjectives={saveObjectives} /></TabsContent>
      <TabsContent value="swot"><SwotTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} /></TabsContent>
      <TabsContent value="pestel"><PestelTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} /></TabsContent>
      <TabsContent value="market"><MarketTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} /></TabsContent>
      <TabsContent value="competition"><CompetitionTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} /></TabsContent>
      <TabsContent value="risks">
        {risksLocked ? (
          <LockedPanel
            title="Évaluation des risques réservée à l'abonnement Premium"
            description="Identifiez vos risques, évaluez leur probabilité et leur impact, et décrivez vos mesures d'atténuation grâce au registre de criticité (probabilité × impact)."
            features={['Registre des risques avec criticité /25', 'Mesures d\'atténuation par risque', 'Inclus dans le dossier et la présentation générés']}
            onUpgrade={() => openCheckout()}
          />
        ) : (
          <RisksTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} />
        )}
      </TabsContent>
      <TabsContent value="feasibility"><FeasibilityTab projectId={project.id} analysis={analysis} save={saveAnalysis} ex={ex} /></TabsContent>
      <TabsContent value="synthesis"><SynthesisTab projectId={project.id} analysis={analysis} save={saveAnalysis} /></TabsContent>
    </Tabs>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Aperçu général
// ---------------------------------------------------------------------------

function OverviewTab({ project, overview, objectives, saveOverview, saveObjectives }: {
  project: ProjectRecord
  overview: OverviewData
  objectives: string[]
  saveOverview: (v: OverviewData, immediate?: boolean) => void
  saveObjectives: (v: string[], immediate?: boolean) => void
}) {
  const set = <K extends keyof OverviewData>(k: K, v: OverviewData[K]) => saveOverview({ ...overview, [k]: v })
  return (
    <div className="space-y-5">
      <CountryResearch project={project} overview={overview} />
      <div className="grid lg:grid-cols-2 gap-5">
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Identification du projet</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Porteur du projet</Label>
            <Input value={overview.promoter} onChange={(e) => set('promoter', e.target.value)} placeholder="Nom et qualité du porteur" />
          </div>
          <div className="space-y-1.5">
            <Label>Forme juridique envisagée</Label>
            <Select value={overview.legalForm} onValueChange={(v) => set('legalForm', v)}>
              <SelectTrigger><SelectValue placeholder="Choisir une forme juridique" /></SelectTrigger>
              <SelectContent>
                {LEGAL_FORMS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Pays du projet</Label>
              <Input value={project.country || ''} disabled placeholder="Défini à la création du projet" />
            </div>
            <div className="space-y-1.5">
              <Label>Région / ville du projet</Label>
              {REGIONS[project.country]?.length ? (
                <Input value={overview.location} onChange={(e) => set('location', e.target.value)} placeholder={REGIONS[project.country].join(', ')} />
              ) : (
                <Input value={overview.location} onChange={(e) => set('location', e.target.value)} placeholder="Ex. Zone industrielle de Douala" />
              )}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Date prévisionnelle de démarrage</Label>
            <Input type="date" value={overview.startDate} onChange={(e) => set('startDate', e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Vision, mission & valeurs</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <Label>Vision</Label>
              <div className="flex items-center gap-1.5">
                <ExampleButton onClick={() => set('vision', insertExample(overview.vision, OVERVIEW_TEMPLATES.vision))} />
                <AiImproveButton compact projectId={project.id} target="overview.vision" value={overview.vision} onApply={(v) => set('vision', v as string)} />
              </div>
            </div>
            <Textarea rows={2} value={overview.vision} onChange={(e) => set('vision', e.target.value)} placeholder="Où voulez-vous être dans 5 ans ?" />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <Label>Mission</Label>
              <div className="flex items-center gap-1.5">
                <ExampleButton onClick={() => set('mission', insertExample(overview.mission, OVERVIEW_TEMPLATES.mission))} />
                <AiImproveButton compact projectId={project.id} target="overview.mission" value={overview.mission} onApply={(v) => set('mission', v as string)} />
              </div>
            </div>
            <Textarea rows={3} value={overview.mission} onChange={(e) => set('mission', e.target.value)} placeholder="Quelle valeur créez-vous, pour qui, comment ?" />
          </div>
          <div className="space-y-1.5">
            <Label>Valeurs</Label>
            <Input value={overview.values} onChange={(e) => set('values', e.target.value)} placeholder="Qualité, transparence, ancrage local…" />
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="text-base">Résumé exécutif</CardTitle>
            <div className="flex items-center gap-1.5">
              <ExampleButton label="Insérer un modèle à compléter" onClick={() => set('summary', insertExample(overview.summary, OVERVIEW_TEMPLATES.summary))} />
              <AiImproveButton projectId={project.id} target="overview.summary" value={overview.summary} onApply={(v) => set('summary', v as string)} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Textarea rows={5} value={overview.summary} onChange={(e) => set('summary', e.target.value)} placeholder="Synthèse complète du projet : activité, marché, besoins de financement, résultats attendus… (utilisé en première page du dossier)" />
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="text-base">Objectifs du projet</CardTitle>
            <AiImproveButton projectId={project.id} target="objectives" value={objectives.filter((o) => o.trim())} onApply={(v) => { const arr = v as string[]; if (arr.length) saveObjectives(arr, true) }} />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {objectives.length === 0 && <p className="text-sm text-muted-foreground">Aucun objectif défini. Ajoutez des objectifs mesurables.</p>}
          {objectives.map((o, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={o}
                onChange={(e) => {
                  const arr = [...objectives]
                  arr[i] = e.target.value
                  saveObjectives(arr)
                }}
              />
              <Button variant="ghost" size="icon" aria-label="Supprimer" onClick={() => saveObjectives(objectives.filter((_, j) => j !== i))}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={() => saveObjectives([...objectives, ''])}>
            <Plus className="h-4 w-4 mr-1.5" /> Ajouter un objectif
          </Button>
        </CardContent>
      </Card>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// SWOT
// ---------------------------------------------------------------------------

const SWOT_QUADRANTS: Array<{
  key: 'strengths' | 'weaknesses' | 'opportunities' | 'threats'
  label: string
  icon: typeof TrendingUp
  hint: string
  tone: string
}> = [
  { key: 'strengths', label: 'Forces', icon: ThumbsUp, hint: 'Avantages internes dont vous disposez', tone: 'border-emerald-200 bg-emerald-50/40' },
  { key: 'weaknesses', label: 'Faiblesses', icon: ThumbsDown, hint: 'Limites internes à corriger ou assumer', tone: 'border-red-200 bg-red-50/40' },
  { key: 'opportunities', label: 'Opportunités', icon: TrendingUp, hint: 'Facteurs externes favorables à saisir', tone: 'border-sky-200 bg-sky-50/40' },
  { key: 'threats', label: 'Menaces', icon: TrendingDown, hint: 'Risques externes à anticiper', tone: 'border-amber-200 bg-amber-50/40' },
]

function SwotTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  const [drafts, setDrafts] = useState<Record<string, string>>({})

  const addItem = (quad: keyof typeof analysis.swot) => {
    const label = (drafts[quad] || '').trim()
    if (!label) return
    const item: SwotItem = { id: uid(), label }
    save({ ...analysis, swot: { ...analysis.swot, [quad]: [...analysis.swot[quad], item] } }, true)
    setDrafts((d) => ({ ...d, [quad]: '' }))
  }

  const addAllExamples = (quad: keyof typeof analysis.swot) => {
    const existing = new Set(analysis.swot[quad].map((i) => i.label))
    const fresh = ex.swot[quad].filter((l) => !existing.has(l)).map((label): SwotItem => ({ id: uid(), label }))
    if (fresh.length === 0) return
    save({ ...analysis, swot: { ...analysis.swot, [quad]: [...analysis.swot[quad], ...fresh] } }, true)
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {SWOT_QUADRANTS.map((q) => {
        const Icon = q.icon
        const items = analysis.swot[q.key]
        return (
          <Card key={q.key} className={cn('border', q.tone)}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Icon className="h-4 w-4" /> {q.label}
                <Badge variant="outline" className="ml-auto">{items.length}</Badge>
                <AiImproveButton
                  compact
                  projectId={projectId}
                  target={`swot.${q.key}`}
                  value={items.map((i) => i.label)}
                  onApply={(v) => {
                    const labels = v as string[]
                    if (!labels.length) return
                    save({ ...analysis, swot: { ...analysis.swot, [q.key]: labels.map((label): SwotItem => ({ id: uid(), label })) } }, true)
                  }}
                />
              </CardTitle>
              <p className="text-xs text-muted-foreground font-normal">{q.hint}</p>
            </CardHeader>
            <CardContent className="space-y-2">
              <ul className="space-y-1.5">
                {items.map((item) => (
                  <li key={item.id} className="flex items-start gap-2 group">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-current opacity-40 shrink-0" />
                    <span className="text-sm flex-1 leading-snug">{item.label}</span>
                    <button
                      type="button"
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                      onClick={() => save({ ...analysis, swot: { ...analysis.swot, [q.key]: items.filter((i) => i.id !== item.id) } }, true)}
                      aria-label="Supprimer"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
                {items.length === 0 && <li className="text-xs text-muted-foreground">Aucun élément — cliquez sur un exemple ci-dessous pour l&apos;insérer.</li>}
              </ul>
              <div className="flex gap-2 pt-1">
                <Input
                  className="h-8 text-xs"
                  placeholder={`Ajouter une ${q.label.toLowerCase().replace(/s$/, '')}…`}
                  value={drafts[q.key] || ''}
                  onChange={(e) => setDrafts((d) => ({ ...d, [q.key]: e.target.value }))}
                  onKeyDown={(e) => e.key === 'Enter' && addItem(q.key)}
                />
                <Button size="sm" variant="outline" className="h-8" onClick={() => addItem(q.key)}>
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] text-muted-foreground">Exemples à adapter :</span>
                {ex.swot[q.key].map((s) => (
                  <button
                    key={s}
                    type="button"
                    title={s}
                    onClick={() => setDrafts((d) => ({ ...d, [q.key]: s }))}
                    className="max-w-full truncate rounded-full border bg-background px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                  >
                    {s.length > 44 ? `${s.slice(0, 44)}…` : s}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => addAllExamples(q.key)}
                  className="inline-flex items-center gap-1 rounded-full border border-amber-300 bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-900 transition-colors hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200 dark:hover:bg-amber-900/40"
                >
                  <Sparkles className="h-3 w-3" /> Tout ajouter
                </button>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

// ---------------------------------------------------------------------------
// PESTEL
// ---------------------------------------------------------------------------

const PESTEL_FIELDS: Array<{ key: keyof PestelData; label: string; hint: string }> = [
  { key: 'politique', label: 'Politique', hint: 'Stabilité, politiques publiques, subventions, taxes' },
  { key: 'economique', label: 'Économique', hint: 'Inflation, pouvoir d\'achat, taux d\'intérêt, change' },
  { key: 'socioculturel', label: 'Socioculturel', hint: 'Démographie, habitudes de consommation, culture' },
  { key: 'technologique', label: 'Technologique', hint: 'Innovations, équipements disponibles, digitalisation' },
  { key: 'ecologique', label: 'Écologique', hint: 'Climat, ressources, gestion des déchets, normes' },
  { key: 'legal', label: 'Légal', hint: 'Réglementations, licences, normes sanitaires, fiscalité' },
]

function PestelTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  const filled = PESTEL_FIELDS.filter((f) => analysis.pestel[f.key].trim().length > 0).length

  const setField = (key: keyof PestelData, value: string) =>
    save({ ...analysis, pestel: { ...analysis.pestel, [key]: value } })

  const addChip = (key: keyof PestelData, chip: string) =>
    setField(key, insertExample(analysis.pestel[key], chip))

  // Insère l'exemple complet du secteur dans chaque dimension encore vide
  const fillEmptyFields = () => {
    const next = { ...analysis.pestel }
    let touched = false
    for (const f of PESTEL_FIELDS) {
      if (!next[f.key].trim()) {
        next[f.key] = ex.pestel[f.key]
        touched = true
      }
    }
    if (touched) save({ ...analysis, pestel: next }, true)
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-sky-200 bg-sky-50/60 dark:bg-sky-950/20 dark:border-sky-900 p-3.5 text-xs text-sky-900 dark:text-sky-200 leading-relaxed flex gap-2.5">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <div>
          <strong>PESTEL = le scan de votre environnement extérieur</strong> : tout ce que vous ne contrôlez
          pas mais qui influence votre projet. Pour chaque dimension, lisez les <strong>questions à vous poser</strong>,
          cliquez sur les <strong>suggestions</strong> proches de votre situation puis adaptez le texte (remplacez
          les éléments entre [crochets] par vos propres observations). Le bouton
          <Lightbulb className="inline h-3 w-3 mx-1 -mt-0.5" /><strong>Exemple</strong> insère un paragraphe complet à reprendre.
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Badge variant="outline" className={cn('shrink-0', filled === 6 && 'bg-emerald-50 text-emerald-800 border-emerald-200')}>
          {filled}/6 dimensions renseignées
        </Badge>
        <div className="h-1.5 flex-1 min-w-[120px] rounded-full bg-muted overflow-hidden">
          <div className="h-full rounded-full bg-primary transition-all duration-300" style={{ width: `${(filled / 6) * 100}%` }} />
        </div>
        <Button variant="outline" size="sm" onClick={fillEmptyFields} disabled={filled === 6}>
          <Sparkles className="h-3.5 w-3.5 mr-1.5" /> Pré-remplir les champs vides
        </Button>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {PESTEL_FIELDS.map((f) => {
          const isFilled = analysis.pestel[f.key].trim().length > 0
          return (
            <Card key={f.key} className={cn(isFilled && 'border-emerald-200 dark:border-emerald-900')}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between gap-2">
                  <CardTitle className="text-sm flex items-center gap-1.5">
                    {f.label}
                    {isFilled && <Check className="h-3.5 w-3.5 text-emerald-600" aria-label="Renseigné" />}
                  </CardTitle>
                  <div className="flex items-center gap-1.5">
                  <ExampleButton onClick={() => setField(f.key, insertExample(analysis.pestel[f.key], ex.pestel[f.key]))} />
                  <AiImproveButton compact projectId={projectId} target={`pestel.${f.key}`} value={analysis.pestel[f.key]} onApply={(v) => setField(f.key, v as string)} />
                </div>
                </div>
                <p className="text-xs text-muted-foreground font-normal">{f.hint}</p>
              </CardHeader>
              <CardContent className="space-y-2.5">
                <div className="rounded-lg bg-muted/50 p-2.5 text-[11px] leading-relaxed text-muted-foreground">
                  <span className="font-medium text-foreground">Questions à vous poser :</span>
                  <ul className="mt-1 space-y-0.5 list-disc list-inside">
                    {PESTEL_QUESTIONS[f.key].map((q) => <li key={q}>{q}</li>)}
                  </ul>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] text-muted-foreground">Suggestions :</span>
                  {ex.pestelChips[f.key].map((chip) => {
                    // Troncature propre : coupe à l'espace précédent, jamais au
                    // milieu d'un mot ni à l'intérieur d'un crochet.
                    const short = chip.length > 56
                      ? `${chip.slice(0, Math.max(chip.lastIndexOf(' ', 56), 30)).replace(/[\s—:,-]+$/, '')}…`
                      : chip
                    return (
                      <button
                        key={chip}
                        type="button"
                        title={chip}
                        onClick={() => addChip(f.key, chip)}
                        className="max-w-full truncate rounded-full border bg-background px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                      >
                        {short}
                      </button>
                    )
                  })}
                </div>
                <Textarea
                  rows={5}
                  value={analysis.pestel[f.key]}
                  onChange={(e) => setField(f.key, e.target.value)}
                  placeholder={`Ex. : le contexte ${f.label.toLowerCase()} qui influence votre projet…`}
                />
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Marché
// ---------------------------------------------------------------------------

const MARKET_FIELDS: Array<{ key: keyof MarketData; label: string; hint: string; rows?: number }> = [
  { key: 'demande', label: 'Analyse de la demande', hint: 'Volume, saisonnalité, évolution. Notez vos hypothèses : elles devront être validées par une enquête terrain.', rows: 4 },
  { key: 'offre', label: 'Analyse de l\'offre', hint: 'Qui produit/vend déjà ? En quelles quantités ? À quels prix ?', rows: 4 },
  { key: 'segments', label: 'Segments de clientèle', hint: 'Décrivez chaque segment (ménages, professionnels, institutions…)', rows: 3 },
  { key: 'cible', label: 'Clientèle cible', hint: 'Segments prioritaires et premiers clients visés', rows: 3 },
  { key: 'zones', label: 'Zone de chalandise', hint: 'Zone géographique desservie, distances, logistique', rows: 2 },
  { key: 'tendances', label: 'Tendances du marché', hint: 'Évolutions de consommation, digitalisation, réglementations', rows: 3 },
  { key: 'conclusion', label: 'Conclusion de l\'étude', hint: 'Le marché justifie-t-il le lancement ? Conditions de succès.', rows: 3 },
]

function MarketTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  const addTypeNeeds = () => {
    const existing = new Set(analysis.needs.map((n) => n.label))
    const fresh = ex.needs
      .filter((n) => !existing.has(n.label))
      .map((n): NeedItem => ({ id: uid(), ...n }))
    if (fresh.length === 0) return
    save({ ...analysis, needs: [...analysis.needs, ...fresh] }, true)
  }
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-amber-200 bg-amber-50/60 dark:bg-amber-950/20 dark:border-amber-900 p-4 text-xs text-amber-900 dark:text-amber-200 leading-relaxed">
        <strong>Rigueur des données :</strong> GESCOM PROJECT n&apos;insère jamais de statistiques de marché
        inventées. Renseignez vos propres observations et validez-les par une enquête terrain avant de
        présenter votre dossier.
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        {MARKET_FIELDS.map((f) => (
          <Card key={f.key}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-sm">{f.label}</CardTitle>
                <div className="flex items-center gap-1.5">
                  <ExampleButton onClick={() => save({ ...analysis, market: { ...analysis.market, [f.key]: insertExample(analysis.market[f.key], ex.market[f.key]) } })} />
                  <AiImproveButton compact projectId={projectId} target={`market.${f.key}`} value={analysis.market[f.key]} onApply={(v) => save({ ...analysis, market: { ...analysis.market, [f.key]: v as string } })} />
                </div>
              </div>
              <p className="text-xs text-muted-foreground font-normal">{f.hint}</p>
            </CardHeader>
            <CardContent>
              <Textarea
                rows={f.rows ?? 3}
                value={analysis.market[f.key]}
                onChange={(e) => save({ ...analysis, market: { ...analysis.market, [f.key]: e.target.value } })}
              />
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Besoins identifiés */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">Besoins identifiés
            <Badge variant="outline">{analysis.needs.length}</Badge>
            <AiImproveButton
              compact
              projectId={projectId}
              target="needs"
              value={analysis.needs.map((n) => ({ label: n.label, target: n.target, frequency: n.frequency }))}
              onApply={(v) => {
                const rows = v as Array<{ label: string; target: string; frequency: string }>
                if (rows.length) save({ ...analysis, needs: rows.map((n) => ({ id: uid(), ...n })) }, true)
              }}
            />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[45%]">Besoin</TableHead>
                <TableHead>Cible</TableHead>
                <TableHead>Fréquence</TableHead>
                <TableHead className="w-10" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {analysis.needs.map((n) => (
                <TableRow key={n.id}>
                  <TableCell>
                    <Input
                      className="h-8 text-sm"
                      value={n.label}
                      onChange={(e) => save({ ...analysis, needs: analysis.needs.map((x) => x.id === n.id ? { ...x, label: e.target.value } : x) })}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      className="h-8 text-sm"
                      value={n.target}
                      onChange={(e) => save({ ...analysis, needs: analysis.needs.map((x) => x.id === n.id ? { ...x, target: e.target.value } : x) })}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      className="h-8 text-sm"
                      value={n.frequency}
                      onChange={(e) => save({ ...analysis, needs: analysis.needs.map((x) => x.id === n.id ? { ...x, frequency: e.target.value } : x) })}
                    />
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Supprimer" onClick={() => save({ ...analysis, needs: analysis.needs.filter((x) => x.id !== n.id) }, true)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline" size="sm"
              onClick={() => {
                const n: NeedItem = { id: uid(), label: '', target: '', frequency: '' }
                save({ ...analysis, needs: [...analysis.needs, n] }, true)
              }}
            >
              <Plus className="h-4 w-4 mr-1.5" /> Ajouter un besoin
            </Button>
            {ex.needs.length > 0 && (
              <Button variant="outline" size="sm" onClick={addTypeNeeds}>
                <Sparkles className="h-4 w-4 mr-1.5" /> Insérer des besoins types du secteur
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Concurrence
// ---------------------------------------------------------------------------

function CompetitionTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  const add = () => {
    const c: Competitor = { id: uid(), name: '', type: 'Concurrent direct', strengths: '', weaknesses: '', positioning: '' }
    save({ ...analysis, competitors: [...analysis.competitors, c] }, true)
  }
  const addTypeCompetitors = () => {
    const existing = new Set(analysis.competitors.map((c) => c.name))
    const fresh = ex.competitors
      .filter((c) => !existing.has(c.name))
      .map((c): Competitor => ({ id: uid(), ...c }))
    if (fresh.length === 0) return
    save({ ...analysis, competitors: [...analysis.competitors, ...fresh] }, true)
  }
  const update = (id: string, patch: Partial<Competitor>) =>
    save({ ...analysis, competitors: analysis.competitors.map((c) => c.id === id ? { ...c, ...patch } : c) })

  return (
    <div className="space-y-4">
      {analysis.competitors.length === 0 && (
        <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">
          Aucun concurrent renseigné. Identifiez vos concurrents directs et indirects, ou insérez
          des concurrents types du secteur ci-dessous pour partir d&apos;une base à adapter.
        </CardContent></Card>
      )}
      {analysis.competitors.map((c, i) => (
        <Card key={c.id}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              Concurrent {i + 1}
              <Button variant="ghost" size="icon" className="ml-auto h-7 w-7" aria-label="Supprimer" onClick={() => save({ ...analysis, competitors: analysis.competitors.filter((x) => x.id !== c.id) }, true)}>
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Nom / catégorie</Label>
              <Input className="h-8" value={c.name} onChange={(e) => update(c.id, { name: e.target.value })} placeholder="Ex. Fermes semi-industrielles locales" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Type de concurrence</Label>
              <Select value={c.type} onValueChange={(v) => update(c.id, { type: v })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Concurrent direct">Concurrent direct</SelectItem>
                  <SelectItem value="Concurrent indirect">Concurrent indirect</SelectItem>
                  <SelectItem value="Substitut potentiel">Substitut potentiel</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Forces</Label>
              <Textarea rows={2} value={c.strengths} onChange={(e) => update(c.id, { strengths: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Faiblesses</Label>
              <Textarea rows={2} value={c.weaknesses} onChange={(e) => update(c.id, { weaknesses: e.target.value })} />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-xs">Votre positionnement face à ce concurrent</Label>
              <Input value={c.positioning} onChange={(e) => update(c.id, { positioning: e.target.value })} />
            </div>
          </CardContent>
        </Card>
      ))}
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={add}><Plus className="h-4 w-4 mr-1.5" /> Ajouter un concurrent</Button>
        {ex.competitors.length > 0 && (
          <Button variant="outline" onClick={addTypeCompetitors}><Sparkles className="h-4 w-4 mr-1.5" /> Insérer des concurrents types</Button>
        )}
        <AiImproveButton
          projectId={projectId}
          target="competitors"
          value={analysis.competitors.map((c) => ({ name: c.name, type: c.type, strengths: c.strengths, weaknesses: c.weaknesses, positioning: c.positioning }))}
          onApply={(v) => {
            const rows = v as Array<{ name: string; type: string; strengths: string; weaknesses: string; positioning: string }>
            if (rows.length) save({ ...analysis, competitors: rows.map((c) => ({ id: uid(), ...c })) }, true)
          }}
        />
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Risques
// ---------------------------------------------------------------------------

function criticitéBadge(p: number, i: number) {
  const score = p * i
  if (score >= 15) return <Badge className="bg-red-100 text-red-800 border-red-200" variant="outline">Critique ({score}/25)</Badge>
  if (score >= 8) return <Badge className="bg-amber-100 text-amber-800 border-amber-200" variant="outline">Élevée ({score}/25)</Badge>
  if (score >= 4) return <Badge className="bg-sky-100 text-sky-800 border-sky-200" variant="outline">Modérée ({score}/25)</Badge>
  return <Badge className="bg-slate-100 text-slate-600 border-slate-200" variant="outline">Faible ({score}/25)</Badge>
}

function RisksTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  const update = (id: string, patch: Partial<RiskItem>) =>
    save({ ...analysis, risks: analysis.risks.map((r) => r.id === id ? { ...r, ...patch } : r) })
  const addTypeRisks = () => {
    const existing = new Set(analysis.risks.map((r) => r.label))
    const fresh = ex.risks
      .filter((r) => !existing.has(r.label))
      .map((r): RiskItem => ({ id: uid(), ...r }))
    if (fresh.length === 0) return
    save({ ...analysis, risks: [...analysis.risks, ...fresh] }, true)
  }

  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">
        La criticité se calcule automatiquement : <strong>probabilité × impact</strong>. Triez vos actions d&apos;atténuation
        en priorisant les risques critiques.
      </p>
      {[...analysis.risks].sort((a, b) => b.probability * b.impact - a.probability * a.impact).map((r) => (
        <Card key={r.id}>
          <CardContent className="p-4 space-y-3">
            <div className="flex flex-col sm:flex-row gap-3">
              <Input
                className="flex-1"
                value={r.label}
                onChange={(e) => update(r.id, { label: e.target.value })}
                placeholder="Intitulé du risque"
              />
              <div className="flex gap-2">
                <Select value={String(r.probability)} onValueChange={(v) => update(r.id, { probability: Number(v) })}>
                  <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5].map((n) => <SelectItem key={n} value={String(n)}>Probabilité {n}/5</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={String(r.impact)} onValueChange={(v) => update(r.id, { impact: Number(v) })}>
                  <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5].map((n) => <SelectItem key={n} value={String(n)}>Impact {n}/5</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button variant="ghost" size="icon" aria-label="Supprimer" onClick={() => save({ ...analysis, risks: analysis.risks.filter((x) => x.id !== r.id) }, true)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {criticitéBadge(r.probability, r.impact)}
              <Input
                className="flex-1 min-w-[240px] h-8 text-sm"
                value={r.category}
                onChange={(e) => update(r.id, { category: e.target.value })}
                placeholder="Catégorie (sanitaire, financier, commercial…)"
              />
            </div>
            <Textarea
              rows={2}
              className="text-sm"
              value={r.mitigation}
              onChange={(e) => update(r.id, { mitigation: e.target.value })}
              placeholder="Mesures d'atténuation prévues…"
            />
          </CardContent>
        </Card>
      ))}
      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          onClick={() => {
            const r: RiskItem = { id: uid(), label: '', category: '', probability: 3, impact: 3, mitigation: '' }
            save({ ...analysis, risks: [...analysis.risks, r] }, true)
          }}
        >
          <Plus className="h-4 w-4 mr-1.5" /> Ajouter un risque
        </Button>
        {ex.risks.length > 0 && (
          <Button variant="outline" onClick={addTypeRisks}>
            <Sparkles className="h-4 w-4 mr-1.5" /> Insérer des risques types du secteur
          </Button>
        )}
        <AiImproveButton
          projectId={projectId}
          target="risks"
          value={analysis.risks.map((r) => ({ label: r.label, category: r.category, probability: r.probability, impact: r.impact, mitigation: r.mitigation }))}
          onApply={(v) => {
            const rows = v as Array<{ label: string; category: string; probability: number; impact: number; mitigation: string }>
            if (rows.length) save({ ...analysis, risks: rows.map((r) => ({ id: uid(), ...r })) }, true)
          }}
        />
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Faisabilité
// ---------------------------------------------------------------------------

const FEASIBILITY_FIELDS: Array<{ key: Exclude<keyof FeasibilityData, 'verdict'>; label: string; hint: string }> = [
  { key: 'technique', label: 'Faisabilité technique', hint: 'Technologies, compétences, équipements nécessaires et disponibles' },
  { key: 'economique', label: 'Faisabilité économique', hint: 'Coûts, marges, seuil de rentabilité, sensibilité' },
  { key: 'juridique', label: 'Faisabilité juridique', hint: 'Autorisations, licences, réglementation applicable' },
  { key: 'organisationnelle', label: 'Faisabilité organisationnelle', hint: 'Équipe, partenaires, processus de gestion' },
  { key: 'commerciale', label: 'Faisabilité commerciale', hint: 'Accès aux clients, canaux de vente, concurrence' },
]

function FeasibilityTab({ projectId, analysis, save, ex }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void; ex: SectorExamples }) {
  return (
    <div className="space-y-4">
      <div className="grid lg:grid-cols-2 gap-4">
        {FEASIBILITY_FIELDS.map((f) => (
          <Card key={f.key}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-sm">{f.label}</CardTitle>
                <div className="flex items-center gap-1.5">
                  <ExampleButton onClick={() => save({ ...analysis, feasibility: { ...analysis.feasibility, [f.key]: insertExample(analysis.feasibility[f.key], ex.feasibility[f.key]) } })} />
                  <AiImproveButton compact projectId={projectId} target={`feasibility.${f.key}`} value={analysis.feasibility[f.key]} onApply={(v) => save({ ...analysis, feasibility: { ...analysis.feasibility, [f.key]: v as string } })} />
                </div>
              </div>
              <p className="text-xs text-muted-foreground font-normal">{f.hint}</p>
            </CardHeader>
            <CardContent>
              <Textarea
                rows={4}
                value={analysis.feasibility[f.key]}
                onChange={(e) => save({ ...analysis, feasibility: { ...analysis.feasibility, [f.key]: e.target.value } })}
              />
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base">Verdict global</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap items-center gap-3">
          <Select value={analysis.feasibility.verdict} onValueChange={(v) => save({ ...analysis, feasibility: { ...analysis.feasibility, verdict: v as AnalysisData['feasibility']['verdict'] } }, true)}>
            <SelectTrigger className="w-[260px]"><SelectValue placeholder="Conclure l'étude de faisabilité" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="FAVORABLE">Favorable — poursuivre le projet</SelectItem>
              <SelectItem value="RESERVE">Favorable sous réserves</SelectItem>
              <SelectItem value="DEFAVORABLE">Défavorable — revoir le projet</SelectItem>
            </SelectContent>
          </Select>
          {analysis.feasibility.verdict === 'FAVORABLE' && <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200" variant="outline">Projet viable au stade actuel</Badge>}
          {analysis.feasibility.verdict === 'RESERVE' && <Badge className="bg-amber-100 text-amber-800 border-amber-200" variant="outline">Points de vigilance à lever</Badge>}
          {analysis.feasibility.verdict === 'DEFAVORABLE' && <Badge className="bg-red-100 text-red-800 border-red-200" variant="outline">Réorientation nécessaire</Badge>}
        </CardContent>
      </Card>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Synthèse & recommandations
// ---------------------------------------------------------------------------

function SynthesisTab({ projectId, analysis, save }: { projectId: string; analysis: AnalysisData; save: (v: AnalysisData, immediate?: boolean) => void }) {
  const counts = [
    analysis.swot.strengths.length, analysis.swot.weaknesses.length,
    analysis.swot.opportunities.length, analysis.swot.threats.length,
  ]
  const pestelFilled = Object.values(analysis.pestel).filter((v) => v.trim().length > 0).length
  const marketKeys: Array<keyof typeof analysis.market> = ['demande', 'offre', 'segments', 'cible', 'zones', 'tendances', 'conclusion']
  const marketFilled = marketKeys.filter((k) => analysis.market[k].trim().length > 0).length
  const feasKeys: Array<Exclude<keyof typeof analysis.feasibility, 'verdict'>> = ['technique', 'economique', 'juridique', 'organisationnelle', 'commerciale']
  const feasFilled = feasKeys.filter((k) => analysis.feasibility[k].trim().length > 0).length
  const risksCovered = analysis.risks.filter((r) => r.mitigation.trim().length > 0).length

  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">État de l'analyse</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <CheckRow label="Matrice SWOT complétée" ok={counts.every((c) => c > 0)} detail={`${counts.reduce((a, b) => a + b, 0)} éléments`} />
          <CheckRow label="Analyse PESTEL renseignée" ok={pestelFilled >= 4} detail={`${pestelFilled}/6 dimensions`} />
          <CheckRow label="Étude de marché documentée" ok={marketFilled >= 3} detail={`${marketFilled}/7 sections`} />
          <CheckRow label="Concurrence analysée" ok={analysis.competitors.length > 0} detail={`${analysis.competitors.length} concurrent(s)`} />
          <CheckRow label="Risques avec mesures" ok={analysis.risks.length > 0 && risksCovered === analysis.risks.length} detail={`${risksCovered}/${analysis.risks.length} couverts`} />
          <CheckRow label="Étude de faisabilité" ok={feasFilled >= 3} detail={`${feasFilled}/5 axes`} />
          <CheckRow label="Verdict de faisabilité" ok={Boolean(analysis.feasibility.verdict)} detail={analysis.feasibility.verdict || 'non défini'} />
        </CardContent>
      </Card>
      <Card className="lg:col-span-2">
        <CardHeader className="pb-3"><CardTitle className="text-base">Synthèse & recommandations</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <Label>Synthèse stratégique</Label>
              <div className="flex items-center gap-1.5">
                <ExampleButton label="Insérer un modèle" onClick={() => save({ ...analysis, synthesis: insertExample(analysis.synthesis, SYNTHESIS_TEMPLATE) })} />
                <AiImproveButton compact projectId={projectId} target="synthesis" value={analysis.synthesis} onApply={(v) => save({ ...analysis, synthesis: v as string })} />
              </div>
            </div>
            <Textarea
              rows={6}
              value={analysis.synthesis}
              onChange={(e) => save({ ...analysis, synthesis: e.target.value })}
              placeholder="Résumez les conclusions de vos analyses : attractivité du marché, positionnement, risques majeurs…"
            />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <Label>Recommandations</Label>
              <div className="flex items-center gap-1.5">
                <ExampleButton label="Insérer un modèle" onClick={() => save({ ...analysis, recommendations: insertExample(analysis.recommendations, RECOMMENDATIONS_TEMPLATE) })} />
                <AiImproveButton compact projectId={projectId} target="recommendations" value={analysis.recommendations} onApply={(v) => save({ ...analysis, recommendations: v as string })} />
              </div>
            </div>
            <Textarea
              rows={6}
              value={analysis.recommendations}
              onChange={(e) => save({ ...analysis, recommendations: e.target.value })}
              placeholder="Listez les actions recommandées avant le lancement (enquête terrain, contrats, formations…)"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ExampleButton({ onClick, label = 'Exemple' }: { onClick: () => void; label?: string }) {
  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      className="h-6 shrink-0 gap-1 rounded-full px-2 text-[11px] font-normal text-muted-foreground hover:text-foreground"
      onClick={onClick}
      title="Insérer un exemple à adapter"
    >
      <Lightbulb className="h-3 w-3" /> {label}
    </Button>
  )
}

function CheckRow({ label, ok, detail }: { label: string; ok: boolean; detail: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className={cn('h-4 w-4 rounded-full flex items-center justify-center text-[10px] shrink-0', ok ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-400')}>
        {ok ? '✓' : '·'}
      </span>
      <span className="flex-1 leading-snug">{label}</span>
      <span className="text-xs text-muted-foreground">{detail}</span>
    </div>
  )
}
