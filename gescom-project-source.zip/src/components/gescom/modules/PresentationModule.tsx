'use client'

// GESCOM PROJECT – Module Présentation : génération de slides
// professionnelles par audience (investisseurs, banque, partenaires, académique)
import { useCallback, useEffect, useMemo, useState } from 'react'
import { apiDownload, apiGet, authHeaders } from '@/lib/client-api'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import type { AnalysisData, DocPrefs, FinanceData } from '@/lib/types'
import { PRESENTATION_AUDIENCES, PRESENTATION_THEMES } from '@/lib/constants'
import { computeFinance } from '@/lib/finance'
import { fmtCurrency } from '@/lib/format'
import { isPremium, PREMIUM_EXPORT_SECTIONS } from '@/lib/plans'
import { useApp } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { Presentation, Loader2, MonitorPlay, Users, Landmark, GraduationCap, Info } from 'lucide-react'

interface Props {
  project: ProjectRecord
  docPrefs: DocPrefs
  analysis: AnalysisData
  finance: FinanceData
  saveDocPrefs: (v: DocPrefs) => void
}

const AUDIENCE_ICONS: Record<string, typeof Users> = {
  INVESTOR: Users,
  BANK: Landmark,
  PARTNER: MonitorPlay,
  ACADEMIC: GraduationCap,
}

const AUDIENCE_NOTES: Record<string, string> = {
  INVESTOR: 'Accent sur l\'opportunité de marché, la rentabilité (VAN, TRI) et la vision de croissance.',
  BANK: 'Accent sur le besoin de financement, les garanties de remboursement (DSCR) et la prudence des hypothèses.',
  PARTNER: 'Accent sur l\'organisation, le plan d\'action et les complémentarités à construire.',
  ACADEMIC: 'Accent sur la démarche méthodologique complète, de l\'idée aux résultats.',
}

// Ordre des sections par audience (cohérent avec le générateur PPTX)
const AUDIENCE_ORDER: Record<string, string[]> = {
  INVESTOR: ['overview', 'market', 'strategy', 'financials', 'indicators', 'risks', 'actionplan', 'financing'],
  BANK: ['overview', 'market', 'investment', 'financing', 'financials', 'indicators', 'risks', 'actionplan'],
  PARTNER: ['overview', 'market', 'strategy', 'organization', 'actionplan', 'risks', 'indicators'],
  ACADEMIC: ['overview', 'market', 'strategy', 'feasibility', 'financials', 'indicators', 'risks', 'actionplan', 'annexes'],
}

const SECTION_LABELS: Record<string, string> = {
  overview: 'Présentation générale',
  market: 'Étude de marché',
  strategy: 'Analyse stratégique (SWOT, PESTEL)',
  feasibility: 'Étude de faisabilité',
  organization: 'Organisation & RH',
  investment: 'Plan d\'investissement',
  financing: 'Plan de financement',
  financials: 'Prévisions financières',
  indicators: 'Indicateurs de rentabilité',
  risks: 'Analyse des risques',
  actionplan: "Plan d'action",
  annexes: 'Annexes & méthodologie',
}

export function PresentationModule({ project, docPrefs, analysis, finance, saveDocPrefs }: Props) {
  const { toast } = useToast()
  const [audience, setAudience] = useState<string>('INVESTOR')
  const [theme, setTheme] = useState<string>(PRESENTATION_THEMES[0].value)
  const [generating, setGenerating] = useState(false)
  // Logo de l'entreprise (Identité visuelle, onglet Documents) : affiché sur
  // l'aperçu de la page de titre et intégré au fichier PowerPoint généré.
  const [logoUrl, setLogoUrl] = useState<string | null>(null)
  // Plan gratuit : les sections Premium sont exclues de la présentation
  // (le serveur applique le même filtrage à la génération PPTX).
  const premium = isPremium(useApp((s) => s.user?.plan))

  const comp = useMemo(() => computeFinance(finance), [finance])
  const cur = project.currency || 'XAF'

  // Chargement du logo enregistré pour le projet (aperçu local authentifié).
  const loadLogo = useCallback(async () => {
    try {
      const d = await apiGet<{ assets: { logo: { url: string } | null } }>(`/api/projects/${project.id}/assets`)
      if (!d.assets?.logo?.url) {
        setLogoUrl(null)
        return
      }
      const res = await fetch(d.assets.logo.url, { credentials: 'include', headers: authHeaders() })
      if (!res.ok) {
        setLogoUrl(null)
        return
      }
      setLogoUrl(URL.createObjectURL(await res.blob()))
    } catch {
      setLogoUrl(null)
    }
  }, [project.id])

  useEffect(() => {
    void loadLogo()
    return () => {
      setLogoUrl((u) => {
        if (u) URL.revokeObjectURL(u)
        return null
      })
    }
  }, [loadLogo])

  const outline = useMemo(() => {
    const slides: Array<{ title: string; detail: string }> = [
      { title: 'Page de titre', detail: `${docPrefs.coverTitle || project.name} — ${audienceLabel(audience)}` },
      { title: 'Sommaire', detail: 'Plan de la présentation' },
    ]
    const hasSwot = analysis.swot.strengths.length > 0 || analysis.swot.opportunities.length > 0
    for (const id of AUDIENCE_ORDER[audience]) {
      if (!premium && PREMIUM_EXPORT_SECTIONS.has(id)) continue
      switch (id) {
        case 'overview':
          slides.push({ title: SECTION_LABELS.overview, detail: project.idea ? 'Idée, porteur, localisation' : 'À compléter dans Aperçu' })
          if (project.idea) slides.push({ title: 'Objectifs du projet', detail: 'Objectifs clés' })
          break
        case 'market':
          slides.push({ title: SECTION_LABELS.market, detail: 'Demande, offre, cibles' })
          if (analysis.competitors.length > 0) slides.push({ title: 'Concurrence', detail: `${analysis.competitors.length} concurrent(s) analysé(s)` })
          break
        case 'strategy':
          if (hasSwot) slides.push({ title: 'Matrice SWOT', detail: 'Forces, faiblesses, opportunités, menaces' })
          break
        case 'investment':
          if (finance.investments.length > 0) slides.push({ title: SECTION_LABELS.investment, detail: `${fmtCurrency(comp.totalInvestment, cur)} d'investissements` })
          break
        case 'financing':
          if (finance.financing.length > 0) slides.push({ title: SECTION_LABELS.financing, detail: `${fmtCurrency(comp.totalFinancing, cur)} mobilisés` })
          break
        case 'financials':
          if (finance.assumptions.products.length > 0) slides.push({ title: SECTION_LABELS.financials, detail: `CA an 1 : ${fmtCurrency(comp.years[0]?.revenue ?? 0, cur)}` })
          break
        case 'indicators':
          if (finance.assumptions.products.length > 0) slides.push({ title: SECTION_LABELS.indicators, detail: `VAN ${fmtCurrency(comp.ratios.npv, cur)} · TRI ${comp.ratios.irr !== null ? comp.ratios.irr.toFixed(1) + ' %' : '—'}` })
          break
        case 'risks':
          if (analysis.risks.length > 0) slides.push({ title: SECTION_LABELS.risks, detail: `${analysis.risks.length} risque(s) et mesures d'atténuation` })
          break
        case 'actionplan':
          slides.push({ title: SECTION_LABELS.actionplan, detail: 'Calendrier de mise en œuvre' })
          break
        default:
          slides.push({ title: SECTION_LABELS[id] || id, detail: '' })
      }
    }
    slides.push({ title: 'Merci de votre attention', detail: 'Coordonnées de contact' })
    return slides
  }, [audience, analysis, finance, comp, cur, project, docPrefs, premium])

  async function generate() {
    setGenerating(true)
    try {
      const name = await apiDownload(
        `/api/projects/${project.id}/export`,
        { format: 'PPTX', audience, theme },
        'presentation.pptx',
      )
      toast({ title: 'Présentation générée ✅', description: `${name} a été téléchargé et ajouté à la bibliothèque (voir Documents).` })
    } catch (err) {
      toast({ title: 'Échec de génération', description: err instanceof Error ? err.message : 'Réessayez.', variant: 'destructive' })
    } finally {
      setGenerating(false)
    }
  }

  const author = docPrefs.author
  const organization = docPrefs.organization

  return (
    <div className="grid lg:grid-cols-2 gap-5">
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Paramètres de la présentation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Auteur</Label>
              <Input value={author} onChange={(e) => saveDocPrefs({ ...docPrefs, author: e.target.value })} placeholder="Nom du présentateur" />
            </div>
            <div className="space-y-1.5">
              <Label>Organisation</Label>
              <Input value={organization} onChange={(e) => saveDocPrefs({ ...docPrefs, organization: e.target.value })} placeholder="Nom de l'organisation" />
            </div>
            <div className="space-y-1.5">
              <Label>Audience cible</Label>
              <div className="grid sm:grid-cols-2 gap-2">
                {PRESENTATION_AUDIENCES.map((a) => {
                  const Icon = AUDIENCE_ICONS[a.value] || Presentation
                  return (
                    <button
                      key={a.value}
                      type="button"
                      onClick={() => setAudience(a.value)}
                      className={cn(
                        'flex items-center gap-2.5 rounded-lg border p-3 text-left transition-all',
                        audience === a.value ? 'border-[#d4a72c] bg-accent/50 ring-1 ring-[#d4a72c]/40' : 'hover:bg-accent/30',
                      )}
                    >
                      <Icon className={cn('h-4.5 w-4.5 h-[18px] w-[18px] shrink-0', audience === a.value ? 'text-[#b0880f]' : 'text-muted-foreground')} />
                      <span className="text-xs font-medium leading-tight">{a.label}</span>
                    </button>
                  )
                })}
              </div>
              <p className="text-xs text-muted-foreground mt-1.5">{AUDIENCE_NOTES[audience]}</p>
            </div>
            <div className="space-y-1.5">
              <Label>Thème visuel</Label>
              <div className="grid grid-cols-3 gap-2">
                {PRESENTATION_THEMES.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setTheme(t.value)}
                    className={cn(
                      'rounded-lg border p-2.5 transition-all',
                      theme === t.value ? 'ring-2 ring-[#d4a72c]/50 border-[#d4a72c]' : 'hover:bg-accent/30',
                    )}
                  >
                    <div className="h-8 rounded-md mb-1.5" style={{ background: `#${t.primary}` }}>
                      <div className="h-full w-8 rounded-l-md" style={{ background: `#${t.accent}` }} />
                    </div>
                    <span className="text-[11px] font-medium">{t.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <Button onClick={generate} disabled={generating} className="w-full h-11 gold-gradient text-[#0f172a] hover:opacity-90">
              {generating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Presentation className="h-4 w-4 mr-2" />}
              Générer la présentation PowerPoint
            </Button>
            <p className="text-xs text-muted-foreground flex items-start gap-1.5">
              <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              Le fichier .pptx est généré côté serveur à partir de vos données réelles, ajouté à la
              bibliothèque du projet, puis téléchargé. Il reste entièrement modifiable dans PowerPoint.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        {/* Aperçu de la page de titre (identique à la 1re diapositive générée) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Aperçu de la page de titre</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">
              Rendu de la première diapositive du fichier PowerPoint généré.
            </p>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl bg-[#0f172a] p-4 sm:p-5 aspect-[16/9] flex flex-col overflow-hidden">
              <div className="flex items-start justify-between gap-3">
                <span className="text-[10px] font-bold tracking-wider text-[#d4a72c]">GESCOM PROJECT</span>
                {logoUrl && (
                  <img src={logoUrl} alt="Logo de l'entreprise" className="h-9 sm:h-11 max-w-[30%] object-contain" />
                )}
              </div>
              <div className="flex-1 flex flex-col justify-center min-h-0">
                <div className="text-base sm:text-xl font-bold text-white leading-snug line-clamp-3">
                  {docPrefs.coverTitle || project.name}
                </div>
                <div className="text-xs sm:text-sm text-slate-300 mt-1.5">{audienceLabel(audience)}</div>
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                {[author, organization].filter(Boolean).join(' — ') || 'Votre nom — Votre organisation'}
              </div>
            </div>
            {!logoUrl && (
              <p className="text-xs text-muted-foreground mt-2.5">
                Astuce : ajoutez le logo de votre entreprise dans l&apos;onglet <strong>Documents → Identité visuelle</strong> —
                il apparaîtra ici et sur toutes les diapositives de la présentation.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Aperçu du plan des slides */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Plan des diapositives (aperçu)</CardTitle>
            <p className="text-xs text-muted-foreground font-normal">
              {outline.length} diapositives seront générées pour l&apos;audience « {audienceLabel(audience).toLowerCase()} ».
            </p>
          </CardHeader>
          <CardContent>
            <ol className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {outline.map((s, i) => (
                <li key={i} className="flex gap-3 items-start rounded-lg border p-3">
                  <span className="h-6 w-6 rounded-full bg-[#0f172a] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  <div className="min-w-0">
                    <div className="text-sm font-medium leading-snug">{s.title}</div>
                    {s.detail && <div className="text-xs text-muted-foreground mt-0.5">{s.detail}</div>}
                  </div>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function audienceLabel(a: string): string {
  return PRESENTATION_AUDIENCES.find((x) => x.value === a)?.label || a
}
