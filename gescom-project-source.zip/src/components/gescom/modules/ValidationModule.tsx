'use client'

// GESCOM PROJECT – Module de validation automatique & d'analyse de rentabilité
//
// Tableau de bord de validation : statut global du projet, indicateurs
// financiers (VAN, TRI, IP), contrôle de conformité section par section,
// zones à corriger avec recommandations et accès direct aux modules.
// Le rapport est recalculé par le serveur à chaque ouverture : après chaque
// correction, les contrôles sont automatiquement relancés.
import { useCallback, useEffect, useRef, useState } from 'react'
import { apiDownload, apiGet } from '@/lib/client-api'
import { useApp, type View } from '@/lib/store'
import { isPremium } from '@/lib/plans'
import { usePlanUpgrade } from '@/components/gescom/usePlan'
import { LockedPanel } from '@/components/gescom/LockedPanel'
import type { ValidationReport, ValidationProblem, IndicatorResult } from '@/lib/validation'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import { groupNumber } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import {
  ShieldCheck, ShieldX, ShieldAlert, ShieldQuestion, CircleCheck, CircleAlert,
  TrendingUp, TrendingDown, Minus, Printer, FileSearch, RefreshCw, ArrowRight,
  Crown, CircleEqual, Info,
} from 'lucide-react'

// Couleurs et icônes par statut de validation
const STATUS_UI: Record<string, { icon: typeof ShieldCheck; badge: string; ring: string; bar: string }> = {
  VALIDE: {
    icon: ShieldCheck,
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    ring: 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/60 dark:bg-emerald-950/20',
    bar: '[&>div]:bg-emerald-500',
  },
  A_CORRIGER: {
    icon: ShieldAlert,
    badge: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    ring: 'border-amber-300 dark:border-amber-800 bg-amber-50/60 dark:bg-amber-950/20',
    bar: '[&>div]:bg-amber-500',
  },
  NON_RENTABLE: {
    icon: ShieldX,
    badge: 'bg-red-100 text-red-800 border-red-300 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800',
    ring: 'border-red-300 dark:border-red-800 bg-red-50/60 dark:bg-red-950/20',
    bar: '[&>div]:bg-red-500',
  },
  INCOMPLET: {
    icon: ShieldQuestion,
    badge: 'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-700',
    ring: 'border-slate-300 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-950/20',
    bar: '[&>div]:bg-slate-400',
  },
}

const INDICATOR_UI: Record<string, { badge: string; icon: typeof TrendingUp }> = {
  FAVORABLE: { badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300', icon: TrendingUp },
  EQUILIBRE: { badge: 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300', icon: CircleEqual },
  DEFAVORABLE: { badge: 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300', icon: TrendingDown },
  NON_CALCULE: { badge: 'bg-slate-100 text-slate-600 dark:bg-slate-900 dark:text-slate-300', icon: Minus },
}

const SEVERITY_BADGE: Record<string, string> = {
  BLOQUANT: 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300',
  MAJEUR: 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300',
  MINEUR: 'bg-sky-100 text-sky-800 dark:bg-sky-950/40 dark:text-sky-300',
}

const FIX_MODULE_LABELS: Record<string, string> = {
  analysis: 'module Analyse',
  finance: 'module Finance',
  'action-plan': "module Plan d'action",
  premium: 'abonnement Premium',
}

function IndicatorCard({ ind }: { ind: IndicatorResult }) {
  const ui = INDICATOR_UI[ind.status] ?? INDICATOR_UI.NON_CALCULE
  const Icon = ui.icon
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="text-xs font-medium text-muted-foreground leading-snug">{ind.label}</div>
          <Badge className={cn('shrink-0 gap-1 border-transparent', ui.badge)}>
            <Icon className="h-3 w-3" aria-hidden />
            {ind.status === 'FAVORABLE' ? 'Favorable' : ind.status === 'EQUILIBRE' ? 'Équilibre' : ind.status === 'NON_CALCULE' ? 'Non calculable' : 'Défavorable'}
          </Badge>
        </div>
        <div className="mt-2 text-2xl font-bold tracking-tight">{ind.formatted}</div>
        <div className="mt-1 text-[11px] text-muted-foreground">Critère : {ind.criterion}</div>
        <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{ind.explanation}</p>
      </CardContent>
    </Card>
  )
}

function ProblemCard({ p }: { p: ValidationProblem }) {
  const navigate = useApp((s) => s.navigate)
  return (
    <div className="rounded-lg border bg-card p-3.5 space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <Badge className={cn('border-transparent text-[10px]', SEVERITY_BADGE[p.severity])}>{p.severity === 'MAJEUR' ? 'Anomalie majeure' : p.severity === 'BLOQUANT' ? 'Bloquant' : 'Avertissement'}</Badge>
        <span className="text-xs font-medium text-muted-foreground">{p.sectionLabel}</span>
      </div>
      <div className="text-sm font-medium leading-snug">{p.problem}</div>
      <p className="text-xs text-muted-foreground leading-relaxed">
        <span className="font-semibold text-foreground/70">Pourquoi : </span>{p.why}
      </p>
      <p className="text-xs leading-relaxed rounded-md bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900 p-2.5 text-emerald-900 dark:text-emerald-200">
        <span className="font-semibold">Recommandation : </span>{p.recommendation}
      </p>
      {p.fixModule !== 'premium' ? (
        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => navigate(p.fixModule as View)}>
          Corriger dans {FIX_MODULE_LABELS[p.fixModule]} <ArrowRight className="h-3 w-3 ml-1" />
        </Button>
      ) : (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#b0880f]">
          <Crown className="h-3.5 w-3.5" aria-hidden /> Nécessite l&apos;abonnement Premium
        </span>
      )}
    </div>
  )
}

export function ValidationModule({ project, onAutoCompleted }: { project: ProjectRecord; onAutoCompleted?: () => void }) {
  const { toast } = useToast()
  const navigate = useApp((s) => s.navigate)
  const userPlan = useApp((s) => s.user?.plan)
  const premium = isPremium(userPlan)
  const { upgrade, upgrading } = usePlanUpgrade()

  const [report, setReport] = useState<ValidationReport | null>(null)
  const [projectStatus, setProjectStatus] = useState<string>(project.status)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [downloading, setDownloading] = useState(false)

  // Callback parent (synchronisation du badge) via ref : une fonction inline
  // change d'identité à chaque rendu et recréerait `load` (boucle de fetch).
  const autoCbRef = useRef(onAutoCompleted)
  useEffect(() => {
    autoCbRef.current = onAutoCompleted
  })

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const d = await apiGet<{ report: ValidationReport; autoCompleted?: boolean; autoDemoted?: boolean; projectStatus?: string }>(
        `/api/projects/${project.id}/validation`,
      )
      setReport(d.report)
      setProjectStatus(d.projectStatus ?? project.status)
      // Règle Gescom Project : le projet vient d'être validé et confirmé
      // « Terminé » automatiquement par le serveur — on l'annonce et on
      // synchronise le badge de statut de l'espace projet.
      if (d.autoCompleted) {
        toast({
          title: 'Projet validé par Gescom Project 🎉',
          description: 'Aucune anomalie détectée : le projet est automatiquement confirmé « Terminé ».',
        })
        autoCbRef.current?.()
      }
      // Règle inverse : le projet était « Terminé » mais une anomalie ou une
      // correction réapparaît — la validation est retirée et le projet
      // repasse automatiquement « En cours ».
      if (d.autoDemoted) {
        toast({
          title: 'Anomalie détectée — validation retirée',
          description: 'Le projet ne peut rester « Terminé » tant qu\'une anomalie ou une correction subsiste : il repasse automatiquement « En cours ».',
          variant: 'destructive',
        })
        autoCbRef.current?.()
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analyse impossible.')
    } finally {
      setLoading(false)
    }
  }, [project.id, project.status, toast])

  // Rechargement automatique à chaque ouverture du module : après chaque
  // correction dans les autres modules, l'analyse est relancée et le statut
  // actualisé (cahier des charges §6).
  useEffect(() => {
    void load()
  }, [load])

  async function downloadDiagnostic() {
    setDownloading(true)
    try {
      const name = await apiDownload(
        `/api/projects/${project.id}/export`,
        { format: 'DIAGNOSTIC' },
        'diagnostic.pdf',
      )
      toast({ title: 'Rapport de diagnostic généré ✅', description: `${name} a été téléchargé et ajouté à la bibliothèque.` })
    } catch (err) {
      toast({ title: 'Échec de génération', description: err instanceof Error ? err.message : 'Réessayez.', variant: 'destructive' })
    } finally {
      setDownloading(false)
    }
  }

  if (loading && !report) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40" />
        <div className="grid md:grid-cols-3 gap-4">
          <Skeleton className="h-40" /><Skeleton className="h-40" /><Skeleton className="h-40" />
        </div>
        <Skeleton className="h-64" />
      </div>
    )
  }

  if (error || !report) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <CircleAlert className="h-8 w-8 text-destructive mx-auto mb-3" />
          <p className="font-medium">{error || 'Analyse impossible.'}</p>
          <Button variant="outline" className="mt-4" onClick={() => void load()}>
            <RefreshCw className="h-4 w-4 mr-2" /> Relancer l&apos;analyse
          </Button>
        </CardContent>
      </Card>
    )
  }

  const ui = STATUS_UI[report.status] ?? STATUS_UI.INCOMPLET
  const StatusIcon = ui.icon

  return (
    <div className="space-y-5">
      {/* ------------------------------------------------ Bandeau décision */}
      <Card className={cn('border-2', ui.ring)}>
        <CardContent className="p-5">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex items-start gap-3.5 flex-1 min-w-0">
              <div className={cn('h-12 w-12 rounded-xl flex items-center justify-center shrink-0 border', ui.badge)}>
                <StatusIcon className="h-6 w-6" aria-hidden />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-bold text-lg leading-tight">Décision de GESCOM PROJECT</h2>
                  <Badge className={cn('border font-semibold', ui.badge)}>{report.statusLabel}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{report.decision}</p>
                {report.status === 'VALIDE' && (
                  <p className="text-xs mt-2 flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300">
                    <CircleCheck className="h-3.5 w-3.5 shrink-0" />
                    {projectStatus === 'COMPLETED' ? (
                      <span>Statut du projet : <strong>Terminé</strong> — confirmé automatiquement par Gescom Project.</span>
                    ) : (
                      <span>Statut du projet : <strong>{projectStatus === 'DRAFT' ? 'Brouillon' : 'En cours'}</strong> — démarrez le projet (statut « En cours ») pour la confirmation automatique « Terminé ».</span>
                    )}
                  </p>
                )}
                <div className="flex flex-wrap gap-2 mt-3">
                  <Button size="sm" variant="outline" onClick={() => void load()} disabled={loading}>
                    <RefreshCw className={cn('h-3.5 w-3.5 mr-1.5', loading && 'animate-spin')} /> Relancer les contrôles
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => void downloadDiagnostic()} disabled={downloading}>
                    {downloading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <FileSearch className="h-3.5 w-3.5 mr-1.5" />}
                    Rapport de diagnostic (PDF)
                  </Button>
                  {report.canExport && (
                    <Button
                      size="sm"
                      className="bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
                      onClick={() => navigate('documents')}
                    >
                      <Printer className="h-3.5 w-3.5 mr-1.5" /> Générer le dossier final
                    </Button>
                  )}
                </div>
              </div>
            </div>
            {/* Taux de conformité */}
            <div className="lg:w-64 shrink-0 rounded-xl border bg-background p-4 flex flex-col justify-center gap-2">
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-muted-foreground font-medium">Conformité globale</span>
                <span className="text-2xl font-bold">{report.conformityRate} %</span>
              </div>
              <Progress value={report.conformityRate} className={cn('h-2', ui.bar)} />
              <div className="grid grid-cols-3 gap-1.5 text-center mt-1">
                <div className="rounded-md bg-emerald-50 dark:bg-emerald-950/30 py-1.5">
                  <div className="text-sm font-bold text-emerald-700 dark:text-emerald-300">{report.counts.sectionsConformes}/{report.counts.sectionsTotal}</div>
                  <div className="text-[9px] text-muted-foreground leading-tight">sections conformes</div>
                </div>
                <div className="rounded-md bg-amber-50 dark:bg-amber-950/30 py-1.5">
                  <div className="text-sm font-bold text-amber-700 dark:text-amber-300">{report.counts.anomalies}</div>
                  <div className="text-[9px] text-muted-foreground leading-tight">anomalies</div>
                </div>
                <div className="rounded-md bg-red-50 dark:bg-red-950/30 py-1.5">
                  <div className="text-sm font-bold text-red-700 dark:text-red-300">{report.counts.correctionsRestantes}</div>
                  <div className="text-[9px] text-muted-foreground leading-tight">corrections restantes</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ------------------------------------------------ Rentabilité (VAN, TRI, IP) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4.5 w-[18px] text-[#d4a72c]" aria-hidden /> Rentabilité financière
          </CardTitle>
          <p className="text-xs text-muted-foreground font-normal flex items-start gap-1.5">
            <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" aria-hidden />
            Le projet est réputé rentable dès qu&apos;au moins un des trois indicateurs satisfait son critère. Avis actuel :{' '}
            <span className={cn('font-semibold', report.rentabilityFavorable ? 'text-emerald-700 dark:text-emerald-300' : 'text-red-700 dark:text-red-300')}>
              {report.rentabilityFavorable ? 'favorable' : 'défavorable'}
            </span>
            {report.indicators.length > 0 && <> · taux d&apos;actualisation retenu : {groupNumber(report.discountRatePct, 1)} %</>}
          </p>
        </CardHeader>
        <CardContent>
          {premium ? (
            report.indicators.length > 0 ? (
              <>
                <div className="grid md:grid-cols-3 gap-3">
                  {report.indicators.map((ind) => <IndicatorCard key={ind.key} ind={ind} />)}
                </div>
                {report.rentabilityFavorable && (
                  <p className="mt-3 text-xs flex items-start gap-1.5 text-emerald-700 dark:text-emerald-300">
                    <CircleCheck className="h-3.5 w-3.5 mt-0.5 shrink-0" aria-hidden />
                    Critère de rentabilité satisfait : au moins un indicateur est favorable — avis favorable sur le critère de rentabilité financière.
                  </p>
                )}
              </>
            ) : (
              <div className="rounded-lg border border-dashed p-6 text-center">
                <CircleAlert className="h-6 w-6 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm font-medium">Rentabilité non évaluable en l&apos;état</p>
                <p className="text-xs text-muted-foreground mt-1 max-w-md mx-auto">
                  La VAN, le TRI et l&apos;IP exigent un investissement initial et une prévision de chiffre
                  d&apos;affaires cohérents. Complétez le plan d&apos;investissement et les prévisions de ventes.
                </p>
                <Button size="sm" variant="outline" className="mt-3" onClick={() => navigate('finance')}>
                  Compléter le module Finance <ArrowRight className="h-3 w-3 ml-1" />
                </Button>
              </div>
            )
          ) : (
            <LockedPanel
              compact
              title="Analyse de rentabilité réservée au Premium"
              description="La validation automatique (VAN, TRI, IP) et l'autorisation d'impression du dossier définitif nécessitent l'abonnement Premium."
              onUpgrade={() => void upgrade('MONTHLY')}
              upgrading={upgrading}
            />
          )}
        </CardContent>
      </Card>

      {/* ------------------------------------------------ Contrôle par section */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldCheck className="h-4.5 w-[18px] text-[#d4a72c]" aria-hidden /> Contrôle de conformité du dossier
          </CardTitle>
          <p className="text-xs text-muted-foreground font-normal">
            Chaque partie du projet est vérifiée : présence des informations, cohérence et conformité aux
            exigences d&apos;un dossier professionnel. Cliquez sur une section pour voir les corrections demandées.
          </p>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="space-y-2">
            {report.sections.map((s) => {
              const conforme = s.status === 'CONFORME'
              return (
                <AccordionItem key={s.id} value={s.id} className={cn('border rounded-lg px-4', conforme ? 'border-emerald-200 dark:border-emerald-900' : 'border-amber-200 dark:border-amber-900')}>
                  <AccordionTrigger className="hover:no-underline py-3">
                    <div className="flex items-center gap-3 w-full text-left">
                      {conforme ? (
                        <CircleCheck className="h-5 w-5 text-emerald-600 shrink-0" aria-hidden />
                      ) : (
                        <CircleAlert className="h-5 w-5 text-amber-600 shrink-0" aria-hidden />
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium leading-tight">{s.label}</div>
                        <div className="text-[11px] text-muted-foreground">
                          {conforme ? 'Toutes les exigences sont satisfaites' : `${s.problems.length} point(s) à corriger`}
                        </div>
                      </div>
                      <div className="w-20 shrink-0 mr-2">
                        <Progress value={s.filledRatio} className={cn('h-1.5', conforme ? '[&>div]:bg-emerald-500' : '[&>div]:bg-amber-500')} />
                        <div className="text-[10px] text-muted-foreground mt-1 text-right">{s.filledRatio} %</div>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-4">
                    {s.problems.length === 0 ? (
                      <p className="text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                        <CircleCheck className="h-3.5 w-3.5" aria-hidden /> Section conforme aux exigences de GESCOM PROJECT.
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {s.problems.map((p) => <ProblemCard key={p.code} p={p} />)}
                      </div>
                    )}
                  </AccordionContent>
                </AccordionItem>
              )
            })}
          </Accordion>
        </CardContent>
      </Card>

      {/* ------------------------------------------------ Rappel règles d'impression */}
      {!report.canExport && (
        <div className="rounded-lg border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 px-4 py-3 text-xs text-red-900 dark:text-red-200 flex items-start gap-2">
          <ShieldX className="h-4 w-4 shrink-0 mt-0.5" aria-hidden />
          <span className="leading-relaxed">
            <span className="font-semibold">Impression de la version définitive bloquée.</span> Aucun projet ne peut être
            imprimé en version définitive (PDF / Word) sans avoir satisfait aux critères de validation. Le rapport de
            diagnostic reste téléchargeable en toutes circonstances pour vous guider dans les corrections.
          </span>
        </div>
      )}
    </div>
  )
}
