'use client'

// GESCOM PROJECT – Module Plan d'action : activités, responsables,
// échéances, statuts, avancement, diagramme de Gantt, alertes de retard
import { Fragment, useMemo, useState } from 'react'
import { apiSend } from '@/lib/client-api'
import type { Task } from '@prisma/client'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import { TASK_STATUS_LABELS } from '@/lib/constants'
import { fmtDate } from '@/lib/format'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  Plus, X, GanttChartSquare, ListChecks, AlertTriangle, CalendarDays,
} from 'lucide-react'
import { AiImproveButton } from '@/components/gescom/ai/AiImprove'

interface Props {
  project: ProjectRecord
  tasks: Task[]
  setTasks: (t: Task[]) => void
  reload: () => Promise<void>
}

const statusBadge: Record<string, string> = {
  TODO: 'bg-slate-100 text-slate-700 border-slate-200',
  IN_PROGRESS: 'bg-amber-50 text-amber-800 border-amber-200',
  DONE: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  BLOCKED: 'bg-red-50 text-red-700 border-red-200',
}

export function ActionPlanModule({ project, tasks, setTasks, reload }: Props) {
  const { toast } = useToast()
  const [display, setDisplay] = useState<'table' | 'gantt'>('table')
  const [editing, setEditing] = useState<Task | null>(null)
  const [isNew, setIsNew] = useState(false)
  const today = new Date().toISOString().slice(0, 10)

  const phases = useMemo(() => {
    const map = new Map<string, Task[]>()
    for (const t of tasks) {
      const key = t.phase || 'Sans phase'
      if (!map.has(key)) map.set(key, [])
      map.get(key)!.push(t)
    }
    return Array.from(map.entries())
  }, [tasks])

  const overdue = tasks.filter((t) => t.status !== 'DONE' && t.endDate && t.endDate < today)
  const globalProgress = tasks.length > 0 ? tasks.reduce((s, t) => s + t.progress, 0) / tasks.length : 0

  async function saveTask(task: Task) {
    try {
      if (isNew) {
        const res = await apiSend<{ task: Task }>(`/api/projects/${project.id}/tasks`, 'POST', task)
        setTasks([...tasks, res.task])
      } else if (editing) {
        const res = await apiSend<{ task: Task }>(`/api/tasks/${task.id}`, 'PATCH', task)
        setTasks(tasks.map((t) => (t.id === task.id ? res.task : t)))
      }
      setEditing(null)
      setIsNew(false)
      toast({ title: isNew ? 'Activité ajoutée' : 'Activité mise à jour' })
      void reload()
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Enregistrement impossible.', variant: 'destructive' })
    }
  }

  async function quickStatus(task: Task, status: string) {
    try {
      const res = await apiSend<{ task: Task }>(`/api/tasks/${task.id}`, 'PATCH', {
        status,
        progress: status === 'DONE' ? 100 : task.progress,
      })
      setTasks(tasks.map((t) => (t.id === task.id ? res.task : t)))
    } catch {
      toast({ title: 'Erreur', description: 'Mise à jour impossible.', variant: 'destructive' })
    }
  }

  async function removeTask(id: string) {
    try {
      await apiSend(`/api/tasks/${id}`, 'DELETE')
      setTasks(tasks.filter((t) => t.id !== id))
      void reload()
    } catch {
      toast({ title: 'Erreur', description: 'Suppression impossible.', variant: 'destructive' })
    }
  }

  // Ajout des activités proposées par l'assistant IA (après validation explicite
  // de l'utilisateur dans le dialogue « Améliorer avec l'IA »).
  async function addAiTasks(rows: Array<{ phase: string; title: string }>) {
    try {
      const created: Task[] = []
      let order = tasks.length
      for (const row of rows) {
        const res = await apiSend<{ task: Task }>(`/api/projects/${project.id}/tasks`, 'POST', {
          id: '', projectId: project.id, phase: row.phase, title: row.title,
          responsible: '', startDate: today, endDate: '', status: 'TODO', progress: 0, order: order++, createdAt: new Date(),
        })
        created.push(res.task)
      }
      setTasks([...tasks, ...created])
      void reload()
      toast({ title: 'Activités ajoutées', description: `${created.length} activité(s) proposée(s) par l'IA ont été ajoutées. Ajustez responsables et échéances.` })
    } catch (err) {
      toast({ title: 'Erreur', description: err instanceof Error ? err.message : 'Ajout impossible.', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4">
      {/* Bandeau synthèse */}
      <div className="grid sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Activités</div>
            <div className="text-xl font-bold">{tasks.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Avancement moyen</div>
            <div className="text-xl font-bold">{Math.round(globalProgress)} %</div>
            <Progress value={globalProgress} className="h-1.5 mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Terminées</div>
            <div className="text-xl font-bold text-emerald-600">{tasks.filter((t) => t.status === 'DONE').length}</div>
          </CardContent>
        </Card>
        <Card className={overdue.length > 0 ? 'border-red-200' : ''}>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground flex items-center gap-1.5">
              {overdue.length > 0 && <AlertTriangle className="h-3.5 w-3.5 text-red-500" />} En retard
            </div>
            <div className={cn('text-xl font-bold', overdue.length > 0 ? 'text-red-600' : '')}>{overdue.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Barre d'outils */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <Tabs value={display} onValueChange={(v) => setDisplay(v as 'table' | 'gantt')}>
          <TabsList>
            <TabsTrigger value="table" className="gap-1.5"><ListChecks className="h-3.5 w-3.5" /> Tableau</TabsTrigger>
            <TabsTrigger value="gantt" className="gap-1.5"><GanttChartSquare className="h-3.5 w-3.5" /> Calendrier (Gantt)</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-2 flex-wrap">
          <AiImproveButton
            projectId={project.id}
            target="tasks"
            value={tasks.map((t) => ({ phase: t.phase, title: t.title }))}
            onApply={(v) => void addAiTasks(v as Array<{ phase: string; title: string }>)}
          />
          <Button onClick={() => {
            setIsNew(true)
            setEditing({
              id: '', projectId: project.id, phase: phases[0]?.[0] && phases[0][0] !== 'Sans phase' ? phases[0][0] : '', title: '',
              responsible: '', startDate: today, endDate: '', status: 'TODO', progress: 0, order: tasks.length, createdAt: new Date(),
            })
          }}>
            <Plus className="h-4 w-4 mr-1.5" /> Ajouter une activité
          </Button>
        </div>
      </div>

      {/* Vue tableau */}
      {display === 'table' && (
        <Card>
          <CardContent className="p-0">
            {tasks.length === 0 ? (
              <div className="py-14 text-center text-sm text-muted-foreground">
                Aucune activité. Cliquez sur « Ajouter une activité » pour construire votre plan d&apos;action.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table className="min-w-[760px]">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[34%]">Activité</TableHead>
                      <TableHead>Responsable</TableHead>
                      <TableHead>Échéance</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead className="w-36">Avancement</TableHead>
                      <TableHead className="w-10" />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {phases.map(([phase, phaseTasks]) => (
                      <Fragment key={`p-${phase}`}>
                        <TableRow className="bg-muted/40 hover:bg-muted/40">
                          <TableCell colSpan={6} className="text-xs font-semibold uppercase tracking-wide text-muted-foreground py-2">
                            {phase} — {phaseTasks.length} activité(s)
                          </TableCell>
                        </TableRow>
                        {phaseTasks.map((t) => {
                          const late = t.status !== 'DONE' && t.endDate && t.endDate < today
                          return (
                            <TableRow key={t.id}>
                              <TableCell>
                                <button className="text-left text-sm font-medium hover:underline" type="button"
                                  onClick={() => { setIsNew(false); setEditing(t) }}>
                                  {t.title || '(sans titre)'}
                                </button>
                                {t.phase && t.phase !== phase && <div className="text-[11px] text-muted-foreground">{t.phase}</div>}
                              </TableCell>
                              <TableCell className="text-sm">{t.responsible || '—'}</TableCell>
                              <TableCell className={cn('text-sm', late && 'text-red-600 font-medium')}>
                                {t.endDate ? fmtDate(t.endDate) : '—'}
                                {late && <span className="block text-[10px]">en retard</span>}
                              </TableCell>
                              <TableCell>
                                <Select value={t.status} onValueChange={(v) => quickStatus(t, v)}>
                                  <SelectTrigger className={cn('h-7 w-[120px] text-xs border', statusBadge[t.status])}>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {Object.entries(TASK_STATUS_LABELS).map(([k, v]) => (
                                      <SelectItem key={k} value={k}>{v}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Progress value={t.progress} className="h-1.5 flex-1" />
                                  <span className="text-[11px] w-8 text-right">{Math.round(t.progress)} %</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Supprimer" onClick={() => removeTask(t.id)}>
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </Fragment>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Vue Gantt */}
      {display === 'gantt' && <GanttView tasks={tasks} onOpen={(t) => { setIsNew(false); setEditing(t) }} />}

      {/* Dialog d'édition */}
      <Dialog open={editing !== null} onOpenChange={(o) => { if (!o) { setEditing(null); setIsNew(false) } }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isNew ? 'Nouvelle activité' : 'Modifier l\'activité'}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Intitulé de l&apos;activité *</Label>
                <Input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} placeholder="Ex. Construction du poulailler" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Phase</Label>
                  <Input value={editing.phase} onChange={(e) => setEditing({ ...editing, phase: e.target.value })} placeholder="Ex. Phase 1 – Montage" list="phase-list" />
                  <datalist id="phase-list">
                    {phases.map(([p]) => <option key={p} value={p} />)}
                  </datalist>
                </div>
                <div className="space-y-1.5">
                  <Label>Responsable</Label>
                  <Input value={editing.responsible} onChange={(e) => setEditing({ ...editing, responsible: e.target.value })} placeholder="Nom ou rôle" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Date de début</Label>
                  <Input type="date" value={editing.startDate || ''} onChange={(e) => setEditing({ ...editing, startDate: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Date de fin</Label>
                  <Input type="date" value={editing.endDate || ''} onChange={(e) => setEditing({ ...editing, endDate: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 items-end">
                <div className="space-y-1.5">
                  <Label>Statut</Label>
                  <Select value={editing.status} onValueChange={(v) => setEditing({ ...editing, status: v, progress: v === 'DONE' ? 100 : editing.progress })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(TASK_STATUS_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Avancement : {Math.round(editing.progress)} %</Label>
                  <Slider value={[editing.progress]} min={0} max={100} step={5}
                    onValueChange={(v) => setEditing({ ...editing, progress: v[0] })} />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setEditing(null); setIsNew(false) }}>Annuler</Button>
            <Button onClick={() => editing && saveTask(editing)} disabled={!editing?.title.trim()}>
              {isNew ? 'Ajouter' : 'Enregistrer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Diagramme de Gantt (CSS pur, responsive)
// ---------------------------------------------------------------------------

function GanttView({ tasks, onOpen }: { tasks: Task[]; onOpen: (t: Task) => void }) {
  const dated = tasks.filter((t) => t.startDate && t.endDate)
  const today = new Date().toISOString().slice(0, 10)

  if (dated.length === 0) {
    return (
      <Card>
        <CardContent className="py-14 text-center text-sm text-muted-foreground">
          Aucune activité datée. Renseignez des dates de début et de fin pour visualiser le calendrier.
        </CardContent>
      </Card>
    )
  }

  const dates = dated.flatMap((t) => [t.startDate, t.endDate]).sort()
  const min = new Date(dates[0])
  const max = new Date(dates[dates.length - 1])
  // Arrondi au mois
  const start = new Date(min.getFullYear(), min.getMonth(), 1)
  const end = new Date(max.getFullYear(), max.getMonth() + 1, 0)
  const totalDays = Math.max(1, Math.round((end.getTime() - start.getTime()) / 86400000))

  // Mois affichés
  const months: Array<{ label: string; days: number; offset: number }> = []
  const cursor = new Date(start)
  while (cursor <= end) {
    const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)
    const from = Math.max(cursor.getTime(), start.getTime())
    const to = Math.min(monthEnd.getTime(), end.getTime())
    const days = Math.round((to - from) / 86400000) + 1
    months.push({ label: cursor.toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' }), days, offset: Math.round((from - start.getTime()) / 86400000) })
    cursor.setMonth(cursor.getMonth() + 1)
  }

  const barColor = (t: Task) =>
    t.status === 'DONE' ? 'bg-emerald-500' : t.status === 'IN_PROGRESS' ? 'bg-[#d4a72c]' : t.status === 'BLOCKED' ? 'bg-red-500' : 'bg-slate-400'

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <CalendarDays className="h-4 w-4" /> Calendrier de mise en œuvre
        </CardTitle>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <div className="min-w-[720px]">
          {/* Axe des mois */}
          <div className="flex mb-2">
            <div className="w-56 shrink-0" />
            <div className="flex-1 relative h-5">
              {months.map((m, i) => (
                <div key={i} className="absolute top-0 text-[10px] text-muted-foreground border-l border-border pl-1"
                  style={{ left: `${(m.offset / totalDays) * 100}%`, width: `${(m.days / totalDays) * 100}%` }}>
                  {m.label}
                </div>
              ))}
            </div>
          </div>
          {/* Lignes */}
          <div className="space-y-1.5">
            {dated.map((t) => {
              const offset = Math.round((new Date(t.startDate).getTime() - start.getTime()) / 86400000)
              const duration = Math.max(1, Math.round((new Date(t.endDate).getTime() - new Date(t.startDate).getTime()) / 86400000) + 1)
              const late = t.status !== 'DONE' && t.endDate < today
              return (
                <div key={t.id} className="flex items-center group">
                  <button className="w-56 shrink-0 pr-3 text-left" type="button" onClick={() => onOpen(t)}>
                    <span className="text-xs font-medium line-clamp-1 group-hover:underline block">{t.title}</span>
                    <span className="text-[10px] text-muted-foreground">{t.responsible || t.phase}</span>
                  </button>
                  <div className="flex-1 relative h-7 bg-muted/40 rounded">
                    {/* Ligne du jour */}
                    {today >= dates[0] && today <= dates[dates.length - 1] && (
                      <div
                        className="absolute top-0 bottom-0 w-px bg-red-400/70 z-10"
                        style={{ left: `${(Math.round((new Date(today).getTime() - start.getTime()) / 86400000) / totalDays) * 100}%` }}
                        title="Aujourd'hui"
                      />
                    )}
                    <button
                      type="button"
                      onClick={() => onOpen(t)}
                      className={cn(
                        'absolute top-1 h-5 rounded-full transition-all hover:opacity-90 flex items-center overflow-hidden',
                        barColor(t), late && t.status !== 'DONE' && 'ring-2 ring-red-300',
                      )}
                      style={{
                        left: `${(offset / totalDays) * 100}%`,
                        width: `${Math.min(100, (duration / totalDays) * 100)}%`,
                      }}
                      title={`${t.title} : ${fmtDate(t.startDate)} → ${fmtDate(t.endDate)} (${Math.round(t.progress)} %)`}
                    >
                      <span className="bg-white/30 h-full" style={{ width: `${t.progress}%` }} />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
          {/* Légende */}
          <div className="flex flex-wrap gap-4 mt-5 text-[11px] text-muted-foreground">
            <LegendDot color="bg-emerald-500" label="Terminé" />
            <LegendDot color="bg-[#d4a72c]" label="En cours" />
            <LegendDot color="bg-slate-400" label="À faire" />
            <LegendDot color="bg-red-500" label="Bloqué" />
            <span className="flex items-center gap-1.5"><span className="h-3 w-px bg-red-400 inline-block" /> Aujourd&apos;hui</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded ring-2 ring-red-300 bg-slate-400 inline-block" /> En retard</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return <span className="flex items-center gap-1.5"><span className={cn('h-2.5 w-4 rounded-full inline-block', color)} /> {label}</span>
}
