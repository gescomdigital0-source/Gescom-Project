'use client'

// GESCOM PROJECT – Générateur intelligent d'amélioration des idées
// Bouton « Améliorer avec l'IA » + dialogue de consultation/validation.
//
// Principes de fonctionnement (exigences produit) :
//  • un bouton est disponible à chaque rubrique du Business Plan où
//    l'utilisateur fournit des informations ;
//  • l'IA analyse le contenu, identifie les insuffisances et incohérences,
//    reformule/enrichit et propose des recommandations adaptées au secteur,
//    au marché et au contexte géographique ;
//  • la proposition est TOUJOURS affichée, modifiable, et jamais appliquée
//    automatiquement : l'utilisateur accepte ou refuse explicitement ;
//  • les informations de l'utilisateur, les hypothèses et les recommandations
//    sont clairement distinguées ; l'IA ne présente pas de données inventées
//    comme vérifiées (les chiffres sont signalés comme hypothèses à ajuster).
import { useCallback, useEffect, useMemo, useState } from 'react'
import { apiSend, ApiError } from '@/lib/client-api'
import { AI_TARGETS } from '@/lib/ai-targets'
import { isPremium, PREMIUM_PRICE_MONTHLY, PREMIUM_PRICE_YEARLY, formatEur, type BillingPeriod } from '@/lib/plans'
import { fmtNumber } from '@/lib/format'
import { uid } from '@/lib/types'
import { useApp } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  AlertTriangle, Check, Crown, Info, Lightbulb, Loader2, Lock, Plus, RefreshCw, SearchCheck, Sparkles, Trash2,
} from 'lucide-react'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface AiImprovement {
  analyse: string[]
  hypothese: string[]
  recommandations: string[]
  proposition: unknown
}

type Row = Record<string, string | number>

export interface AiImproveProps {
  /** Projet ouvert (contexte enrichi côté serveur). Absent dans l'assistant de création. */
  projectId?: string
  /** Clé de la rubrique (src/lib/ai-targets.ts). */
  target: string
  /** Contenu actuel de la rubrique (jamais modifié sans validation). */
  value: unknown
  /** Applique la valeur validée par l'utilisateur (sauvegarde du module). */
  onApply: (v: unknown) => void
  /** Mini-contexte pour l'assistant de création (projet pas encore enregistré). */
  context?: Record<string, string>
  /** Variante compacte : bouton « IA » pour les champs multiples. */
  compact?: boolean
  disabled?: boolean
  className?: string
}

const LOADING_STEPS = [
  'Analyse des informations que vous avez fournies…',
  'Identification des insuffisances et des incohérences…',
  'Recherche d\'opportunités adaptées à votre secteur et à votre marché…',
  'Formulation de recommandations stratégiques…',
]

const INVESTMENT_CATEGORIES: Array<{ value: string; label: string }> = [
  { value: 'TERRAIN', label: 'Terrain & aménagements' },
  { value: 'BATIMENT', label: 'Bâtiment' },
  { value: 'EQUIPEMENT', label: 'Équipements' },
  { value: 'MATERIEL', label: 'Matériel roulant & outillage' },
  { value: 'FRAIS_ETABLISSEMENT', label: 'Frais d\'établissement' },
  { value: 'AUTRE', label: 'Autre' },
]

const FINANCING_TYPES: Array<{ value: string; label: string }> = [
  { value: 'EQUITY', label: 'Fonds propres' },
  { value: 'LOAN', label: 'Emprunt' },
  { value: 'GRANT', label: 'Subvention' },
]

// ---------------------------------------------------------------------------
// Composant principal
// ---------------------------------------------------------------------------

export function AiImproveButton({ projectId, target, value, onApply, context, compact, disabled, className }: AiImproveProps) {
  const { toast } = useToast()
  const def = AI_TARGETS[target]
  const user = useApp((s) => s.user)
  const locked = !isPremium(user?.plan)
  const openCheckout = useApp((s) => s.openCheckout)
  const [open, setOpen] = useState(false)
  const [premiumOpen, setPremiumOpen] = useState(false)
  const [phase, setPhase] = useState<'loading' | 'result' | 'error'>('loading')
  const [error, setError] = useState('')
  const [data, setData] = useState<AiImprovement | null>(null)
  const [loadingStep, setLoadingStep] = useState(0)

  // Proposition éditable (jamais appliquée sans validation explicite)
  const [editedText, setEditedText] = useState('') // kind text / list (une entrée par ligne)
  const [editedRows, setEditedRows] = useState<Row[]>([]) // kinds structurés
  const [replaceExisting, setReplaceExisting] = useState(false)

  const kind = def?.kind ?? 'text'
  const addMode = Boolean(def?.addMode)

  // Rotation des messages de chargement
  useEffect(() => {
    if (phase !== 'loading') return
    const id = setInterval(() => setLoadingStep((s) => (s + 1) % LOADING_STEPS.length), 2600)
    return () => clearInterval(id)
  }, [phase])

  const run = useCallback(async () => {
    setPhase('loading')
    setError('')
    setData(null)
    try {
      const res = await apiSend<AiImprovement>('/api/ai/improve', 'POST', {
        target,
        value,
        projectId,
        context,
      })
      setData(res)
      const prop = res.proposition
      if (kind === 'text') setEditedText(typeof prop === 'string' ? prop : '')
      else if (kind === 'list') setEditedText(Array.isArray(prop) ? prop.join('\n') : '')
      else setEditedRows(Array.isArray(prop) ? (prop as Row[]).map((r) => ({ ...r })) : [])
      setReplaceExisting(false)
      setPhase('result')
    } catch (err) {
      // Verrou serveur (abonnement expiré entre-temps…) : on propose le passage
      // à Premium plutôt qu'une erreur brute.
      if (err instanceof ApiError && err.status === 403) {
        setOpen(false)
        setPremiumOpen(true)
        setPhase('loading')
        return
      }
      setError(err instanceof Error ? err.message : 'L\'amélioration a échoué. Réessayez.')
      setPhase('error')
    }
  }, [target, value, projectId, context, kind])

  function onOpen(next: boolean) {
    setOpen(next)
    if (next) void run()
  }

  function onButtonClick() {
    // Rubrique réservée au Premium : on ouvre le dialogue d'abonnement
    // au lieu d'appeler l'assistant IA.
    if (locked) {
      setPremiumOpen(true)
      return
    }
    onOpen(true)
  }

  // Passage à Premium depuis le dialogue : ouverture du tunnel d'abonnement
  // (formulaire de renseignement + choix du moyen de paiement Mobile Money
  // selon le pays, ou carte bancaire pour l'Europe — montants FCFA et euro).
  function doUpgrade(billing: BillingPeriod) {
    setPremiumOpen(false)
    openCheckout(billing)
  }

  // ---------------------------------------------------------------- application
  function apply() {
    if (!def) return
    const existing = Array.isArray(value) ? (value as unknown[]) : []

    if (kind === 'text') {
      const t = editedText.trim()
      if (!t) return
      onApply(t)
      finish()
      return
    }

    if (kind === 'list') {
      const items = editedText.split('\n').map((l) => l.trim()).filter(Boolean)
      if (!items.length) return
      if (addMode && !replaceExisting) {
        const seen = new Set(existing.map((x) => String(x).toLowerCase().trim()))
        onApply([...existing.filter((x) => typeof x === 'string'), ...items.filter((i) => !seen.has(i.toLowerCase()))])
      } else {
        onApply(items)
      }
      finish()
      return
    }

    // Kinds structurés : normalisation vers les types de l'application
    if (!editedRows.length) return
    switch (kind) {
      case 'needs':
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => ({ id: uid(), label: String(r.label || ''), target: String(r.target || ''), frequency: String(r.frequency || '') })),
          replaceExisting && addMode,
        ))
        break
      case 'competitors':
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => ({ id: uid(), name: String(r.name || ''), type: String(r.type || 'Concurrent direct'), strengths: String(r.strengths || ''), weaknesses: String(r.weaknesses || ''), positioning: String(r.positioning || '') })),
          replaceExisting && addMode,
        ))
        break
      case 'risks':
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => ({ id: uid(), label: String(r.label || ''), category: String(r.category || 'Général'), probability: Number(r.probability) || 3, impact: Number(r.impact) || 3, mitigation: String(r.mitigation || '') })),
          replaceExisting && addMode,
        ))
        break
      case 'investments': {
        const dep = (c: string) => c !== 'TERRAIN'
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => {
            const category = String(r.category || 'AUTRE')
            return { id: uid(), label: String(r.label || ''), category, amount: Number(r.amount) || 0, depreciable: dep(category), depYears: category === 'BATIMENT' ? 10 : 5 }
          }),
          replaceExisting && addMode,
        ))
        break
      }
      case 'financing':
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => {
            const type = String(r.type || 'EQUITY')
            return { id: uid(), source: String(r.source || ''), type, amount: Number(r.amount) || 0, rate: type === 'LOAN' ? Number(r.rate) || 0 : 0, termYears: type === 'LOAN' ? Number(r.termYears) || 5 : 0 }
          }),
          replaceExisting && addMode,
        ))
        break
      case 'products':
        onApply(mergeOrReplace(
          existing,
          editedRows.map((r) => ({ id: uid(), label: String(r.label || ''), unit: String(r.unit || 'unité'), unitPrice: Number(r.unitPrice) || 0, qty: Number(r.qty) || 0, volumeGrowth: Number(r.volumeGrowth) || 0, priceGrowth: Number(r.priceGrowth) || 0 })),
          replaceExisting && addMode,
        ))
        break
      case 'tasks':
        // Le plan d'action crée les activités avec ses valeurs par défaut.
        onApply(editedRows.map((r) => ({ phase: String(r.phase || 'Général'), title: String(r.title || '') })))
        break
    }
    finish()
  }

  function finish() {
    setOpen(false)
    toast({ title: 'Proposition appliquée ✅', description: 'Vous pouvez ajuster le contenu inséré à tout moment.' })
  }

  const hasContent = phase === 'result' && (kind === 'text' ? editedText.trim().length > 0 : kind === 'list' ? editedText.trim().length > 0 : editedRows.length > 0)

  if (!def) return null

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size={compact ? 'xs' : 'sm'}
        disabled={disabled}
        aria-label={locked ? "Améliorer avec l'IA (réservé à l'abonnement Premium)" : "Améliorer avec l'IA"}
        title={locked
          ? "Améliorer avec l'IA : réservé à l'abonnement Premium"
          : "Améliorer avec l'IA : analyse, enrichissement et recommandations adaptées à votre projet"}
        onClick={onButtonClick}
        className={cn(
          'gap-1.5 border-[#d4a72c]/60 text-amber-800 hover:bg-amber-50 hover:text-amber-900 hover:border-[#d4a72c]',
          'dark:text-amber-300 dark:hover:bg-amber-950/40',
          compact && 'px-2 font-semibold',
          className,
        )}
      >
        <Sparkles className={cn('h-3.5 w-3.5 text-[#d4a72c]', compact && 'h-3 w-3')} />
        {compact ? 'IA' : 'Améliorer avec l\'IA'}
        {locked && <Lock className="h-3 w-3 text-amber-700 dark:text-amber-400" aria-hidden />}
      </Button>

      <Dialog open={premiumOpen} onOpenChange={setPremiumOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-1 flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40">
              <Crown className="h-5 w-5 text-[#d4a72c]" aria-hidden />
            </div>
            <DialogTitle className="text-center text-base">L&apos;assistant IA est réservé au Premium</DialogTitle>
            <DialogDescription className="text-center text-xs">
              Un expert en entrepreneuriat, stratégie, études de marché et ingénierie financière à vos côtés, à chaque rubrique du business plan.
            </DialogDescription>
          </DialogHeader>

          <ul className="space-y-2 text-xs leading-relaxed">
            {[
              'Analyse de vos informations : insuffisances, incohérences, éléments manquants',
              'Reformulation professionnelle et enrichissement de chaque rubrique',
              'Recommandations adaptées à votre secteur, votre marché et votre pays',
              'Hypothèses clairement signalées — rien n\'est appliqué sans votre validation',
            ].map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Sparkles className="h-3 w-3 mt-0.5 shrink-0 text-[#d4a72c]" aria-hidden />
                <span>{f}</span>
              </li>
            ))}
          </ul>

          <div className="space-y-2">
            <Button type="button" className="w-full bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]" onClick={() => doUpgrade('MONTHLY')}>
              <Crown className="h-3.5 w-3.5 mr-1.5" /> Mensuel — {fmtNumber(PREMIUM_PRICE_MONTHLY)} FCFA ({formatEur(PREMIUM_PRICE_MONTHLY)})
            </Button>
            <Button type="button" variant="outline" className="w-full" onClick={() => doUpgrade('YEARLY')}>
              Annuel — {fmtNumber(PREMIUM_PRICE_YEARLY)} FCFA ({formatEur(PREMIUM_PRICE_YEARLY)}, 2 mois offerts)
            </Button>
          </div>
          <p className="text-center text-[10px] text-muted-foreground">Mobile Money (MTN MoMo, Moov, Orange Money, Wave…) ou carte bancaire · vos données restent enregistrées.</p>
        </DialogContent>
      </Dialog>

      <Dialog open={open} onOpenChange={onOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-4 w-4 text-[#d4a72c]" />
              Amélioration intelligente — {def.label}
            </DialogTitle>
            <DialogDescription className="text-xs">
              L&apos;assistant analyse votre contenu, puis propose une version enrichie et des recommandations adaptées à votre
              projet. Rien n&apos;est appliqué sans votre validation.
            </DialogDescription>
          </DialogHeader>

          {phase === 'loading' && (
            <div className="py-10 flex flex-col items-center gap-3 text-center">
              <Loader2 className="h-7 w-7 animate-spin text-[#d4a72c]" />
              <p className="text-sm font-medium">{LOADING_STEPS[loadingStep]}</p>
              <p className="text-xs text-muted-foreground">Cela peut prendre une quinzaine de secondes.</p>
            </div>
          )}

          {phase === 'error' && (
            <div className="py-8 flex flex-col items-center gap-3 text-center">
              <AlertTriangle className="h-7 w-7 text-destructive" />
              <p className="text-sm">{error}</p>
              <Button variant="outline" size="sm" onClick={() => void run()}>
                <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Réessayer
              </Button>
            </div>
          )}

          {phase === 'result' && data && (
            <div className="space-y-4">
              {data.analyse.length > 0 && (
                <section className="rounded-lg border p-3">
                  <SectionTitle icon={SearchCheck} tone="text-rose-600" title="Analyse de votre contenu" />
                  <ul className="space-y-1.5 mt-2">
                    {data.analyse.map((a, i) => (
                      <li key={i} className="text-xs leading-relaxed flex gap-2"><span className="text-rose-500 shrink-0">•</span>{a}</li>
                    ))}
                  </ul>
                </section>
              )}

              {data.hypothese.length > 0 && (
                <section className="rounded-lg border border-amber-300/70 bg-amber-50/60 dark:bg-amber-950/20 p-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <SectionTitle icon={Info} tone="text-amber-700" title="Hypothèses utilisées — à vérifier et ajuster" />
                    <span className="text-[10px] uppercase tracking-wide font-semibold text-amber-800 bg-amber-100 border border-amber-300 rounded px-1.5 py-0.5">Non vérifiées</span>
                  </div>
                  <ul className="space-y-1.5 mt-2">
                    {data.hypothese.map((h, i) => (
                      <li key={i} className="text-xs leading-relaxed flex gap-2"><span className="text-amber-600 shrink-0">•</span>{h}</li>
                    ))}
                  </ul>
                </section>
              )}

              <section className="rounded-lg border p-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <SectionTitle icon={Sparkles} tone="text-[#b8860b]" title={kind === 'text' || kind === 'list' ? 'Proposition enrichie (modifiable)' : 'Éléments proposés (modifiables)'} />
                  {!addMode && <span className="text-[10px] text-muted-foreground">Remplacera votre contenu actuel si vous acceptez</span>}
                </div>

                {(kind === 'text' || kind === 'list') && (
                  <div className="mt-2 space-y-1.5">
                    {kind === 'list' && (
                      <p className="text-[11px] text-muted-foreground">Une proposition par ligne. Les lignes vides sont ignorées.</p>
                    )}
                    <Textarea rows={kind === 'list' ? Math.min(10, Math.max(4, editedText.split('\n').length + 1)) : 8} value={editedText} onChange={(e) => setEditedText(e.target.value)} className="text-sm" />
                  </div>
                )}

                {kind !== 'text' && kind !== 'list' && (
                  <div className="mt-2 space-y-2">
                    {editedRows.map((row, i) => (
                      <RowEditor
                        key={i}
                        kind={kind}
                        row={row}
                        onChange={(patch) => setEditedRows((rows) => rows.map((r, j) => (j === i ? { ...r, ...patch } : r)))}
                        onRemove={() => setEditedRows((rows) => rows.filter((_, j) => j !== i))}
                      />
                    ))}
                    <Button type="button" variant="ghost" size="sm" className="gap-1 text-xs" onClick={() => setEditedRows((rows) => [...rows, emptyRow(kind)])}>
                      <Plus className="h-3.5 w-3.5" /> Ajouter une ligne
                    </Button>
                  </div>
                )}
              </section>

              {data.recommandations.length > 0 && (
                <section className="rounded-lg border border-emerald-300/60 bg-emerald-50/50 dark:bg-emerald-950/20 p-3">
                  <SectionTitle icon={Lightbulb} tone="text-emerald-700" title="Recommandations stratégiques" />
                  <ul className="space-y-1.5 mt-2">
                    {data.recommandations.map((r, i) => (
                      <li key={i} className="text-xs leading-relaxed flex gap-2"><span className="text-emerald-600 shrink-0">•</span>{r}</li>
                    ))}
                  </ul>
                  <p className="text-[11px] text-muted-foreground mt-2">Ces recommandations sont des conseils : reprenez celles qui vous semblent pertinentes dans votre dossier.</p>
                </section>
              )}
            </div>
          )}

          {phase === 'result' && (
            <DialogFooter className="flex-col gap-3 sm:flex-col border-t pt-3">
              {addMode && kind !== 'tasks' && (
                <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer self-start">
                  <Checkbox checked={replaceExisting} onCheckedChange={(v) => setReplaceExisting(v === true)} />
                  Remplacer entièrement mon contenu actuel (sinon, les éléments proposés sont ajoutés)
                </label>
              )}
              {kind === 'tasks' && (
                <p className="text-xs text-muted-foreground self-start">Les activités proposées seront ajoutées à votre plan d&apos;action. Vous pourrez les modifier ensuite.</p>
              )}
              <div className="flex items-center justify-end gap-2 w-full">
                <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                  Refuser
                </Button>
                <Button type="button" disabled={!hasContent} onClick={apply} className="gap-1.5">
                  <Check className="h-4 w-4" />
                  {kind === 'tasks' ? 'Ajouter au plan d\'action' : addMode && !replaceExisting ? 'Compléter mon contenu' : 'Remplacer mon contenu'}
                </Button>
              </div>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

// ---------------------------------------------------------------------------
// Aides
// ---------------------------------------------------------------------------

function mergeOrReplace(existing: unknown[], added: unknown[], replace: boolean): unknown[] {
  if (replace) return added
  const key = (v: unknown) => {
    const o = v as Record<string, unknown>
    return String(o.label || o.name || o.title || o.source || '').toLowerCase().replace(/\s+/g, ' ').trim()
  }
  const seen = new Set(existing.map(key))
  return [...existing, ...added.filter((a) => key(a) && !seen.has(key(a)))]
}

function SectionTitle({ icon: Icon, tone, title }: { icon: typeof Lightbulb; tone: string; title: string }) {
  return (
    <span className="flex items-center gap-1.5 text-xs font-semibold">
      <Icon className={cn('h-3.5 w-3.5', tone)} /> {title}
    </span>
  )
}

function emptyRow(kind: string): Row {
  switch (kind) {
    case 'needs': return { label: '', target: '', frequency: '' }
    case 'competitors': return { name: '', type: 'Concurrent direct', strengths: '', weaknesses: '', positioning: '' }
    case 'risks': return { label: '', category: '', probability: 3, impact: 3, mitigation: '' }
    case 'investments': return { label: '', category: 'EQUIPEMENT', amount: 0 }
    case 'financing': return { source: '', type: 'EQUITY', amount: 0, rate: 0, termYears: 0 }
    case 'products': return { label: '', unit: 'unité', unitPrice: 0, qty: 0, volumeGrowth: 0, priceGrowth: 0 }
    case 'tasks': return { phase: '', title: '' }
    default: return {}
  }
}

function RowEditor({ kind, row, onChange, onRemove }: {
  kind: string
  row: Row
  onChange: (patch: Row) => void
  onRemove: () => void
}) {
  const num = (v: string): number => (v === '' ? 0 : Number(v))
  return (
    <div className="rounded-lg border bg-muted/20 p-2.5 space-y-2">
      <div className="flex items-start gap-2">
        <div className="grid gap-2 flex-1 min-w-0 sm:grid-cols-2">
          {kind === 'needs' && (
            <>
              <Field label="Besoin"><Input value={String(row.label)} onChange={(e) => onChange({ label: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Cible"><Input value={String(row.target)} onChange={(e) => onChange({ target: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Fréquence / usage" full><Input value={String(row.frequency)} onChange={(e) => onChange({ frequency: e.target.value })} className="h-8 text-xs" /></Field>
            </>
          )}
          {kind === 'competitors' && (
            <>
              <Field label="Concurrent"><Input value={String(row.name)} onChange={(e) => onChange({ name: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Type">
                <Select value={String(row.type)} onValueChange={(v) => onChange({ type: v })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{['Concurrent direct', 'Concurrent indirect', 'Substitut potentiel'].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </Field>
              <Field label="Forces" full><Input value={String(row.strengths)} onChange={(e) => onChange({ strengths: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Faiblesses" full><Input value={String(row.weaknesses)} onChange={(e) => onChange({ weaknesses: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Positionnement proposé" full><Input value={String(row.positioning)} onChange={(e) => onChange({ positioning: e.target.value })} className="h-8 text-xs" /></Field>
            </>
          )}
          {kind === 'risks' && (
            <>
              <Field label="Risque" full><Input value={String(row.label)} onChange={(e) => onChange({ label: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Catégorie"><Input value={String(row.category)} onChange={(e) => onChange({ category: e.target.value })} className="h-8 text-xs" /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Probabilité (1-5)"><Input type="number" min={1} max={5} value={String(row.probability)} onChange={(e) => onChange({ probability: num(e.target.value) })} className="h-8 text-xs" /></Field>
                <Field label="Impact (1-5)"><Input type="number" min={1} max={5} value={String(row.impact)} onChange={(e) => onChange({ impact: num(e.target.value) })} className="h-8 text-xs" /></Field>
              </div>
              <Field label="Mesure de parade" full><Input value={String(row.mitigation)} onChange={(e) => onChange({ mitigation: e.target.value })} className="h-8 text-xs" /></Field>
            </>
          )}
          {kind === 'investments' && (
            <>
              <Field label="Poste"><Input value={String(row.label)} onChange={(e) => onChange({ label: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Catégorie">
                <Select value={String(row.category)} onValueChange={(v) => onChange({ category: v })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{INVESTMENT_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </Field>
              <Field label="Montant indicatif" full><Input type="number" min={0} value={String(row.amount)} onChange={(e) => onChange({ amount: num(e.target.value) })} className="h-8 text-xs" /></Field>
            </>
          )}
          {kind === 'financing' && (
            <>
              <Field label="Source"><Input value={String(row.source)} onChange={(e) => onChange({ source: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Type">
                <Select value={String(row.type)} onValueChange={(v) => onChange({ type: v })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{FINANCING_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </Field>
              <Field label="Montant"><Input type="number" min={0} value={String(row.amount)} onChange={(e) => onChange({ amount: num(e.target.value) })} className="h-8 text-xs" /></Field>
              {String(row.type) === 'LOAN' && (
                <>
                  <Field label="Taux annuel (%)"><Input type="number" min={0} value={String(row.rate)} onChange={(e) => onChange({ rate: num(e.target.value) })} className="h-8 text-xs" /></Field>
                  <Field label="Durée (années)"><Input type="number" min={0} value={String(row.termYears)} onChange={(e) => onChange({ termYears: num(e.target.value) })} className="h-8 text-xs" /></Field>
                </>
              )}
            </>
          )}
          {kind === 'products' && (
            <>
              <Field label="Produit / service"><Input value={String(row.label)} onChange={(e) => onChange({ label: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Unité"><Input value={String(row.unit)} onChange={(e) => onChange({ unit: e.target.value })} className="h-8 text-xs" /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Prix unitaire"><Input type="number" min={0} value={String(row.unitPrice)} onChange={(e) => onChange({ unitPrice: num(e.target.value) })} className="h-8 text-xs" /></Field>
                <Field label="Quantité / an"><Input type="number" min={0} value={String(row.qty)} onChange={(e) => onChange({ qty: num(e.target.value) })} className="h-8 text-xs" /></Field>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Croissance volumes (%)"><Input type="number" value={String(row.volumeGrowth)} onChange={(e) => onChange({ volumeGrowth: num(e.target.value) })} className="h-8 text-xs" /></Field>
                <Field label="Croissance prix (%)"><Input type="number" value={String(row.priceGrowth)} onChange={(e) => onChange({ priceGrowth: num(e.target.value) })} className="h-8 text-xs" /></Field>
              </div>
            </>
          )}
          {kind === 'tasks' && (
            <>
              <Field label="Phase"><Input value={String(row.phase)} onChange={(e) => onChange({ phase: e.target.value })} className="h-8 text-xs" /></Field>
              <Field label="Activité" full><Input value={String(row.title)} onChange={(e) => onChange({ title: e.target.value })} className="h-8 text-xs" /></Field>
            </>
          )}
        </div>
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 shrink-0" aria-label="Retirer cette ligne" onClick={onRemove}>
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  )
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={cn('space-y-1', full && 'sm:col-span-2')}>
      <Label className="text-[10px] text-muted-foreground font-medium">{label}</Label>
      {children}
    </div>
  )
}
