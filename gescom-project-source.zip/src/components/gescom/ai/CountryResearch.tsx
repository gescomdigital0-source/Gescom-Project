'use client'

// GESCOM PROJECT – Recherche locale (pays / région / ville)
//
// Carte affichée dans Analyse → Aperçu général : une fois le pays et la
// région/ville du projet choisis, l'utilisateur lance une recherche web
// ciblée (marché local, réglementation, fiscalité, financements, concurrence)
// synthétisée par l'IA en un rapport français avec sources réelles.
// Fonctionnalité réservée à l'abonnement Premium.
import { useState } from 'react'
import type { ProjectRecord } from '@/components/gescom/useProjectData'
import type { OverviewData } from '@/lib/types'
import type { CountryResearchResult } from '@/lib/research'
import { useApp } from '@/lib/store'
import { isPremium } from '@/lib/plans'
import { LockedPanel } from '@/components/gescom/LockedPanel'
import { apiSend, ApiError } from '@/lib/client-api'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Globe, Search, Loader2, ExternalLink, Copy, Check, RefreshCw,
  TrendingUp, Scale, Landmark, HandCoins, Users, Lightbulb, Info, AlertTriangle,
} from 'lucide-react'

function reportToText(project: ProjectRecord, r: CountryResearchResult): string {
  const section = (title: string, items: string[]) =>
    items.length ? `\n${title.toUpperCase()}\n${items.map((i) => `- ${i}`).join('\n')}\n` : ''
  return [
    `RECHERCHE LOCALE – ${project.name}`,
    `${r.country} · ${r.location} — rapport généré le ${new Date(r.searchedAt).toLocaleString('fr-FR')}`,
    r.webOk ? '' : '\n(Recherche web indisponible : synthèse générale, points à vérifier.)',
    section('Synthèse', r.resume),
    section('Marché local', r.marche),
    section('Réglementation et autorisations', r.reglementation),
    section('Fiscalité et formalités', r.fiscalite),
    section('Financement et aides', r.financement),
    section('Concurrence et filière', r.concurrence),
    section('Recommandations', r.recommandations),
    r.sources.length
      ? `\nSOURCES\n${r.sources.map((s, i) => `${i + 1}. ${s.title} — ${s.url}`).join('\n')}\n`
      : '',
  ].filter(Boolean).join('\n')
}

function ResearchSection({ icon: Icon, title, items }: {
  icon: typeof TrendingUp
  title: string
  items: string[]
}) {
  if (!items.length) return null
  return (
    <div className="rounded-lg border bg-card p-3.5">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4 text-[#d4a72c]" />
        <h4 className="text-sm font-semibold">{title}</h4>
      </div>
      <ul className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className="text-xs text-muted-foreground leading-relaxed flex gap-1.5">
            <span className="text-[#d4a72c] shrink-0">•</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export function CountryResearch({ project, overview }: {
  project: ProjectRecord
  overview: OverviewData
}) {
  const plan = useApp((s) => s.user?.plan)
  const openCheckout = useApp((s) => s.openCheckout)
  const { toast } = useToast()
  const locked = !isPremium(plan)

  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState<CountryResearchResult | null>(null)
  const [copied, setCopied] = useState(false)

  const location = (overview.location || '').trim() || (project.region || '').trim()
  const canRun = Boolean((project.country || '').trim() && location)

  async function run() {
    if (!canRun || busy) return
    setBusy(true)
    setError('')
    setCopied(false)
    try {
      const r = await apiSend<CountryResearchResult>(
        `/api/projects/${project.id}/research`,
        'POST',
        { location },
      )
      setResult(r)
      toast({
        title: 'Recherche locale terminée',
        description: `Rapport généré pour ${r.country} · ${r.location}${r.sources.length ? ` — ${r.sources.length} sources` : ''}.`,
      })
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) {
        setError("Cette fonctionnalité est réservée à l'abonnement Premium.")
      } else {
        const payload = err instanceof ApiError ? (err.payload as { error?: string } | null) : null
        setError(payload?.error || 'La recherche locale est momentanément indisponible. Réessayez dans quelques instants.')
      }
    } finally {
      setBusy(false)
    }
  }

  async function copyReport() {
    if (!result) return
    try {
      await navigator.clipboard.writeText(reportToText(project, result))
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    } catch {
      toast({ title: 'Copie impossible', description: 'Votre navigateur a refusé la copie automatique.', variant: 'destructive' })
    }
  }

  if (locked) {
    return (
      <LockedPanel
        title="Recherche locale réservée à l'abonnement Premium"
        description="Une fois le pays et la région/ville choisis, Gescom Project effectue pour vous une recherche web ciblée sur votre zone et synthétise un rapport : marché local, réglementation, fiscalité, financements et concurrence."
        features={[
          'Recherche web ciblée sur votre pays et votre ville',
          'Rapport structuré : marché, réglementation, fiscalité, financements, concurrence',
          'Sources réelles cliquables pour appuyer votre dossier',
        ]}
        onUpgrade={() => openCheckout()}
      />
    )
  }

  return (
    <Card className="border-sky-200 dark:border-sky-900">
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Globe className="h-4 w-4 text-sky-600" />
            Recherche locale — {project.country || 'pays non choisi'}{location ? ` · ${location}` : ''}
          </CardTitle>
          {result && (
            <div className="flex items-center gap-1.5">
              <Button variant="outline" size="sm" className="h-7 text-xs" onClick={copyReport}>
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? 'Copié' : 'Copier le rapport'}
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={run} disabled={busy}>
                <RefreshCw className={`h-3.5 w-3.5 ${busy ? 'animate-spin' : ''}`} />
                Relancer
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!result && (
          <p className="text-xs text-muted-foreground leading-relaxed flex gap-2">
            <Info className="h-4 w-4 shrink-0 mt-0.5 text-sky-600" />
            <span>
              Dès que le <strong>pays</strong> et la <strong>région / ville</strong> du projet sont choisis, Gescom Project
              effectue une recherche web ciblée sur votre zone (marché, réglementation, fiscalité, financements,
              concurrence) et en synthétise un rapport avec sources — directement exploitable dans votre analyse.
            </span>
          </p>
        )}

        {!location && (
          <p className="text-xs text-amber-800 bg-amber-50 dark:bg-amber-950/30 dark:text-amber-200 border border-amber-200 dark:border-amber-900 rounded-lg p-2.5 leading-relaxed">
            Choisissez ou saisissez d'abord la <strong>région / ville du projet</strong> (champ « Région / ville du projet »
            ci-dessous), puis lancez la recherche.
          </p>
        )}

        {error && (
          <p className="text-xs text-red-800 bg-red-50 dark:bg-red-950/30 dark:text-red-200 border border-red-200 dark:border-red-900 rounded-lg p-2.5 leading-relaxed flex gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </p>
        )}

        {!result && (
          <Button onClick={run} disabled={!canRun || busy} className="gap-2 bg-sky-600 hover:bg-sky-700 text-white">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            {busy ? 'Recherche en cours…' : 'Lancer la recherche locale'}
          </Button>
        )}

        {busy && (
          <p className="text-xs text-muted-foreground animate-pulse">
            Recherche web sur 5 axes (marché, réglementation, fiscalité, financements, concurrence) puis synthèse —
            cela peut prendre jusqu'à une minute…
          </p>
        )}

        {result && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <Badge variant="outline" className={result.webOk
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-amber-50 text-amber-800 border-amber-200'}>
                {result.webOk ? 'Recherche web effectuée' : 'Synthèse générale (web indisponible)'}
              </Badge>
              <span>Rapport du {new Date(result.searchedAt).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</span>
            </div>

            {result.resume.length > 0 && (
              <div className="rounded-lg border border-sky-200 dark:border-sky-900 bg-sky-50/60 dark:bg-sky-950/20 p-3.5 space-y-1.5">
                {result.resume.map((item, i) => (
                  <p key={i} className="text-xs text-sky-900 dark:text-sky-200 leading-relaxed">{item}</p>
                ))}
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-3">
              <ResearchSection icon={TrendingUp} title="Marché local" items={result.marche} />
              <ResearchSection icon={Scale} title="Réglementation & autorisations" items={result.reglementation} />
              <ResearchSection icon={Landmark} title="Fiscalité & formalités" items={result.fiscalite} />
              <ResearchSection icon={HandCoins} title="Financement & aides" items={result.financement} />
              <ResearchSection icon={Users} title="Concurrence & filière" items={result.concurrence} />
              <ResearchSection icon={Lightbulb} title="Recommandations" items={result.recommandations} />
            </div>

            {result.sources.length > 0 && (
              <div className="rounded-lg border bg-card p-3.5">
                <h4 className="text-sm font-semibold mb-2">Sources consultées ({result.sources.length})</h4>
                <ul className="space-y-1.5">
                  {result.sources.map((s, i) => (
                    <li key={i} className="text-xs leading-relaxed">
                      <a
                        href={s.url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-sky-700 dark:text-sky-300 hover:underline"
                      >
                        <ExternalLink className="h-3 w-3 shrink-0" />
                        <span className="font-medium">{s.title}</span>
                      </a>
                      <span className="text-muted-foreground"> — {s.host}{s.date ? ` · ${s.date}` : ''}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
