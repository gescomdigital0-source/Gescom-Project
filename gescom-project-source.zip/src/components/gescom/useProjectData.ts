'use client'

// GESCOM PROJECT – Hook de données projet (chargement + sauvegarde auto)
import { useCallback, useEffect, useRef, useState } from 'react'
import { apiGet, apiSend, ApiError } from '@/lib/client-api'
import type { Task } from '@prisma/client'
import type {
  AnalysisData, DocPrefs, FinanceData, OverviewData,
} from '@/lib/types'
import { emptyAnalysis, emptyFinance, emptyOverview, defaultDocPrefs } from '@/lib/types'
import { PROJECT_STATUS_LABELS } from '@/lib/constants'
import type { ValidationReport } from '@/lib/validation'
import { useToast } from '@/hooks/use-toast'

export interface ProjectRecord {
  id: string
  name: string
  idea: string
  description: string
  sector: string
  type: string
  country: string
  region: string
  currency: string
  status: string
  createdAt: string
  updatedAt: string
  tasksCount: number
  docsCount: number
  progress: number
  objectives: string
  overview: string
  analysis: string
  finance: string
  docPrefs: string
}

function parseJson<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback
  try {
    return { ...fallback, ...JSON.parse(json) } as T
  } catch {
    return fallback
  }
}

export function useProjectData(projectId: string | null) {
  const { toast } = useToast()
  const [project, setProject] = useState<ProjectRecord | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // Échec de sauvegarde ≠ échec de chargement : on ne détruit PAS la vue,
  // on affiche un bandeau et on relance automatiquement une fois.
  const [saveError, setSaveError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [savedAt, setSavedAt] = useState<string | null>(null)
  // Refus de confirmation « Terminé » : le projet n'est pas (encore) validé
  // par Gescom Project. On conserve le rapport complet pour afficher la liste
  // des corrections dans une boîte de dialogue dédiée.
  const [statusBlock, setStatusBlock] = useState<{ status: string; report: ValidationReport } | null>(null)
  const saveTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({})
  const failedSaves = useRef<Record<string, unknown>>({})
  const retryTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  const reload = useCallback(async () => {
    if (!projectId) return
    setLoading(true)
    setError(null)
    try {
      const [p, t] = await Promise.all([
        apiGet<{ project: ProjectRecord }>(`/api/projects/${projectId}`),
        apiGet<{ tasks: Task[] }>(`/api/projects/${projectId}/tasks`),
      ])
      setProject(p.project)
      setTasks(t.tasks)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur de chargement.')
    } finally {
      setLoading(false)
    }
  }, [projectId])

  useEffect(() => {
    setProject(null)
    setTasks([])
    void reload()
  }, [reload])

  // Envoi effectif d'une section au serveur
  const pushSection = useCallback(
    async (section: string, value: unknown) => {
      setSaving(true)
      try {
        const res = await apiSend<{ ok: boolean; savedAt?: string; autoCompleted?: boolean; autoDemoted?: boolean }>(
          `/api/projects/${projectId}/data`,
          'PATCH',
          { [section]: value },
        )
        setSavedAt(res.savedAt ?? new Date().toISOString())
        setSaveError(null)
        delete failedSaves.current[section]
        // Règle Gescom Project : la sauvegarde a rendu le projet VALIDÉ (zéro
        // anomalie) ⇒ le serveur vient de confirmer « Terminé » automatiquement.
        // On aligne le badge et on célèbre la validation.
        if (res.autoCompleted) {
          setProject((p) => (p ? { ...p, status: 'COMPLETED' } : p))
          toast({
            title: 'Projet validé par Gescom Project 🎉',
            description: 'Toutes les conditions sont réunies : le projet est automatiquement passé « Terminé ».',
          })
        }
        // Règle inverse : la sauvegarde a introduit une anomalie ou une
        // correction sur un projet « Terminé » ⇒ il n'est plus validé et
        // repasse automatiquement « En cours ».
        if (res.autoDemoted) {
          setProject((p) => (p ? { ...p, status: 'ONGOING' } : p))
          toast({
            title: 'Anomalie détectée — validation retirée',
            description: 'Le projet contient à nouveau une anomalie ou une correction : il ne peut rester « Terminé » et repasse automatiquement « En cours ».',
            variant: 'destructive',
          })
        }
      } catch (err) {
        console.error('Sauvegarde échouée', err)
        failedSaves.current[section] = value
        setSaveError(
          'Enregistrement momentanément impossible (serveur peut-être en veille). '
          + 'Vos modifications restent affichées et seront envoyées au prochain essai.',
        )
        // Une relance automatique unique : la passerelle a souvent juste
        // besoin de quelques secondes pour réveiller l'application.
        clearTimeout(retryTimer.current)
        retryTimer.current = setTimeout(() => void retryFailedSaves(), 3000)
      } finally {
        setSaving(false)
      }
    },
    [projectId],
  )

  // Relance les sauvegardes qui ont échoué (appelé automatiquement et par le bouton)
  const retryFailedSaves = useCallback(() => {
    clearTimeout(retryTimer.current)
    const pending = { ...failedSaves.current }
    failedSaves.current = {}
    for (const [section, value] of Object.entries(pending)) {
      void pushSection(section, value)
    }
  }, [pushSection])

  // Sauvegarde d'une section (debounce 700 ms)
  const saveSection = useCallback(
    (section: 'objectives' | 'overview' | 'analysis' | 'finance' | 'docPrefs', value: unknown, immediate = false) => {
      if (!projectId) return
      // Mise à jour locale immédiate : les champs contrôlés reflètent la saisie
      // sans attendre le serveur (sinon le texte disparaît après la pause de
      // frappe qui déclenche l'enregistrement différé).
      setProject((p) => (p ? { ...p, [section]: JSON.stringify(value) } : p))
      clearTimeout(saveTimers.current[section])
      if (immediate) {
        void pushSection(section, value)
      } else {
        saveTimers.current[section] = setTimeout(() => void pushSection(section, value), 700)
      }
    },
    [projectId, pushSection],
  )

  // Changement de statut du projet (Brouillon / En cours / Terminé / Archivé).
  // Mise à jour optimiste : le badge réagit immédiatement ; en cas d'échec
  // réseau on affiche le bandeau d'erreur sans casser la vue.
  //
  // Règle Gescom Project : « Terminé » exige un projet VALIDÉ. Si le serveur
  // refuse (403 + rapport de validation), on revient au statut précédent
  // (En cours) et on ouvre la boîte de dialogue des corrections.
  const updateStatus = useCallback(
    async (status: string) => {
      if (!projectId) return
      const previous = project?.status
      if (previous === status) return
      setProject((p) => (p ? { ...p, status } : p))
      try {
        await apiSend<{ ok: boolean }>(`/api/projects/${projectId}`, 'PATCH', { status })
        setSavedAt(new Date().toISOString())
        setSaveError(null)
        setStatusBlock(null)
      } catch (err) {
        setProject((p) => (p && previous ? { ...p, status: previous } : p))
        if (err instanceof ApiError && err.status === 403 && err.payload?.validation) {
          // Refus métier attendu : projet non validé ⇒ il reste « En cours ».
          console.info('[statut] Terminé refusé : projet non validé par Gescom Project.')
          setStatusBlock({ status, report: err.payload.validation as ValidationReport })
          setSaveError(null)
          return
        }
        console.error('Changement de statut échoué', err)
        setSaveError(
          `Impossible de changer le statut en « ${PROJECT_STATUS_LABELS[status] || status} » `
          + '(serveur peut-être en veille). Réessayez.',
        )
      }
    },
    [projectId, project?.status],
  )

  // Données parsées (avec valeurs par défaut sûres).
  // parseJson ne fusionne qu'à un niveau : si une sauvegarde ancienne ou
  // partielle contient un sous-objet incomplet (ex. PESTEL sans « legal »),
  // l'accès `analysis.pestel[f.key].trim()` planterait et ferait tout planter
  // (écran blanc). On complète donc chaque sous-section avec les valeurs par
  // défaut avant de rendre les données aux modules.
  const baseAnalysis = emptyAnalysis()
  const rawAnalysis = parseJson<AnalysisData>(project?.analysis, baseAnalysis)
  const analysis: AnalysisData = {
    ...baseAnalysis,
    ...rawAnalysis,
    swot: { ...baseAnalysis.swot, ...(rawAnalysis.swot ?? {}) },
    pestel: { ...baseAnalysis.pestel, ...(rawAnalysis.pestel ?? {}) },
    market: { ...baseAnalysis.market, ...(rawAnalysis.market ?? {}) },
    feasibility: { ...baseAnalysis.feasibility, ...(rawAnalysis.feasibility ?? {}) },
    competitors: Array.isArray(rawAnalysis.competitors) ? rawAnalysis.competitors : [],
    needs: Array.isArray(rawAnalysis.needs) ? rawAnalysis.needs : [],
    risks: Array.isArray(rawAnalysis.risks) ? rawAnalysis.risks : [],
  }
  const baseFinance = emptyFinance()
  const rawFinance = parseJson<FinanceData>(project?.finance, baseFinance)
  const finance: FinanceData = {
    ...baseFinance,
    ...rawFinance,
    assumptions: { ...baseFinance.assumptions, ...(rawFinance.assumptions ?? {}) },
    investments: Array.isArray(rawFinance.investments) ? rawFinance.investments : [],
    financing: Array.isArray(rawFinance.financing) ? rawFinance.financing : [],
  }
  const overview: OverviewData = { ...emptyOverview(), ...parseJson<OverviewData>(project?.overview, emptyOverview()) }
  const docPrefs: DocPrefs = { ...defaultDocPrefs(), ...parseJson<DocPrefs>(project?.docPrefs, defaultDocPrefs()) }
  const objectives: string[] = (() => {
    try {
      const v = JSON.parse(project?.objectives || '[]')
      return Array.isArray(v) ? v : []
    } catch {
      return []
    }
  })()

  return {
    project, tasks, setTasks, loading, error, saveError, saving, savedAt, reload,
    retryFailedSaves, saveSection, updateStatus, statusBlock, clearStatusBlock: () => setStatusBlock(null),
    overview, analysis, finance, docPrefs, objectives,
  }
}
