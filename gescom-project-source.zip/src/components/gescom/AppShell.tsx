'use client'

// GESCOM PROJECT – Shell applicatif : sidebar, topbar, navigation
import { useEffect, useState } from 'react'
import { useApp, PROJECT_VIEWS, VIEW_TITLES, type View } from '@/lib/store'
import { apiSend, setToken } from '@/lib/client-api'
import { useTheme } from 'next-themes'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, FolderKanban, FolderPlus, ChartPie, Calculator,
  ListChecks, ShieldCheck, FileText, Presentation, Settings, Moon, Sun, LogOut,
  Menu, ChevronsUpDown, Building2, Crown, ArrowLeft, ArrowRight,
} from 'lucide-react'
import { isPremium, PLAN_LABELS, normalizePlan } from '@/lib/plans'
import { LanguageMenu } from '@/components/gescom/LanguageLayer'
import { DashboardView } from '@/components/gescom/views/DashboardView'
import { ProjectsView } from '@/components/gescom/views/ProjectsView'
import { NewProjectWizard } from '@/components/gescom/views/NewProjectWizard'
import { ProjectWorkspace } from '@/components/gescom/views/ProjectWorkspace'
import { SettingsView } from '@/components/gescom/views/SettingsView'

const NAV: Array<{ view: View; label: string; icon: typeof LayoutDashboard }> = [
  { view: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { view: 'projects', label: 'Mes projets', icon: FolderKanban },
  { view: 'new-project', label: 'Nouveau projet', icon: FolderPlus },
  { view: 'analysis', label: 'Analyse', icon: ChartPie },
  { view: 'finance', label: 'Finance', icon: Calculator },
  { view: 'action-plan', label: "Plan d'action", icon: ListChecks },
  { view: 'validation', label: 'Validation', icon: ShieldCheck },
  { view: 'documents', label: 'Documents', icon: FileText },
  { view: 'presentation', label: 'Présentation', icon: Presentation },
  { view: 'settings', label: 'Paramètres', icon: Settings },
]

export function AppShell() {
  const { user, view, activeProjectId, navigate, goBack, goForward, navHistory, navFuture } = useApp()
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const [mobileOpen, setMobileOpen] = useState(false)

  // Retour de paiement Mobile Money (FedaPay) : rouvre Paramètres → Abonnement.
  // SettingsView lit ?payment=return&ref=… puis nettoie l'URL lui-même.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('payment') === 'return') {
      navigate('settings')
    }
  }, [])

  // Repositionne la fenêtre en haut à chaque changement d'écran ou de projet.
  // Sans cette remise à zéro, la nouvelle vue s'ouvre à la position de
  // défilement de l'écran précédent : son contenu du haut (onglets, premiers
  // champs, boutons d'action) se retrouve masqué sous l'en-tête collant, et
  // les clics « ne répondent plus » (ils atteignent le titre de page au lieu
  // des éléments visibles).
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [view, activeProjectId])

  async function logout() {
    try {
      await apiSend('/api/auth/logout', 'POST')
    } catch {
      // même en cas d'erreur réseau, on purge la session locale
    }
    setToken(null)
    window.location.reload()
  }

  const needsProject = PROJECT_VIEWS.includes(view)
  // Destinations des flèches retour / avant (pour les info-bulles)
  const backEntry = navHistory.length > 0 ? navHistory[navHistory.length - 1] : null
  const forwardEntry = navFuture.length > 0 ? navFuture[navFuture.length - 1] : null
  const backLabel = backEntry ? `Retour : ${VIEW_TITLES[backEntry.view]}` : 'Aucun écran précédent'
  const forwardLabel = forwardEntry ? `Avancer : ${VIEW_TITLES[forwardEntry.view]}` : 'Aucun écran suivant'
  const initials = user
    ? `${user.firstName.charAt(0) || ''}${user.lastName.charAt(0) || ''}`.toUpperCase() || 'GP'
    : 'GP'

  const navContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 h-16 border-b border-sidebar-border shrink-0">
        <div className="h-9 w-9 rounded-lg bg-white flex items-center justify-center shrink-0 overflow-hidden shadow-sm">
          <img src="/logo.png" alt="Logo GESCOM DIGITAL SERVICES" className="h-full w-full object-contain" />
        </div>
        <div className="min-w-0">
          <div className="font-bold text-white text-sm tracking-tight truncate">GESCOM PROJECT</div>
          <div className="text-[10px] text-sidebar-foreground/70 truncate">De l&apos;idée au dossier</div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1" aria-label="Navigation principale">
        {NAV.map((item) => {
          const active = view === item.view
          const Icon = item.icon
          return (
            <button
              key={item.view}
              onClick={() => {
                navigate(item.view)
                setMobileOpen(false)
              }}
              className={cn(
                'w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors text-left',
                active
                  ? 'bg-sidebar-accent text-white shadow-sm'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-white',
              )}
              aria-current={active ? 'page' : undefined}
            >
              <Icon className={cn('h-4.5 w-4.5 h-[18px] w-[18px] shrink-0', active ? 'text-[#d4a72c]' : 'text-sidebar-foreground/70')} />
              <span className="truncate">{item.label}</span>
              {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#d4a72c]" />}
            </button>
          )
        })}
      </nav>

      {/* Utilisateur */}
      <div className="p-3 border-t border-sidebar-border shrink-0">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-sidebar-accent/60 transition-colors text-left">
              <Avatar className="h-8 w-8 border border-white/20">
                <AvatarFallback className="bg-[#d4a72c] text-[#0f172a] text-xs font-bold">{initials}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-white truncate">
                  {user?.firstName} {user?.lastName}
                </div>
                <div className="text-[11px] text-sidebar-foreground/70 truncate">{user?.email}</div>
              </div>
              <ChevronsUpDown className="h-4 w-4 text-sidebar-foreground/60" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="start" className="w-56">
            <DropdownMenuLabel className="flex items-center justify-between gap-2">
              <span>Mon compte</span>
              <span className={cn(
                'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold',
                isPremium(user?.plan)
                  ? 'border-[#d4a72c]/60 bg-[#d4a72c]/15 text-[#b8860b] dark:text-[#d4a72c]'
                  : 'border-muted-foreground/30 bg-muted text-muted-foreground',
              )}>
                {isPremium(user?.plan) && <Crown className="h-3 w-3" aria-hidden />}
                {PLAN_LABELS[normalizePlan(user?.plan)]}
              </span>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('settings')}>
              <Crown className="h-4 w-4 mr-2" /> Abonnement
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('settings')}>
              <Settings className="h-4 w-4 mr-2" /> Paramètres
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
              <LogOut className="h-4 w-4 mr-2" /> Se déconnecter
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar desktop */}
      <aside className="hidden lg:block w-64 bg-sidebar shrink-0 no-print" aria-label="Menu latéral">
        <div className="fixed lg:sticky top-0 h-screen w-64">{navContent}</div>
      </aside>

      {/* Sidebar mobile */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden fixed top-3 left-3 z-40 bg-card/80 backdrop-blur no-print" aria-label="Ouvrir le menu">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-72 bg-sidebar border-sidebar-border">
          <SheetTitle className="sr-only">Menu de navigation</SheetTitle>
          {navContent}
        </SheetContent>
      </Sheet>

      {/* Contenu principal */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="h-16 border-b bg-card/80 backdrop-blur sticky top-0 z-30 flex items-center gap-3 px-4 lg:px-8 no-print">
          <div className="lg:hidden w-12" />
          {/* Flèches de navigation retour / avant (historique des écrans) */}
          <div className="flex items-center gap-0.5 shrink-0">
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={goBack}
              disabled={navHistory.length === 0}
              aria-label={backLabel}
              title={backLabel}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={goForward}
              disabled={navFuture.length === 0}
              aria-label={forwardLabel}
              title={forwardLabel}
            >
              <ArrowRight className="h-5 w-5" />
            </Button>
          </div>
          <div className="min-w-0">
            <h1 className="font-bold text-lg leading-tight truncate">{VIEW_TITLES[view]}</h1>
            <p className="text-xs text-muted-foreground truncate">
              {needsProject ? 'Sélectionnez ou ouvrez un projet pour travailler sur ses données' : 'GESCOM PROJECT — plateforme de structuration de projets'}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <LanguageMenu />
            {user?.organization && (
              <span className="hidden md:inline-flex items-center gap-1.5 text-xs text-muted-foreground border rounded-full px-3 py-1.5">
                <Building2 className="h-3.5 w-3.5" /> {user.organization}
              </span>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              aria-label="Basculer le thème clair/sombre"
            >
              <Sun className="h-5 w-5 hidden dark:block" />
              <Moon className="h-5 w-5 dark:hidden" />
            </Button>
          </div>
        </header>

        {/* Vues */}
        <main className="flex-1 min-h-0 animate-fade-up">
          {view === 'dashboard' && <DashboardView />}
          {view === 'projects' && <ProjectsView />}
          {view === 'new-project' && <NewProjectWizard />}
          {needsProject && <ProjectWorkspace view={view} />}
          {view === 'settings' && <SettingsView />}
        </main>
      </div>
    </div>
  )
}
