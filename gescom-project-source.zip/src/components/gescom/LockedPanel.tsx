'use client'

// GESCOM PROJECT – Panneau « fonctionnalité réservée au Premium »
// Affiché à la place du contenu verrouillé pour le plan Gratuit (0 FCFA).
import { Crown, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export function LockedPanel({
  title,
  description,
  features,
  onUpgrade,
  upgrading = false,
  compact = false,
}: {
  title: string
  description: string
  features?: string[]
  onUpgrade: () => void
  upgrading?: boolean
  compact?: boolean
}) {
  return (
    <Card className="border-amber-200 dark:border-amber-900 bg-gradient-to-br from-amber-50/70 to-background dark:from-amber-950/20">
      <CardContent className={compact ? 'p-5 text-center' : 'p-6 text-center'}>
        <div className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40">
          <Lock className="h-5 w-5 text-amber-700 dark:text-amber-400" aria-hidden />
        </div>
        <h3 className="font-semibold text-sm">{title}</h3>
        <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed max-w-md mx-auto">{description}</p>
        {features && features.length > 0 && (
          <ul className="mt-3 space-y-1 text-xs text-muted-foreground max-w-md mx-auto text-left">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-1.5">
                <Crown className="h-3 w-3 mt-0.5 shrink-0 text-[#d4a72c]" aria-hidden />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        )}
        <Button
          size="sm"
          className="mt-4 bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
          onClick={onUpgrade}
          disabled={upgrading}
        >
          <Crown className="h-3.5 w-3.5 mr-1.5" aria-hidden />
          {upgrading ? 'Activation…' : 'Passer à Premium'}
        </Button>
        <p className="mt-2 text-[10px] text-muted-foreground">Vos données restent enregistrées et réapparaîtront après activation.</p>
      </CardContent>
    </Card>
  )
}
