'use client'

// GESCOM PROJECT – Tunnel d'abonnement Premium
//
// Formulaire ouvert depuis tous les boutons « Passer à Premium » :
//  1. Renseignement des informations du payeur (prénom, nom, e-mail, pays,
//     téléphone) ;
//  2. Choix de la formule (mensuelle ou annuelle), montants affichés en
//     FCFA et en euro (parité fixe 1 € = 655,957 FCFA) ;
//  3. Choix du moyen de paiement : les opérateurs Mobile Money disponibles
//     dans le pays sélectionné (MTN MoMo, Orange Money, Wave, T-Money…) ou
//     la carte bancaire (Visa / Mastercard) pour les payeurs en Europe et
//     dans le reste du monde.
//
// L'encaissement réel est opéré par FedaPay (agrégateur, Togo) : après
// validation, le payeur est redirigé vers la page de paiement sécurisée où il
// confirme son numéro / saisit sa carte. L'activation du Premium est ensuite
// automatique (webhook vérifié + contrôle au retour sur /?payment=return).
// Sans clé d'encaissement configurée, un repli « mode démonstration »
// (paiement simulé) reste proposé.
import { useCallback, useEffect, useMemo, useState } from 'react'
import { apiGet, apiSend } from '@/lib/client-api'
import { useApp } from '@/lib/store'
import type { SessionUser } from '@/lib/types'
import {
  PLAN_PRICING,
  formatEur, type BillingPeriod,
} from '@/lib/plans'
import { fmtNumber } from '@/lib/format'
import { PAYER_COUNTRIES, findCountry, type PaymentOperator } from '@/lib/payments-methods'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  AlertTriangle, Check, CreditCard, Crown, Loader2, ShieldCheck, Smartphone,
} from 'lucide-react'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

interface BillingStatus {
  configured: boolean
  pricing?: { MONTHLY?: number; YEARLY?: number }
}

export function CheckoutDialog() {
  const { toast } = useToast()
  const user = useApp((s) => s.user)
  const setUser = useApp((s) => s.setUser)
  const billing = useApp((s) => s.checkoutBilling)
  const closeCheckout = useApp((s) => s.closeCheckout)

  const open = billing !== null

  // Formule choisie (pré-sélectionnée par le bouton qui a ouvert le tunnel)
  const [period, setPeriod] = useState<BillingPeriod>('MONTHLY')
  useEffect(() => {
    if (billing) setPeriod(billing)
  }, [billing])

  // Informations du payeur (pré-remplies avec le compte connecté)
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [countryCode, setCountryCode] = useState('TG')
  const [phoneDigits, setPhoneDigits] = useState('')

  useEffect(() => {
    if (!open || !user) return
    setFirstName((v) => v || user.firstName || '')
    setLastName((v) => v || user.lastName || '')
    setEmail((v) => v || user.email || '')
  }, [open, user])

  // Moyen de paiement : dépend du pays sélectionné
  const country = findCountry(countryCode) ?? PAYER_COUNTRIES[0]
  const [method, setMethod] = useState('T_MONEY')
  useEffect(() => {
    // au changement de pays : on sélectionne le premier moyen disponible
    setMethod(country.operators[0]?.id ?? 'CARD')
  }, [countryCode])  

  // État de l'encaissement (clé FedaPay configurée ?) + soumission
  const [configured, setConfigured] = useState<boolean | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [demoOffer, setDemoOffer] = useState(false)

  useEffect(() => {
    if (!open) return
    setError('')
    setDemoOffer(false)
    setConfigured(null)
    let alive = true
    apiGet<BillingStatus>('/api/account/plan/payments')
      .then((s) => { if (alive) setConfigured(Boolean(s.configured)) })
      .catch(() => { if (alive) setConfigured(true) // en cas d'échec réseau, on tente le paiement réel
      })
    return () => { alive = false }
  }, [open])

  const amount = PLAN_PRICING[period].amount
  const canSubmit = useMemo(
    () =>
      firstName.trim().length > 1 &&
      lastName.trim().length > 1 &&
      EMAIL_RE.test(email.trim()) &&
      phoneDigits.replace(/\D/g, '').length >= 8 &&
      Boolean(method),
    [firstName, lastName, email, phoneDigits, method],
  )

  const activateDemo = useCallback(async () => {
    setSubmitting(true)
    setError('')
    try {
      const res = await apiSend<{ user: SessionUser }>('/api/account/plan', 'POST', { plan: 'PREMIUM', billing: period })
      setUser(res.user)
      toast({
        title: 'Abonnement Premium activé ✅',
        description: 'Mode démonstration (paiement simulé) : tout le contenu est débloqué.',
      })
      closeCheckout()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Activation impossible. Réessayez.')
    } finally {
      setSubmitting(false)
    }
  }, [period, setUser, toast, closeCheckout])

  async function submit() {
    setError('')
    // Repli démonstration : pas de clé d'encaissement configurée
    if (configured === false) {
      await activateDemo()
      return
    }
    setSubmitting(true)
    try {
      const res = await apiSend<{ paymentUrl: string }>('/api/account/plan/checkout', 'POST', {
        billing: period,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        phone: phoneDigits.replace(/\D/g, ''),
        country: country.code,
        method,
      })
      // Redirection vers la page de paiement sécurisée (Mobile Money ou carte)
      setSubmitting(false)
      closeCheckout()
      window.location.href = res.paymentUrl
    } catch (err) {
      setSubmitting(false)
      if (err instanceof Error && err.message.includes('503')) {
        setDemoOffer(true)
        setConfigured(false)
        return
      }
      setError(err instanceof Error ? err.message : 'Le démarrage du paiement a échoué. Réessayez.')
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) closeCheckout() }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <Crown className="h-4 w-4 text-[#d4a72c]" />
            Passer à l&apos;abonnement Premium
          </DialogTitle>
          <DialogDescription className="text-xs">
            Renseignez vos informations et choisissez votre moyen de paiement : Mobile Money de votre pays
            ou carte bancaire. L&apos;activation est automatique dès la confirmation du paiement.
          </DialogDescription>
        </DialogHeader>

        {/* ---------- 1. Formule ---------- */}
        <section className="space-y-2">
          <SectionTitle n={1} title="Choisissez votre formule" />
          <div className="grid grid-cols-2 gap-2">
            {(['MONTHLY', 'YEARLY'] as BillingPeriod[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={cn(
                  'relative rounded-xl border p-3 text-left transition-colors',
                  period === p ? 'border-[#d4a72c] bg-accent/50 ring-1 ring-[#d4a72c]/40' : 'hover:bg-accent/30',
                )}
              >
                {p === 'YEARLY' && (
                  <span className="absolute top-0 right-0 bg-[#d4a72c] text-[#0f172a] text-[9px] font-bold px-2 py-0.5 rounded-bl-lg">2 MOIS OFFERTS</span>
                )}
                <div className="text-xs font-medium">{PLAN_PRICING[p].label}</div>
                <div className="text-lg font-bold mt-0.5">
                  {fmtNumber(PLAN_PRICING[p].amount)} <span className="text-[10px] font-semibold">FCFA</span>
                </div>
                <div className="text-[11px] text-muted-foreground">≈ {formatEur(PLAN_PRICING[p].amount)} {p === 'MONTHLY' ? '/ mois' : '/ an'}</div>
              </button>
            ))}
          </div>
        </section>

        {/* ---------- 2. Informations du payeur ---------- */}
        <section className="space-y-2.5">
          <SectionTitle n={2} title="Vos informations" />
          <div className="grid grid-cols-2 gap-2">
            <Field label="Prénom">
              <Input value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Awa" className="h-9 text-sm" autoComplete="given-name" />
            </Field>
            <Field label="Nom">
              <Input value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Nkeng" className="h-9 text-sm" autoComplete="family-name" />
            </Field>
          </div>
          <Field label="Adresse e-mail (reçu et confirmation)">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="awa@exemple.com" className="h-9 text-sm" autoComplete="email" />
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Pays de paiement">
              <Select value={countryCode} onValueChange={setCountryCode}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-64">
                  {PAYER_COUNTRIES.map((c) => (
                    <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Téléphone">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-muted-foreground bg-muted rounded px-2 h-9 flex items-center shrink-0 min-w-11 justify-center">{country.dial}</span>
                <Input
                  value={phoneDigits}
                  onChange={(e) => setPhoneDigits(e.target.value.replace(/[^0-9\s]/g, ''))}
                  placeholder="90 00 00 00"
                  inputMode="tel"
                  className="h-9 text-sm"
                  autoComplete="tel-national"
                />
              </div>
            </Field>
          </div>
        </section>

        {/* ---------- 3. Moyen de paiement ---------- */}
        <section className="space-y-2">
          <SectionTitle n={3} title="Moyen de paiement" />
          <div className="space-y-1.5">
            {country.operators.map((op) => (
              <OperatorOption
                key={op.id}
                op={op}
                selected={method === op.id}
                onSelect={() => setMethod(op.id)}
              />
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed flex items-start gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 mt-0.5 shrink-0 text-emerald-600" />
            {method === 'CARD'
              ? 'Paiement sécurisé 3-D Secure : vous saisirez les informations de votre carte sur la page de paiement sécurisée (Visa, Mastercard).'
              : 'Après validation, suivez les instructions sur la page sécurisée : une demande de confirmation arrivera sur votre téléphone.'}
          </p>
        </section>

        {/* ---------- Repli démonstration ---------- */}
        {demoOffer && (
          <div className="rounded-lg border border-amber-300/70 bg-amber-50/70 dark:bg-amber-950/20 p-3 text-xs leading-relaxed">
            <div className="flex items-center gap-1.5 font-semibold text-amber-800 dark:text-amber-300">
              <AlertTriangle className="h-3.5 w-3.5" /> Encaissement non configuré
            </div>
            <p className="mt-1 text-muted-foreground">
              Le serveur n&apos;a pas encore de clé de paiement FedaPay. En attendant, vous pouvez activer
              le Premium en mode démonstration (paiement simulé) pour tester toutes les fonctionnalités.
            </p>
            <Button size="sm" variant="outline" className="mt-2" onClick={() => void activateDemo()} disabled={submitting}>
              {submitting ? <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Activation…</> : <><Crown className="h-3.5 w-3.5 mr-1.5" /> Activer en mode démonstration</>}
            </Button>
          </div>
        )}

        {error && (
          <p className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</p>
        )}

        {/* ---------- Total + action ---------- */}
        <div className="border-t pt-3 space-y-2.5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Total à payer</span>
            <span className="font-bold">
              {fmtNumber(amount)} FCFA
              <span className="text-muted-foreground font-normal"> ≈ {formatEur(amount)}</span>
            </span>
          </div>
          <Button
            type="button"
            className="w-full bg-[#0f172a] hover:bg-[#1e293b] text-white dark:bg-[#d4a72c] dark:text-[#0f172a] dark:hover:bg-[#e0b640]"
            disabled={!canSubmit || submitting}
            onClick={() => void submit()}
          >
            {submitting ? (
              <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Redirection vers le paiement…</>
            ) : configured === false ? (
              <><Crown className="h-4 w-4 mr-1.5" /> Activer Premium (démo, simulé)</>
            ) : (
              <><Check className="h-4 w-4 mr-1.5" /> Payer {fmtNumber(amount)} FCFA ({formatEur(amount)})</>
            )}
          </Button>
          <p className="text-center text-[10px] text-muted-foreground">
            Encaissement sécurisé via FedaPay · MTN MoMo, Moov, Orange Money, Wave, carte bancaire ·
            Vos données restent enregistrées après l&apos;abonnement.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ---------------------------------------------------------------------------
// Aides
// ---------------------------------------------------------------------------

function SectionTitle({ n, title }: { n: number; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="h-5 w-5 rounded-full bg-[#0f172a] dark:bg-[#d4a72c] text-white dark:text-[#0f172a] text-[10px] font-bold flex items-center justify-center">{n}</span>
      <h4 className="text-xs font-semibold">{title}</h4>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label className="text-[11px] text-muted-foreground font-medium">{label}</Label>
      {children}
    </div>
  )
}

function OperatorOption({ op, selected, onSelect }: { op: PaymentOperator; selected: boolean; onSelect: () => void }) {
  const Icon = op.kind === 'CARD' ? CreditCard : Smartphone
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        'w-full flex items-center gap-2.5 rounded-lg border p-2.5 text-left transition-colors',
        selected ? 'border-[#d4a72c] bg-accent/50 ring-1 ring-[#d4a72c]/40' : 'hover:bg-accent/30',
      )}
      aria-pressed={selected}
    >
      <span className={cn(
        'h-8 w-8 rounded-lg flex items-center justify-center shrink-0',
        op.kind === 'CARD' ? 'bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300',
      )}>
        <Icon className="h-4 w-4" aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-xs font-semibold truncate">{op.label}</span>
        <span className="block text-[10px] text-muted-foreground">
          {op.kind === 'CARD' ? 'Visa · Mastercard · 3-D Secure' : 'Confirmation par code sur votre téléphone'}
        </span>
      </span>
      <span className={cn(
        'h-4 w-4 rounded-full border flex items-center justify-center shrink-0',
        selected ? 'border-[#d4a72c] bg-[#d4a72c]' : 'border-muted-foreground/40',
      )}>
        {selected && <Check className="h-2.5 w-2.5 text-white dark:text-[#0f172a]" aria-hidden />}
      </span>
    </button>
  )
}
