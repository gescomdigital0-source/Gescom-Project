// GESCOM PROJECT – Codes à 6 chiffres envoyés par e-mail
//
// Deux usages (paramètre « purpose ») :
//  • SIGNUP         – activation du compte à l'inscription ;
//  • PASSWORD_RESET – réinitialisation d'un mot de passe oublié.
//
// Règles de sécurité :
//  • le code est généré de façon cryptographique (crypto.randomInt) ;
//  • seuls son SHA-256 et son expiration sont stockés en base ;
//  • validité de 10 minutes, maximum 5 tentatives de saisie ;
//  • 60 secondes minimum entre deux envois (anti-spam) ;
//  • comparaison à temps constant (timingSafeEqual).
import { db } from '@/lib/db'
import crypto from 'crypto'
import { smtpConfigured } from '@/lib/mailer'

export const CODE_TTL_MINUTES = 10
export const MAX_ATTEMPTS = 5
export const RESEND_COOLDOWN_SECONDS = 60

export type CodePurpose = 'SIGNUP' | 'PASSWORD_RESET'

function hashCode(code: string): string {
  return crypto.createHash('sha256').update(code).digest('hex')
}

export function generateCode(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0')
}

export type IssueResult =
  | { ok: true; code: string; minutes: number }
  | { ok: false; error: string; retryAfterSeconds?: number }

// Crée (ou remplace) le code en attente pour une adresse e-mail et un usage.
// Le délai anti-spam de 60 s ne s'applique QUE si les e-mails partent
// réellement (SMTP configuré, en base ou via .env). En mode démonstration,
// aucun e-mail n'est envoyé : le code est affiché à l'écran, on le régénère
// donc à chaque demande — sans quoi l'utilisateur serait bloqué sans code.
export async function issueCode(email: string, purpose: CodePurpose): Promise<IssueResult> {
  const existing = await db.emailVerification.findUnique({
    where: { email_purpose: { email, purpose } },
  })
  if (existing && (await smtpConfigured())) {
    const elapsed = (Date.now() - existing.lastSentAt.getTime()) / 1000
    const stillValid = existing.expiresAt > new Date()
    if (stillValid && elapsed < RESEND_COOLDOWN_SECONDS) {
      const retryAfterSeconds = Math.ceil(RESEND_COOLDOWN_SECONDS - elapsed)
      return {
        ok: false,
        error: `Un code a déjà été envoyé à cette adresse. Un nouveau pourra être demandé dans ${retryAfterSeconds} s.`,
        retryAfterSeconds,
      }
    }
  }
  const code = generateCode()
  const data = {
    codeHash: hashCode(code),
    expiresAt: new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000),
    attempts: 0,
    lastSentAt: new Date(),
  }
  await db.emailVerification.upsert({
    where: { email_purpose: { email, purpose } },
    create: { email, purpose, ...data },
    update: data,
  })
  return { ok: true, code, minutes: CODE_TTL_MINUTES }
}

export type CheckResult = { ok: true } | { ok: false; error: string }

// Vérifie le code saisi par l'utilisateur pour un usage donné.
export async function checkCode(email: string, purpose: CodePurpose, code: string): Promise<CheckResult> {
  const record = await db.emailVerification.findUnique({
    where: { email_purpose: { email, purpose } },
  })
  if (!record) {
    return { ok: false, error: 'Aucun code en attente pour cette adresse. Demandez un nouveau code.' }
  }
  if (record.expiresAt < new Date()) {
    return { ok: false, error: 'Ce code a expiré. Demandez un nouveau code.' }
  }
  if (record.attempts >= MAX_ATTEMPTS) {
    return { ok: false, error: 'Trop de tentatives incorrectes. Demandez un nouveau code.' }
  }
  const given = Buffer.from(hashCode(code))
  const stored = Buffer.from(record.codeHash)
  const valid = given.length === stored.length && crypto.timingSafeEqual(given, stored)
  if (!valid) {
    await db.emailVerification.update({
      where: { id: record.id },
      data: { attempts: { increment: 1 } },
    })
    const remaining = MAX_ATTEMPTS - record.attempts - 1
    return {
      ok: false,
      error:
        remaining > 0
          ? `Code incorrect. ${remaining} tentative${remaining > 1 ? 's' : ''} restante${remaining > 1 ? 's' : ''}.`
          : 'Code incorrect. Plus aucune tentative restante : demandez un nouveau code.',
    }
  }
  await db.emailVerification.delete({ where: { id: record.id } })
  return { ok: true }
}
