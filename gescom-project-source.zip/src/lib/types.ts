// GESCOM PROJECT – Types partagés (client & serveur)

// ---------------------------------------------------------------------------
// Analyse stratégique
// ---------------------------------------------------------------------------

export interface SwotItem {
  id: string
  label: string
}

export interface SwotData {
  strengths: SwotItem[] // Forces
  weaknesses: SwotItem[] // Faiblesses
  opportunities: SwotItem[] // Opportunités
  threats: SwotItem[] // Menaces
}

export interface PestelData {
  politique: string
  economique: string
  socioculturel: string
  technologique: string
  ecologique: string
  legal: string
}

export interface MarketData {
  demande: string // Analyse de la demande
  offre: string // Analyse de l'offre
  segments: string // Segments de clientèle
  tendances: string // Tendances du marché
  cible: string // Clientèle cible
  zones: string // Zone de chalandise / localisation
  conclusion: string
}

export interface Competitor {
  id: string
  name: string
  type: string
  strengths: string
  weaknesses: string
  positioning: string
}

export interface NeedItem {
  id: string
  label: string
  target: string
  frequency: string
}

export interface RiskItem {
  id: string
  label: string
  category: string
  probability: number // 1..5
  impact: number // 1..5
  mitigation: string
}

export interface FeasibilityData {
  technique: string
  economique: string
  juridique: string
  organisationnelle: string
  commerciale: string
  verdict: 'FAVORABLE' | 'RESERVE' | 'DEFAVORABLE' | ''
}

export interface AnalysisData {
  swot: SwotData
  pestel: PestelData
  market: MarketData
  competitors: Competitor[]
  needs: NeedItem[]
  risks: RiskItem[]
  feasibility: FeasibilityData
  synthesis: string
  recommendations: string
}

// ---------------------------------------------------------------------------
// Finance
// ---------------------------------------------------------------------------

export interface InvestmentLine {
  id: string
  label: string
  category: string // TERRAIN | BATIMENT | EQUIPEMENT | MATERIEL | FRAIS_ETABLISSEMENT | AUTRE
  amount: number
  depreciable: boolean
  depYears: number
}

export interface FinancingLine {
  id: string
  source: string
  type: 'EQUITY' | 'LOAN' | 'GRANT' // Fonds propres | Emprunt | Subvention
  amount: number
  rate: number // % annuel (emprunts)
  termYears: number // durée en années (emprunts)
}

export interface ProductLine {
  id: string
  label: string
  unit: string
  unitPrice: number
  qty: number // quantité annuelle (année 1)
  volumeGrowth: number // % croissance annuelle des quantités
  priceGrowth: number // % croissance annuelle du prix
}

export interface CostLine {
  id: string
  label: string
  mode: 'QTY' | 'PCT' // quantité × prix unitaire | % du chiffre d'affaires
  unitPrice: number
  qty: number
  pct: number // % du CA
  annualAmount: number // montant annuel fixe (mode charges fixes)
  growth: number // % croissance annuelle
}

export interface StaffLine {
  id: string
  role: string
  count: number
  monthlySalary: number
  annualGrowth: number // % augmentation annuelle
}

export interface FinanceAssumptions {
  horizonYears: number // 1..10
  discountRate: number // %
  taxRate: number // %
  products: ProductLine[]
  variableCosts: CostLine[]
  fixedCosts: CostLine[]
  staff: StaffLine[]
}

export interface FinanceData {
  investments: InvestmentLine[]
  workingCapital: number // Fonds de roulement initial (BFR)
  financing: FinancingLine[]
  assumptions: FinanceAssumptions
}

// ---------------------------------------------------------------------------
// Résultats du moteur financier
// ---------------------------------------------------------------------------

export interface YearResult {
  year: number
  revenue: number
  variableCosts: number
  fixedCosts: number
  ebitda: number // Excédent brut d'exploitation
  depreciation: number
  interest: number
  ebt: number // Résultat avant impôt
  tax: number
  netIncome: number
  principalRepayment: number
  caf: number // Capacité d'autofinancement
  freeCashFlow: number // Flux net après service de la dette
  cumulativeFCF: number // Flux cumulé (avec mise de fonds initiale)
}

export interface LoanScheduleYear {
  year: number
  source: string
  openingBalance: number
  interest: number
  principal: number
  annuity: number
  closingBalance: number
}

export interface FinancialRatios {
  netMargin: number // %
  ebitdaMargin: number // %
  roi: number // % (résultat net moyen / investissement total)
  autonomyRate: number // % fonds propres / financement total
  dscr: number | null // EBE / (intérêts + principal) année 1 — null si aucun emprunt
  payback: number | null // années
  npv: number // VAN (flux projet, taux d'actualisation)
  irr: number | null // TRI %
  breakEvenRevenue: number // Seuil de rentabilité (CA)
  breakEvenYear: number // année d'atteinte
}

export interface ScenarioResult {
  name: 'OPTIMISTIC' | 'REALISTIC' | 'PESSIMISTIC'
  label: string
  revenue1: number
  netIncome1: number
  netIncomeAvg: number
  payback: number | null
  npv: number
}

export interface FinanceComputation {
  years: YearResult[]
  loanSchedule: LoanScheduleYear[]
  totalInvestment: number
  totalWorkingCapital: number
  totalNeeds: number
  totalFinancing: number
  totalEquity: number
  totalLoans: number
  totalGrants: number
  financingGap: number // besoins - financements
  ratios: FinancialRatios
  scenarios: ScenarioResult[]
}

// ---------------------------------------------------------------------------
// Aperçu général & création
// ---------------------------------------------------------------------------

export interface OverviewData {
  legalForm: string // Forme juridique envisagée
  location: string // Localisation du projet
  promoter: string // Porteur du projet
  startDate: string // Date prévisionnelle de démarrage
  summary: string // Résumé exécutif
  vision: string
  mission: string
  values: string
}

export interface DocPrefs {
  coverTitle: string
  coverSubtitle: string
  author: string
  organization: string
  includeCover: boolean
  includeToc: boolean
  headerText: string
  footerText: string
}

// ---------------------------------------------------------------------------
// Préférences utilisateur
// ---------------------------------------------------------------------------

export interface UserPrefs {
  language: string // fr
  country: string
  currency: string
  dateFormat: string // DD/MM/YYYY
  timezone: string
  theme: 'light' | 'dark' | 'system'
  notifInApp: boolean
  notifEmail: boolean
  notifDeadlines: boolean
}

// ---------------------------------------------------------------------------
// Divers
// ---------------------------------------------------------------------------

export type ProjectStatus = 'DRAFT' | 'ONGOING' | 'COMPLETED' | 'ARCHIVED'

export interface SessionUser {
  id: string
  email: string
  firstName: string
  lastName: string
  role: string
  emailVerified: boolean // adresse e-mail confirmée par code à 6 chiffres
  plan: string // FREE | PREMIUM (plan effectif, expiration prise en compte)
  planExpiresAt: string | null // fin de validité du Premium (ISO) ou null
  organization: string
  jobTitle: string
  phone: string
  prefs: UserPrefs
}

// Paiement Mobile Money (historique d'abonnement)
export interface PaymentRecord {
  id: string
  reference: string
  provider: string
  billing: string
  amount: number
  currency: string
  status: string
  paidAt: string | null
  createdAt: string
}

export interface ActivityEntry {
  id: string
  type: string
  message: string
  createdAt: string
  projectId?: string | null
}

// Identifiant unique côté client
export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
}

export const emptySwot = (): SwotData => ({
  strengths: [],
  weaknesses: [],
  opportunities: [],
  threats: [],
})

export const emptyAnalysis = (): AnalysisData => ({
  swot: emptySwot(),
  pestel: { politique: '', economique: '', socioculturel: '', technologique: '', ecologique: '', legal: '' },
  market: { demande: '', offre: '', segments: '', tendances: '', cible: '', zones: '', conclusion: '' },
  competitors: [],
  needs: [],
  risks: [],
  feasibility: { technique: '', economique: '', juridique: '', organisationnelle: '', commerciale: '', verdict: '' },
  synthesis: '',
  recommendations: '',
})

export const emptyFinance = (): FinanceData => ({
  investments: [],
  workingCapital: 0,
  financing: [],
  assumptions: {
    horizonYears: 5,
    discountRate: 12,
    taxRate: 25,
    products: [],
    variableCosts: [],
    fixedCosts: [],
    staff: [],
  },
})

export const emptyOverview = (): OverviewData => ({
  legalForm: '',
  location: '',
  promoter: '',
  startDate: '',
  summary: '',
  vision: '',
  mission: '',
  values: '',
})

export const defaultDocPrefs = (): DocPrefs => ({
  coverTitle: '',
  coverSubtitle: '',
  author: '',
  organization: '',
  includeCover: true,
  includeToc: true,
  headerText: 'GESCOM PROJECT',
  footerText: '',
})
