// GESCOM PROJECT – Données de démonstration
// Projet complet : Ferme avicole de 2 000 poulets de chair au Cameroun
// ATTENTION : il s'agit de données ILLUSTRATIVES fournies pour explorer la
// plateforme. Elles doivent être remplacées par les données réelles de
// l'utilisateur (prix, rendements et statistiques de marché à valider par
// une enquête de terrain).

import type { AnalysisData, FinanceData, OverviewData, DocPrefs } from '@/lib/types'

export const DEMO_USER = {
  email: 'demo@gescom.pro',
  password: 'demo2026',
  firstName: 'Awa',
  lastName: 'Nkeng',
  phone: '+237 6 90 00 00 00',
  jobTitle: 'Entrepreneure agricole',
  organization: 'Awa Farms & Co',
}

export const DEMO_ADMIN = {
  email: 'admin@gescom.pro',
  password: 'admin2026',
  firstName: 'Admin',
  lastName: 'GESCOM',
  role: 'ADMIN',
}

export const DEMO_PROJECT = {
  name: 'Ferme avicole moderne – 2 000 poulets de chair',
  idea:
    "Créer une ferme avicole moderne de 2 000 poulets de chair par bande (6 bandes par an) dans la région du Centre au Cameroun, pour approvisionner les marchés, restaurants et ménages de Yaoundé en viande de volaille fraîche, locale et de qualité.",
  description:
    "Le projet consiste à construire et exploiter un poulailler semi-industriel d'une capacité de 2 000 sujets par bande, soit environ 12 000 poulets commercialisés par an après déduction de la mortalité. La ferme produira des poulets de chair de 2,2 kg de poids moyen vif, vendus vivants et abattus aux ménages, restaurants, hôtels et grossistes de la ville de Yaoundé. L'exploitation s'appuie sur des pratiques d'élevage améliorées : suivi vétérinaire régulier, alimentation équilibrée en trois phases (démarrage, croissance, finition), biosécurité de base et gestion rigoureuse des bandes. Unvolet complémentaire de valorisation du fumier en sacs pour les maraîchers permet de générer un revenu annexe et de réduire les déchets.",
  sector: 'Agriculture & Élevage',
  type: "Création d'entreprise",
  country: 'Cameroun',
  region: 'Centre',
  currency: 'XAF',
  status: 'ONGOING',
  objectives: [
    "Mettre en place une capacité d'élevage de 2 000 sujets par bande d'ici le premier trimestre d'exploitation",
    'Atteindre 6 bandes par an avec un taux de mortalité maîtrisé inférieur à 6 %',
    "Réaliser un chiffre d'affaires annuel d'environ 76 millions FCFA dès la première année",
    "Obtenir un délai de récupération de l'investissement inférieur à 2 ans",
    'Créer 2 emplois directs et former 2 jeunes de la localité aux bonnes pratiques d\'élevage',
  ],
}

export const DEMO_OVERVIEW: OverviewData = {
  legalForm: 'Entreprise individuelle (en cours d\'immatriculation au RCCM)',
  location: 'Village périphérique de Yaoundé, Région du Centre, Cameroun (à 25 km du marché de Mokolo)',
  promoter: 'Awa Nkeng, entrepreneure agricole, diplômée en gestion des exploitations agricoles',
  startDate: new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().slice(0, 10),
  summary:
    "La ferme avicole Awa Farms & Co produira environ 11 280 poulets de chair commercialisables par an (6 bandes de 2 000 sujets, mortalité estimée à 6 %). Le besoin de financement total est estimé à 17,8 millions FCFA (6,0 millions d'investissements et 11,8 millions de fonds de roulement couvrant deux bandes), financé à hauteur de 7,8 millions en fonds propres et 10 millions en prêt bancaire sur 5 ans au taux de 12 %. Les prévisions font apparaître un chiffre d'affaires de première année d'environ 76,8 millions FCFA et un résultat net supérieur à 27 millions FCFA, avec un délai de récupération inférieur à un an d'exploitation complète. Ces chiffres sont des hypothèses à affiner lors de l'enquête de marché.",
  vision: 'Devenir une référence régionale de la volaille de chair locale, fraîche et traçable autour de Yaoundé.',
  mission:
    'Produire des poulets de chair de qualité à coût maîtrisé, en appliquant des bonnes pratiques d\'élevage respectueuses de la santé animale et de l\'environnement, et en garantissant un approvisionnement régulier aux clients.',
  values: 'Qualité, régularité, transparence, respect du bien-être animal, ancrage local.',
}

export const DEMO_ANALYSIS: AnalysisData = {
  swot: {
    strengths: [
      { id: 's1', label: 'Demande locale forte et régulière en viande de volaille autour de Yaoundé' },
      { id: 's2', label: 'Proximité du plus grand marché de consommation de la région du Centre' },
      { id: 's3', label: 'Porteuse de projet expérimentée en gestion d\'exploitations agricoles' },
      { id: 's4', label: 'Coût de revient compétitif grâce à un circuit d\'aliment négocié en gros' },
      { id: 's5', label: 'Revenu annexe possible grâce à la vente de fumier aux maraîchers' },
    ],
    weaknesses: [
      { id: 'w1', label: 'Dépendance aux provenderies pour l\'aliment (poste de coût n°1)' },
      { id: 'w2', label: 'Dépendance au réseau électrique et au carburant du groupe électrogène' },
      { id: 'w3', label: 'Trésorerie sensible en début d\'exploitation (2 bandes de fonds de roulement)' },
      { id: 'w4', label: 'Notoriété commerciale à construire face aux fermes déjà installées' },
    ],
    opportunities: [
      { id: 'o1', label: 'Croissance urbaine et hausse de la consommation de protéines animales' },
      { id: 'o2', label: 'Pics de demande récurrents (fêtes de fin d\'année, fêtes religieuses)' },
      { id: 'o3', label: 'Restaurants et hôtels en quête de fournisseurs locaux réguliers' },
      { id: 'o4', label: 'Possibilité de contrats cadres avec cantines et supermarchés' },
      { id: 'o5', label: 'Valorisation du fumier pour les cultures maraîchères voisines' },
    ],
    threats: [
      { id: 't1', label: 'Risque sanitaire : grippe aviaire et épizooties' },
      { id: 't2', label: 'Hausse du prix mondial des matières premières (maïs, tourteaux)' },
      { id: 't3', label: 'Concurrence du poulet congelé importé' },
      { id: 't4', label: 'Volatilité des prix de vente en périodes de forte offre' },
    ],
  },
  pestel: {
    politique:
      "Le gouvernement camerounais soutient l'agriculture via le Plan National de Développement Agricole et des programmes de subvention des intrants ; les importations de volailles congelées sont réglementées. À surveiller : évolution des taxes et exigences sanitaires à l'importation.",
    economique:
      "Inflation sur les intrants agricoles, volatilité du FCFA face au dollar (aliment importé), pouvoir d'achat urbain en croissance ; taux d'intérêt bancaire agricole usuel de 10 à 15 %. Hypothèses retenues : prêt à 12 %, inflation des charges de 2 %/an.",
    socioculturel:
      "Le poulet est la viande de fête par excellence et une source de protéines accessible ; préférence marquée pour le poulet vivant/local dans les ménages ; jeunesse urbaine attirée par la restauration rapide (grillades).",
    technologique:
      "Disponibilité croissante de poussins améliorés (souche chair), de provendes spécialisées et de vaccins ; outils de gestion d'élevage (suivi des bandes, alertes) et plateformes de commercialisation en ligne émergentes.",
    ecologique:
      "Gestion des déchets d'élevage (fumier valorisable), consommation d'eau maîtrisée via forage, besoin de traitement des cadavres (fosses), risque climatique sur la température du poulailler (ventilation naturelle + ventilation d'appoint).",
    legal:
      "Obligations d'immatriculation au RCCM et de déclaration fiscale, autorisation d'exploitation d'élevage auprès de la Délégation MINEPIA, respect des normes de biosécurité et d'hygiène (arrêtés ministériels), registre d'élevage tenu à jour.",
  },
  market: {
    demande:
      "La demande en poulet de chair autour de Yaoundé est soutenue toute l'année, avec des pics marqués en fin d'année et pendant les fêtes religieuses. Les acheteurs privilégient la fraîcheur et le poids vif de 2 à 2,5 kg. La demande des restaurants et hôtels est régulière et réclame des livraisons programmées. (Estimation à valider par enquête terrain auprès des commerçants des marchés Mokolo, Mvog-Ada et Mvog-Mbi.)",
    offre:
      "L'offre est constituée de trois catégories : (1) fermes industrielles et semi-industrielles situées en périphérie de la ville, (2) fermes de quartier de petite capacité (moins de 500 sujets), (3) poulet congelé importé vendu dans les surfaces de vente. L'offre locale reste inférieure à la demande en périodes de forte consommation, ce qui provoque des hausses de prix saisonnières.",
    segments:
      "Segment 1 – Ménages (achats à la ferme et dans les marchés) ; Segment 2 – Restaurants, bars-grills et hôtels (commandes hebdomadaires) ; Segment 3 – Grossistes et revendeuses des marchés (achats en lot) ; Segment 4 – Cantines et institutions (contrats cadres à développer).",
    tendances:
      "Montée en gamme vers le poulet local frais face au congelé ; intérêt croissant pour la traçabilité ; développement de la commande par téléphone et WhatsApp avec livraison ; sensibilité au prix en milieu rural, moins forte dans les quartiers résidentiels.",
    cible:
      "Cœur de cible : restaurants et hôtels de Yaoundé (commandes régulières de 30 à 100 sujets par semaine) et grossistes des marchés. Cible secondaire : ménages des quartiers résidentiels proches de la ferme (vente à la ferme le week-end).",
    zones:
      "Zone de chalandise principale : Yaoundé et sa périphérie (25 km autour de la ferme). Zone secondaire : axes routiers vers Obala et Mbalmayo pour la vente en gros.",
    conclusion:
      "Le marché présente une demande supérieure à l'offre locale sur les périodes de pointe et un positionnement « poulet local frais livré » différenciant. Les hypothèses commerciales du projet (prix de 3 000 FCFA/kg vif, absorption de 6 bandes par an) devront être confirmées par une enquête de terrain de 4 semaines et des pré-commandes auprès de 10 restaurants avant le lancement.",
  },
  competitors: [
    {
      id: 'c1',
      name: 'Fermes semi-industrielles périurbaines',
      type: 'Concurrent direct',
      strengths: 'Capacité importante, prix négociés avec les provenderies, notoriété établie',
      weaknesses: 'Prix de vente parfois moins flexibles, rarement de livraison aux restaurants',
      positioning: 'Se différencier par le service de livraison programmée et la régularité des calibres',
    },
    {
      id: 'c2',
      name: 'Fermes de quartier (< 500 sujets)',
      type: 'Concurrent direct',
      strengths: 'Très proches des clients, vente au détail flexible',
      weaknesses: 'Ruptures fréquentes d\'approvisionnement, poids et qualité irréguliers',
      positioning: 'Garantir un approvisionnement continu grâce au planning des 6 bandes',
    },
    {
      id: 'c3',
      name: 'Poulet congelé importé',
      type: 'Concurrent indirect',
      strengths: 'Prix attractif en gros conditionnement, disponibilité permanente',
      weaknesses: 'Perçu comme moins frais et moins savoureux, chaîne du froid incertaine',
      positioning: 'Mettre en avant la fraîcheur, la qualité gustative et l\'origine locale',
    },
  ],
  needs: [
    { id: 'n1', label: 'Poulet de chair frais de 2 à 2,5 kg, disponible toute l\'année', target: 'Ménages et restaurants', frequency: 'Hebdomadaire' },
    { id: 'n2', label: 'Livraisons programmées et régulières en quantité', target: 'Restaurants et hôtels', frequency: 'Hebdomadaire' },
    { id: 'n3', label: 'Lots en gros à prix compétitif pour la revente', target: 'Grossistes des marchés', frequency: 'Par bande' },
    { id: 'n4', label: 'Contrats cadres de fourniture pour cantines', target: 'Institutions et cantines', frequency: 'Mensuelle' },
    { id: 'n5', label: 'Fumier organique traité pour les cultures', target: 'Maraîchers voisins', frequency: 'Après chaque bande' },
  ],
  risks: [
    { id: 'r1', label: 'Épizootie (grippe aviaire, Newcastle)', category: 'Sanitaire', probability: 2, impact: 5, mitigation: 'Plan de vaccination strict avec le vétérinaire, biosécurité (pediluve, tenues), assurance du cheptel si disponible, quarantaine des nouveaux sujets' },
    { id: 'r2', label: 'Hausse du prix de l\'aliment', category: 'Économique', probability: 4, impact: 4, mitigation: 'Contrat d\'approvisionnement avec deux provenderies, achat groupé, ajustement annuel des prix de vente, réserve de trésorerie' },
    { id: 'r3', label: 'Mortalité supérieure aux prévisions', category: 'Technique', probability: 3, impact: 3, mitigation: 'Formation de l\'ouvrier, suivi vétérinaire hebdomadaire, registre de bande, protocole de démarrage (brooding) renforcé' },
    { id: 'r4', label: 'Écoulement difficile d\'une bande', category: 'Commercial', probability: 3, impact: 4, mitigation: 'Pré-commandes auprès de restaurants et grossistes avant chaque fin de bande, calendrier de production évitant les périodes creuses, flexibilité du calendrier des bandes' },
    { id: 'r5', label: 'Coupures d\'électricité prolongées', category: 'Technique', probability: 4, impact: 2, mitigation: 'Groupe électrogène de secours, abreuvoirs automatiques à réservoir, ventilation naturelle renforcée du bâtiment' },
    { id: 'r6', label: 'Retard de décaissement du prêt', category: 'Financier', probability: 2, impact: 4, mitigation: 'Phasage du chantier adaptable, apport personnel sécurisant la première bande, recherche d\'un crédit de campagne en solution de repli' },
  ],
  feasibility: {
    technique:
      "Favorable : le bâtiment (200 m²), les équipements standards et les souches disponibles localement permettent un élevage maîtrisé. L'expérience de la porteuse et l'encadrement vétérinaire externe sécurisent la conduite d'élevage.",
    economique:
      "Favorable : la marge sur coûts variables est supérieure à 50 % dans les hypothèses retenues et le seuil de rentabilité est atteint dès la première année d'exploitation. Sensibilité forte au prix de l'aliment : chaque hausse de 10 % de l'aliment réduit le résultat d'environ 10 %.",
    juridique:
      "Favorable : les démarches (RCCM, autorisation MINEPIA, registre d'élevage) sont identifiées et budgétées dans les frais d'établissement (350 000 FCFA).",
    organisationnelle:
      "Favorable : équipe minimale viable (gérante à plein temps + ouvrier gardien) complétée par des prestataires externes (vétérinaire, manœuvres ponctuels pour les vidanges de bande).",
    commerciale:
      "À consolider : le réseau de grossistes et restaurants doit être formalisé avant le lancement (contrats ou lettres d'intention). Prévoir 4 semaines d'enquête terrain et un objectif de 10 pré-commandes.",
    verdict: 'FAVORABLE',
  },
  synthesis:
    "Le projet de ferme avicole de 2 000 poulets par bande présente un modèle économiquement attractif (marge sur coûts variables > 50 %, seuil de rentabilité atteint en première année) sur un marché local structurellement déficitaire en poulet frais. Les principaux points de vigilance sont la maîtrise du poste aliment (plus de la moitié des charges variables), le risque sanitaire et la structuration des débouchés. Le montage financier proposé (43 % de fonds propres) limite le risque bancaire et la trésorerie de deux bandes couvre le cycle d'exploitation.",
  recommendations:
    "1. Réaliser l'enquête de marché terrain (4 semaines) et sécuriser 10 lettres d'intention de restaurants avant le lancement. 2. Négocier un contrat d'approvisionnement en aliment avec deux provenderies. 3. Formaliser le plan de biosécurité avec le vétérinaire dès la construction. 4. Échelonner les bandes pour lisser la trésorerie et éviter les périodes creuses. 5. Mettre en place un registre de bande et un tableau de bord de suivi (mortalité, indice de consommation, coût de revient par poulet) dès la première bande.",
}

export const DEMO_FINANCE: FinanceData = {
  investments: [
    { id: 'i1', label: 'Aménagement du terrain & construction du poulailler (200 m²)', category: 'BATIMENT', amount: 3000000, depreciable: true, depYears: 10 },
    { id: 'i2', label: 'Équipements d\'élevage (mangeoires, abreuvoirs, éleveuses)', category: 'EQUIPEMENT', amount: 900000, depreciable: true, depYears: 5 },
    { id: 'i3', label: 'Forage et réservoir d\'eau', category: 'EQUIPEMENT', amount: 700000, depreciable: true, depYears: 10 },
    { id: 'i4', label: 'Groupe électrogène de secours', category: 'EQUIPEMENT', amount: 500000, depreciable: true, depYears: 5 },
    { id: 'i5', label: 'Petit matériel (balance, pulvérisateur, pediluves)', category: 'MATERIEL', amount: 250000, depreciable: true, depYears: 5 },
    { id: 'i6', label: 'Installation électrique du bâtiment', category: 'EQUIPEMENT', amount: 300000, depreciable: true, depYears: 5 },
    { id: 'i7', label: 'Frais d\'établissement (RCCM, autorisations, notaire)', category: 'FRAIS_ETABLISSEMENT', amount: 350000, depreciable: true, depYears: 2 },
  ],
  workingCapital: 11828000, // ≈ 2 bandes de charges variables d'exploitation
  financing: [
    { id: 'f1', source: 'Apport personnel (épargne + vente terrain)', type: 'EQUITY', amount: 7828000, rate: 0, termYears: 0 },
    { id: 'f2', source: 'Prêt bancaire agricole', type: 'LOAN', amount: 10000000, rate: 12, termYears: 5 },
  ],
  assumptions: {
    horizonYears: 5,
    discountRate: 12,
    taxRate: 25,
    products: [
      {
        id: 'p1',
        label: 'Vente de poulets de chair (2,2 kg vif, 11 280 sujets vendus/an)',
        unit: 'poulet',
        unitPrice: 6600, // ≈ 3 000 FCFA/kg vif × 2,2 kg
        qty: 11280, // 6 bandes × 2 000 sujets × 94 % de survie
        volumeGrowth: 0,
        priceGrowth: 2,
      },
      {
        id: 'p2',
        label: 'Vente de fumier en sacs (valorisation annexe)',
        unit: 'sac de 50 kg',
        unitPrice: 1000,
        qty: 2400, // ≈ 400 sacs par bande
        volumeGrowth: 0,
        priceGrowth: 0,
      },
    ],
    variableCosts: [
      { id: 'v1', label: 'Achat de poussins (2 000 par bande, 6 bandes)', mode: 'QTY', unitPrice: 500, qty: 12000, pct: 0, annualAmount: 0, growth: 2 },
      { id: 'v2', label: 'Aliment volaille (≈ 50,4 tonnes/an : 4,2 kg par sujet démarré)', mode: 'QTY', unitPrice: 430000, qty: 50.4, pct: 0, annualAmount: 0, growth: 2 },
      { id: 'v3', label: 'Santé animale : vaccins, vitamines, désinfectants', mode: 'QTY', unitPrice: 125, qty: 12000, pct: 0, annualAmount: 0, growth: 2 },
      { id: 'v4', label: 'Transport & commercialisation (par sujet vendu)', mode: 'QTY', unitPrice: 400, qty: 11280, pct: 0, annualAmount: 0, growth: 2 },
      { id: 'v5', label: 'Litière, chauffage et énergie par bande', mode: 'QTY', unitPrice: 300, qty: 6000, pct: 0, annualAmount: 0, growth: 2 },
    ],
    fixedCosts: [
      { id: 'c1', label: 'Eau & électricité (factures annuelles)', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 240000, growth: 2 },
      { id: 'c2', label: 'Assurance (bâtiment & responsabilité civile)', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 300000, growth: 0 },
      { id: 'c3', label: 'Entretien & maintenance des équipements', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 400000, growth: 2 },
      { id: 'c4', label: 'Divers & imprévus', mode: 'QTY', unitPrice: 0, qty: 0, pct: 0, annualAmount: 200000, growth: 2 },
    ],
    staff: [
      { id: 'st1', role: 'Gérante (porteuse de projet)', count: 1, monthlySalary: 100000, annualGrowth: 3 },
      { id: 'st2', role: 'Ouvrier gardien d\'élevage', count: 1, monthlySalary: 70000, annualGrowth: 3 },
    ],
  },
}

export const DEMO_DOCPREFS: DocPrefs = {
  coverTitle: 'Dossier de projet – Ferme avicole moderne de 2 000 poulets de chair',
  coverSubtitle: 'De l\'idée au dossier finançable',
  author: 'Awa Nkeng',
  organization: 'Awa Farms & Co',
  includeCover: true,
  includeToc: true,
  headerText: 'Awa Farms & Co – Ferme avicole moderne',
  footerText: 'Document généré avec GESCOM PROJECT',
}

export interface DemoTask {
  phase: string
  title: string
  responsible: string
  startDate: string
  endDate: string
  status: string
  progress: number
}

function d(offsetDays: number): string {
  return new Date(Date.now() + offsetDays * 24 * 3600 * 1000).toISOString().slice(0, 10)
}

export const DEMO_TASKS: DemoTask[] = [
  // Phase 1 – Montage du projet
  { phase: 'Phase 1 – Montage du projet', title: 'Finalisation de l\'étude de marché terrain (enquête 4 semaines)', responsible: 'Awa Nkeng', startDate: d(-30), endDate: d(0), status: 'DONE', progress: 100 },
  { phase: 'Phase 1 – Montage du projet', title: 'Dépôt du dossier bancaire et décaissement du prêt', responsible: 'Awa Nkeng / Banque', startDate: d(-10), endDate: d(15), status: 'IN_PROGRESS', progress: 40 },
  { phase: 'Phase 1 – Montage du projet', title: 'Immatriculation RCCM & autorisation d\'exploitation (MINEPIA)', responsible: 'Conseiller juridique', startDate: d(0), endDate: d(25), status: 'IN_PROGRESS', progress: 20 },
  { phase: 'Phase 1 – Montage du projet', title: 'Sécurisation du foncier et contrat d\'aménagement', responsible: 'Awa Nkeng', startDate: d(-20), endDate: d(5), status: 'DONE', progress: 100 },
  // Phase 2 – Construction & équipement
  { phase: 'Phase 2 – Construction & équipement', title: 'Construction du poulailler de 200 m²', responsible: 'Entreprise BTP locale', startDate: d(15), endDate: d(60), status: 'TODO', progress: 0 },
  { phase: 'Phase 2 – Construction & équipement', title: 'Réalisation du forage et du réservoir d\'eau', responsible: 'Entreprise forage', startDate: d(25), endDate: d(45), status: 'TODO', progress: 0 },
  { phase: 'Phase 2 – Construction & équipement', title: 'Installation électrique et raccordement du groupe électrogène', responsible: 'Électricien', startDate: d(50), endDate: d(65), status: 'TODO', progress: 0 },
  { phase: 'Phase 2 – Construction & équipement', title: 'Achat et installation des équipements d\'élevage', responsible: 'Awa Nkeng', startDate: d(55), endDate: d(70), status: 'TODO', progress: 0 },
  // Phase 3 – Préparation du lancement
  { phase: 'Phase 3 – Préparation du lancement', title: 'Formation de l\'ouvrier aux bonnes pratiques d\'élevage', responsible: 'Vétérinaire conseil', startDate: d(60), endDate: d(70), status: 'TODO', progress: 0 },
  { phase: 'Phase 3 – Préparation du lancement', title: 'Signature de 10 lettres d\'intention (restaurants & grossistes)', responsible: 'Awa Nkeng', startDate: d(30), endDate: d(60), status: 'IN_PROGRESS', progress: 30 },
  { phase: 'Phase 3 – Préparation du lancement', title: 'Première commande de poussins et d\'aliment (bande 1)', responsible: 'Awa Nkeng', startDate: d(68), endDate: d(74), status: 'TODO', progress: 0 },
  // Phase 4 – Exploitation (année 1)
  { phase: 'Phase 4 – Exploitation (année 1)', title: 'Bande 1 : démarrage, suivi et commercialisation', responsible: 'Équipe ferme', startDate: d(75), endDate: d(135), status: 'TODO', progress: 0 },
  { phase: 'Phase 4 – Exploitation (année 1)', title: 'Bande 2 : production et commercialisation', responsible: 'Équipe ferme', startDate: d(136), endDate: d(196), status: 'TODO', progress: 0 },
  { phase: 'Phase 4 – Exploitation (année 1)', title: 'Bande 3 : production et commercialisation', responsible: 'Équipe ferme', startDate: d(197), endDate: d(257), status: 'TODO', progress: 0 },
  { phase: 'Phase 4 – Exploitation (année 1)', title: 'Bilan de fin d\'année 1 et révision des hypothèses', responsible: 'Awa Nkeng', startDate: d(258), endDate: d(270), status: 'TODO', progress: 0 },
]
