// GESCOM PROJECT – Formatage (devise, nombres, dates)
//
// Convention monétaire demandée : le POINT comme séparateur de milliers
// (6.500.000 FCFA), la virgule conservée pour les décimales (12,5 %).
// Formatage déterministe (indépendant de la locale du navigateur/serveur).

export function groupNumber(n: number, decimals = 0): string {
  if (!Number.isFinite(n)) return '—'
  let fixed = n.toFixed(decimals)
  // Évite « -0 » quand la valeur est négative mais s'arrondit à zéro
  if (parseFloat(fixed) === 0) fixed = (0).toFixed(decimals)
  const [int, dec] = fixed.split('.')
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.')
  return dec ? `${grouped},${dec}` : grouped
}

export function fmtNumber(n: number, decimals = 0): string {
  if (!Number.isFinite(n)) return '—'
  return groupNumber(n, decimals)
}

export function fmtCurrency(n: number, currency = 'XAF'): string {
  if (!Number.isFinite(n)) return '—'
  const symbol = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'CAD' ? '$' : currency === 'CHF' ? 'CHF' : currency === 'MAD' ? 'MAD' : 'FCFA'
  return `${groupNumber(Math.round(n))} ${symbol}`
}

export function fmtCompact(n: number): string {
  if (!Number.isFinite(n)) return '—'
  const abs = Math.abs(n)
  if (abs >= 1_000_000_000) return `${groupNumber(n / 1_000_000_000, 1)} Md`
  if (abs >= 1_000_000) return `${groupNumber(n / 1_000_000, 1)} M`
  if (abs >= 1_000) return `${groupNumber(n / 1_000)} k`
  return groupNumber(n)
}

export function fmtPct(n: number, decimals = 1): string {
  if (!Number.isFinite(n)) return '—'
  return `${groupNumber(n, decimals)} %`
}

export function fmtDate(iso: string | Date | null | undefined): string {
  if (!iso) return '—'
  const d = typeof iso === 'string' ? new Date(iso) : iso
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

export function fmtDateTime(iso: string | Date | null | undefined): string {
  if (!iso) return '—'
  const d = typeof iso === 'string' ? new Date(iso) : iso
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

export function fmtBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`
  if (bytes < 1024 * 1024) return `${groupNumber(bytes / 1024, 1)} Ko`
  return `${groupNumber(bytes / (1024 * 1024), 1)} Mo`
}

export function slugify(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toLowerCase()
    .slice(0, 60) || 'projet'
}
