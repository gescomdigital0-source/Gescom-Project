// GESCOM PROJECT – Application automatique du statut selon la validation
//
// Règles demandées (cahier des charges) :
//  1. Un projet VALIDÉ par Gescom Project (zéro anomalie, zéro correction)
//     est automatiquement confirmé « Terminé » — sans action de l'utilisateur.
//  2. S'il reste UNE SEULE anomalie ou correction sur le projet (bloquante,
//     majeure ou même simple avertissement), le projet n'est NI validé NI
//     terminé : un projet actuellement « Terminé » repasse automatiquement
//     « En cours » dès qu'une anomalie réapparaît (ex. modification qui
//     dégrade le dossier).
//
// Périmètre volontairement restreint :
//  • « Brouillon » → reste brouillon (l'utilisateur doit d'abord démarrer le
//    projet — règle confirmée par le cahier des charges) ;
//  • « Archivé »  → reste archivé (état de classement choisi par l'utilisateur).
import { db } from '@/lib/db'
import { logActivity } from '@/lib/api-helpers'
import type { ValidationReport } from '@/lib/validation'

export interface AutoStatusResult {
  changed: boolean
  status: string // statut réel du projet après application de la règle
  promoted: boolean // passe « Terminé » automatiquement (validation réussie)
  demoted: boolean // retire « Terminé » (anomalie détectée sur un projet terminé)
}

export async function applyAutoStatus(
  userId: string,
  projectId: string,
  currentStatus: string,
  report: ValidationReport,
): Promise<AutoStatusResult> {
  const unchanged: AutoStatusResult = { changed: false, status: currentStatus, promoted: false, demoted: false }

  try {
    if (report.status === 'VALIDE') {
      // Règle 1 : validation réussie → « Terminé » automatique.
      if (currentStatus === 'COMPLETED' || currentStatus === 'DRAFT' || currentStatus === 'ARCHIVED') {
        return unchanged
      }
      await db.project.update({ where: { id: projectId }, data: { status: 'COMPLETED' } })
      await logActivity(
        userId,
        'VALIDATION',
        'Projet validé par Gescom Project (aucune anomalie) : statut automatiquement confirmé « Terminé ».',
        projectId,
      )
      return { changed: true, status: 'COMPLETED', promoted: true, demoted: false }
    }

    // Règle 2 : anomalies présentes → le projet ne doit PAS rester « Terminé ».
    if (currentStatus === 'COMPLETED') {
      await db.project.update({ where: { id: projectId }, data: { status: 'ONGOING' } })
      await logActivity(
        userId,
        'VALIDATION',
        'Anomalie(s) détectée(s) sur un projet terminé : le projet n\'est plus validé et repasse automatiquement « En cours ».',
        projectId,
      )
      return { changed: true, status: 'ONGOING', promoted: false, demoted: true }
    }

    return unchanged
  } catch (err) {
    // L'application automatique du statut ne doit jamais faire échouer la requête appelante.
    console.error('[validation-auto] Application automatique du statut impossible :', err)
    return unchanged
  }
}
