// GESCOM PROJECT – Générateur intelligent d'amélioration des idées
// Registre des rubriques du Business Plan que l'IA peut analyser et enrichir.
// Ce fichier est partagé client/serveur : il définit, pour chaque rubrique,
//   • label       : libellé français affiché à l'utilisateur ;
//   • kind        : forme de la proposition renvoyée par l'IA ;
//   • instruction : consigne experte injectée dans le prompt (qualité métier) ;
//   • addMode     : true = la proposition complète le contenu existant
//                   (l'utilisateur choisit « compléter » ou « remplacer ») ;
//                   false/absent = la proposition remplace le champ
//                   (jamais sans validation explicite dans le dialogue).

export type AiPropositionKind =
  | 'text' // proposition : texte (remplace le champ)
  | 'list' // proposition : string[] (une entrée par ligne)
  | 'needs' // { label, target, frequency }[]
  | 'competitors' // { name, type, strengths, weaknesses, positioning }[]
  | 'risks' // { label, category, probability, impact, mitigation }[]
  | 'investments' // { label, category, amount }[]
  | 'financing' // { source, type, amount, rate, termYears }[]
  | 'products' // { label, unit, unitPrice, qty, volumeGrowth, priceGrowth }[]
  | 'tasks' // { phase, title }[]

export interface AiTargetDef {
  label: string
  kind: AiPropositionKind
  instruction: string
  addMode?: boolean
}

export const AI_TARGETS: Record<string, AiTargetDef> = {
  // ------------------------------------------------------------------ Identité
  idea: {
    label: 'Idée du projet',
    kind: 'text',
    instruction:
      'Formule une idée de projet complète et convaincante : quoi (produit/service), pour qui (clients cibles), où (zone géographique), à quel ordre de grandeur (volume de production ou capacité) et avec quelle valeur distinctive. De une à trois phrases denses, sans généralités ni formules creuses.',
  },
  description: {
    label: 'Description du projet',
    kind: 'text',
    instruction:
      'Rédige la présentation générale du projet : activité, produits/services proposés, mode de fonctionnement (process, approvisionnement, production, vente), clients visés, modèle de revenus et points de différenciation. Deux à quatre paragraphes courts et concrets.',
  },
  objectives: {
    label: 'Objectifs du projet',
    kind: 'list',
    addMode: true,
    instruction:
      'Propose des objectifs SMART (spécifiques, mesurables, atteignables, réalistes, temporellement définis), couvrant la production, le commercial, la finance et l\'organisation. Une phrase par objectif, avec un horizon temporel (ex. « d\'ici 12 mois »). Si l\'utilisateur fournit des chiffres dans le contexte, réutilise-les ; n\'en invente jamais.',
  },

  // ------------------------------------------------------------------ Aperçu
  'overview.summary': {
    label: 'Résumé exécutif',
    kind: 'text',
    instruction:
      'Rédige un résumé exécutif percutant de 5 à 8 phrases : activité, marché visé, avantage concurrentiel, besoin de financement et affectation, résultats attendus. N\'utilise des chiffres que s\'ils figurent dans le contexte du projet ; sinon reste qualitatif.',
  },
  'overview.vision': {
    label: 'Vision',
    kind: 'text',
    instruction:
      'Formule une vision inspirante mais concrète : où l\'entreprise veut être dans 5 ans (position, taille, rayonnement). Une seule phrase mémorable.',
  },
  'overview.mission': {
    label: 'Mission',
    kind: 'text',
    instruction:
      'Formule la mission : quelle valeur l\'entreprise crée, pour qui, et comment. Une à deux phrases précises.',
  },

  // ------------------------------------------------------------------ SWOT
  'swot.strengths': {
    label: 'Forces (SWOT)',
    kind: 'list',
    addMode: true,
    instruction:
      'Propose des forces internes réalistes pour ce projet dans ce contexte : maîtrise technique, coûts, localisation, réseau, qualité, disponibilité des intrants… Chaque item : une phrase courte et argumentée, jamais une évidence creuse (« bonne motivation » sans justification).',
  },
  'swot.weaknesses': {
    label: 'Faiblesses (SWOT)',
    kind: 'list',
    addMode: true,
    instruction:
      'Propose des faiblesses internes honnêtes et utiles au pilotage : dépendances, capacité limitée, trésorerie, expérience commerciale, organisation… Une phrase courte par item. Des faiblesses réalistes rendent le dossier crédible.',
  },
  'swot.opportunities': {
    label: 'Opportunités (SWOT)',
    kind: 'list',
    addMode: true,
    instruction:
      'Propose des opportunités externes crédibles pour ce secteur dans ce pays/région : dynamique de la demande, urbanisation, politiques publiques, tendances de consommation, produits importés substituables, partenariats possibles… Sans chiffrage inventé.',
  },
  'swot.threats': {
    label: 'Menaces (SWOT)',
    kind: 'list',
    addMode: true,
    instruction:
      'Propose des menaces externes plausibles : concurrence informelle, volatilité des prix des intrants, saisonnalité, défaillances d\'approvisionnement ou d\'énergie, changement réglementaire, climat… Une phrase courte par item.',
  },

  // ------------------------------------------------------------------ PESTEL
  'pestel.politique': {
    label: 'PESTEL – Politique',
    kind: 'text',
    instruction:
      'Analyse le facteur politique pertinent pour ce projet dans ce pays : stabilité, priorités gouvernementales du secteur, programmes publics, relations avec les autorités locales. Indique les implications opérationnelles concrètes pour l\'entreprise. 3 à 6 phrases.',
  },
  'pestel.economique': {
    label: 'PESTEL – Économique',
    kind: 'text',
    instruction:
      'Analyse le facteur économique : croissance, inflation, pouvoir d\'achat, accès au crédit, coût des intrants, taux de change le cas échéant. Reste qualitatif sauf si des chiffres figurent dans le contexte ; signale dans « hypothese » les données à vérifier. 3 à 6 phrases.',
  },
  'pestel.socioculturel': {
    label: 'PESTEL – Socioculturel',
    kind: 'text',
    instruction:
      'Analyse le facteur socioculturel : habitudes de consommation, démographie urbaine, modes de vie, préférences locales, rôle des communautés. Implications concrètes pour l\'offre et la communication. 3 à 6 phrases.',
  },
  'pestel.technologique': {
    label: 'PESTEL – Technologique',
    kind: 'text',
    instruction:
      'Analyse le facteur technologique : technologies disponibles et accessibles (mobile money, froid, irrigation, mechanisation, digitalisation), pénétration d\'internet, écart technologique à combler. 3 à 6 phrases.',
  },
  'pestel.ecologique': {
    label: 'PESTEL – Écologique',
    kind: 'text',
    instruction:
      'Analyse le facteur écologique : climat, saisonnalité, ressources (eau, sol, énergie), gestion des déchets, exigences environnementales. Implications pour la production et la résilience. 3 à 6 phrases.',
  },
  'pestel.legal': {
    label: 'PESTEL – Légal',
    kind: 'text',
    instruction:
      'Analyse le facteur légal : formalités de création, registres et autorisations du secteur, normes (sanitaires, qualité, étiquetage), fiscalité applicable, droit du travail. Signale dans « hypothese » les vérifications réglementaires à faire auprès des administrations compétentes. 3 à 6 phrases.',
  },

  // ------------------------------------------------------------------ Marché
  'market.demande': {
    label: 'Marché – Analyse de la demande',
    kind: 'text',
    instruction:
      'Structure l\'analyse de la demande : qui achète (ménages, restaurants, commerçants, institutions…), quels besoins, facteurs de décision (prix, qualité, régularité, proximité), saisonnalité. Aucune statistique inventée : liste dans « hypothese » les données à collecter par enquête terrain ou auprès des institutions.',
  },
  'market.offre': {
    label: 'Marché – Analyse de l\'offre',
    kind: 'text',
    instruction:
      'Analyse l\'offre existante : typologie des acteurs (formels, informels, importations), niveaux de qualité et de prix observés qualitativement, limites de l\'offre actuelle (régularité, quantité, qualité) que le projet peut exploiter.',
  },
  'market.segments': {
    label: 'Marché – Segments de clientèle',
    kind: 'text',
    instruction:
      'Propose 3 à 5 segments de clientèle opérationnels (critères : usage, pouvoir d\'achat, canal d\'achat, localisation). Pour chaque segment : besoin principal, exigence clé, mode d\'accès. Rends-les spécifiques au projet, pas des catégories génériques.',
  },
  'market.tendances': {
    label: 'Marché – Tendances',
    kind: 'text',
    instruction:
      'Identifie les tendances plausibles du marché (consommation, distribution, réglementation, numérisation) et leurs implications concrètes pour l\'offre du projet. Ce qui n\'est pas vérifiable doit figurer dans « hypothese ».',
  },
  'market.cible': {
    label: 'Marché – Clientèle cible',
    kind: 'text',
    instruction:
      'Définis la clientèle cible prioritaire : profil précis, localisation, besoin servi, fréquence et volume d\'achat plausibles, canal d\'accès privilégié, et justification de ce choix au regard du projet.',
  },
  'market.zones': {
    label: 'Marché – Zone de chalandise',
    kind: 'text',
    instruction:
      'Définis la zone de chalandise : zone primaire et secondaire, justification logistique (distances, transport, chaîne du froid, délais), points de vente et canaux (marchés, boutiques, grossistes, contrats B2B, livraison).',
  },
  'market.conclusion': {
    label: 'Marché – Conclusion',
    kind: 'text',
    instruction:
      'Rédige la conclusion de l\'étude de marché : attrait du marché, conditions de réussite, précautions à prendre. 3 à 5 phrases fermes et professionnelles.',
  },

  // ------------------------------------------------------- Besoins & concurrence
  needs: {
    label: 'Besoins des clients',
    kind: 'needs',
    addMode: true,
    instruction:
      'Propose des besoins typiques des clients cibles de ce projet : besoin (label court), cible concernée, fréquence ou usage. Reste dans le plausible du secteur et du contexte.',
  },
  competitors: {
    label: 'Concurrents',
    kind: 'competitors',
    addMode: true,
    instruction:
      'Propose des concurrents typiques à analyser pour ce projet : directs, indirects, substituts. Pour chacun : forces et faiblesses habituelles de ce type d\'acteur, et un positionnement possible pour s\'en différencier. Précise dans « hypothese » que ces acteurs sont à confirmer par une visite terrain.',
  },

  // ------------------------------------------------------------------ Risques
  risks: {
    label: 'Risques',
    kind: 'risks',
    addMode: true,
    instruction:
      'Propose des risques spécifiques au secteur et au contexte : approvisionnement, sanitaire, climatique, commercial, financier, réglementaire, sécurité. Probabilité et impact sur 1 à 5 cohérentes entre elles, et mesures de mitigation concrètes, en privilégiant les parades peu coûteuses. Une mesure par risque.',
  },

  // ------------------------------------------------------------------ Faisabilité
  'feasibility.technique': {
    label: 'Faisabilité technique',
    kind: 'text',
    instruction:
      'Évalue la faisabilité technique : disponibilité des intrants et équipements, compétences requises, capacité de production, points de vigilance opérationnels. Factuel ; ce qui n\'est pas connu va dans « hypothese ».',
  },
  'feasibility.economique': {
    label: 'Faisabilité économique',
    kind: 'text',
    instruction:
      'Évalue la faisabilité économique : structure de coûts, seuil de rentabilité qualitatif, dépendance aux prix, marge envisageable. Utilise uniquement les chiffres du contexte ; le reste va dans « hypothese ».',
  },
  'feasibility.juridique': {
    label: 'Faisabilité juridique',
    kind: 'text',
    instruction:
      'Évalue la faisabilité juridique : forme juridique adaptée, autorisations et enregistrements nécessaires, normes à respecter. Signale dans « hypothese » les démarches à confirmer auprès des administrations.',
  },
  'feasibility.organisationnelle': {
    label: 'Faisabilité organisationnelle',
    kind: 'text',
    instruction:
      'Évalue la faisabilité organisationnelle : équipe requise, répartition des rôles, gestion quotidienne, partenaires clés, capacité de l\'entrepreneur à piloter. Reste encourageant mais réaliste.',
  },
  'feasibility.commerciale': {
    label: 'Faisabilité commerciale',
    kind: 'text',
    instruction:
      'Évalue la faisabilité commerciale : accès aux clients, concurrence, canaux de vente, argumentaire, efforts marketing nécessaires. Concret et adapté au terrain.',
  },

  // ------------------------------------------------------------------ Synthèse
  synthesis: {
    label: 'Synthèse stratégique',
    kind: 'text',
    instruction:
      'Rédige une synthèse stratégique cohérente avec le reste du dossier (5 à 8 phrases) : positionnement, atouts, risques majeurs et parades, conditions de rentabilité. Reprends les informations du contexte sans en ajouter d\'inventées.',
  },
  recommendations: {
    label: 'Recommandations',
    kind: 'text',
    instruction:
      'Propose des recommandations opérationnelles priorisées : démarche qualité, sécurisation des approvisionnements, structuration commerciale, suivi financier, formalisation progressive. Une recommandation par ligne, précédée d\'un tiret.',
  },

  // ------------------------------------------------------------------ Finance
  'finance.investments': {
    label: 'Programme d\'investissement',
    kind: 'investments',
    addMode: true,
    instruction:
      'Propose la structure typique du programme d\'investissement pour ce projet : postes répartis entre terrain, bâtiment, équipements, matériel et frais d\'établissement. Les montants sont INDICATIFS et DOIVENT tous être repris dans « hypothese » comme valeurs à ajuster aux prix locaux.',
  },
  'finance.financing': {
    label: 'Plan de financement',
    kind: 'financing',
    addMode: true,
    instruction:
      'Propose un plan de financement équilibré : fonds propres (apport), emprunt bancaire (taux et durée plausibles pour le contexte), éventuellement subvention. Tous les montants, taux et durées sont des hypothèses à confirmer auprès des institutions financières — dis-le dans « hypothese ».',
  },
  'finance.products': {
    label: 'Prévision des ventes',
    kind: 'products',
    addMode: true,
    instruction:
      'Propose des lignes de produits/services pour la prévision des ventes : désignation, unité de vente, prix unitaire et quantité annuelle indicative pour l\'année 1, croissance annuelle plausible des volumes et des prix. Tous les chiffres sont des hypothèses de travail à ajuster — liste-les dans « hypothese ».',
  },

  // ------------------------------------------------------------------ Plan d'action
  tasks: {
    label: 'Plan d\'action',
    kind: 'tasks',
    addMode: true,
    instruction:
      'Propose des activités du plan d\'action, organisées par phase (Études & autorisations, Installation & équipement, Production, Commercialisation, Gestion & suivi). Titres courts, actionnables, commençant par un verbe à l\'infinitif. 8 à 15 activités couvrant le démarrage.',
  },
}

export type AiTargetKey = keyof typeof AI_TARGETS

// Test rapide de validité d'une clé.
export function isAiTarget(key: string): key is AiTargetKey {
  return Object.prototype.hasOwnProperty.call(AI_TARGETS, key)
}
