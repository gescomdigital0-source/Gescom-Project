// GESCOM PROJECT – Encaissement Mobile Money via FedaPay
//
// FedaPay (https://fedapay.com) est un agrégateur de paiement basé au Togo qui
// couvre MTN MoMo, Moov Money, Orange Money, Wave… dans la zone UEMOA/CEMAC.
//
// Variables d'environnement (fichier .env.local) :
//   FEDAPAY_SECRET_KEY   clé secrète API (sb_sk_… en sandbox, sk_live_… en prod)
//   FEDAPAY_MODE         "sandbox" (défaut) | "live"
//   FEDAPAY_BASE_URL     surcharge de l'URL d'API (tests d'intégration)
//   FEDAPAY_CURRENCY     devise d'encaissement, XOF (défaut) ou XAF — 1 FCFA
//   APP_URL              URL publique de la plateforme (retours navigateur)
//
// Flux : création de transaction API → lien de paiement (page FedaPay où le
// client choisit son opérateur Mobile Money) → confirmation par webhook
// re-vérifiée côté API (source de vérité) → activation du plan Premium.

const SANDBOX_BASE = 'https://sandbox-api.fedapay.com/v1'
const LIVE_BASE = 'https://api.fedapay.com/v1'

export function fedapayBaseUrl(): string {
  const override = process.env.FEDAPAY_BASE_URL
  if (override) return override.replace(/\/$/, '')
  return process.env.FEDAPAY_MODE === 'live' ? LIVE_BASE : SANDBOX_BASE
}

export function fedapaySecretKey(): string | null {
  const key = process.env.FEDAPAY_SECRET_KEY
  return key && key.trim() ? key.trim() : null
}

// Les paiements réels sont disponibles dès que la clé secrète est configurée.
export function isPaymentsConfigured(): boolean {
  return fedapaySecretKey() !== null
}

export function paymentCurrency(): string {
  return (process.env.FEDAPAY_CURRENCY || 'XOF').toUpperCase()
}

export function appBaseUrl(): string {
  return (process.env.APP_URL || 'http://localhost:3000').replace(/\/$/, '')
}

interface FedaPayTransaction {
  id: number
  reference?: string
  status?: string
  amount?: number
  description?: string
  custom_metadata?: Record<string, unknown>
}

// Les réponses FedaPay v1 enveloppent parfois l'objet sous « v1/transaction »
// ou « v1/token » selon la version ; on débrouille les trois formats.
function unwrap<T>(body: unknown, keys: string[]): T | null {
  if (!body || typeof body !== 'object') return null
  const obj = body as Record<string, unknown>
  for (const key of keys) {
    if (obj[key] && typeof obj[key] === 'object') return obj[key] as T
  }
  return obj as T
}

async function fedapayFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const key = fedapaySecretKey()
  if (!key) throw new Error('FEDAPAY_SECRET_KEY n\u2019est pas configurée.')
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15_000)
  try {
    const res = await fetch(`${fedapayBaseUrl()}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(init?.headers || {}),
      },
    })
    const text = await res.text()
    let body: unknown = null
    try { body = text ? JSON.parse(text) : null } catch { body = { raw: text } }
    if (!res.ok) {
      const detail =
        body && typeof body === 'object' && 'message' in (body as Record<string, unknown>)
          ? String((body as Record<string, unknown>).message)
          : text.slice(0, 200)
      throw new Error(`FedaPay ${res.status} : ${detail || 'erreur inconnue'}`)
    }
    return body as T
  } finally {
    clearTimeout(timer)
  }
}

export interface CheckoutResult {
  providerRef: string // id de la transaction FedaPay
  paymentUrl: string // page de paiement où choisir MTN MoMo / Moov / Wave…
}

// Crée la transaction et renvoie le lien de paiement Mobile Money.
export async function createCheckout(params: {
  reference: string // référence interne du Payment (custom_metadata)
  amount: number // FCFA, entier
  description: string
  callbackUrl: string // retour navigateur après paiement
  customer: {
    firstName: string
    lastName: string
    email: string
    phone?: string // numéro complet avec indicatif (ex. +228 90 00 00 00)
    country?: string // code ISO du pays du payeur (BJ, TG, FR…)
  }
  billing: string // MONTHLY | YEARLY
}): Promise<CheckoutResult> {
  const txBody = {
    description: params.description,
    amount: params.amount,
    currency: { iso: paymentCurrency() },
    callback_url: params.callbackUrl,
    merchant_reference: params.reference,
    custom_metadata: {
      reference: params.reference,
      billing: params.billing,
      plan: 'PREMIUM',
      app: 'GESCOM',
      ...(params.customer.country ? { country: params.customer.country } : {}),
    },
    customer: {
      firstname: params.customer.firstName || 'Porteur',
      lastname: params.customer.lastName || 'de projet',
      email: params.customer.email,
      // Numéro du payeur : pré-remplit la page FedaPay et conditionne les
      // opérateurs Mobile Money proposés selon le pays.
      ...(params.customer.phone
        ? {
            phone_number: {
              number: params.customer.phone.replace(/[^+0-9]/g, ''),
              country: params.customer.country || 'TG',
            },
          }
        : {}),
    },
  }

  const created = await fedapayFetch<unknown>('/transactions', {
    method: 'POST',
    body: JSON.stringify(txBody),
  })
  const tx = unwrap<FedaPayTransaction>(created, ['v1/transaction', 'transaction'])
  if (!tx?.id) throw new Error('Réponse FedaPay inattendue à la création de la transaction.')

  const tokenRes = await fedapayFetch<unknown>(`/transactions/${tx.id}/token`, { method: 'POST' })
  const token = unwrap<{ url?: string }>(tokenRes, ['v1/token', 'token'])
  const paymentUrl = token?.url
  if (!paymentUrl) throw new Error('Lien de paiement FedaPay indisponible.')

  return { providerRef: String(tx.id), paymentUrl }
}

export interface TransactionStatus {
  id: string
  status: string // pending | approved | declined | canceled | transferred
  amount?: number
  reference?: string
  metadata?: Record<string, unknown>
}

// Statut réel de la transaction (source de vérité pour la confirmation).
export async function getTransaction(providerRef: string): Promise<TransactionStatus | null> {
  try {
    const body = await fedapayFetch<unknown>(`/transactions/${encodeURIComponent(providerRef)}`)
    const tx = unwrap<FedaPayTransaction>(body, ['v1/transaction', 'transaction'])
    if (!tx?.id) return null
    return {
      id: String(tx.id),
      status: String(tx.status || 'pending'),
      amount: tx.amount,
      reference: tx.reference,
      metadata: tx.custom_metadata,
    }
  } catch (err) {
    // Transaction introuvable (404) → null ; autre erreur → rethrow pour log
    if (err instanceof Error && err.message.includes('404')) return null
    throw err
  }
}
