// GESCOM PROJECT – Confirmation d'un paiement Mobile Money (logique partagée)
//
// Utilisée par le webhook FedaPay et par la vérification au retour du
// navigateur : re-vérifie le statut réel de la transaction auprès de FedaPay
// (source de vérité), puis active ou clôture le paiement en conséquence.
import { db } from '@/lib/db'
import { logActivity } from '@/lib/api-helpers'
import { computePremiumExpiry } from '@/lib/plans'
import { getTransaction } from './fedapay'

export type ConfirmOutcome =
  | 'activated' // paiement confirmé, Premium activé
  | 'already'   // déjà traité (idempotence)
  | 'pending'   // transaction encore en attente
  | 'failed'    // refusée ou annulée
  | 'mismatch'  // montant encaissé différent du montant attendu
  | 'unknown'   // transaction inconnue de FedaPay
  | 'unmatched' // transaction sans paiement correspondant dans GESCOM

export async function confirmPayment(providerRef: string): Promise<ConfirmOutcome> {
  const tx = await getTransaction(providerRef)
  if (!tx) return 'unknown'

  // Retrouve le paiement : par référence FedaPay, sinon par metadata interne
  const payment =
    (await db.payment.findFirst({ where: { providerRef: tx.id }, include: { user: true } })) ??
    (tx.metadata && typeof tx.metadata.reference === 'string'
      ? await db.payment.findUnique({ where: { reference: tx.metadata.reference }, include: { user: true } })
      : null)
  if (!payment) return 'unmatched'

  if (tx.status === 'approved' || tx.status === 'transferred') {
    if (payment.status === 'SUCCEEDED') return 'already'

    // Contrôle d'intégrité : le montant encaissé doit correspondre au paiement attendu
    if (tx.amount != null && tx.amount !== payment.amount) {
      await db.payment.update({ where: { id: payment.id }, data: { status: 'FAILED', providerRef: tx.id } }).catch(() => null)
      return 'mismatch'
    }

    const billing = payment.billing === 'YEARLY' ? 'YEARLY' : 'MONTHLY'
    const expiresAt = computePremiumExpiry(billing, payment.user.planExpiresAt)
    await db.$transaction([
      db.payment.update({
        where: { id: payment.id },
        data: { status: 'SUCCEEDED', paidAt: new Date(), expiresAt, providerRef: tx.id },
      }),
      db.user.update({
        where: { id: payment.userId },
        data: { plan: 'PREMIUM', planExpiresAt: expiresAt },
      }),
    ])
    try {
      await logActivity(
        payment.userId,
        'PAYMENT',
        `Paiement Mobile Money confirmé (${payment.amount} FCFA, réf. ${payment.reference}). Abonnement Premium actif jusqu'au ${expiresAt.toLocaleDateString('fr-FR')}.`,
      )
    } catch { /* journalisation best effort */ }
    return 'activated'
  }

  if (tx.status === 'declined' || tx.status === 'canceled') {
    if (payment.status === 'PENDING') {
      await db.payment.update({ where: { id: payment.id }, data: { status: 'FAILED', providerRef: tx.id } }).catch(() => null)
    }
    return 'failed'
  }

  return 'pending'
}
