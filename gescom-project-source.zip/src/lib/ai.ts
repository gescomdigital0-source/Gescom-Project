// GESCOM PROJECT – Générateur intelligent d'amélioration des idées
// Moteur serveur : construction du contexte projet, appel du modèle (SDK
// z-ai-web-dev-sdk, backend uniquement), extraction et normalisation du JSON.
import ZAI from 'z-ai-web-dev-sdk'
import { AI_TARGETS, isAiTarget } from './ai-targets'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AiImprovement {
  analyse: string[] // insuffisances, incohérences, éléments manquants
  hypothese: string[] // hypothèses utilisées (à vérifier/ajuster par l'utilisateur)
  recommandations: string[] // recommandations stratégiques
  proposition: unknown // contenu proposé (forme dépend de la rubrique)
}

interface RawImprovement {
  analyse?: unknown
  hypothese?: unknown
  recommandations?: unknown
  proposition?: unknown
}

// ---------------------------------------------------------------------------
// Contexte projet compact (déterministe, sans invention)
// ---------------------------------------------------------------------------

type AnyProject = {
  name: string
  idea: string
  description: string
  sector: string
  type: string
  country: string
  region: string
  currency: string
  status: string
  objectives: string
  overview: string
  analysis: string
  finance: string
}

type AnyTask = { phase: string; title: string; status: string }

const cut = (s: unknown, n: number): string => {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim()
  return t.length > n ? t.slice(0, n - 1) + '…' : t
}

function parseJsonSafe(json: string | null | undefined): Record<string, unknown> {
  try {
    const v = json ? JSON.parse(json) : {}
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {}
  } catch {
    return {}
  }
}

function strArray(v: unknown, max: number, maxLen: number): string[] {
  if (!Array.isArray(v)) return []
  return v
    .map((x) => (typeof x === 'string' ? x.trim() : typeof x === 'object' && x !== null ? cut((x as { label?: string }).label, maxLen) : String(x ?? '')))
    .filter(Boolean)
    .slice(0, max)
    .map((x) => cut(x, maxLen))
}

const COUNTRY_NAMES: Record<string, string> = {
  CM: 'Cameroun', TD: 'Tchad', CF: 'République centrafricaine', GA: 'Gabon',
  CG: 'Congo', GQ: 'Guinée équatoriale', TG: 'Togo', BJ: 'Bénin',
  CI: 'Côte d\'Ivoire', SN: 'Sénégal', BF: 'Burkina Faso', ML: 'Mali',
  NE: 'Niger', GN: 'Guinée', CD: 'RD Congo', RW: 'Rwanda',
  BI: 'Burundi', DJ: 'Djibouti', KM: 'Comores', MG: 'Madagascar',
}

function countryName(code: string): string {
  if (!code) return ''
  return COUNTRY_NAMES[code] || code
}

/** Résumé compact et factuel du projet, injecté dans le prompt. */
export function buildProjectContext(project: AnyProject, tasks: AnyTask[] = []): string {
  const overview = parseJsonSafe(project.overview)
  const analysis = parseJsonSafe(project.analysis)
  const finance = parseJsonSafe(project.finance)
  const lines: string[] = []

  lines.push(`Nom du projet : ${cut(project.name, 140)}`)
  if (project.sector) lines.push(`Secteur d'activité : ${cut(project.sector, 90)}`)
  if (project.type) lines.push(`Type de projet : ${cut(project.type, 90)}`)
  const place = [project.region && cut(project.region, 80), countryName(project.country)].filter(Boolean).join(', ')
  if (place) lines.push(`Localisation : ${place}`)
  if (project.currency) lines.push(`Devise : ${project.currency}`)
  lines.push(`Statut : ${project.status === 'COMPLETED' ? 'terminé' : project.status === 'ONGOING' ? 'en cours' : 'brouillon'}`)

  if (project.idea) lines.push(`Idée du projet : ${cut(project.idea, 500)}`)
  if (project.description) lines.push(`Description : ${cut(project.description, 800)}`)

  const objectives = strArray(safeParseArray(project.objectives), 8, 180)
  if (objectives.length) lines.push(`Objectifs : ${objectives.join(' | ')}`)

  if (overview.promoter) lines.push(`Porteur : ${cut(overview.promoter, 100)}`)
  if (overview.legalForm) lines.push(`Forme juridique : ${cut(overview.legalForm, 60)}`)
  if (overview.vision) lines.push(`Vision : ${cut(overview.vision, 300)}`)
  if (overview.mission) lines.push(`Mission : ${cut(overview.mission, 300)}`)
  if (overview.summary) lines.push(`Résumé exécutif : ${cut(overview.summary, 700)}`)

  const swot = analysis.swot as Record<string, unknown> | undefined
  if (swot && typeof swot === 'object') {
    const s = strArray((swot as { strengths?: unknown }).strengths, 6, 120)
    const w = strArray((swot as { weaknesses?: unknown }).weaknesses, 6, 120)
    const o = strArray((swot as { opportunities?: unknown }).opportunities, 6, 120)
    const t = strArray((swot as { threats?: unknown }).threats, 6, 120)
    if (s.length) lines.push(`SWOT Forces : ${s.join(' | ')}`)
    if (w.length) lines.push(`SWOT Faiblesses : ${w.join(' | ')}`)
    if (o.length) lines.push(`SWOT Opportunités : ${o.join(' | ')}`)
    if (t.length) lines.push(`SWOT Menaces : ${t.join(' | ')}`)
  }

  const pestel = analysis.pestel as Record<string, unknown> | undefined
  if (pestel && typeof pestel === 'object') {
    const labels: Record<string, string> = { politique: 'Politique', economique: 'Économique', socioculturel: 'Socioculturel', technologique: 'Technologique', ecologique: 'Écologique', legal: 'Légal' }
    for (const [k, label] of Object.entries(labels)) {
      const v = cut((pestel as Record<string, unknown>)[k], 220)
      if (v) lines.push(`PESTEL ${label} : ${v}`)
    }
  }

  const market = analysis.market as Record<string, unknown> | undefined
  if (market && typeof market === 'object') {
    const labels: Record<string, string> = { demande: 'Demande', offre: 'Offre', segments: 'Segments', tendances: 'Tendances', cible: 'Cible', zones: 'Zones', conclusion: 'Conclusion marché' }
    for (const [k, label] of Object.entries(labels)) {
      const v = cut((market as Record<string, unknown>)[k], 250)
      if (v) lines.push(`Marché ${label} : ${v}`)
    }
  }

  const competitors = analysis.competitors as Array<{ name?: string; type?: string }> | undefined
  if (Array.isArray(competitors) && competitors.length) {
    lines.push(`Concurrents déclarés : ${competitors.slice(0, 8).map((c) => `${cut(c.name, 60)} (${cut(c.type, 40)})`).join(' | ')}`)
  }

  const needs = analysis.needs as Array<{ label?: string; target?: string }> | undefined
  if (Array.isArray(needs) && needs.length) {
    lines.push(`Besoins clients déclarés : ${needs.slice(0, 8).map((n) => cut(n.label, 60)).join(' | ')}`)
  }

  const risks = analysis.risks as Array<{ label?: string; probability?: number; impact?: number }> | undefined
  if (Array.isArray(risks) && risks.length) {
    lines.push(`Risques déclarés : ${risks.slice(0, 8).map((r) => `${cut(r.label, 60)} (P${Number(r.probability) || 3}/I${Number(r.impact) || 3})`).join(' | ')}`)
  }

  const feas = analysis.feasibility as Record<string, unknown> | undefined
  if (feas && typeof feas === 'object') {
    const verdict = feas.verdict ? ` (verdict : ${String(feas.verdict)})` : ''
    const f = ['technique', 'economique', 'juridique', 'organisationnelle', 'commerciale']
      .map((k) => cut((feas as Record<string, unknown>)[k], 150))
      .filter(Boolean)
      .join(' | ')
    if (f) lines.push(`Faisabilité${verdict} : ${f}`)
  }

  if (analysis.synthesis) lines.push(`Synthèse actuelle : ${cut(analysis.synthesis, 500)}`)

  // Finance (résumé factuel, chiffres de l'utilisateur uniquement)
  const investments = (finance.investments as Array<{ label?: string; amount?: number }>) || []
  if (investments.length) {
    const total = investments.reduce((s, i) => s + (Number(i.amount) || 0), 0)
    lines.push(`Investissements déclarés (${investments.length} postes, total ${Math.round(total)} ${project.currency}) : ${investments.slice(0, 10).map((i) => `${cut(i.label, 50)}=${Math.round(Number(i.amount) || 0)}`).join(' | ')}`)
  }
  const financing = (finance.financing as Array<{ source?: string; type?: string; amount?: number }>) || []
  if (financing.length) {
    lines.push(`Financement déclaré : ${financing.slice(0, 8).map((f) => `${cut(f.source, 50)} (${f.type})=${Math.round(Number(f.amount) || 0)}`).join(' | ')}`)
  }
  const assumptions = (finance.assumptions as Record<string, unknown>) || {}
  const products = (assumptions.products as Array<{ label?: string; unit?: string; unitPrice?: number; qty?: number }>) || []
  if (products.length) {
    lines.push(`Produits/services déclarés : ${products.slice(0, 8).map((p) => `${cut(p.label, 50)} (${cut(p.unit, 15)}) px=${Math.round(Number(p.unitPrice) || 0)} qté=${Math.round(Number(p.qty) || 0)}/an`).join(' | ')}`)
  }
  if (Number(finance.workingCapital) > 0) lines.push(`Fonds de roulement : ${Math.round(Number(finance.workingCapital))} ${project.currency}`)

  if (tasks.length) {
    lines.push(`Plan d'action existant : ${tasks.slice(0, 12).map((t) => `${cut(t.title, 60)} [${cut(t.phase, 30)}]`).join(' | ')}`)
  }

  return lines.join('\n')
}

function safeParseArray(json: string | null | undefined): unknown[] {
  try {
    const v = json ? JSON.parse(json) : []
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

// ---------------------------------------------------------------------------
// Prompt & appel du modèle
// ---------------------------------------------------------------------------

const SYSTEM_RULES = `Tu es un expert international en entrepreneuriat, en montage de projets, en stratégie d'entreprise, en études de marché et en ingénierie financière. Tu interviens dans Gescom Project, une plateforme qui accompagne des entrepreneurs — souvent en Afrique francophone — dans la structuration de leur business plan, de l'idée au dossier finançable.

RÈGLES ABSOLUES :
1. Tu ne présentes JAMAIS comme vérifiées des données de marché, des statistiques ou des chiffres que tu ne connais pas réellement. Toute estimation, tout ordre de grandeur et tout chiffre indicatif doit être signalé comme hypothèse dans le champ « hypothese ».
2. Tu distingues rigoureusement : les informations fournies par l'utilisateur (tu ne les inventes pas et tu ne les contredis pas), les hypothèses de travail (champ « hypothese »), et tes recommandations (champ « recommandations »).
3. Tes propositions sont concrètes, réalistes et adaptées au secteur d'activité, au marché cible et au contexte géographique du projet — jamais génériques. Une proposition qui pourrait coller à n'importe quel projet est un échec.
4. Langage professionnel, clair, convaincant, en français. Pas de jargon inutile, pas de markdown (pas de **, pas de #, pas de puces « - » dans les textes : des phrases).
5. Si les informations fournies sont insuffisantes, tu le dis dans « analyse » et tu proposes des éléments complémentaires pertinents dans « proposition ».
6. « analyse » liste les insuffisances, incohérences et éléments manquants du contenu actuel (2 à 5 points courts). Si le contenu est déjà bon, dis ce qui le rend fort et ce qui peut encore être renforcé.
7. « recommandations » donne des conseils stratégiques actionnables (2 à 5 points) adaptés au projet.
8. « proposition » contient UNIQUEMENT le contenu qui sera inséré dans la rubrique après validation par l'utilisateur : il doit donc être complet, autonome et prêt à l'emploi, sans méta-commentaire (« voici », « je propose ») ni référence au dialogue.`

function jsonShapeInstruction(kind: string): string {
  switch (kind) {
    case 'text':
      return '« proposition » est une chaîne de caractères : le texte final de la rubrique, sans titre ni préambule.'
    case 'list':
      return '« proposition » est un tableau de chaînes : chaque chaîne est une entrée autonome (une ligne), courte et informative. 3 à 8 entrées.'
    case 'needs':
      return '« proposition » est un tableau d\'objets { "label": besoin court, "target": cible concernée, "frequency": fréquence ou usage }. 3 à 8 objets.'
    case 'competitors':
      return '« proposition » est un tableau d\'objets { "name": nom du type d\'acteur, "type": "Concurrent direct" | "Concurrent indirect" | "Substitut potentiel", "strengths": forces, "weaknesses": faiblesses, "positioning": comment se différencier }. 2 à 5 objets.'
    case 'risks':
      return '« proposition » est un tableau d\'objets { "label": risque, "category": catégorie courte (ex. Approvisionnement, Sanitaire, Climatique, Commercial, Financier, Réglementaire, Sécurité), "probability": entier 1-5, "impact": entier 1-5, "mitigation": une mesure de parade concrète }. 3 à 8 objets.'
    case 'investments':
      return '« proposition » est un tableau d\'objets { "label": intitulé du poste, "category": "TERRAIN" | "BATIMENT" | "EQUIPEMENT" | "MATERIEL" | "FRAIS_ETABLISSEMENT" | "AUTRE", "amount": montant indicatif en nombre (devise du projet) }. 4 à 10 objets.'
    case 'financing':
      return '« proposition » est un tableau d\'objets { "source": nom de la source, "type": "EQUITY" | "LOAN" | "GRANT", "amount": montant en nombre, "rate": taux annuel % en nombre (0 si pas un emprunt), "termYears": durée en années (0 si pas un emprunt) }. 2 à 5 objets.'
    case 'products':
      return '« proposition » est un tableau d\'objets { "label": produit/service, "unit": unité de vente, "unitPrice": prix unitaire en nombre, "qty": quantité annuelle année 1 en nombre, "volumeGrowth": croissance annuelle des volumes en % (nombre), "priceGrowth": croissance annuelle du prix en % (nombre) }. 1 à 6 objets.'
    case 'tasks':
      return '« proposition » est un tableau d\'objets { "phase": phase courte, "title": activité commençant par un verbe à l\'infinitif }. 8 à 15 objets.'
    default:
      return '« proposition » est une chaîne de caractères.'
  }
}

function userPrompt(targetKey: string, value: unknown, context: string): string {
  const def = AI_TARGETS[targetKey]
  const current = formatCurrentValue(value)
  return [
    context ? `CONTEXTE DU PROJET (informations fournies par l'utilisateur) :\n${context}` : 'CONTEXTE : le projet est en cours de création ; seul le contenu fourni ci-dessous est connu.',
    '',
    `RUBRIQUE À AMÉLIORER : ${def.label}`,
    `CONTENU ACTUEL DE LA RUBRIQUE (fourni par l'utilisateur) :`,
    current || '(vide — propose des éléments complémentaires pertinents pour démarrer cette rubrique)',
    '',
    'Tâche : 1) analyse ce contenu ; 2) identifie les insuffisances, incohérences et éléments manquants ; 3) reformule et enrichis dans un langage professionnel et convaincant ; 4) adapte tes propositions au secteur, au marché cible et au contexte géographique ; 5) renforce la cohérence, la faisabilité et la rentabilité du projet ; 6) si les informations sont insuffisantes, propose des éléments complémentaires pertinents.',
    'Réponds UNIQUEMENT avec un JSON valide, sans texte autour, au format :',
    '{ "analyse": ["…"], "hypothese": ["…"], "proposition": …, "recommandations": ["…"] }',
    jsonShapeInstruction(def.kind),
  ].join('\n')
}

function formatCurrentValue(value: unknown): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'string') return cut(value, 4000)
  if (Array.isArray(value)) {
    if (value.length === 0) return '(liste vide)'
    return value
      .slice(0, 20)
      .map((v, i) => {
        if (typeof v === 'string') return `${i + 1}. ${cut(v, 250)}`
        if (v && typeof v === 'object') {
          const o = v as Record<string, unknown>
          return `${i + 1}. ${Object.entries(o)
            .filter(([k]) => k !== 'id')
            .map(([k, val]) => `${k}: ${cut(val, 120)}`)
            .join(' ; ')}`
        }
        return `${i + 1}. ${String(v)}`
      })
      .join('\n')
  }
  return cut(JSON.stringify(value), 2000)
}

// Extraction robuste du JSON (gère les clôtures de code et le texte résiduel).
function extractJson(raw: string): RawImprovement {
  let s = raw.trim()
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '')
  const start = s.indexOf('{')
  const end = s.lastIndexOf('}')
  if (start === -1 || end === -1 || end <= start) throw new Error('Réponse IA illisible (pas de JSON).')
  return JSON.parse(s.slice(start, end + 1)) as RawImprovement
}

// ---------------------------------------------------------------------------
// Normalisation de la réponse
// ---------------------------------------------------------------------------

const asStrList = (v: unknown, max: number, maxLen: number): string[] => {
  if (!Array.isArray(v)) {
    if (typeof v === 'string' && v.trim()) {
      // le modèle a répondu avec un texte multi-lignes : découper proprement
      return v
        .split(/\n+/)
        .map((l) => l.replace(/^\s*(?:[-•*]|\d+[.)])\s*/, '').trim())
        .filter(Boolean)
        .slice(0, max)
        .map((l) => cut(l, maxLen))
    }
    return []
  }
  return v
    .map((x) => (typeof x === 'string' ? x.trim() : x && typeof x === 'object' ? cut((x as { text?: string }).text, maxLen) : ''))
    .filter(Boolean)
    .slice(0, max)
    .map((x) => cut(String(x).replace(/^[-•*]\s*/, ''), maxLen))
}

const clampInt = (v: unknown, min: number, max: number, dflt: number): number => {
  const n = Math.round(Number(v))
  if (!Number.isFinite(n)) return dflt
  return Math.min(max, Math.max(min, n))
}

const clean = (v: unknown, maxLen: number): string => cut(String(v ?? '').replace(/[*#]/g, ''), maxLen)

// Étiquettes déjà présentes (pour éviter de proposer des doublons en mode ajout).
function existingLabels(value: unknown): Set<string> {
  const set = new Set<string>()
  const push = (s: unknown) => {
    const t = String(s ?? '').toLowerCase().replace(/\s+/g, ' ').trim()
    if (t.length > 2) set.add(t)
  }
  if (Array.isArray(value)) {
    for (const v of value) {
      if (typeof v === 'string') push(v)
      else if (v && typeof v === 'object') {
        const o = v as Record<string, unknown>
        push(o.label || o.name || o.title || o.source)
      }
    }
  }
  return set
}

function normalizeProposition(kind: string, raw: unknown, value: unknown): unknown {
  const dup = existingLabels(value)
  const notDup = (label: string) => !dup.has(label.toLowerCase().replace(/\s+/g, ' ').trim())

  switch (kind) {
    case 'text': {
      if (typeof raw !== 'string') return ''
      return cut(raw.replace(/\s*\n\s*/g, '\n').trim(), 4500)
    }
    case 'list': {
      return asStrList(raw, 10, 240)
    }
    case 'needs': {
      if (!Array.isArray(raw)) return []
      return raw
        .slice(0, 10)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.label, 140).length > 1 && notDup(clean(r.label, 140)))
        .map((r) => ({ label: clean(r.label, 140), target: clean(r.target, 140), frequency: clean(r.frequency, 140) }))
    }
    case 'competitors': {
      if (!Array.isArray(raw)) return []
      return raw
        .slice(0, 6)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.name, 120).length > 1 && notDup(clean(r.name, 120)))
        .map((r) => ({
          name: clean(r.name, 120),
          type: ['Concurrent direct', 'Concurrent indirect', 'Substitut potentiel'].includes(clean(r.type, 40)) ? clean(r.type, 40) : 'Concurrent direct',
          strengths: clean(r.strengths, 400),
          weaknesses: clean(r.weaknesses, 400),
          positioning: clean(r.positioning, 300),
        }))
    }
    case 'risks': {
      if (!Array.isArray(raw)) return []
      return raw
        .slice(0, 10)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.label, 160).length > 1 && notDup(clean(r.label, 160)))
        .map((r) => ({
          label: clean(r.label, 160),
          category: clean(r.category, 60) || 'Général',
          probability: clampInt(r.probability, 1, 5, 3),
          impact: clampInt(r.impact, 1, 5, 3),
          mitigation: clean(r.mitigation, 400),
        }))
    }
    case 'investments': {
      if (!Array.isArray(raw)) return []
      const CATS = ['TERRAIN', 'BATIMENT', 'EQUIPEMENT', 'MATERIEL', 'FRAIS_ETABLISSEMENT', 'AUTRE']
      return raw
        .slice(0, 12)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.label, 140).length > 1 && notDup(clean(r.label, 140)))
        .map((r) => {
          const cat = String(r.category ?? '').toUpperCase().replace(/\s+/g, '_')
          return {
            label: clean(r.label, 140),
            category: CATS.includes(cat) ? cat : 'AUTRE',
            amount: Math.max(0, Math.round(Number(r.amount) || 0)),
          }
        })
    }
    case 'financing': {
      if (!Array.isArray(raw)) return []
      const TYPES = ['EQUITY', 'LOAN', 'GRANT']
      return raw
        .slice(0, 6)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.source, 140).length > 1 && notDup(clean(r.source, 140)))
        .map((r) => {
          const t = String(r.type ?? '').toUpperCase()
          return {
            source: clean(r.source, 140),
            type: TYPES.includes(t) ? t : 'EQUITY',
            amount: Math.max(0, Math.round(Number(r.amount) || 0)),
            rate: Math.min(100, Math.max(0, Number(r.rate) || 0)),
            termYears: clampInt(r.termYears, 0, 30, 0),
          }
        })
    }
    case 'products': {
      if (!Array.isArray(raw)) return []
      return raw
        .slice(0, 6)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.label, 140).length > 1 && notDup(clean(r.label, 140)))
        .map((r) => ({
          label: clean(r.label, 140),
          unit: clean(r.unit, 30) || 'unité',
          unitPrice: Math.max(0, Number(r.unitPrice) || 0),
          qty: Math.max(0, Math.round(Number(r.qty) || 0)),
          volumeGrowth: Math.min(500, Math.max(-100, Number(r.volumeGrowth) || 0)),
          priceGrowth: Math.min(500, Math.max(-100, Number(r.priceGrowth) || 0)),
        }))
    }
    case 'tasks': {
      if (!Array.isArray(raw)) return []
      return raw
        .slice(0, 16)
        .map((r) => r as Record<string, unknown>)
        .filter((r) => clean(r.title, 160).length > 1 && notDup(clean(r.title, 160)))
        .map((r) => ({ phase: clean(r.phase, 80) || 'Général', title: clean(r.title, 160) }))
    }
    default:
      return null
  }
}

// ---------------------------------------------------------------------------
// Appel principal
// ---------------------------------------------------------------------------

const REQUEST_TIMEOUT_MS = 90_000

export async function callAiImprove(params: { targetKey: string; value: unknown; context: string }): Promise<AiImprovement> {
  if (!isAiTarget(params.targetKey)) throw new Error('Rubrique inconnue.')
  const def = AI_TARGETS[params.targetKey]
  const kind = def.kind

  const messages = [
    { role: 'assistant' as const, content: `${SYSTEM_RULES}\n\nRUBRIQUE ACTUELLE : ${def.label}\nCONSIGNE SPÉCIFIQUE À CETTE RUBRIQUE : ${def.instruction}` },
    { role: 'user' as const, content: userPrompt(params.targetKey, params.value, params.context) },
  ]

  const run = async (): Promise<RawImprovement> => {
    const zai = await ZAI.create()
    const completion = (await Promise.race([
      zai.chat.completions.create({ messages, thinking: { type: 'disabled' } }),
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), REQUEST_TIMEOUT_MS)),
    ])) as Awaited<ReturnType<import('z-ai-web-dev-sdk').default['chat']['completions']['create']>>
    const content = completion.choices?.[0]?.message?.content
    if (!content || !content.trim()) throw new Error('Réponse IA vide.')
    return extractJson(content)
  }

  // Une seule relance : en cas d'échec de parsing, on rappelle avec une consigne plus ferme.
  let raw: RawImprovement
  try {
    raw = await run()
  } catch (err) {
    const msg = err instanceof Error ? err.message : ''
    if (msg === 'timeout') throw err
    raw = await run()
  }

  const improvement: AiImprovement = {
    analyse: asStrList(raw.analyse, 6, 300),
    hypothese: asStrList(raw.hypothese, 10, 300),
    recommandations: asStrList(raw.recommandations, 6, 300),
    proposition: normalizeProposition(kind, raw.proposition, params.value),
  }
  return improvement
}
