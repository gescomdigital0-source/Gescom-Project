// GESCOM PROJECT – Bibliothèque d'exemples d'analyse par secteur
//
// Objectif : aider le porteur de projet à démarrer chaque partie de l'analyse
// (SWOT, PESTEL, marché, concurrence, risques, faisabilité) avec des exemples
// concrets à adapter. Les chiffres apparaissent entre crochets [ ] : la
// plateforme n'invente jamais de statistiques, l'utilisateur les remplace par
// ses propres observations.

import type {
  Competitor, FeasibilityData, MarketData, NeedItem, PestelData, RiskItem,
} from './types'

// Suggestions PESTEL courtes : une phrase à insérer en un clic puis à adapter
// (les éléments entre [crochets] sont à remplacer par les observations de
// l'utilisateur).
export interface PestelChips {
  politique: string[]
  economique: string[]
  socioculturel: string[]
  technologique: string[]
  ecologique: string[]
  legal: string[]
}

// Questions-guides PESTEL (indépendantes du secteur) : aident l'utilisateur à
// savoir quoi observer dans chaque dimension avant de rédiger.
export const PESTEL_QUESTIONS: PestelChips = {
  politique: [
    "L'État soutient-il votre secteur (subventions, programmes, prix garantis) ?",
    'Les taxes et restrictions à l\u2019importation protègent-elles votre activité ?',
    'Y a-t-il des élections ou des changements de règles à anticiper ?',
  ],
  economique: [
    'Comment évoluent les prix de vos intrants, fournitures ou marchandises ?',
    'Quel est le pouvoir d\u2019achat de vos clients cibles ?',
    'À quelles conditions (taux, garanties) pouvez-vous financer le projet ?',
  ],
  socioculturel: [
    'À quelles occasions et à quelle fréquence vos clients consomment-ils ?',
    'Quelles préférences locales (goûts, habitudes, langue) influencent la demande ?',
    'La population de votre zone croît-elle et s\u2019urbanise-t-elle ?',
  ],
  technologique: [
    'Quels équipements et techniques améliorés sont disponibles près de vous ?',
    'Vos clients utilisent-ils le mobile money, WhatsApp ou Internet ?',
    'De quelles formations ou compétences avez-vous besoin ?',
  ],
  ecologique: [
    'Votre activité est-elle exposée aux aléas climatiques (pluies, chaleur) ?',
    'Comment gérerez-vous les déchets et valoriserez-vous les sous-produits ?',
    'Quelles ressources naturelles (eau, énergie, sol) utilisez-vous, à quel coût ?',
  ],
  legal: [
    'Quelles formalités d\u2019enregistrement et quel régime fiscal s\u2019appliquent ?',
    'Quelles autorisations, licences ou agréments votre activité exige-t-elle ?',
    'Quelles normes (hygiène, sécurité, étiquetage) devez-vous respecter ?',
  ],
}

export interface SectorExamples {
  swot: {
    strengths: string[]
    weaknesses: string[]
    opportunities: string[]
    threats: string[]
  }
  pestel: PestelData
  // Suggestions courtes à insérer en un clic dans chaque dimension PESTEL
  pestelChips: PestelChips
  market: MarketData
  needs: Array<Pick<NeedItem, 'label' | 'target' | 'frequency'>>
  competitors: Array<Pick<Competitor, 'name' | 'type' | 'strengths' | 'weaknesses' | 'positioning'>>
  risks: Array<Pick<RiskItem, 'label' | 'category' | 'probability' | 'impact' | 'mitigation'>>
  feasibility: Omit<FeasibilityData, 'verdict'>
}

// ---------------------------------------------------------------------------
// Profil PRODUCTION : agriculture, élevage, agroalimentaire, artisanat
// ---------------------------------------------------------------------------

const production: SectorExamples = {
  swot: {
    strengths: [
      'Produits frais et de qualité, traçabilité maîtrisée de la production à la vente.',
      "Coûts de production compétitifs grâce à une main-d'œuvre locale disponible.",
      'Expérience pratique du porteur et réseau de contacts dans la filière.',
    ],
    weaknesses: [
      "Dépendance à un fournisseur unique d'intrants (aliments, semences, matières premières).",
      'Capacité de stockage et de conservation limitée, pertes après récolte à réduire.',
      'Trésorerie limitée pour absorber les aléas (saisonnalité, impayés).',
    ],
    opportunities: [
      'Demande urbaine croissante en produits locaux et frais.',
      "Contrats d'approvisionnement possibles avec restaurants, écoles ou supermarchés.",
      'Subventions et appuis des programmes agricoles et des partenaires au développement.',
    ],
    threats: [
      'Volatilité des prix des intrants et des produits sur le marché.',
      'Aléas climatiques et maladies pouvant détruire une partie de la production.',
      'Arrivée de produits importés moins chers en période de pointe.',
    ],
  },
  pestel: {
    politique: "Politiques d'appui à la production locale : programmes de subventions, exonérations possibles sur les intrants. À vérifier : démarches auprès du ministère sectoriel et des collectivités locales, stabilité de la fiscalité locale.",
    economique: "Inflation sur les intrants qui comprime les marges ; pouvoir d'achat variable selon les villes. À chiffrer : prix de vente moyen dans votre zone, coût unitaire de production, écart entre haute et basse saison.",
    socioculturel: 'Consommation soutenue lors des fêtes et événements ; préférence pour les produits frais et locaux. Habitudes à confirmer par une enquête auprès des clients visés (ménages, revendeurs, restaurateurs).',
    technologique: 'Techniques de production améliorées disponibles (intrants, équipements, conservation). Opportunité de digitaliser la commercialisation (commandes par téléphone ou WhatsApp) et de mécaniser certains postes.',
    ecologique: 'Sensibilité aux aléas climatiques (pluies, chaleur) ; gestion responsable de l\u2019eau et des déchets de production. Valorisation possible des sous-produits (compost, alimentation animale).',
    legal: "Réglementations à clarifier : enregistrement de l'entreprise, normes sanitaires, autorisations d'exploitation. Prévoir le budget des licences et le calendrier des démarches.",
  },
  pestelChips: {
    politique: [
      'Appuis publics au secteur : [subventions intrants, programme national, fonds de développement] — démarche auprès de [agence / ministère].',
      'Réglementation des importations concurrentes : [taxes, restrictions] — effet sur les prix locaux.',
      'Priorités politiques de la filière : [programme, zone d\u2019appui] — opportunités à saisir.',
    ],
    economique: [
      'Inflation sur les intrants : [constat sur 12 mois] — impact direct sur le coût de revient.',
      'Pouvoir d\u2019achat de la clientèle : [prix moyen accepté, saisonnalité des achats].',
      'Financement : taux bancaire de [x à y %] — comparer avec [microfinance, tontine, subvention].',
    ],
    socioculturel: [
      'Occasions de consommation : [fêtes, week-ends, événements] — pics de demande à anticiper.',
      'Préférences locales : [produit frais / vivant, calibre, emballage] — à confirmer par une enquête.',
      'Démographie de la zone de vente : [croissance urbaine, nombre de ménages].',
    ],
    technologique: [
      'Intrants et techniques améliorés disponibles : [fournisseurs, semences / souches, équipements].',
      'Vente digitalisée : [commandes WhatsApp, mobile money] — pratiques des clients.',
      'Compétences techniques : [formations, techniciens, vétérinaires] accessibles localement.',
    ],
    ecologique: [
      'Aléas climatiques à anticiper : [pluies, chaleur, saison sèche] — adaptations prévues.',
      'Valorisation des sous-produits : [compost, fumier, recyclage] — revenus annexes possibles.',
      'Ressources utilisées : [eau, énergie, sol] — disponibilité et coût.',
    ],
    legal: [
      'Formalités d\u2019entreprise : [RCCM, identifiant contribuable, régime fiscal] — coûts et délais.',
      'Autorisations d\u2019exploitation : [licence, autorisation sanitaire, registre].',
      'Normes à respecter : [hygiène, biosécurité, emballage] — contrôles par [organisme].',
    ],
  },
  market: {
    demande: "Qui achète le produit (ménages, revendeurs, restaurants, institutions) ? En quelle quantité et à quelle fréquence ? Exemple de formulation : « Les [nombre] restaurants de [ville] s'approvisionnent chacun en [quantité] par semaine, avec un pic en période de fêtes. »",
    offre: 'Lister les producteurs ou fournisseurs concurrents de la zone, leur capacité estimée et leurs prix. Exemple : « On dénombre [nombre] producteurs similaires dans un rayon de [distance] ; leur offre est insuffisante en haute saison, ce qui pousse les acheteurs à se fournir plus loin. »',
    segments: 'Segment 1 : [revendeurs / grossistes] — volumes importants, prix négociés. Segment 2 : [ménages / particuliers] — petits volumes, fidélité forte, exigence de qualité. Segment 3 : [institutions : écoles, hôtels, cantines] — contrats récurrents, exigence de régularité.',
    cible: 'Cible prioritaire : [segment] car [raison : volume régulier, marge, proximité]. Premiers clients identifiés : [types d\u2019acheteurs déjà contactés ou à démarcher en priorité].',
    zones: 'Zone de chalandise : [ville / quartiers desservis], à [distance] km du site de production. Logistique : [moyen de transport, coût et délai de livraison par tournée].',
    tendances: 'Tendances observées : urbanisation, attention croissante à la qualité et à la traçabilité, montée des commandes par téléphone ou WhatsApp. Citer les signaux concrets relevés sur le terrain.',
    conclusion: 'Le marché local absorbe-t-il votre capacité de production à un prix rentable ? Formuler les conditions de succès : contrats signés en amont, calendrier de production aligné sur la demande, qualité constante.',
  },
  needs: [
    { label: 'Intrants de qualité (aliments, semences, matières premières)', target: 'Fournisseurs agricoles agréés', frequency: 'Par cycle de production' },
    { label: 'Transport et logistique de livraison', target: 'Transporteurs locaux / véhicule de service', frequency: 'Quotidienne ou hebdomadaire' },
    { label: "Main-d'œuvre qualifiée et encadrement technique", target: "Marché local de l'emploi / technicien", frequency: 'Permanente' },
  ],
  competitors: [
    {
      name: 'Fermes / ateliers semi-industriels de la région',
      type: 'Concurrent direct',
      strengths: 'Volumes importants, prix bas, relations établies avec les grossistes.',
      weaknesses: "Qualité irrégulière, rupture d'approvisionnement en basse saison.",
      positioning: 'Nous différencier par la fraîcheur, la régularité et un service de livraison à la demande.',
    },
    {
      name: 'Produits importés ou hors zone',
      type: 'Concurrent indirect',
      strengths: 'Présence permanente, conditionnement attractif.',
      weaknesses: 'Prix plus élevés, fraîcheur et qualité perçue inférieures.',
      positioning: 'Mettre en avant la production locale, la fraîcheur et la flexibilité de commande.',
    },
  ],
  risks: [
    { label: "Flambée du prix des intrants (aliments, matières premières)", category: 'Financier', probability: 4, impact: 4, mitigation: "Négocier des achats groupés, diversifier les fournisseurs, indexer partiellement les prix de vente." },
    { label: 'Maladie ou épidémie touchant la production', category: 'Sanitaire', probability: 3, impact: 5, mitigation: 'Plan de prévention, traitement préventif, suivi régulier par un technicien ou vétérinaire, assurance si disponible.' },
    { label: 'Écoulement difficile de la production en basse saison', category: 'Commercial', probability: 3, impact: 4, mitigation: 'Contrats cadre avec des acheteurs institutionnels, capacité de conservation, production étalée dans l\u2019année.' },
    { label: 'Départ ou indisponibilité du personnel clé', category: 'Organisationnel', probability: 2, impact: 3, mitigation: 'Former un adjoint polyvalent, documenter les procédures, fidéliser par des primes.' },
    { label: 'Retard d\u2019encaissement des clients professionnels', category: 'Financier', probability: 3, impact: 3, mitigation: 'Acompte à la commande, plafond d\u2019encours par client, relances structurées.' },
  ],
  feasibility: {
    technique: 'Technologies éprouvées dans la zone ; équipements disponibles localement avec service d\u2019entretien. Compétences : le porteur dispose de [expérience / formation] ; prévoir une formation complémentaire sur [sujet].',
    economique: 'Marges estimées à partir des prix de marché relevés ; seuil de rentabilité atteint à partir de [volume / période]. Point de vigilance : la saisonnalité des prix — chiffrer un scénario pessimiste (prix -20 %, volumes -15 %).',
    juridique: "Forme juridique envisagée : [forme]. Autorisations requises : [registre de commerce, autorisation sanitaire, autorisation d'exploitation]. Délais et coûts estimés : [à préciser].",
    organisationnelle: 'Équipe de démarrage : [nombre] personnes (production, commercialisation, gestion). Partenaires identifiés : [fournisseurs, technicien, institution d\u2019appui]. Outils de suivi : cahier de charges, suivi des stocks, comptabilité simplifiée.',
    commerciale: 'Accès aux clients : proximité du marché cible, contacts établis avec [types d\u2019acheteurs]. Canaux : vente directe, livraisons aux revendeurs, contrats avec institutions. Argument différenciant : fraîcheur + régularité + service.',
  },
}

// ---------------------------------------------------------------------------
// Profil COMMERCE : commerce & distribution, restauration & hôtellerie
// ---------------------------------------------------------------------------

const commerce: SectorExamples = {
  swot: {
    strengths: [
      'Emplacement de vente stratégique, fort passage de clients potentiels.',
      'Relation directe avec la clientèle : écoute, fidélisation, réactivité.',
      "Gamme de produits / services adaptée aux habitudes et aux budgets locaux.",
    ],
    weaknesses: [
      'Stock initial limité et besoin de trésorerie pour élargir l\u2019assortiment.',
      'Dépendance à quelques fournisseurs pour les produits les plus vendus.',
      'Notoriété encore faible face aux enseignes déjà installées.',
    ],
    opportunities: [
      'Croissance de la demande urbaine et de la consommation hors domicile.',
      'Commandes à distance en développement (téléphone, réseaux sociaux, livraison).',
      "Possibilité de diversifier l'offre (nouveaux produits, services complémentaires).",
    ],
    threats: [
      'Concurrence des établissements voisins et pratiques de prix agressives.',
      "Hausse des prix d'achat (transport, approvisionnement) qui comprime les marges.",
      'Saisonnalité de la clientèle (périodes creuses, basse saison).',
    ],
  },
  pestel: {
    politique: 'Fiscalité locale et réglementation commerciale à surveiller : patente, taxes sur les établissements, obligations d\u2019affichage et d\u2019hygiène. Vérifier les exigences auprès de la mairie et des services compétents.',
    economique: "Pouvoir d'achat fluctuant : arbitrage des clients entre qualité et prix. À chiffrer : panier moyen, coût d'achat des marchandises, marge par ligne de produits, impact d'une hausse de 10 % des prix d'achat.",
    socioculturel: 'Habitudes de consommation : achats quotidiens de proximité, repas pris à l\u2019extérieur, préférence pour les produits locaux. Saisonnalité liée aux fêtes, aux salaires et aux événements de la zone.',
    technologique: 'Paiement mobile et commandes via WhatsApp en plein essor ; logiciels de caisse abordables. Opportunité : digitaliser la prise de commande et le suivi du stock pour réduire les pertes.',
    ecologique: "Gestion des déchets d'emballage et, pour la restauration, des restes ; économies d'énergie (éclairage, froid). Sensibilisation croissante des clients aux emballages réutilisables.",
    legal: "Obligations : registre de commerce, patente, normes d'hygiène et de sécurité (agrément sanitaire pour la restauration), affichage des prix, facturation. Établir la liste précise et le coût de chaque autorisation.",
  },
  pestelChips: {
    politique: [
      'Politique commerciale : [taxes à l\u2019importation, réglementation des prix] — impact sur l\u2019approvisionnement.',
      'Appuis au commerce local : [foires, marchés structurés, guichets PME].',
      'Réglementation des établissements : [patente, horaires, affichage] — à vérifier auprès de [mairie].',
    ],
    economique: [
      'Évolution des prix d\u2019achat : [constat sur 12 mois] — impact sur les marges.',
      'Pouvoir d\u2019achat des clients : [panier moyen, sensibilité au prix].',
      'Charges fixes à couvrir : [loyer, salaires, énergie] — seuil de ventes quotidien.',
    ],
    socioculturel: [
      'Habitudes d\u2019achat : [fréquence, lieux, moments] dans la zone de vente.',
      'Préférences produits : [marques, origine, formats] constatées chez les clients.',
      'Évolution des usages : [commandes à emporter, livraison, paiement mobile].',
    ],
    technologique: [
      'Outils de vente : [mobile money, commandes WhatsApp, logiciel de caisse] — coût et adoption.',
      'Gestion des stocks : [suivi par tableur / caisse] pour réduire les pertes.',
      'Concurrence en ligne : [vendeurs sur réseaux sociaux] — à intégrer dans la stratégie.',
    ],
    ecologique: [
      'Emballages et déchets : [réglementation, attentes des clients, alternatives réutilisables].',
      'Conservation : [chaîne du froid, pertes à maîtriser].',
      'Transport et carburant : [coût, régularité des approvisionnements].',
    ],
    legal: [
      'Enregistrement : [RCCM, patente, régime fiscal] — coûts et délais.',
      'Obligations spécifiques : [affichage des prix, facturation, agrément sanitaire].',
      'Normes produits : [étiquetage, dates de péremption, certification].',
    ],
  },
  market: {
    demande: "Estimer le flux de clients potentiels : « La zone compte [nombre] habitants / [nombre] bureaux / [nombre] établissements ; le passage moyen est de [nombre] personnes par jour. » Préciser la fréquence d'achat et le panier moyen visé.",
    offre: 'Cartographier les établissements concurrents de la zone : nombre, gammes, prix, points forts et faibles. Indiquer ce que l\u2019offre actuelle ne couvre pas (créneau horaire, gamme, service, livraison).',
    segments: 'Segment 1 : [employés / actifs de la zone] — achats rapides aux heures de pointe. Segment 2 : [familles du quartier] — volumes le week-end. Segment 3 : [groupes / événementiel] — grosses commandes sur réservation.',
    cible: 'Cible prioritaire : [segment], avec une offre et des prix adaptés. Objectifs : [nombre] clients par jour en année 1 ; fidélisation par [carte de fidélité, promotion, service].',
    zones: 'Zone de chalandise : [rayon de X minutes à pied / km], délimitée par [axes routiers, quartiers]. Livraison possible sur [zones] avec des frais de [montant].',
    tendances: 'Tendances : croissance de la commande à emporter et de la livraison, exigence d\u2019hygiène, recherche du meilleur rapport qualité-prix. Citer des observations concrètes relevées dans la zone.',
    conclusion: 'La demande locale soutient-elle un nouvel acteur ? Conditions de succès : emplacement, différenciation claire, gestion stricte des coûts, créneaux adaptés aux habitudes locales.',
  },
  needs: [
    { label: "Approvisionnement régulier en produits de première nécessité", target: 'Grossistes / producteurs locaux', frequency: 'Hebdomadaire' },
    { label: 'Personnel de vente et de service formé', target: "Marché local de l'emploi", frequency: 'Permanente' },
    { label: "Équipement de conservation et de présentation (froid, étagères)", target: "Fournisseurs d'équipements", frequency: "À l'installation" },
  ],
  competitors: [
    {
      name: 'Commerces / établissements installés dans la même zone',
      type: 'Concurrent direct',
      strengths: 'Clientèle fidélisée, assortiment large, prix connus.',
      weaknesses: 'Accueil inégal, créneaux limités, qualité variable.',
      positioning: "Se différencier par l'accueil, la régularité de la qualité et des horaires étendus.",
    },
    {
      name: 'Vente ambulante et marchés de quartier',
      type: 'Concurrent indirect',
      strengths: 'Prix bas, proximité immédiate.',
      weaknesses: 'Pas de garantie, assortiment limité, pas de service.',
      positioning: "Mettre en avant la garantie, la régularité et le confort d'achat.",
    },
  ],
  risks: [
    { label: "Baisse du pouvoir d'achat affectant les ventes", category: 'Commercial', probability: 4, impact: 4, mitigation: 'Gamme à plusieurs niveaux de prix, promotions ciblées, maîtrise stricte des charges fixes.' },
    { label: "Hausse des prix d'approvisionnement", category: 'Financier', probability: 4, impact: 3, mitigation: 'Négociation fournisseurs, achats groupés, révision périodique des prix de vente.' },
    { label: 'Vol ou perte de marchandises / de recettes', category: 'Sécurité', probability: 3, impact: 3, mitigation: 'Procédures de caisse, rapprochement quotidien, sécurisation des locaux.' },
    { label: 'Panne du matériel essentiel (froid, caisse)', category: 'Technique', probability: 2, impact: 4, mitigation: "Contrat d'entretien, fournisseur de secours, fonds de réserve technique." },
    { label: 'Concurrence nouvelle à proximité immédiate', category: 'Commercial', probability: 3, impact: 3, mitigation: "Fidélisation (carte, service), différenciation par l'offre et l'expérience client." },
  ],
  feasibility: {
    technique: 'Locaux et équipements identifiés : [adresse / type], état général [bon / à rénover]. Équipements requis : [liste] — disponibles localement pour un budget de [montant]. Compétences du porteur : [expérience dans le domaine].',
    economique: 'Marge commerciale moyenne estimée : [x %] ; seuil de rentabilité atteint avec [nombre] ventes / clients par jour. Points de vigilance : charges fixes (loyer, salaires, énergie) et rotation du stock.',
    juridique: 'Statut envisagé : [forme]. Obligations : patente, registre de commerce, agrément sanitaire le cas échéant, affichage des prix. Coût et délais des formalités : [à préciser].',
    organisationnelle: "Organisation de démarrage : [nombre] employés (vente, production / cuisine, caisse). Processus : achats, contrôle des stocks, caisse et suivi quotidien des recettes.",
    commerciale: 'Trafic de la zone confirmé par [observation]. Canaux : vente sur place, commandes par téléphone / WhatsApp, livraison. Politique de prix : [positionnement par rapport aux concurrents].',
  },
}

// ---------------------------------------------------------------------------
// Profil SERVICES : conseil, finance, médias, éducation, santé…
// ---------------------------------------------------------------------------

const services: SectorExamples = {
  swot: {
    strengths: [
      "Expertise reconnue du porteur en [domaine] et approche personnalisée.",
      'Faibles besoins en immobilisation : démarrage léger et souple.',
      'Réseau professionnel déjà constitué (anciens employeurs, clients, partenaires).',
    ],
    weaknesses: [
      'Notoriété à construire : aucune référence commerciale au lancement.',
      'Dépendance au temps du porteur : revenus limités par sa capacité personnelle.',
      "Pas de revenus récurrents tant qu'aucun contrat cadre n'est signé.",
    ],
    opportunities: [
      'Entreprises et institutions en recherche croissante de prestataires spécialisés.',
      'Possibilité de constituer un réseau de partenaires pour accroître la capacité.',
      'Digitalisation : visibilité à moindre coût (réseaux professionnels, site vitrine).',
    ],
    threats: [
      'Concurrence de prestataires expérimentés et de structures déjà établies.',
      'Cycles de décision longs chez les clients institutionnels (paiements à 30-90 jours).',
      'Activité sensible à la conjoncture : les budgets de services sont souvent réduits en premier.',
    ],
  },
  pestel: {
    politique: "Commandes publiques et programmes d'appui aux PME ou à la formation : opportunités d'appels d'offres. Suivre les procédures de passation et les délais de paiement administratifs.",
    economique: "Budgets clients serrés ; arbitrage entre prestataires externes et ressources internes. À chiffrer : prix de journée, coût de revient d'une mission, taux d'utilisation cible (jours facturés / jours ouvrés).",
    socioculturel: 'Demande de professionnalisation et de compétences pratiques ; attentes de résultats mesurables. Adapter l\u2019offre : formats courts, accompagnement, éventuellement langue locale.',
    technologique: 'Outils collaboratifs et visioconférence réduisent les coûts et élargissent la zone d\u2019intervention. Protéger les données clients (sauvegarde, mots de passe, confidentialité).',
    ecologique: 'Activité de bureau : impact limité ; privilégier la dématérialisation (documents, factures) et optimiser les déplacements.',
    legal: 'Cadre à clarifier : statut juridique, régime fiscal des prestations, contrats types (conditions générales, confidentialité). Certains métiers exigent un agrément ou une inscription professionnelle : [à vérifier].',
  },
  pestelChips: {
    politique: [
      'Commandes publiques de services : [appels d\u2019offres, prestations récurrentes] — procédures à suivre.',
      'Appuis aux PME et prestataires : [guichet unique, exonérations, programmes].',
      'Réglementation du métier : [agréments, ordres professionnels] — à vérifier.',
    ],
    economique: [
      'Budgets de la cible : [prix de journée, forfaits pratiqués] et fréquence d\u2019achat.',
      'Délais de paiement : [pratiques constatées] — trésorerie nécessaire pour tenir.',
      'Charges fixes : [local, connectivité, personnel] — seuil de rentabilité en jours facturés.',
    ],
    socioculturel: [
      'Attentes des clients : [qualité, confiance, résultats mesurables].',
      'Réputation et bouche-à-oreille : [importance dans la zone].',
      'Évolution des besoins : [nouveaux usages, formats courts, accompagnement].',
    ],
    technologique: [
      'Outils de travail : [visioconférence, CRM, facturation] — coûts et maîtrise.',
      'Canaux digitaux : [site vitrine, réseaux professionnels] — visibilité à moindre coût.',
      'Protection des données clients : [sauvegardes, confidentialité].',
    ],
    ecologique: [
      'Dématérialisation possible : [factures, documents] — économies et image.',
      'Déplacements : [optimisation, visioconférence] — coûts et empreinte.',
      'Consommation du local : [énergie, papier] — réductions possibles.',
    ],
    legal: [
      'Statut et fiscalité : [forme juridique, régime des prestations].',
      'Contrats types : [conditions générales, confidentialité, pénalités de retard].',
      'Assurance professionnelle : [responsabilité civile] — coût et couverture.',
    ],
  },
  market: {
    demande: "Qui a besoin du service ? « Les [type de clients] de [ville] font appel à des prestataires pour [besoin] environ [fréquence]. » Évaluer le nombre de clients potentiels et le budget qu'ils consacrent à ce besoin.",
    offre: 'Recenser les prestataires actifs : nombre, spécialités, tarifs, références. Identifier les créneaux non couverts : [spécialisation, langue, zone géographique, créneau horaire].',
    segments: 'Segment 1 : [PME] — besoins récurrents, budget modéré. Segment 2 : [institutions / ONG] — projets d\u2019envergure via appels d\u2019offres. Segment 3 : [particuliers] — volume faible mais utile pour la visibilité.',
    cible: 'Cible prioritaire : [segment]. Stratégie d\u2019entrée : [2-3 missions à prix d\u2019appel pour constituer des références, partenariats avec des acteurs établis].',
    zones: "Zone d'intervention : [ville(s) / national / à distance]. Déplacements prévus : [fréquence, coût]. Livrables à distance possibles : [rapports, formations en ligne, suivi à distance].",
    tendances: 'Tendances : externalisation croissante des fonctions supports, exigence de résultats chiffrés, montée du travail hybride. Citer des exemples observés dans votre réseau.',
    conclusion: 'Le besoin est-il récurrent et solvable ? Conditions de succès : références solides dès la première année, trésorerie adaptée aux délais de paiement, spécialisation claire.',
  },
  needs: [
    { label: 'Clients de référence pour lancer l\u2019activité', target: 'Réseau personnel / appels d\u2019offres / recommandation', frequency: 'Ponctuelle puis récurrente' },
    { label: 'Outils de travail et licences logicielles', target: 'Fournisseurs informatiques', frequency: "À l'installation puis renouvellement" },
    { label: 'Visibilité professionnelle (site, supports, réseaux sociaux)', target: 'Prestataires de communication', frequency: 'Au lancement puis mise à jour annuelle' },
  ],
  competitors: [
    {
      name: 'Cabinets / prestataires établis',
      type: 'Concurrent direct',
      strengths: 'Références solides, équipes structurées, crédibilité institutionnelle.',
      weaknesses: 'Tarifs élevés, processus lourds, peu flexibles pour les petits clients.',
      positioning: 'Proposer une offre spécialisée, réactive et à coût maîtrisé pour les PME.',
    },
    {
      name: 'Consultants indépendants informels',
      type: 'Concurrent indirect',
      strengths: 'Prix bas, souplesse.',
      weaknesses: 'Absence de garanties, de contrat et de suivi.',
      positioning: 'Valoriser la qualité contractuelle, la continuité de service et les résultats mesurables.',
    },
  ],
  risks: [
    { label: 'Délais de paiement longs fragilisant la trésorerie', category: 'Financier', probability: 4, impact: 4, mitigation: 'Acompte à la commande, échéancier contractuel, provision de trésorerie de 3 mois de charges.' },
    { label: 'Dépendance à 1-2 clients majeurs', category: 'Commercial', probability: 3, impact: 4, mitigation: 'Plafonner un client à [x %] du chiffre d\u2019affaires, prospection continue, diversification de l\u2019offre.' },
    { label: 'Difficulté à recruter et retenir des compétences clés', category: 'Organisationnel', probability: 3, impact: 3, mitigation: 'Partenariats écoles / universités, réseau de freelances, politique de rémunération motivante.' },
    { label: 'Image impactée par un livrable de qualité insuffisante', category: 'Réputation', probability: 2, impact: 4, mitigation: 'Revue qualité systématique avant livraison, charte de service, gestion des réclamations.' },
    { label: 'Évolution rapide des besoins et des normes du métier', category: 'Stratégique', probability: 3, impact: 3, mitigation: 'Veille professionnelle, formation continue, partenariats avec des spécialistes.' },
  ],
  feasibility: {
    technique: 'Compétences disponibles : [domaines + niveau]. Outils nécessaires : [matériel, logiciels, licences] — budget estimé [montant]. Méthodologie éprouvée : [approche, standards du métier].',
    economique: 'Tarification : [prix / jour ou forfait] ; coût de revient journalier : [montant] ; seuil de rentabilité : [nombre] jours facturés par mois. Scénario prudent : taux d\u2019utilisation de 60 %.',
    juridique: 'Statut : [forme]. Vérifier : obligations fiscales, assurance responsabilité civile professionnelle, éventuel agrément. Préparer des contrats types (conditions générales de vente, confidentialité).',
    organisationnelle: 'Structure légère : porteur + [associés / freelances]. Processus : qualification du besoin, devis, exécution, facturation, suivi client. Outils de gestion : agenda partagé, suivi des temps, comptabilité.',
    commerciale: "Accès au premier portefeuille : réseau personnel, appels d'offres, partenariats. Proposition de valeur : [spécialisation + résultats mesurables]. Objectif : [nombre] clients actifs à 12 mois.",
  },
}

// ---------------------------------------------------------------------------
// Profil TECH : technologie & numérique
// ---------------------------------------------------------------------------

const tech: SectorExamples = {
  swot: {
    strengths: [
      'Solution innovante répondant à un problème concret identifié sur le terrain.',
      'Coûts de structure faibles : développement et distribution numériques.',
      "Agilité : adaptation rapide du produit selon les retours utilisateurs.",
    ],
    weaknesses: [
      'Notoriété nulle au lancement ; confiance des premiers utilisateurs à gagner.',
      'Dépendance à un petit nombre de développeurs / au porteur technique.',
      'Modèle économique à valider : disposition à payer des clients encore incertaine.',
    ],
    opportunities: [
      'Pénétration croissante d\u2019Internet et du mobile dans la cible.',
      'Digitalisation encouragée dans les secteurs cibles [éducation, commerce, agriculture…].',
      'Partenariats possibles avec des opérateurs, banques ou institutions.',
    ],
    threats: [
      'Évolution rapide des technologies exigeant une mise à jour permanente.',
      'Entrée possible d\u2019acteurs internationaux mieux financés.',
      'Dépendance aux infrastructures locales (électricité, réseau, paiement mobile).',
    ],
  },
  pestel: {
    politique: 'Stratégie nationale de transformation numérique, soutien aux startups (labels, incubateurs, concours). Suivre la réglementation sur les données personnelles et les plateformes.',
    economique: "Pouvoir d'achat et disposition à payer pour des services numériques à évaluer précisément ; coûts d'hébergement en devis fort. Chiffrer le coût d'acquisition client dès les premiers mois.",
    socioculturel: 'Adoption rapide chez les jeunes ; méfiance possible chez les utilisateurs moins familiarisés — prévoir un parcours simple et un accompagnement (tutoriels, support WhatsApp).',
    technologique: 'Écosystème favorable : paiement mobile répandu, hébergement cloud à coût maîtrisé, outils open source. Prévoir la performance sur terminaux d\u2019entrée de gamme et un mode hors-ligne pour les connexions instables.',
    ecologique: 'Empreinte des serveurs à optimiser (hébergement sobre, compression des données) ; allonger la durée de vie des équipements ; limiter la consommation des applications.',
    legal: 'Protection des données personnelles, conditions générales d\u2019utilisation et de vente, propriété intellectuelle du code, contrats de développement. Formaliser ces points dès le départ.',
  },
  pestelChips: {
    politique: [
      'Stratégie numérique nationale : [labels startups, incubateurs, concours] — dispositifs mobilisables.',
      'Régulation du secteur : [protection des données, licences de plateformes].',
      'Marchés publics numériques : [opportunités, procédures de passation].',
    ],
    economique: [
      'Disposition à payer de la cible : [montant par mois] — à valider par un pilote.',
      'Coûts en devises : [hébergement, licences] — impact du taux de change.',
      'Financement : [fonds d\u2019amorçage, concours, investisseurs] disponibles.',
    ],
    socioculturel: [
      'Adoption du numérique : [smartphones, mobile money] dans la cible.',
      'Confiance envers les solutions locales : [freins, leviers].',
      'Accompagnement nécessaire : [tutoriels, support WhatsApp] pour les moins familiers.',
    ],
    technologique: [
      'Infrastructure : [réseau mobile, électricité, cloud] — fiabilité constatée.',
      'Paiement mobile : [intégrations disponibles] pour encaisser.',
      'Terminaux de la cible : [entrée de gamme] — performance et mode hors-ligne à prévoir.',
    ],
    ecologique: [
      'Hébergement sobre : [optimisation, compression des données] — coûts et image.',
      'Durée de vie du matériel : [reconditionné, recyclage].',
      'Consommation des applications : [optimisation data] pour les connexions faibles.',
    ],
    legal: [
      'Données personnelles : [loi applicable, consentement, sécurité].',
      'Propriété intellectuelle : [dépôt de marque, cession des droits sur le code].',
      'Conditions d\u2019utilisation et de vente : [CGU / CGV, responsabilité].',
    ],
  },
  market: {
    demande: 'Problème ciblé : [problème] touchant [type d\u2019utilisateurs]. Évaluer : nombre d\u2019utilisateurs potentiels, solutions utilisées aujourd\u2019hui, disposition à payer [montant] par [période].',
    offre: 'Solutions existantes : [applications, tableurs, groupes WhatsApp, procédés manuels]. Leurs limites : [coût, fiabilité, couverture]. Notre différenciation : [valeur unique].',
    segments: 'Segment 1 : [B2B — PME] : besoin de productivité, budget disponible. Segment 2 : [B2C — particuliers] : volume important, monétisation freemium. Segment 3 : [institutions] : contrats plus longs et stables.',
    cible: 'Cible de lancement : [segment]. Stratégie : programme pilote avec [nombre] utilisateurs, collecte de retours, itérations. Indicateurs : taux d\u2019activation, rétention à 30 jours, utilisateurs actifs hebdomadaires.',
    zones: 'Zone de lancement : [ville / campus / secteur] pour concentrer les efforts ; extension ensuite à [zones]. Distribution : [application, site web, agents / relais locaux].',
    tendances: 'Croissance des paiements mobiles, usage massif de WhatsApp, besoin de solutions hors-ligne. Appuyer la stratégie produit sur ces usages observés.',
    conclusion: "Valider le problème, la solution et la disposition à payer via un pilote avant d'investir davantage. Conditions de succès : rétention des utilisateurs, coût d'acquisition maîtrisé, fiabilité technique.",
  },
  needs: [
    { label: 'Utilisateurs pilotes pour tester et améliorer la solution', target: 'Communautés ciblées / partenaires terrain', frequency: 'Au lancement puis en continu' },
    { label: 'Hébergement et services cloud fiables', target: 'Fournisseurs cloud', frequency: 'Permanente' },
    { label: 'Visibilité et acquisition (réseaux sociaux, référencement)', target: 'Agences / marketing digital', frequency: 'Continue' },
  ],
  competitors: [
    {
      name: 'Applications / plateformes existantes sur le même besoin',
      type: 'Concurrent direct',
      strengths: 'Fonctionnalités étendues, base utilisateurs installée.',
      weaknesses: 'Prix élevés, adaptation locale limitée, support faible.',
      positioning: 'Gagner sur la simplicité, le support local et un prix adapté au marché.',
    },
    {
      name: 'Procédés actuels des utilisateurs (tableur, papier, groupes WhatsApp)',
      type: 'Substitut potentiel',
      strengths: 'Gratuit ou perçu comme gratuit, habitude installée.',
      weaknesses: 'Erreurs, aucun suivi, pas d\u2019automatisation.',
      positioning: 'Démontrer le gain de temps et de fiabilité par un pilote chiffré.',
    },
  ],
  risks: [
    { label: 'Faible adoption / rétention des utilisateurs', category: 'Commercial', probability: 4, impact: 5, mitigation: 'Pilote utilisateurs, itérations rapides, parcours simplifié, support réactif.' },
    { label: 'Dépendance au développeur clé', category: 'Organisationnel', probability: 3, impact: 4, mitigation: 'Documentation technique, droits sur le code, compétences de secours (second développeur).' },
    { label: 'Infrastructures instables (coupures réseau / électricité)', category: 'Technique', probability: 4, impact: 3, mitigation: 'Mode hors-ligne, optimisation des données, hébergement redondant.' },
    { label: 'Sécurité des données et fraude', category: 'Sécurité', probability: 3, impact: 4, mitigation: 'Chiffrement, sauvegardes régulières, audit de sécurité, conformité légale.' },
    { label: 'Modèle économique non rentable à temps', category: 'Financier', probability: 3, impact: 4, mitigation: 'Tester plusieurs sources de revenus (abonnement, commission, services), maîtriser le taux de consommation.' },
  ],
  feasibility: {
    technique: 'Technologies retenues : [stack] — maîtrisées par l\u2019équipe. Architecture simple et évolutive ; tests sur terminaux bas de gamme. Plan de maintenance et de mises à jour défini.',
    economique: 'Coûts : développement [montant], hébergement [montant / mois], acquisition client [montant]. Revenus : [abonnement de X par mois] ; point mort à [nombre] abonnés. Chiffrer les scénarios optimiste et prudent.',
    juridique: 'Statut de la société : [forme]. Protection : dépôt de la marque, conditions d\u2019utilisation, politique de confidentialité conforme à la loi sur les données personnelles. Contrats des développeurs cédant les droits.',
    organisationnelle: 'Équipe : [rôles : produit, technique, commercial]. Organisation : méthode agile, revues hebdomadaires, support utilisateur attribué. Décisions produit documentées.',
    commerciale: "Canal d'acquisition principal : [partenariats, réseaux sociaux, terrain]. Proposition : essai gratuit + accompagnement à l'inscription. Objectif : [nombre] utilisateurs actifs à 6 mois.",
  },
}

// ---------------------------------------------------------------------------
// Profil INFRA : BTP, transport & logistique, énergie & environnement
// ---------------------------------------------------------------------------

const infra: SectorExamples = {
  swot: {
    strengths: [
      'Savoir-faire technique du porteur et équipe opérationnelle constituée.',
      'Besoins d\u2019infrastructure et de services en forte croissance dans la zone.',
      "Maîtrise des coûts d'exécution grâce à une organisation éprouvée.",
    ],
    weaknesses: [
      'Besoin important de trésorerie pour les avances (chantier, carburant, matériel).',
      'Dépendance à un petit nombre d\u2019équipements critiques (pannes coûteuses).',
      'Peu de références contractuelles formelles au démarrage.',
    ],
    opportunities: [
      'Marchés publics et projets d\u2019aménagement dans la région.',
      'Sous-traitance auprès de grandes entreprises du secteur pour bâtir des références.',
      'Croissance urbaine : demande continue de services [construction, transport, énergie].',
    ],
    threats: [
      "Délais de paiement longs chez les donneurs d'ordre (publics notamment).",
      'Volatilité des prix des matériaux et du carburant.',
      'Concurrence d\u2019entreprises mieux outillées ou d\u2019acteurs informels à prix bas.',
    ],
  },
  pestel: {
    politique: "Programmes publics d'infrastructures, d'électrification ou d'assainissement : opportunités de marchés. Vigilance : procédures d'appels d'offres, cautions et délais de paiement administratifs.",
    economique: 'Coûts des intrants (matériaux, carburant) très variables : prévoir l\u2019indexation des devis. À chiffrer : coût horaire d\u2019un équipement, marge par opération, impact d\u2019un retard de paiement sur la trésorerie.',
    socioculturel: 'Exigence croissante de qualité et de sécurité ; importance des recommandations et de la réputation locale. L\u2019emploi local est un facteur d\u2019acceptabilité et de stabilité.',
    technologique: 'Matériel plus efficient disponible (économie de carburant, précision) ; outils de suivi digital des chantiers et des flottes. Prévoir la maintenance et les pièces de rechange.',
    ecologique: 'Normes environnementales à respecter (déchets de chantier, émissions, bruit) ; opportunité de solutions propres [solaire, recyclage] valorisées par les clients.',
    legal: "Obligations : qualification de l'entreprise, assurances (chantier, responsabilité civile), normes de sécurité du travail, permis spécifiques selon l'activité. Constituer un dossier administratif complet.",
  },
  pestelChips: {
    politique: [
      'Programmes publics : [infrastructures, électrification, aménagements] — calendrier des projets.',
      'Marchés publics : [accès PME locales, cautions, délais de paiement].',
      'Politiques environnementales : [normes, incitations au solaire / propre].',
    ],
    economique: [
      'Prix des matériaux et du carburant : [volatilité] — clauses de révision des devis.',
      'Délais de paiement du secteur : [pratiques] — trésorerie à sécuriser.',
      'Coût horaire des équipements : [chiffrage] — taux d\u2019utilisation visé.',
    ],
    socioculturel: [
      'Emploi local : [facteur d\u2019acceptabilité, stabilité des équipes].',
      'Réputation et recommandations : [importance pour obtenir des contrats].',
      'Exigences de qualité et de sécurité : [attentes des donneurs d\u2019ordre].',
    ],
    technologique: [
      'Équipements efficients : [économie de carburant, précision] — coût vs gain.',
      'Suivi digital : [chantiers, flottes] — outils disponibles.',
      'Maintenance et pièces de rechange : [disponibilité locale].',
    ],
    ecologique: [
      'Normes environnementales : [déchets de chantier, émissions, bruit].',
      'Solutions propres : [solaire, recyclage] — valorisées par les clients.',
      'Saisonnalité climatique : [pluies] — planning des travaux.',
    ],
    legal: [
      'Qualification de l\u2019entreprise : [agréments, catégories de travaux].',
      'Assurances : [chantier, responsabilité civile] — obligations.',
      'Sécurité du travail : [équipements de protection, formation].',
    ],
  },
  market: {
    demande: 'Identifier les besoins et les donneurs d\u2019ordre : « [nombre] projets identifiés dans la zone sur [période], pour un besoin estimé à [volume / valeur]. » Clients potentiels : particuliers, entreprises, collectivités, ONG.',
    offre: 'Recenser les entreprises du secteur actives localement : capacités, équipements, réputation. Détecter les segments mal servis : [petites opérations, livraisons spécifiques, maintenance].',
    segments: 'Segment 1 : [particuliers] : petites opérations, paiement rapide. Segment 2 : [entreprises] : sous-traitance récurrente. Segment 3 : [institutions] : gros volumes, procédures formelles.',
    cible: 'Cible prioritaire : [segment]. Entrée par [sous-traitance / petites opérations] pour constituer des références, puis montée en gamme progressive.',
    zones: "Zone d'activité : [rayon géographique] ; contraintes logistiques : [routes, distances, carburant]. Base d'opérations : [dépôt, garage, bureau].",
    tendances: 'Croissance urbaine, investissements publics, exigence de conformité environnementale. Observer les projets en cours et le calendrier des financements annoncés.',
    conclusion: 'La demande est-elle suffisante et solvable pour atteindre le seuil de rentabilité de la structure ? Conditions de succès : références, trésorerie solide, fiabilité des équipements.',
  },
  needs: [
    { label: "Équipements et matériel d'exécution", target: "Loueurs / fournisseurs d'équipements", frequency: "À l'installation puis maintenance régulière" },
    { label: 'Personnel technique qualifié et certifié', target: "Marché local / centres de formation", frequency: 'Permanente' },
    { label: 'Avances de trésorerie pour opérer', target: 'Banque / microfinance / apporteurs', frequency: 'Par opération ou contrat' },
  ],
  competitors: [
    {
      name: 'Entreprises établies du secteur',
      type: 'Concurrent direct',
      strengths: 'Équipements lourds, références, capacité de caution.',
      weaknesses: 'Charges lourdes, prix élevés, peu présentes sur les petits contrats.',
      positioning: 'Cibler les opérations de taille intermédiaire avec des délais courts et des prix compétitifs.',
    },
    {
      name: 'Acteurs informels du secteur',
      type: 'Concurrent indirect',
      strengths: 'Prix bas, flexibilité immédiate.',
      weaknesses: 'Ni garantie, ni sécurité, ni recours en cas de litige.',
      positioning: 'Valoriser la sécurité, la conformité et la garantie de résultat.',
    },
  ],
  risks: [
    { label: 'Retards de paiement fragilisant la trésorerie', category: 'Financier', probability: 4, impact: 5, mitigation: 'Échéanciers contractuels, acomptes systématiques, ligne de crédit de trésorerie, pénalités de retard.' },
    { label: "Panne d'un équipement critique arrêtant l'activité", category: 'Technique', probability: 3, impact: 4, mitigation: 'Maintenance préventive, solution de remplacement en location, fonds de réserve équipement.' },
    { label: 'Accident du travail sur site', category: 'Sécurité', probability: 3, impact: 5, mitigation: "Équipements de protection, formation sécurité, assurances, procédures d'urgence." },
    { label: 'Hausse imprévue des prix des matériaux ou du carburant', category: 'Financier', probability: 4, impact: 3, mitigation: 'Clauses de révision de prix dans les devis, achats anticipés, fournisseurs multiples.' },
    { label: "Dépendance à un donneur d'ordre principal", category: 'Commercial', probability: 3, impact: 4, mitigation: 'Diversifier le portefeuille clients, prospection continue, plafond de dépendance.' },
  ],
  feasibility: {
    technique: 'Capacité technique : équipements [liste] en propriété ou en location ; équipe de [nombre] personnes dont [corps de métier]. Partenaires pour les compétences spécialisées : [bureaux d\u2019études, laboratoires].',
    economique: "Structure de coûts par opération : [détail] ; marge visée [x %] ; point mort à [volume] d'activité. Vigilance : taux d'utilisation des équipements et saisonnalité de l'activité.",
    juridique: 'Autorisations : [qualification entreprise, assurances, permis]. Intégrer la conformité sécurité du travail et environnement dans les coûts. Formaliser des contrats types (marché, sous-traitance).',
    organisationnelle: 'Organisation : chef d\u2019équipe / superviseur, planning, suivi des stocks et du carburant. RH : recrutement local, formation sécurité. Reporting : rapport d\u2019avancement par opération.',
    commerciale: "Accès aux marchés : appels d'offres, référencement auprès des grandes entreprises, réseau local. Argumentaire : fiabilité, délais, sécurité. Objectif : [nombre] contrats à 12 mois.",
  },
}

// ---------------------------------------------------------------------------
// Profil GÉNÉRIQUE : "Autre" ou secteur non reconnu
// ---------------------------------------------------------------------------

const generic: SectorExamples = {
  swot: {
    strengths: [
      'Compétence et expérience du porteur dans l\u2019activité proposée.',
      'Avantage différenciant identifié : [qualité, prix, service, proximité…].',
      'Coûts de structure maîtrisés au démarrage.',
    ],
    weaknesses: [
      'Notoriété à construire auprès de la clientèle visée.',
      'Trésorerie limitée pour financer la croissance et absorber les imprévus.',
      'Dépendance à quelques fournisseurs ou partenaires clés.',
    ],
    opportunities: [
      'Demande locale en croissance pour [produit / service].',
      'Canaux de vente complémentaires possibles : [en ligne, partenariats, institutions].',
      'Appuis disponibles : [programmes d\u2019appui aux entreprises, incubateurs, réseaux].',
    ],
    threats: [
      'Concurrence existante ou nouvelle entrée sur le marché.',
      'Hausse possible des coûts d\u2019approvisionnement ou d\u2019exploitation.',
      'Évolution de la réglementation ou de la demande.',
    ],
  },
  pestel: {
    politique: "Politiques publiques concernées : [appuis aux entreprises, réglementation sectorielle, fiscalité locale]. À vérifier : démarches administratives et stabilité des règles applicables à l'activité.",
    economique: "Pouvoir d'achat de la clientèle visée, inflation sur les coûts, accès au crédit. À chiffrer : prix de vente moyen, coût de revient, marge, impact d'une hausse de 10 % des charges.",
    socioculturel: 'Habitudes de consommation de la clientèle visée, saisonnalité de la demande, attentes de qualité. À confirmer par une enquête terrain auprès de [nombre] clients potentiels.',
    technologique: 'Équipements et outils disponibles pour l\u2019activité ; digitalisation possible de la commercialisation ou de la gestion. Prévoir la maintenance et le renouvellement.',
    ecologique: 'Impact environnemental de l\u2019activité : [déchets, énergie, ressources]. Opportunité : pratiques durables valorisées par les clients et partenaires.',
    legal: "Formalités : [enregistrement, licences, normes applicables, assurances]. Établir la liste précise, le coût et le calendrier des autorisations nécessaires.",
  },
  pestelChips: {
    politique: [
      'Appuis publics disponibles : [programmes PME, subventions, agences d\u2019appui].',
      'Réglementation sectorielle : [règles applicables à l\u2019activité].',
      'Fiscalité locale : [taxes, patente] — coûts à intégrer.',
    ],
    economique: [
      'Pouvoir d\u2019achat de la cible : [prix moyen accepté].',
      'Évolution des coûts : [intrants, charges] sur les 12 derniers mois.',
      'Accès au financement : [taux, garanties exigées, alternatives].',
    ],
    socioculturel: [
      'Habitudes de consommation : [occasions, fréquence, lieux].',
      'Démographie de la zone : [croissance, urbain / rural].',
      'Perception de l\u2019offre : [freins et leviers culturels].',
    ],
    technologique: [
      'Équipements disponibles localement : [état des lieux].',
      'Digitalisation possible : [mobile money, commandes en ligne, réseaux sociaux].',
      'Compétences à renforcer : [formation, recrutement].',
    ],
    ecologique: [
      'Aléas climatiques : [constat, adaptations prévues].',
      'Déchets et ressources : [gestion, valorisation].',
      'Attentes environnementales des clients : [signaux].',
    ],
    legal: [
      'Formalités : [enregistrement, licences, assurances].',
      'Normes du secteur : [hygiène, sécurité, qualité].',
      'Contrats clés : [baux, clients, fournisseurs] — clauses importantes.',
    ],
  },
  market: {
    demande: 'Qui achète le produit / service ? En quelle quantité et à quelle fréquence ? Exemple : « Les [type de clients] de [ville] dépensent environ [montant] par [période] pour ce besoin, avec un pic à [période]. »',
    offre: 'Recenser les acteurs qui répondent déjà au besoin : nombre, capacité, prix, points forts et faibles. Identifier ce que l\u2019offre actuelle ne couvre pas.',
    segments: 'Segment 1 : [type de clients] — caractéristiques, volume, attentes. Segment 2 : [type de clients] — idem. Segment 3 : [type de clients] — idem.',
    cible: 'Cible prioritaire : [segment] car [raison : volume, marge, accessibilité]. Premiers clients à démarcher : [types, noms, lieux].',
    zones: "Zone de chalandise ou d'intervention : [ville / quartiers / rayon km]. Logistique : [transport, délais, coûts de livraison ou de déplacement].",
    tendances: 'Tendances observées : évolution de la demande, nouveaux usages, digitalisation. Citer des signaux concrets relevés sur le terrain.',
    conclusion: 'Le marché justifie-t-il le lancement ? Conditions de succès : [différenciation, contrats en amont, gestion des coûts, qualité constante].',
  },
  needs: [
    { label: 'Approvisionnement / ressources nécessaires à l\u2019activité', target: 'Fournisseurs identifiés', frequency: 'Hebdomadaire ou par cycle' },
    { label: 'Personnel formé aux activités clés', target: "Marché local de l'emploi", frequency: 'Permanente' },
    { label: 'Équipements et outils de production / service', target: "Fournisseurs d'équipements", frequency: "À l'installation" },
  ],
  competitors: [
    {
      name: 'Acteurs établis de la zone',
      type: 'Concurrent direct',
      strengths: 'Clientèle fidélisée, prix connus, expérience.',
      weaknesses: 'Qualité ou service inégaux, peu de souplesse.',
      positioning: 'Se différencier par [service, qualité, régularité, proximité].',
    },
    {
      name: 'Alternatives utilisées par les clients (fait maison, importation…)',
      type: 'Concurrent indirect',
      strengths: 'Prix parfois plus bas, habitudes installées.',
      weaknesses: 'Régularité, garantie et service limités.',
      positioning: 'Valoriser la fiabilité, la garantie et le gain de temps pour le client.',
    },
  ],
  risks: [
    { label: 'Demande inférieure aux prévisions au démarrage', category: 'Commercial', probability: 3, impact: 4, mitigation: 'Valider la demande par une enquête et des pré-commandes, ajuster l\u2019offre et communiquer localement.' },
    { label: 'Hausse des coûts de fonctionnement', category: 'Financier', probability: 3, impact: 3, mitigation: 'Fournisseurs multiples, suivi mensuel des coûts, clause de révision des prix.' },
    { label: 'Retard des autorisations nécessaires', category: 'Juridique', probability: 3, impact: 4, mitigation: 'Anticiper les démarches, se faire accompagner, prévoir un calendrier réaliste.' },
    { label: 'Indisponibilité du personnel clé', category: 'Organisationnel', probability: 2, impact: 3, mitigation: 'Former une personne de remplacement, documenter les procédures.' },
    { label: 'Impayés ou retards de paiement des clients', category: 'Financier', probability: 3, impact: 3, mitigation: 'Acompte à la commande, plafond d\u2019encours par client, relances structurées.' },
  ],
  feasibility: {
    technique: 'Compétences et équipements nécessaires : [liste] ; disponibles localement à [budget]. Expérience du porteur : [à préciser]. Besoins de formation : [sujets].',
    economique: 'Marges estimées à partir des prix du marché : [x %] ; seuil de rentabilité à [volume / période]. Chiffrer un scénario prudent (coûts +10 %, ventes -10 %).',
    juridique: 'Forme juridique : [forme]. Autorisations et assurances requises : [liste]. Coût et délais : [à préciser].',
    organisationnelle: 'Équipe de démarrage : [nombre] personnes et rôles. Partenaires : [fournisseurs, appuis techniques]. Processus de gestion : [achats, stocks, trésorerie, comptabilité].',
    commerciale: 'Accès aux clients : [localisation, canaux, réseau]. Proposition de valeur : [avantage différenciant]. Objectif commercial année 1 : [nombre de clients / volume].',
  },
}

// ---------------------------------------------------------------------------
// Sélection du profil selon le secteur du projet
// ---------------------------------------------------------------------------

const PROFILES: Array<{ keys: string[]; examples: SectorExamples }> = [
  { keys: ['Agriculture', 'Élevage', 'Agroalimentaire', 'Artisanat', 'Production'], examples: production },
  { keys: ['Commerce', 'Distribution', 'Restauration', 'Hôtellerie'], examples: commerce },
  { keys: ['Technologie', 'Numérique'], examples: tech },
  { keys: ['Bâtiment', 'Travaux', 'Transport', 'Logistique', 'Énergie', 'Environnement'], examples: infra },
  { keys: ['Services', 'Conseil', 'Finance', 'Microfinance', 'Communication', 'Médias', 'Éducation', 'Formation', 'Santé', 'Bien-être'], examples: services },
]

export function sectorExamples(sector?: string | null): SectorExamples {
  const s = (sector || '').toLowerCase()
  for (const p of PROFILES) {
    if (p.keys.some((k) => s.includes(k.toLowerCase()))) return p.examples
  }
  return generic
}

// ---------------------------------------------------------------------------
// Modèles à compléter (indépendants du secteur)
// ---------------------------------------------------------------------------

export const OVERVIEW_TEMPLATES = {
  vision: "Devenir, d'ici [5] ans, la référence [régionale / nationale] en [activité], reconnue pour [avantage différenciant] et au service de [clientèle].",
  mission: "[Nom de l'entreprise] fournit [produit / service] de qualité à [clientèle cible], en s'appuyant sur [atouts : équipe, proximité, innovation], afin de [bénéfice pour le client] tout en créant des emplois durables.",
  summary: [
    'Présenté par [porteur], le projet [nom] consiste à [activité principale] à [lieu].',
    'Le marché : [besoin constaté, clientèle visée, concurrence existante].',
    'Le modèle : [comment l\u2019entreprise gagne de l\u2019argent : produits, prix, canaux de vente].',
    'Le financement : le projet requiert [montant total], financé par [apport, emprunt, subvention], dont [montant] d\u2019investissements et [montant] de fonds de roulement.',
    'Les résultats attendus : [chiffre d\u2019affaires année 1], [résultat net], [emplois créés], rentabilité prévue dès [période].',
  ].join('\n'),
}

export const SYNTHESIS_TEMPLATE = [
  'Attractivité : [le marché visé est en croissance / le besoin est récurrent et solvable…].',
  'Position concurrentielle : s\u2019appuyer sur [forces principales] et corriger [faiblesses prioritaires].',
  'Environnement : facteurs PESTEL déterminants pour le projet : [facteurs].',
  'Risques majeurs : [2-3 risques critiques] — mesures prévues : [atténuations].',
  'Conclusion : le projet est [favorable / favorable sous réserves] ; conditions de succès : [conditions].',
].join('\n')

export const RECOMMENDATIONS_TEMPLATE = [
    '1. Valider les hypothèses de marché par une enquête terrain auprès de [nombre] clients potentiels.',
    '2. Sécuriser [contrats d\u2019approvisionnement / clients pilotes / autorisations] avant le lancement.',
    '3. Renforcer [compétence / processus] via [formation / recrutement / partenariat].',
    '4. Mettre en place un suivi mensuel de [trésorerie, ventes, production] avec des indicateurs simples.',
    '5. Finaliser le plan de financement avec [institution / partenaire] et sécuriser le fonds de roulement.',
  ].join('\n')

// Insère un exemple dans un champ texte : remplit si vide, sinon ajoute à la
// suite (sans dupliquer un exemple déjà présent).
export function insertExample(current: string, example: string): string {
  if (!current.trim()) return example
  if (current.includes(example.slice(0, 50))) return current
  return `${current.replace(/\s+$/, '')}\n\n${example}`
}
