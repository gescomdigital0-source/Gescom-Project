// GESCOM PROJECT – Recherche locale contextuelle (pays / région / ville)
//
// Une fois le pays et la région (ou la ville) du projet choisis, la plateforme
// interroge le web (fonction « web_search » du SDK) sur cinq axes propres au
// projet — marché local, réglementation, fiscalité & formalités, financement
// & aides, concurrence & filière — puis synthétise les résultats en un
// rapport structuré en français, avec les vraies sources rencontrées.
//
// Résilience : si la recherche web échoue (réseau, indisponibilité), la
// synthèse IA reste produite à partir des connaissances générales et le
// rapport est marqué « webOk: false » avec une consigne de vérification.
import ZAI from 'z-ai-web-dev-sdk'

export interface ResearchSource {
  title: string
  url: string
  host: string
  date: string
}

export interface CountryResearchResult {
  country: string
  location: string
  searchedAt: string
  webOk: boolean // la recherche web a réellement donné des résultats
  resume: string[]
  marche: string[]
  reglementation: string[]
  fiscalite: string[]
  financement: string[]
  concurrence: string[]
  recommandations: string[]
  sources: ResearchSource[]
}

export interface ResearchInput {
  name: string
  sector: string
  country: string
  location: string
  idea?: string
  legalForm?: string
}

interface Axis {
  key: 'marche' | 'reglementation' | 'fiscalite' | 'financement' | 'concurrence'
  label: string
  query: string
}

const SEARCH_TIMEOUT_MS = 25_000
const SYNTH_TIMEOUT_MS = 120_000

const cut = (s: unknown, n: number): string => {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim()
  return t.length > n ? t.slice(0, n - 1) + '…' : t
}

// ---------------------------------------------------------------------------
// Axes de recherche (adaptés au pays, à la ville et au secteur du projet)
// ---------------------------------------------------------------------------

export function buildResearchAxes(input: ResearchInput): Axis[] {
  const { sector, country, location } = input
  const where = location ? `${country} ${location}` : country
  return [
    {
      key: 'marche',
      label: 'Marché local',
      query: `marché ${sector} ${where} demande prix clients`,
    },
    {
      key: 'reglementation',
      label: 'Réglementation et autorisations',
      query: `réglementation ${sector} ${country} autorisations licence création entreprise`,
    },
    {
      key: 'fiscalite',
      label: 'Fiscalité et formalités',
      query: `formalités création entreprise ${country} impôts taxes régime`,
    },
    {
      key: 'financement',
      label: 'Financement et aides',
      query: `financement entrepreneuriat ${country} subventions aides PME`,
    },
    {
      key: 'concurrence',
      label: 'Concurrence et filière',
      query: `producteurs ${sector} ${country} concurrence filière prix`,
    },
  ]
}

interface RawSearchItem {
  url?: string
  name?: string
  snippet?: string
  host_name?: string
  rank?: number
  date?: string
}

async function searchAxis(zai: Awaited<ReturnType<typeof ZAI.create>>, axis: Axis): Promise<RawSearchItem[]> {
  try {
    const results = (await Promise.race([
      zai.functions.invoke('web_search', { query: axis.query, num: 5 }),
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), SEARCH_TIMEOUT_MS)),
    ])) as RawSearchItem[]
    return Array.isArray(results) ? results : []
  } catch {
    return [] // un axe qui échoue ne bloque pas les autres
  }
}

// ---------------------------------------------------------------------------
// Digest des résultats → prompt de synthèse
// ---------------------------------------------------------------------------

function buildDigest(axes: Axis[], perAxis: RawSearchItem[][]): string {
  const blocks: string[] = []
  axes.forEach((axis, i) => {
    const items = (perAxis[i] || []).filter((r) => r && (r.name || r.snippet)).slice(0, 4)
    if (items.length === 0) return
    const lines = items.map((r, j) => {
      const host = r.host_name || (r.url ? new URL(r.url).hostname.replace(/^www\./, '') : '')
      const date = r.date ? ` (${r.date})` : ''
      return `${j + 1}. ${cut(r.name, 120)} — ${cut(r.snippet, 220)} [source : ${host}${date} | ${r.url || ''}]`
    })
    blocks.push(`AXE « ${axis.label} » (requête : « ${axis.query} »)\n${lines.join('\n')}`)
  })
  return blocks.join('\n\n')
}

function collectSources(axes: Axis[], perAxis: RawSearchItem[][]): ResearchSource[] {
  const seen = new Set<string>()
  const out: ResearchSource[] = []
  perAxis.flat().forEach((r) => {
    if (!r?.url || seen.has(r.url)) return
    seen.add(r.url)
    let host = r.host_name || ''
    try {
      host = host || new URL(r.url).hostname.replace(/^www\./, '')
    } catch {
      /* url malformée : on garde host_name */
    }
    out.push({ title: cut(r.name, 140) || host, url: r.url, host: cut(host, 80), date: cut(r.date, 20) })
  })
  return out.slice(0, 12)
}

// ---------------------------------------------------------------------------
// Synthèse IA
// ---------------------------------------------------------------------------

function systemPrompt(webOk: boolean): string {
  return [
    "Tu es un consultant senior en études de marché et montage de projets d'entreprise en Afrique francophone.",
    'Tu rédiges en français professionnel, concret et chiffré quand les données le permettent.',
    webOk
      ? "Tu synthétises UNIQUEMENT à partir des résultats de recherche web fournis : chaque point doit s'appuyer sur ces résultats. Si une information est absente des résultats, dis-le clairement plutôt que d'inventer un chiffre."
      : "La recherche web est indisponible : tu t'appuies sur tes connaissances générales du pays concerné, en restant prudent : chaque point incertain doit être signalé comme « à vérifier ».",
    "Réponds UNIQUEMENT avec un JSON valide, sans texte autour, au format :",
    '{ "resume": ["…"], "marche": ["…"], "reglementation": ["…"], "fiscalite": ["…"], "financement": ["…"], "concurrence": ["…"], "recommandations": ["…"] }',
    'Chaque liste contient 3 à 6 points courts (une phrase maximum par point), directement exploitables dans un business plan.',
  ].join('\n')
}

function userPrompt(input: ResearchInput, digest: string, webOk: boolean): string {
  return [
    'PROJET ÉTUDIÉ :',
    `• Nom : ${cut(input.name, 120)}`,
    `• Secteur : ${cut(input.sector, 80)}`,
    `• Pays : ${input.country}`,
    `• Localisation : ${input.location}`,
    input.legalForm && `• Forme juridique envisagée : ${cut(input.legalForm, 80)}`,
    input.idea && `• Idée : ${cut(input.idea, 400)}`,
    '',
    webOk
      ? `RÉSULTATS DE RECHERCHE WEB (sources réelles, classées par axe) :\n\n${digest}`
      : "La recherche web n'a renvoyé aucun résultat : produis la synthèse à partir de tes connaissances générales sur ce pays et ce secteur, en signalant les points à vérifier.",
    '',
    'Tâche : produis le rapport de recherche locale du projet :',
    '• « resume » : 2 à 3 phrases de synthèse du contexte local du projet ;',
    '• « marche » : taille/dynamique du marché local, demande, prix constatés ;',
    '• « reglementation » : autorisations, licences, enregistrements nécessaires ;',
    '• « fiscalite » : régime et formalités applicables à la création d\'entreprise ;',
    '• « financement » : dispositifs d\'aides, subventions, financements accessibles ;',
    '• « concurrence » : acteurs, filière, positionnement possible ;',
    '• « recommandations » : 4 à 6 actions concrètes priorisées pour le porteur.',
  ].filter(Boolean).join('\n')
}

function extractJson(raw: string): Record<string, unknown> {
  let s = raw.trim()
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '')
  const start = s.indexOf('{')
  const end = s.lastIndexOf('}')
  if (start === -1 || end === -1 || end <= start) throw new Error('Réponse IA illisible (pas de JSON).')
  return JSON.parse(s.slice(start, end + 1)) as Record<string, unknown>
}

const asStrList = (v: unknown, max: number, maxLen: number): string[] => {
  if (Array.isArray(v)) {
    return v
      .map((x) => (typeof x === 'string' ? x.trim() : x && typeof x === 'object' ? cut((x as { text?: string }).text, maxLen) : ''))
      .filter(Boolean)
      .slice(0, max)
      .map((x) => cut(String(x).replace(/^[-•*]\s*/, ''), maxLen))
  }
  if (typeof v === 'string' && v.trim()) {
    return v
      .split(/\n+/)
      .map((l) => l.replace(/^\s*(?:[-•*]|\d+[.)])\s*/, '').trim())
      .filter(Boolean)
      .slice(0, max)
      .map((l) => cut(l, maxLen))
  }
  return []
}

// ---------------------------------------------------------------------------
// Appel principal
// ---------------------------------------------------------------------------

export async function runCountryResearch(input: ResearchInput): Promise<CountryResearchResult> {
  const axes = buildResearchAxes(input)
  const zai = await ZAI.create()

  // 1. Recherches web en parallèle (un échec d'axe n'empêche pas les autres).
  const settled = await Promise.all(axes.map((axis) => searchAxis(zai, axis)))
  const sources = collectSources(axes, settled)
  const digest = buildDigest(axes, settled)
  const webOk = sources.length > 0

  // 2. Synthèse IA (une relance en cas de JSON illisible).
  const messages = [
    { role: 'assistant' as const, content: systemPrompt(webOk) },
    { role: 'user' as const, content: userPrompt(input, digest, webOk) },
  ]
  const run = async (): Promise<Record<string, unknown>> => {
    const completion = (await Promise.race([
      zai.chat.completions.create({ messages, thinking: { type: 'disabled' } }),
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), SYNTH_TIMEOUT_MS)),
    ])) as { choices?: { message?: { content?: string } }[] }
    const content = completion.choices?.[0]?.message?.content
    if (!content || !content.trim()) throw new Error('Réponse IA vide.')
    return extractJson(content)
  }
  let raw: Record<string, unknown>
  try {
    raw = await run()
  } catch (err) {
    const msg = err instanceof Error ? err.message : ''
    if (msg === 'timeout') throw err
    raw = await run()
  }

  return {
    country: input.country,
    location: input.location,
    searchedAt: new Date().toISOString(),
    webOk,
    resume: asStrList(raw.resume, 4, 320),
    marche: asStrList(raw.marche, 6, 300),
    reglementation: asStrList(raw.reglementation, 6, 300),
    fiscalite: asStrList(raw.fiscalite, 6, 300),
    financement: asStrList(raw.financement, 6, 300),
    concurrence: asStrList(raw.concurrence, 6, 300),
    recommandations: asStrList(raw.recommandations, 6, 300),
    sources,
  }
}
