import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

const globalForPrismaInit = globalThis as unknown as {
  prismaHealing: boolean | undefined
}

/**
 * Accès base de données auto-réparant.
 *
 * Deux modes de connexion (choisi automatiquement selon DATABASE_URL) :
 *  • « file:… » (local / self-hosted) : fichier SQLite classique, accès
 *    direct au disque — mode par défaut en développement ;
 *  • « libsql://… » (production Vercel) : base Turso (libSQL) via
 *    l'adaptateur officiel @prisma/adapter-libsql — indispensable car le
 *    système de fichiers de Vercel est éphémère : un fichier SQLite y serait
 *    réinitialisé à chaque redéploiement. Jeton fourni par
 *    DATABASE_AUTH_TOKEN (ou TURSO_AUTH_TOKEN).
 *
 * Dans l'environnement d'exécution, le répertoire du projet peut être
 * resynchronisé entre deux sessions : le fichier SQLite est remplacé
 * (nouvel inode) alors que le serveur garde des descripteurs vers l'ancien
 * fichier supprimé. Toutes les écritures échouent ensuite avec
 * « attempt to write a readonly database » (SQLITE_READONLY) jusqu'au
 * redémarrage du serveur.
 *
 * Correctif :
 *  1. `db` est un Proxy qui délègue toujours au client actif — chaque
 *     accès (db.project, db.user, …) est résolu sur le client courant ;
 *  2. une extension de requête ($extends) intercepte les erreurs
 *     « readonly », crée un client neuf (qui rouvre le fichier actuel),
 *     bascule le client actif puis rejoue l'opération une seule fois.
 * Aucune donnée n'est perdue : la requête initiale n'a rien écrit
 * (la base étant en lecture seule, l'opération a échoué atomiquement).
 */

const holder: { client: PrismaClient } = {
  client: globalForPrisma.prisma ?? createClient(),
}

function isReadonlyError(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false
  const message = String((err as { message?: unknown }).message || '')
  return message.toLowerCase().includes('readonly')
}

function decapitalize(value: string): string {
  return value ? value.charAt(0).toLowerCase() + value.slice(1) : value
}

function createClient(): PrismaClient {
  // Mode production Vercel : base Turso (libSQL) via l'adaptateur officiel.
  // Actif dès que DATABASE_URL commence par « libsql:// » ; le jeton
  // d'authentification vient de DATABASE_AUTH_TOKEN ou TURSO_AUTH_TOKEN.
  const url = (process.env.DATABASE_URL || '').trim()
  if (url.startsWith('libsql://')) {
    const adapter = new PrismaLibSQL({
      url,
      authToken: (process.env.DATABASE_AUTH_TOKEN || process.env.TURSO_AUTH_TOKEN || '').trim(),
    })
    const client = new PrismaClient({ adapter })
    // L'auto-réparation « fichier en lecture seule » n'a pas de sens sur
    // Turso (base distante) : on renvoie le client directement.
    return client
  }

  const client = new PrismaClient({ log: ['query'] })

  const extended = client.$extends({
    query: {
      $allModels: {
        async $allOperations({ model, operation, args, query }) {
          try {
            return await query(args)
          } catch (err) {
            if (!isReadonlyError(err) || globalForPrismaInit.prismaHealing) throw err
            const label = `${model ? decapitalize(model) : '?'}·${operation || '?'}`
            console.warn(`[db] SQLite en lecture seule (${label}) — recréation du client puis nouvelle tentative…`)
            globalForPrismaInit.prismaHealing = true
            try {
              try {
                await holder.client.$disconnect()
              } catch {
                /* ignore : le client est remplacé de toute façon */
              }
              const fresh = createClient()
              holder.client = fresh
              if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = fresh
              if (model && operation) {
                const delegates = fresh as unknown as Record<string, Record<string, unknown> | undefined>
                const delegate = delegates[decapitalize(model)]
                const replay = delegate?.[operation]
                if (delegate && typeof replay === 'function') {
                  return await (replay as (a: unknown) => Promise<unknown>).call(delegate, args)
                }
              }
              // Repli : rejouer via le canal d'origine (client remplacé
              // néanmoins, au cas où l'opération serait ré-exécutable).
              return await query(args)
            } finally {
              globalForPrismaInit.prismaHealing = false
            }
          }
        },
      },
    },
  })

  // Le client étendu expose la même surface publique que PrismaClient
  // (modèles, $connect, $disconnect, $transaction…) : on conserve ce type
  // pour ne pas modifier les modules consommateurs.
  return extended as unknown as PrismaClient
}

export const db: PrismaClient = new Proxy(holder.client, {
  get(_target, prop, _receiver) {
    const client = holder.client
    const value = Reflect.get(client, prop, client)
    if (typeof value === 'function') {
      return (value as (...args: unknown[]) => unknown).bind(client)
    }
    return value
  },
  has(_target, prop) {
    return Reflect.has(holder.client, prop)
  },
  getPrototypeOf() {
    return PrismaClient.prototype
  },
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = holder.client
