// GESCOM PROJECT – Génération PPTX (pptxgenjs)
// Présentations professionnelles par audience : investisseurs, banques,
// partenaires, soutenance académique. Thèmes personnalisables.
import PptxGenJS from 'pptxgenjs'
import type { Dossier, DossierSection } from '@/lib/exports/content'

export interface PptxOptions {
  audience: 'INVESTOR' | 'BANK' | 'PARTNER' | 'ACADEMIC'
  themePrimary: string // hex sans #
  themeAccent: string
  author: string
  organization: string
  /** Logo de l'entreprise (PNG, transparence conservée) intégré à la présentation. */
  logo?: { data: Buffer; width: number; height: number }
}

type SlideSpec = {
  title: string
  bullets: string[]
  table?: { headers: string[]; rows: string[][] }
  kind: 'title' | 'content' | 'table' | 'closing'
}

// Ordre des sections selon l'audience cible
const AUDIENCE_ORDER: Record<PptxOptions['audience'], string[]> = {
  INVESTOR: ['overview', 'market', 'strategy', 'financials', 'indicators', 'risks', 'actionplan', 'financing'],
  BANK: ['overview', 'market', 'investment', 'financing', 'financials', 'indicators', 'risks', 'actionplan'],
  PARTNER: ['overview', 'market', 'strategy', 'organization', 'actionplan', 'risks', 'indicators'],
  ACADEMIC: ['overview', 'market', 'strategy', 'feasibility', 'financials', 'indicators', 'risks', 'actionplan', 'annexes'],
}

const AUDIENCE_TITLES: Record<PptxOptions['audience'], string> = {
  INVESTOR: 'Présentation investisseurs',
  BANK: 'Dossier de financement',
  PARTNER: 'Présentation partenaires',
  ACADEMIC: 'Soutenance de projet',
}

function sectionToSlides(section: DossierSection): SlideSpec[] {
  const slides: SlideSpec[] = []
  let current: SlideSpec | null = null
  const maxBullets = 7

  const pushCurrent = () => {
    if (current && (current.bullets.length > 0 || current.table)) slides.push(current)
  }

  for (const block of section.blocks) {
    if (block.type === 'heading') {
      pushCurrent()
      current = { title: `${section.title} — ${block.text}`, bullets: [], kind: 'content' }
    } else if (block.type === 'paragraph') {
      const text = (block.text || '').trim()
      if (!text) continue
      if (!current) current = { title: section.title, bullets: [], kind: 'content' }
      // Un paragraphe long devient 1 à 3 puces condensées (phrases clés)
      const sentences = text.split(/(?<=[.!?])\s+(?=[A-ZÀ-ÖØ-Þ])/).filter((s) => s.trim().length > 0)
      const take = sentences.length > 6 ? sentences.slice(0, 5).concat([sentences[sentences.length - 1]]) : sentences
      for (const s of take) {
        if (current.bullets.length >= maxBullets) {
          pushCurrent()
          current = { title: `${section.title} (suite)`, bullets: [], kind: 'content' }
        }
        current.bullets.push(s.trim())
      }
    } else if (block.type === 'bullets') {
      if (!current) current = { title: section.title, bullets: [], kind: 'content' }
      if (block.text && current.bullets.length === 0) current.title = `${section.title} — ${block.text}`
      for (const item of block.items || []) {
        if (current.bullets.length >= maxBullets) {
          pushCurrent()
          current = { title: `${section.title} (suite)`, bullets: [], kind: 'content' }
        }
        current.bullets.push(item)
      }
    } else if (block.type === 'table') {
      if (!block.table) continue
      pushCurrent()
      current = {
        title: block.table.title ? `${section.title} — ${block.table.title}` : section.title,
        bullets: [],
        table: { headers: block.table.headers, rows: block.table.rows },
        kind: 'table',
      }
      pushCurrent()
      current = null
    }
  }
  pushCurrent()
  return slides
}

export async function generatePptx(dossier: Dossier, opts: PptxOptions): Promise<Buffer> {
  // Audience inconnue (paramètre invalide, ancien client…) : repli sur INVESTOR
  // plutôt qu'un crash à la génération.
  const audience: PptxOptions['audience'] = AUDIENCE_ORDER[opts.audience] ? opts.audience : 'INVESTOR'
  const pptx = new PptxGenJS()
  pptx.layout = 'LAYOUT_16x9'
  // pptxgenjs n'échappe pas les métadonnées du package (docProps/app.xml) :
  // un « & » dans le nom de l'organisation (ex. « Awa Farms & Co ») produit
  // un XML mal formé qui empêche l'ouverture de la présentation. On échappe
  // donc explicitement les valeurs insérées dans les propriétés du fichier.
  const xmlEscape = (s: string) =>
    s.replace(/[&<>"']/g, (c) =>
      c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : '&apos;')
  pptx.author = xmlEscape(opts.author || 'GESCOM PROJECT')
  pptx.company = xmlEscape(opts.organization || 'GESCOM PROJECT')
  pptx.title = xmlEscape(`${dossier.projectName} — ${AUDIENCE_TITLES[audience]}`)

  const primary = opts.themePrimary.replace('#', '')
  const accent = opts.themeAccent.replace('#', '')

  // Logo : encodé une seule fois, dimensionné en conservant ses proportions.
  const logoB64 = opts.logo ? `image/png;base64,${opts.logo.data.toString('base64')}` : null
  const placeLogo = (
    slide: PptxGenJS.Slide,
    box: { x: number; y: number; maxW: number; maxH: number },
  ) => {
    if (!logoB64 || !opts.logo) return
    const { w, h } = fitBox(opts.logo.width, opts.logo.height, box.maxW, box.maxH)
    slide.addImage({ data: logoB64, x: box.x, y: box.y, w, h })
  }

  // Diapositive 1 : titre
  const titleSlide = pptx.addSlide()
  titleSlide.background = { color: primary }
  placeLogo(titleSlide, { x: 7.8, y: 0.45, maxW: 1.6, maxH: 1.0 })
  titleSlide.addText('GESCOM PROJECT', {
    x: 0.6, y: 0.5, w: 4, h: 0.4, fontSize: 14, bold: true, color: accent, fontFace: 'Times New Roman',
  })
  titleSlide.addText(dossier.title, {
    x: 0.6, y: 2.1, w: 8.8, h: 1.8, fontSize: 32, bold: true, color: 'FFFFFF', fontFace: 'Times New Roman',
  })
  titleSlide.addText(AUDIENCE_TITLES[audience], {
    x: 0.6, y: 3.9, w: 8.8, h: 0.5, fontSize: 18, color: 'CBD5E1', fontFace: 'Times New Roman',
  })
  titleSlide.addText(
    [opts.author, opts.organization, dossier.date].filter(Boolean).join('  •  '),
    { x: 0.6, y: 6.6, w: 8.8, h: 0.4, fontSize: 12, color: '94A3B8', fontFace: 'Times New Roman' },
  )

  // Sommaire
  const order = AUDIENCE_ORDER[audience]
  const sectionsById = new Map(dossier.sections.map((s) => [s.id, s]))
  const ordered = order.map((id) => sectionsById.get(id)).filter(Boolean) as DossierSection[]
  // Sections du dossier absentes de l'ordre (export partiel) ajoutées à la fin
  for (const s of dossier.sections) {
    if (!ordered.includes(s)) ordered.push(s)
  }

  const agenda = pptx.addSlide()
  agenda.addText('Sommaire', { x: 0.6, y: 0.4, fontSize: 26, bold: true, color: primary, fontFace: 'Times New Roman' })
  agenda.addText(
    ordered.map((s, i) => ({ text: `${i + 1}. ${s.title.replace(/^\d+\.\s*/, '')}`, options: { breakLine: true, fontSize: 14, color: '334155' } })),
    { x: 0.8, y: 1.3, w: 8.4, h: 5.2, lineSpacingMultiple: 1.4, fontFace: 'Times New Roman' },
  )

  // Sections
  for (const section of ordered) {
    for (const spec of sectionToSlides(section)) {
      if (spec.kind === 'title') continue
      const slide = pptx.addSlide()
      slide.background = { color: 'FFFFFF' }
      // bandeau titre
      slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 10, h: 0.9, fill: { color: primary } })
      slide.addText(spec.title.replace(/^\d+\.\s*/, ''), {
        x: 0.5, y: 0.12, w: logoB64 ? 8.1 : 9, h: 0.66, fontSize: 18, bold: true, color: 'FFFFFF', fontFace: 'Times New Roman',
      })
      slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0.9, w: 10, h: 0.06, fill: { color: accent } })
      // logo en haut à droite du bandeau (diapositives de contenu)
      placeLogo(slide, { x: 8.75, y: (0.9 - 0.62) / 2, maxW: 0.95, maxH: 0.62 })

      if (spec.kind === 'table' && spec.table) {
        const { headers, rows } = spec.table
        const shownRows = rows.slice(0, 12)
        const tableRows = [
          headers.map((h) => ({
            text: h,
            options: { bold: true, color: 'FFFFFF', fill: { color: primary }, fontSize: 9 },
          })),
          ...shownRows.map((row, ri) =>
            row.map((cell) => ({
              text: String(cell ?? ''),
              options: { fontSize: 8.5, color: '1E293B', fill: { color: ri % 2 === 1 ? 'F1F5F9' : 'FFFFFF' } },
            })),
          ),
        ]
        if (rows.length > shownRows.length) {
          slide.addText(`(+ ${rows.length - shownRows.length} lignes supplémentaires dans le dossier complet)`, {
            x: 0.5, y: 6.9, w: 9, h: 0.3, fontSize: 9, italic: true, color: '94A3B8', fontFace: 'Times New Roman',
          })
        }
        slide.addTable(tableRows, {
          x: 0.5, y: 1.15, w: 9.0, colW: distributeWidths(headers, rows, 9.0),
          border: { type: 'solid', pt: 0.5, color: 'E2E8F0' },
          valign: 'middle',
          margin: 0.04,
          fontFace: 'Times New Roman',
        })
      } else {
        slide.addText(
          spec.bullets.map((b) => ({
            text: b,
            options: { bullet: { characterCode: '2022', color: accent }, breakLine: true, color: '334155' },
          })),
          { x: 0.7, y: 1.3, w: 8.6, h: 5.4, fontSize: 13, lineSpacingMultiple: 1.25, valign: 'top', fontFace: 'Times New Roman' },
        )
      }
      // pied de page
      slide.addText(`${dossier.projectName}  —  GESCOM PROJECT`, {
        x: 0.5, y: 7.15, w: 9, h: 0.3, fontSize: 8, color: '94A3B8', fontFace: 'Times New Roman',
      })
    }
  }

  // Conclusion
  const closing = pptx.addSlide()
  closing.background = { color: primary }
  placeLogo(closing, { x: (10 - 2.0) / 2, y: 1.1, maxW: 2.0, maxH: 1.3 })
  closing.addText('Merci de votre attention', {
    x: 0.6, y: 2.6, w: 8.8, h: 1, fontSize: 32, bold: true, color: 'FFFFFF', align: 'center', fontFace: 'Times New Roman',
  })
  closing.addText(
    `Contact : ${[opts.author, opts.organization].filter(Boolean).join(' — ') || 'Porteur de projet'}`,
    { x: 0.6, y: 3.8, w: 8.8, h: 0.5, fontSize: 14, color: 'CBD5E1', align: 'center', fontFace: 'Times New Roman' },
  )
  closing.addText('Présentation générée avec GESCOM PROJECT', {
    x: 0.6, y: 6.8, w: 8.8, h: 0.4, fontSize: 10, color: '94A3B8', align: 'center', fontFace: 'Times New Roman',
  })

  const data = await pptx.write({ outputType: 'nodebuffer' })
  return data as Buffer
}

function distributeWidths(headers: string[], rows: string[][], total: number): number[] {
  const weights = headers.map((h, i) => {
    const avg = rows.length ? rows.reduce((s, r) => s + (r[i]?.length ?? 0), 0) / rows.length : 0
    return Math.max(3, avg + h.length)
  })
  const sum = weights.reduce((a, b) => a + b, 0)
  return weights.map((w) => Math.max(0.4, (w / sum) * total))
}

// Dimensionne une image dans une boîte maximale (pouces) en conservant
// le ratio pixel du logo : jamais de déformation ni de débordement.
function fitBox(wPx: number, hPx: number, maxW: number, maxH: number): { w: number; h: number } {
  const ratio = hPx > 0 && wPx > 0 ? wPx / hPx : 1
  let w = maxW
  let h = w / ratio
  if (h > maxH) {
    h = maxH
    w = h * ratio
  }
  return { w, h }
}
