// GESCOM PROJECT – Préparation des images de marque (logo + image d'illustration)
// Logo   : PNG redimensionné (fond transparent conservé) pour la présentation PowerPoint.
// Couverture : recadrage au format A4 (150 dpi) + voile bleu nuit semi-transparent,
// garantissant la lisibilité du texte par-dessus dans les pages de garde PDF & Word.
import sharp from 'sharp'

export interface PreparedLogo {
  data: Buffer // PNG avec transparence
  width: number
  height: number
}

export interface PreparedCover {
  data: Buffer // JPEG au ratio A4, voile bleu nuit appliqué
  width: number
  height: number
}

// Dimensions cibles de la couverture : A4 à 150 dpi (1240 × 1754 px).
const COVER_W = 1240
const COVER_H = 1754

// Voile bleu nuit en dégradé diagonal posé sur l'image d'illustration :
// plus léger vers le haut/droite (l'activité reste bien reconnaissable),
// plus dense vers le bas/gauche (zones de texte du titre, auteur, date).
// Un voile uniforme trop dense donne une couverture quasi unie — l'image
// semblerait ne pas être prise en compte.
const COVER_VEIL_SVG = (w: number, h: number) => Buffer.from(
  `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">`
  + `<defs>`
  + `<linearGradient id="veil" x1="0%" y1="100%" x2="100%" y2="0%">`
  + `<stop offset="0%" stop-color="#0F172A" stop-opacity="0.88"/>`
  + `<stop offset="50%" stop-color="#0F172A" stop-opacity="0.66"/>`
  + `<stop offset="100%" stop-color="#0F172A" stop-opacity="0.42"/>`
  + `</linearGradient>`
  + `</defs>`
  + `<rect width="${w}" height="${h}" fill="url(#veil)"/>`
  + `</svg>`,
)

export async function prepareLogo(input: Buffer): Promise<PreparedLogo> {
  const data = await sharp(input)
    .rotate() // respecte l'orientation EXIF
    .resize(800, 800, { fit: 'inside', withoutEnlargement: true })
    .png()
    .toBuffer()
  const meta = await sharp(data).metadata()
  return { data, width: meta.width ?? 800, height: meta.height ?? 800 }
}

export async function prepareCover(input: Buffer): Promise<PreparedCover> {
  const data = await sharp(input)
    .rotate()
    .resize(COVER_W, COVER_H, { fit: 'cover', position: 'centre' })
    .composite([{ input: COVER_VEIL_SVG(COVER_W, COVER_H) }])
    .jpeg({ quality: 88 })
    .toBuffer()
  return { data, width: COVER_W, height: COVER_H }
}

// Conversion Buffer Prisma (Uint8Array) → Buffer Node exploitable par sharp.
export function toNodeBuffer(bytes: Uint8Array): Buffer {
  return Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes)
}
