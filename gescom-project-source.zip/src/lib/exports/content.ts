// GESCOM PROJECT – Constructeur de contenu de dossier partagé
// Source unique de vérité pour les 4 formats d'export (PDF, DOCX, XLSX, PPTX).
// Les données proviennent exclusivement de ce qui est réellement enregistré
// dans le système, complété par les calculs du moteur financier partagé.

import type { Project, Task } from '@prisma/client'
import { computeFinance, normalizeFinance } from '@/lib/finance'
import { groupNumber } from '@/lib/format'
import { isPremium, PREMIUM_EXPORT_SECTIONS } from '@/lib/plans'
import type {
  AnalysisData, DocPrefs, FinanceData, FinanceComputation, OverviewData,
} from '@/lib/types'
import type { ValidationReport } from '@/lib/validation'
import { EXPORT_SECTIONS } from '@/lib/constants'

export interface DossierTable {
  title?: string
  headers: string[]
  rows: string[][]
  note?: string
}

export interface DossierBlock {
  type: 'paragraph' | 'table' | 'bullets' | 'heading'
  text?: string
  table?: DossierTable
  items?: string[]
}

export interface DossierSection {
  id: string
  title: string
  blocks: DossierBlock[]
}

export interface Dossier {
  title: string
  subtitle: string
  author: string
  organization: string
  date: string
  currency: string
  projectName: string
  sections: DossierSection[]
}

// ---------------------------------------------------------------------------
// Parsers JSON sûrs
// ---------------------------------------------------------------------------

function parse<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback
  try {
    return { ...fallback, ...JSON.parse(json) } as T
  } catch {
    return fallback
  }
}

function parseArray<T>(json: string | null | undefined, fallback: T[]): T[] {
  if (!json) return fallback
  try {
    const v = JSON.parse(json)
    return Array.isArray(v) ? v : fallback
  } catch {
    return fallback
  }
}

const money = (n: number, currency: string) => `${groupNumber(Math.round(n))} ${currencySymbol(currency)}`

function currencySymbol(c: string) {
  return c === 'EUR' ? 'EUR' : c === 'USD' ? 'USD' : c === 'CAD' ? 'CAD' : c === 'CHF' ? 'CHF' : c === 'MAD' ? 'MAD' : 'FCFA'
}

export interface DossierInput {
  project: Project
  tasks: Task[]
  /** Plan de l'utilisateur : false (gratuit) → sections Premium exclues du dossier. */
  premium?: boolean
}

export function buildDossier(input: DossierInput, selectedSections?: string[]): Dossier {
  const p = input.project
  const premium = input.premium === true
  const cur = p.currency || 'XAF'
  const overview = parse<OverviewData>(p.overview, {
    legalForm: '', location: '', promoter: '', startDate: '', summary: '', vision: '', mission: '', values: '',
  })
  const analysis = parse<AnalysisData>(p.analysis, {
    swot: { strengths: [], weaknesses: [], opportunities: [], threats: [] },
    pestel: { politique: '', economique: '', socioculturel: '', technologique: '', ecologique: '', legal: '' },
    market: { demande: '', offre: '', segments: '', tendances: '', cible: '', zones: '', conclusion: '' },
    competitors: [], needs: [], risks: [],
    feasibility: { technique: '', economique: '', juridique: '', organisationnelle: '', commerciale: '', verdict: '' },
    synthesis: '', recommendations: '',
  })
  const finance: FinanceData = normalizeFinance(p.finance)
  const comp: FinanceComputation = computeFinance(finance)
  const docPrefs = parse<DocPrefs>(p.docPrefs, {
    coverTitle: '', coverSubtitle: '', author: '', organization: '',
    includeCover: true, includeToc: true, headerText: 'GESCOM PROJECT', footerText: '',
  })
  const objectives = parseArray<string>(p.objectives, [])

  const all: Record<string, DossierSection> = {
    overview: {
      id: 'overview',
      title: '1. Présentation générale du projet',
      blocks: [
        { type: 'paragraph', text: p.idea ? `Idée de projet : ${p.idea}` : '' },
        { type: 'paragraph', text: p.description },
        {
          type: 'table',
          table: {
            title: 'Fiche signalétique',
            headers: ['Rubrique', 'Information'],
            rows: [
              ['Nom du projet', p.name],
              ['Porteur du projet', overview.promoter || p.name],
              ['Forme juridique envisagée', overview.legalForm || '—'],
              ['Secteur d\'activité', p.sector || '—'],
              ['Type de projet', p.type || '—'],
              ['Localisation', [overview.location, p.region, p.country].filter(Boolean).join(', ') || '—'],
              ['Devise', cur],
              ['Date de démarrage prévue', overview.startDate || '—'],
            ],
          },
        },
        ...(overview.summary ? [{ type: 'paragraph' as const, text: `Résumé exécutif : ${overview.summary}` }] : []),
        ...(objectives.length > 0 ? [{ type: 'bullets' as const, text: 'Objectifs du projet', items: objectives }] : []),
        ...(overview.vision ? [{ type: 'paragraph' as const, text: `Vision : ${overview.vision}` }] : []),
        ...(overview.mission ? [{ type: 'paragraph' as const, text: `Mission : ${overview.mission}` }] : []),
        ...(overview.values ? [{ type: 'paragraph' as const, text: `Valeurs : ${overview.values}` }] : []),
      ].filter((b) => b.type !== 'paragraph' || b.text),
    },
    market: {
      id: 'market',
      title: '2. Étude de marché',
      blocks: [
        { type: 'paragraph', text: analysis.market.demande ? `Analyse de la demande : ${analysis.market.demande}` : '' },
        { type: 'paragraph', text: analysis.market.offre ? `Analyse de l'offre : ${analysis.market.offre}` : '' },
        { type: 'paragraph', text: analysis.market.segments ? `Segments de clientèle : ${analysis.market.segments}` : '' },
        { type: 'paragraph', text: analysis.market.cible ? `Clientèle cible : ${analysis.market.cible}` : '' },
        { type: 'paragraph', text: analysis.market.zones ? `Zone de chalandise : ${analysis.market.zones}` : '' },
        { type: 'paragraph', text: analysis.market.tendances ? `Tendances du marché : ${analysis.market.tendances}` : '' },
        ...(analysis.needs.length > 0
          ? [{
              type: 'table' as const,
              table: {
                title: 'Besoins identifiés',
                headers: ['Besoin', 'Cible', 'Fréquence'],
                rows: analysis.needs.map((n) => [n.label, n.target, n.frequency]),
              },
            }]
          : []),
        { type: 'paragraph', text: analysis.market.conclusion ? `Conclusion de l'étude de marché : ${analysis.market.conclusion}` : '' },
      ].filter((b) => b.type !== 'paragraph' || b.text),
    },
    strategy: {
      id: 'strategy',
      title: '3. Analyse stratégique',
      blocks: [
        ...(analysis.swot.strengths.length || analysis.swot.weaknesses.length || analysis.swot.opportunities.length || analysis.swot.threats.length
          ? [
              { type: 'heading' as const, text: '3.1 Analyse SWOT' },
              { type: 'table' as const, table: {
                title: 'Matrice SWOT',
                headers: ['Forces', 'Faiblesses'],
                rows: zipCols(
                  analysis.swot.strengths.map((i) => i.label),
                  analysis.swot.weaknesses.map((i) => i.label),
                ),
              } },
              { type: 'table' as const, table: {
                headers: ['Opportunités', 'Menaces'],
                rows: zipCols(
                  analysis.swot.opportunities.map((i) => i.label),
                  analysis.swot.threats.map((i) => i.label),
                ),
              } },
            ]
          : []),
        { type: 'heading' as const, text: '3.2 Analyse PESTEL' },
        { type: 'paragraph', text: analysis.pestel.politique ? `Politique : ${analysis.pestel.politique}` : '' },
        { type: 'paragraph', text: analysis.pestel.economique ? `Économique : ${analysis.pestel.economique}` : '' },
        { type: 'paragraph', text: analysis.pestel.socioculturel ? `Socioculturel : ${analysis.pestel.socioculturel}` : '' },
        { type: 'paragraph', text: analysis.pestel.technologique ? `Technologique : ${analysis.pestel.technologique}` : '' },
        { type: 'paragraph', text: analysis.pestel.ecologique ? `Écologique : ${analysis.pestel.ecologique}` : '' },
        { type: 'paragraph', text: analysis.pestel.legal ? `Légal : ${analysis.pestel.legal}` : '' },
        ...(analysis.competitors.length > 0
          ? [
              { type: 'heading' as const, text: '3.3 Analyse de la concurrence' },
              { type: 'table' as const, table: {
                headers: ['Concurrent', 'Type', 'Forces', 'Faiblesses', 'Positionnement retenu'],
                rows: analysis.competitors.map((c) => [c.name, c.type, c.strengths, c.weaknesses, c.positioning]),
              } },
            ]
          : []),
        ...(analysis.synthesis ? [{ type: 'paragraph' as const, text: `Synthèse stratégique : ${analysis.synthesis}` }] : []),
      ].filter((b) => b.type !== 'paragraph' || b.text),
    },
    feasibility: {
      id: 'feasibility',
      title: '4. Étude de faisabilité',
      blocks: [
        { type: 'paragraph', text: analysis.feasibility.technique ? `Faisabilité technique : ${analysis.feasibility.technique}` : '' },
        { type: 'paragraph', text: analysis.feasibility.economique ? `Faisabilité économique : ${analysis.feasibility.economique}` : '' },
        { type: 'paragraph', text: analysis.feasibility.juridique ? `Faisabilité juridique : ${analysis.feasibility.juridique}` : '' },
        { type: 'paragraph', text: analysis.feasibility.organisationnelle ? `Faisabilité organisationnelle : ${analysis.feasibility.organisationnelle}` : '' },
        { type: 'paragraph', text: analysis.feasibility.commerciale ? `Faisabilité commerciale : ${analysis.feasibility.commerciale}` : '' },
        ...(analysis.feasibility.verdict
          ? [{ type: 'paragraph' as const, text: `Verdict global : ${verdictLabel(analysis.feasibility.verdict)}` }]
          : []),
        ...(analysis.recommendations ? [{ type: 'paragraph' as const, text: `Recommandations : ${analysis.recommendations}` }] : []),
      ].filter((b) => b.type !== 'paragraph' || b.text),
    },
    organization: {
      id: 'organization',
      title: '5. Organisation & ressources humaines',
      blocks: [
        ...(finance.assumptions.staff.length > 0
          ? [{
              type: 'table' as const,
              table: {
                title: 'Effectifs et masse salariale (année 1)',
                headers: ['Poste', 'Effectif', 'Salaire mensuel', 'Coût annuel'],
                rows: finance.assumptions.staff.map((s) => [
                  s.role,
                  String(s.count),
                  money(s.monthlySalary, cur),
                  money(s.count * s.monthlySalary * 12, cur),
                ]),
              },
            }]
          : [{ type: 'paragraph' as const, text: 'Aucune structure d\'équipe n\'a encore été renseignée dans le module Finance.' }]),
        { type: 'paragraph', text: `Porteur du projet : ${overview.promoter || '—'}. Forme juridique : ${overview.legalForm || '—'}.` },
      ],
    },
    investment: {
      id: 'investment',
      title: '6. Plan d\'investissement',
      blocks: [
        ...(finance.investments.length > 0
          ? [{
              type: 'table' as const,
              table: {
                title: 'Programme d\'investissement',
                headers: ['Rubrique', 'Catégorie', 'Montant', 'Amortissable', 'Durée (ans)'],
                rows: [
                  ...finance.investments.map((i) => [
                    i.label,
                    i.category,
                    money(i.amount, cur),
                    i.depreciable ? 'Oui' : 'Non',
                    i.depreciable ? String(i.depYears) : '—',
                  ]),
                  ['TOTAL', '', money(comp.totalInvestment, cur), '', ''],
                ],
              },
            }]
          : [{ type: 'paragraph' as const, text: 'Aucun investissement renseigné dans le module Finance.' }]),
        { type: 'paragraph', text: `Fonds de roulement initial (besoin en fonds de roulement) : ${money(comp.totalWorkingCapital, cur)}.` },
        { type: 'paragraph', text: `Besoin total de financement : ${money(comp.totalNeeds, cur)}.` },
      ],
    },
    financing: {
      id: 'financing',
      title: '7. Plan de financement',
      blocks: [
        ...(finance.financing.length > 0
          ? [{
              type: 'table' as const,
              table: {
                title: 'Structure de financement',
                headers: ['Source', 'Nature', 'Montant', 'Taux', 'Durée'],
                rows: [
                  ...finance.financing.map((f) => [
                    f.source,
                    f.type === 'EQUITY' ? 'Fonds propres' : f.type === 'LOAN' ? 'Emprunt' : 'Subvention',
                    money(f.amount, cur),
                    f.type === 'LOAN' ? `${f.rate} %` : '—',
                    f.type === 'LOAN' ? `${f.termYears} ans` : '—',
                  ]),
                  ['TOTAL', '', money(comp.totalFinancing, cur), '', ''],
                ],
              },
            }]
          : [{ type: 'paragraph' as const, text: 'Aucun financement renseigné dans le module Finance.' }]),
        ...(comp.financingGap > 0
          ? [{ type: 'paragraph' as const, text: `Attention : le financement identifié couvre ${money(comp.totalFinancing, cur)} sur un besoin de ${money(comp.totalNeeds, cur)}, soit un déficit de ${money(comp.financingGap, cur)} à combler.` }]
          : [{ type: 'paragraph' as const, text: 'Le plan de financement couvre l\'intégralité des besoins identifiés.' }]),
        ...(comp.loanSchedule.length > 0
          ? [{
              type: 'table' as const,
              table: {
                title: 'Échéancier de remboursement des emprunts',
                headers: ['Année', 'Source', 'Capital restant dû (début)', 'Intérêts', 'Capital remboursé', 'Annuité'],
                rows: comp.loanSchedule.map((l) => [
                  String(l.year), l.source, money(l.openingBalance, cur), money(l.interest, cur), money(l.principal, cur), money(l.annuity, cur),
                ]),
              },
            }]
          : []),
      ],
    },
    financials: {
      id: 'financials',
      title: '8. Études financières prévisionnelles',
      blocks: [
        ...(finance.assumptions.products.length > 0
          ? [{ type: 'table' as const, table: {
                title: 'Hypothèses de chiffre d\'affaires (année 1)',
                headers: ['Produit / service', 'Quantité annuelle', 'Prix unitaire', 'Croissance volume', 'Croissance prix'],
                rows: finance.assumptions.products.map((prod) => [
                  prod.label, `${prod.qty} ${prod.unit}`, money(prod.unitPrice, cur), `${prod.volumeGrowth} %/an`, `${prod.priceGrowth} %/an`,
                ]),
              } },
              { type: 'table' as const, table: {
                title: 'Charges variables (année 1)',
                headers: ['Charge', 'Base', 'Montant annuel'],
                rows: finance.assumptions.variableCosts.map((c) => [
                  c.label,
                  c.mode === 'PCT' ? `${c.pct} % du CA` : `${c.qty} × ${money(c.unitPrice, cur)}`,
                  money(c.mode === 'PCT' ? (comp.years[0]?.revenue ?? 0) * (c.pct / 100) : c.qty * c.unitPrice, cur),
                ]),
              } },
              { type: 'table' as const, table: {
                title: 'Charges fixes (année 1)',
                headers: ['Charge', 'Montant annuel'],
                rows: [
                  ...finance.assumptions.fixedCosts.map((c) => [c.label, money(c.annualAmount, cur)]),
                  ...finance.assumptions.staff.map((s) => [`Personnel : ${s.role} (×${s.count})`, money(s.count * s.monthlySalary * 12, cur)]),
                ],
              } }]
          : [{ type: 'paragraph' as const, text: 'Aucune hypothèse d\'exploitation renseignée dans le module Finance.' }]),
        ...(comp.years.length > 0
          ? [{ type: 'table' as const, table: {
                title: 'Compte de résultat prévisionnel',
                headers: ['Rubrique', ...comp.years.map((y) => `Année ${y.year}`)],
                rows: [
                  ['Chiffre d\'affaires', ...comp.years.map((y) => money(y.revenue, cur))],
                  ['Charges variables', ...comp.years.map((y) => money(y.variableCosts, cur))],
                  ['Marge sur coûts variables', ...comp.years.map((y) => money(y.revenue - y.variableCosts, cur))],
                  ['Charges fixes', ...comp.years.map((y) => money(y.fixedCosts, cur))],
                  ['Excédent brut d\'exploitation (EBE)', ...comp.years.map((y) => money(y.ebitda, cur))],
                  ['Amortissements', ...comp.years.map((y) => money(y.depreciation, cur))],
                  ['Intérêts sur emprunts', ...comp.years.map((y) => money(y.interest, cur))],
                  ['Résultat avant impôt', ...comp.years.map((y) => money(y.ebt, cur))],
                  ['Impôt sur les sociétés', ...comp.years.map((y) => money(y.tax, cur))],
                  ['RÉSULTAT NET', ...comp.years.map((y) => money(y.netIncome, cur))],
                ],
              } },
              { type: 'table' as const, table: {
                title: 'Flux de trésorerie prévisionnels',
                headers: ['Rubrique', ...comp.years.map((y) => `Année ${y.year}`)],
                rows: [
                  ['Capacité d\'autofinancement (CAF)', ...comp.years.map((y) => money(y.caf, cur))],
                  ['Remboursement du capital emprunté', ...comp.years.map((y) => money(y.principalRepayment, cur))],
                  ['Flux net de trésorerie', ...comp.years.map((y) => money(y.freeCashFlow, cur))],
                  ['Flux cumulé (avec mise de fonds initiale)', ...comp.years.map((y) => money(y.cumulativeFCF, cur))],
                ],
              } }]
          : []),
      ],
    },
    indicators: {
      id: 'indicators',
      title: '9. Indicateurs de rentabilité',
      blocks: [
        {
          type: 'table',
          table: {
            title: 'Indicateurs calculés par GESCOM PROJECT',
            headers: ['Indicateur', 'Valeur', 'Lecture'],
            rows: [
              ['Valeur Actuelle Nette (VAN)', money(comp.ratios.npv, cur), `Taux d'actualisation : ${finance.assumptions.discountRate} % — VAN ${comp.ratios.npv >= 0 ? 'positive : le projet crée de la valeur' : 'négative : le projet détruit de la valeur aux hypothèses actuelles'}`],
              ['Taux de Rentabilité Interne (TRI)', comp.ratios.irr !== null ? `${comp.ratios.irr.toFixed(1)} %` : '—', comp.ratios.irr !== null ? `À comparer au coût du capital (${finance.assumptions.discountRate} %)` : 'Non calculable avec les données actuelles'],
              ['Délai de récupération', comp.ratios.payback !== null ? `${comp.ratios.payback.toFixed(1)} ans` : '—', 'Nombre d\'années nécessaires pour récupérer la mise de fonds initiale'],
              ['Seuil de rentabilité (année 1)', money(comp.ratios.breakEvenRevenue, cur), 'Niveau de CA couvrant l\'ensemble des charges'],
              ['Marge nette (année 1)', `${comp.ratios.netMargin.toFixed(1)} %`, 'Résultat net / chiffre d\'affaires'],
              ['Marge d\'EBE (année 1)', `${comp.ratios.ebitdaMargin.toFixed(1)} %`, 'EBE / chiffre d\'affaires'],
              ['Rentabilité des investissements (ROI)', `${comp.ratios.roi.toFixed(1)} %`, 'Résultat net moyen / investissements'],
              ['Autonomie financière', `${comp.ratios.autonomyRate.toFixed(1)} %`, 'Fonds propres et subventions / financement total'],
              ['DSCR (année 1)', comp.ratios.dscr !== null ? `${comp.ratios.dscr.toFixed(2)}×` : '—', 'Capacité à rembourser le service de la dette'],
            ],
          },
        },
        { type: 'table', table: {
          title: 'Comparaison des scénarios',
          headers: ['Scénario', 'CA (année 1)', 'Résultat net (année 1)', 'Résultat net moyen', 'Délai de récupération', 'VAN'],
          rows: comp.scenarios.map((s) => [
            s.name === 'OPTIMISTIC' ? 'Optimiste' : s.name === 'PESSIMISTIC' ? 'Pessimiste' : 'Réaliste',
            money(s.revenue1, cur),
            money(s.netIncome1, cur),
            money(s.netIncomeAvg, cur),
            s.payback !== null ? `${s.payback.toFixed(1)} ans` : '—',
            money(s.npv, cur),
          ]),
        } },
      ],
    },
    risks: {
      id: 'risks',
      title: '10. Analyse des risques',
      blocks: [
        ...(analysis.risks.length > 0
          ? [{ type: 'table' as const, table: {
                title: 'Registre des risques (criticité = probabilité × impact)',
                headers: ['Risque', 'Catégorie', 'Probabilité', 'Impact', 'Criticité', 'Mesures d\'atténuation'],
                rows: [...analysis.risks]
                  .sort((a, b) => b.probability * b.impact - a.probability * a.impact)
                  .map((r) => [
                    r.label, r.category, `${r.probability}/5`, `${r.impact}/5`,
                    `${r.probability * r.impact}/25`, r.mitigation,
                  ]),
              } }]
          : [{ type: 'paragraph' as const, text: 'Aucun risque renseigné dans le module Analyse.' }]),
      ],
    },
    actionplan: {
      id: 'actionplan',
      title: '11. Plan d\'action & calendrier de mise en œuvre',
      blocks: [
        ...(input.tasks.length > 0
          ? [{ type: 'table' as const, table: {
                title: 'Calendrier des activités',
                headers: ['Phase', 'Activité', 'Responsable', 'Début', 'Fin', 'Statut', 'Avancement'],
                rows: input.tasks.map((t) => [
                  t.phase, t.title, t.responsible || '—', t.startDate || '—', t.endDate || '—',
                  statusLabel(t.status), `${Math.round(t.progress)} %`,
                ]),
              } }]
          : [{ type: 'paragraph' as const, text: 'Aucune activité renseignée dans le module Plan d\'action.' }]),
      ],
    },
    annexes: {
      id: 'annexes',
      title: '12. Annexes',
      blocks: [
        { type: 'paragraph', text: 'Annexe 1 – Détail des hypothèses de calcul : l\'ensemble des hypothèses (investissements, financement, produits, charges) est disponible dans le classeur Excel joint au dossier, où chaque valeur reste modifiable et chaque indicateur est recalculé automatiquement.' },
        { type: 'paragraph', text: 'Annexe 2 – Méthodologie des indicateurs : la VAN actualise les flux de trésorerie disponibles au taux indiqué ; le TRI est obtenu par dichotomie ; le délai de récupération est calculé sur les flux cumulés avec interpolation linéaire ; le seuil de rentabilité applique la formule charges fixes / taux de marge sur coûts variables.' },
        { type: 'paragraph', text: 'Annexe 3 – Ce dossier a été généré automatiquement par GESCOM PROJECT à partir des données enregistrées dans la plateforme. Toute modification des données doit être suivie d\'une nouvelle génération pour rester cohérente.' },
        ...(!premium ? [{ type: 'paragraph' as const, text: 'Note d\'abonnement : l\'évaluation des risques du projet, le plan de financement, la prévision des ventes et le compte de résultat prévisionnel (ainsi que les indicateurs de rentabilité) sont disponibles avec l\'abonnement Premium de GESCOM PROJECT.' }] : []),
      ],
    },
  }

  const wanted = (selectedSections && selectedSections.length > 0)
    ? selectedSections
    : EXPORT_SECTIONS.map((s) => s.id)
  // Plan gratuit : exclusion des sections réservées au Premium.
  const allowed = premium ? wanted : wanted.filter((id) => !PREMIUM_EXPORT_SECTIONS.has(id))
  const kept = allowed.map((id) => all[id]).filter(Boolean)
  // Renumérotation consécutive : après exclusion des sections Premium, le
  // dossier gratuit reste numéroté 1., 2., 3.… sans trous (les titres internes
  // « 3.1 », « 3.2 »… restent cohérents car l'ordre relatif est conservé).
  const sections: DossierSection[] = kept.map((s, i) => ({
    ...s,
    title: s.title.replace(/^\d+\.\s*/, `${i + 1}. `),
  }))

  return normalizeThousandsDots({
    title: docPrefs.coverTitle || `Dossier de projet – ${p.name}`,
    subtitle: docPrefs.coverSubtitle || 'Business plan & étude de faisabilité',
    author: docPrefs.author || overview.promoter || '',
    organization: docPrefs.organization || '',
    date: new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }),
    currency: cur,
    projectName: p.name,
    sections,
  })
}

// Séparateur de milliers « . » (convention GESCOM) appliqué aussi aux textes
// narratifs : les descriptions saisies ou générées par l'IA peuvent contenir
// « 4 500 000 » ou « 4 500 000 » (espaces) ; on les convertit en « 4.500.000 ».
// Le motif cible les groupes de exactement 3 chiffres séparés par un espace
// (normal, insécable ou fin) — les dates (2026-11-25) et décimales (12,5)
// ne sont pas touchées.
function normDots(s: string): string {
  return s.replace(/(\d)[ \u00A0\u202F](?=\d{3}(?!\d))/g, '$1.')
}
function normalizeThousandsDots(d: Dossier): Dossier {
  for (const s of d.sections) {
    s.title = normDots(s.title)
    for (const b of s.blocks) {
      if (b.text) b.text = normDots(b.text)
      if (b.items) b.items = b.items.map(normDots)
      if (b.table) {
        if (b.table.title) b.table.title = normDots(b.table.title)
        if (b.table.note) b.table.note = normDots(b.table.note)
        b.table.headers = b.table.headers.map(normDots)
        b.table.rows = b.table.rows.map((r) => r.map((c) => normDots(c)))
      }
    }
  }
  return d
}

function zipCols(a: string[], b: string[]): string[][] {
  const len = Math.max(a.length, b.length)
  const rows: string[][] = []
  for (let i = 0; i < len; i++) rows.push([a[i] ?? '', b[i] ?? ''])
  return rows
}

function statusLabel(s: string): string {
  return s === 'DONE' ? 'Terminé' : s === 'IN_PROGRESS' ? 'En cours' : s === 'BLOCKED' ? 'Bloqué' : 'À faire'
}

function verdictLabel(v: string): string {
  return v === 'FAVORABLE' ? 'Favorable' : v === 'RESERVE' ? 'Favorable sous réserves' : v === 'DEFAVORABLE' ? 'Défavorable' : '—'
}

// ---------------------------------------------------------------------------
// Rapport de diagnostic & de validation (imprimable même sans validation)
// ---------------------------------------------------------------------------

const SEVERITY_LABELS: Record<string, string> = {
  BLOQUANT: 'Bloquant',
  MAJEUR: 'Majeure',
  MINEUR: 'Mineure',
}

const INDICATOR_STATUS_LABELS: Record<string, string> = {
  FAVORABLE: 'Favorable',
  EQUILIBRE: 'À l\'équilibre',
  DEFAVORABLE: 'Défavorable',
  NON_CALCULE: 'Non calculable',
}

/** Construit le rapport de diagnostic imprimable (PDF) à partir du rapport de validation. */
export function buildDiagnosticDossier(report: ValidationReport, project: Project): Dossier {
  const problems = report.problems
  return normalizeThousandsDots({
    title: `Rapport de diagnostic – ${project.name}`,
    subtitle: 'Validation automatique & analyse de rentabilité',
    author: '',
    organization: '',
    date: new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }),
    currency: project.currency || 'XAF',
    projectName: project.name,
    sections: [
      {
        id: 'synthese',
        title: '1. Synthèse de la validation',
        blocks: [
          { type: 'paragraph', text: `Décision de Gescom Project : ${report.statusLabel.toUpperCase()}. ${report.decision}` },
          {
            type: 'table',
            table: {
              title: 'Tableau de bord de la validation',
              headers: ['Indicateur', 'Résultat'],
              rows: [
                ['Statut du projet', report.statusLabel],
                ['Taux global de conformité', `${groupNumber(report.conformityRate)} %`],
                ['Sections conformes', `${report.counts.sectionsConformes} sur ${report.counts.sectionsTotal}`],
                ['Anomalies détectées', groupNumber(report.counts.anomalies)],
                ['Corrections obligatoires restantes', groupNumber(report.counts.correctionsRestantes)],
                ['Rentabilité financière', report.rentabilityFavorable ? 'Avis favorable (au moins un indicateur favorable)' : 'Aucun indicateur favorable'],
                ['Impression de la version définitive', report.canExport ? 'Autorisée' : 'Bloquée jusqu\'à validation'],
              ],
            },
          },
        ],
      },
      {
        id: 'indicateurs',
        title: '2. Analyse de la rentabilité financière',
        blocks: [
          {
            type: 'paragraph',
            text: 'Trois indicateurs sont calculés sur la même base de flux financiers, avec un investissement initial et des hypothèses cohérents. Le projet est réputé financièrement rentable dès qu\'au moins un des trois indicateurs satisfait son critère de rentabilité.',
          },
          ...(report.indicators.length > 0
            ? [{
                type: 'table' as const,
                table: {
                  title: 'Indicateurs calculés',
                  headers: ['Indicateur', 'Valeur', 'Critère de validation', 'Avis'],
                  rows: report.indicators.map((i) => [i.label, i.formatted, i.criterion, INDICATOR_STATUS_LABELS[i.status] || i.status]),
                  note: `Taux d'actualisation retenu : ${groupNumber(report.discountRatePct, 1)} %.`,
                },
              }]
            : [{ type: 'paragraph' as const, text: 'Les indicateurs n\'ont pas pu être calculés : complétez d\'abord les hypothèses financières (investissement, prévisions de ventes).' }]),
          ...(report.indicators.length > 0
            ? [{ type: 'bullets' as const, text: 'Lecture des indicateurs', items: report.indicators.map((i) => `${i.label} : ${i.formatted} — ${i.explanation}`) }]
            : []),
        ],
      },
      {
        id: 'controles',
        title: '3. Contrôle de conformité par section',
        blocks: [
          {
            type: 'table',
            table: {
              title: 'Résultat des contrôles',
              headers: ['Section du dossier', 'Statut', 'Conformité'],
              rows: report.sections.map((s) => [
                s.label,
                s.status === 'CONFORME' ? 'Conforme' : 'À corriger',
                `${groupNumber(s.filledRatio)} %`,
              ]),
            },
          },
        ],
      },
      {
        id: 'corrections',
        title: '4. Zones à corriger & recommandations',
        blocks: problems.length === 0
          ? [{ type: 'paragraph', text: 'Aucune anomalie détectée : le dossier satisfait à l\'ensemble des exigences de GESCOM PROJECT.' }]
          : [
              {
                type: 'table',
                table: {
                  headers: ['Section', 'Problème détecté', 'Correction recommandée'],
                  rows: problems.map((p) => [
                    `${p.sectionLabel} (${SEVERITY_LABELS[p.severity] || p.severity})`,
                    `${p.problem} ${p.why}`,
                    p.recommendation,
                  ]),
                },
              },
              {
                type: 'paragraph',
                text: 'Après chaque correction dans la plateforme, relancez l\'analyse de validation : les contrôles sont recalculés automatiquement et le statut du projet est actualisé.',
              },
            ],
      },
    ],
  })
}
