// GESCOM PROJECT – Génération XLSX (exceljs) avec FORMULES réelles
// Les classeurs restent vivants : hypothèses, compte de résultat, flux,
// VAN et TRI se recalculent dans Excel si l'utilisateur modifie les
// hypothèses. Les formules reflètent exactement le moteur financier partagé.
// Plan GRATUIT : feuilles Financement, Échéancier, Compte de résultat,
// Indicateurs et Scénarios omises ; prévision des ventes exclue des Hypothèses.
import ExcelJS from 'exceljs'
import JSZip from 'jszip'
import type { FinanceData } from '@/lib/types'
import { computeFinance } from '@/lib/finance'
import type { Project, Task } from '@prisma/client'

export interface XlsxOptions {
  /** Plan Premium : toutes les feuilles financières sont incluses. */
  premium?: boolean
}

const NAVY = 'FF0F172A'
const GOLD = 'FFD4A72C'
// Séparateur de milliers « . » forcé (convention GESCOM : 6.500.000 FCFA).
// Le format standard #,##0 laisserait Excel choisir le séparateur selon la
// locale (espace en français, virgule en anglais). Les conditions gèrent les
// négatifs (VAN possible) et les montants < 1 000.
const MONEY_FMT = '[>=1000]#"."##0"."##0;[<=-1000]-#"."##0"."##0;0'

export async function generateXlsx(project: Project, tasks: Task[], opts: XlsxOptions = {}): Promise<Buffer> {
  const premium = opts.premium !== false // défaut : Premium (rétrocompatibilité)
  const finance: FinanceData = safeParseFinance(project.finance)
  const comp = computeFinance(finance)
  const wb = new ExcelJS.Workbook()
  wb.creator = 'GESCOM PROJECT'
  wb.created = new Date()
  const cur = currencyLabel(project.currency)
  // Horizon de projection en années (utilisé par les feuilles Compte de
  // résultat ET Indicateurs) — 1 à 10 ans, 5 par défaut.
  const H = Math.max(1, Math.min(10, Number(finance.assumptions.horizonYears) || 5))

  // Indices de lignes utilisés pour les références entre feuilles
  let invTotal = 0, invBfr = 0, invBesoin = 0
  let finTotal = 0, finGap = 0
  const cr = { CA: 0, CV: 0, MCV: 0, CF: 0, EBE: 0, AMO: 0, INT: 0, EBT: 0, TAX: 0, NET: 0, CAF: 0, PRIN: 0, FLUX: 0, CUM: 0, FCFD: 0, TRIRANGE: 0 }
  const ind = { VAN: 0, TRI: 0 }

  // ------------------------------------------------------------------
  // Feuille 1 : Synthèse (créée en premier pour l'ordre des onglets,
  // remplie à la fin quand toutes les références sont connues)
  // ------------------------------------------------------------------
  const syn = wb.addWorksheet('Synthèse', { views: [{ showGridLines: false }] })

  // ------------------------------------------------------------------
  // Feuille 2 : Investissement
  // ------------------------------------------------------------------
  const inv = wb.addWorksheet('Investissement', { views: [{ showGridLines: false }] })
  titleBlock(inv, 'Plan d\'investissement', `Devise : ${cur}`)
  headerRow(inv, 3, ['Rubrique', 'Catégorie', 'Montant', 'Amortissable', 'Durée amort. (ans)', 'Amortissement annuel'])
  {
    let ir = 4
    const first = ir
    for (const line of finance.investments) {
      inv.getCell(ir, 1).value = line.label
      inv.getCell(ir, 2).value = line.category
      inv.getCell(ir, 3).value = Number(line.amount) || 0
      inv.getCell(ir, 4).value = line.depreciable ? 'Oui' : 'Non'
      inv.getCell(ir, 5).value = line.depreciable ? Number(line.depYears) || 0 : ''
      inv.getCell(ir, 6).value = { formula: `IF(AND($D${ir}="Oui",ISNUMBER($E${ir}),$E${ir}>0),$C${ir}/$E${ir},0)` }
      ir++
    }
    const last = ir - 1
    inv.getCell(ir, 1).value = 'TOTAL INVESTISSEMENTS'
    inv.getCell(ir, 3).value = { formula: `SUM(C${first}:C${last})` }
    totalStyle(inv.getRow(ir))
    invTotal = ir
    ir++
    inv.getCell(ir, 1).value = 'Fonds de roulement initial (BFR)'
    inv.getCell(ir, 3).value = Number(finance.workingCapital) || 0
    invBfr = ir
    ir++
    inv.getCell(ir, 1).value = 'BESOIN TOTAL DE FINANCEMENT'
    inv.getCell(ir, 3).value = { formula: `C${invTotal}+C${invBfr}` }
    totalStyle(inv.getRow(ir))
    invBesoin = ir
    formatMoneyCols(inv, [3], first, invBesoin)
    formatMoneyCols(inv, [6], first, last)
    setWidths(inv, [46, 22, 16, 12, 18, 20])
  }

  // ------------------------------------------------------------------
  // Feuille 3 : Financement (Premium)
  // ------------------------------------------------------------------
  if (premium) {
  const fin = wb.addWorksheet('Financement', { views: [{ showGridLines: false }] })
  titleBlock(fin, 'Plan de financement', `Devise : ${cur}`)
  headerRow(fin, 3, ['Source', 'Nature', 'Montant', 'Taux annuel (%)', 'Durée (ans)'])
  {
    let fr = 4
    const first = fr
    for (const f of finance.financing) {
      fin.getCell(fr, 1).value = f.source
      fin.getCell(fr, 2).value = f.type === 'EQUITY' ? 'Fonds propres' : f.type === 'LOAN' ? 'Emprunt' : 'Subvention'
      fin.getCell(fr, 3).value = Number(f.amount) || 0
      fin.getCell(fr, 4).value = f.type === 'LOAN' ? Number(f.rate) || 0 : ''
      fin.getCell(fr, 5).value = f.type === 'LOAN' ? Number(f.termYears) || 0 : ''
      fr++
    }
    const last = fr - 1
    fin.getCell(fr, 1).value = 'TOTAL FINANCEMENT'
    fin.getCell(fr, 3).value = { formula: `SUM(C${first}:C${last})` }
    totalStyle(fin.getRow(fr))
    finTotal = fr
    fr++
    fin.getCell(fr, 1).value = 'Besoins totaux (feuille Investissement)'
    fin.getCell(fr, 3).value = { formula: `Investissement!C${invBesoin}` }
    fr++
    fin.getCell(fr, 1).value = 'ÉCART À FINANCER (besoins − financement)'
    fin.getCell(fr, 3).value = { formula: `C${fr - 1}-C${finTotal}` }
    totalStyle(fin.getRow(fr))
    finGap = fr
    formatMoneyCols(fin, [3], first, finGap)
    setWidths(fin, [40, 18, 18, 16, 12])
  }
  }

  // ------------------------------------------------------------------
  // Feuille 4 : Échéanciers d'emprunts (formules, Premium)
  // ------------------------------------------------------------------
  const loans = finance.financing.filter((f) => f.type === 'LOAN' && (Number(f.amount) || 0) > 0)
  if (loans.length > 0 && premium) {
    const ech = wb.addWorksheet('Échéancier', { views: [{ showGridLines: false }] })
    titleBlock(ech, 'Échéanciers de remboursement', 'Annuités constantes : capital restant dû, intérêts, capital remboursé')
    let er = 4
    for (const loan of loans) {
      const finRowIdx = finance.financing.indexOf(loan) + 4
      ech.getCell(er, 1).value = loan.source
      ech.getCell(er, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
      er++
      headerRow(ech, er, ['Année', 'Capital début', 'Intérêts', 'Capital remboursé', 'Annuité', 'Capital fin'])
      er++
      const n = Math.max(1, Math.round(Number(loan.termYears) || 5))
      for (let y = 1; y <= n; y++) {
        ech.getCell(er, 1).value = y
        ech.getCell(er, 2).value = { formula: y === 1 ? `Financement!C${finRowIdx}` : `F${er - 1}` }
        ech.getCell(er, 3).value = { formula: `B${er}*Financement!$D$${finRowIdx}/100` }
        ech.getCell(er, 4).value = { formula: `IF(A${er}=Financement!$E$${finRowIdx},B${er},E${er}-C${er})` }
        ech.getCell(er, 5).value = {
          formula: `IF(Financement!$D$${finRowIdx}=0,Financement!$C$${finRowIdx}/Financement!$E$${finRowIdx},Financement!$C$${finRowIdx}*Financement!$D$${finRowIdx}/100/(1-(1+Financement!$D$${finRowIdx}/100)^-Financement!$E$${finRowIdx}))`,
        }
        ech.getCell(er, 6).value = { formula: `B${er}-D${er}` }
        er++
      }
      er++
    }
    formatMoneyCols(ech, [2, 3, 4, 5, 6], 6, er)
    setWidths(ech, [34, 16, 14, 18, 16, 16])
  }

  // ------------------------------------------------------------------
  // Feuille 5 : Hypothèses
  // ------------------------------------------------------------------
  const hy = wb.addWorksheet('Hypothèses', { views: [{ showGridLines: false }] })
  titleBlock(hy, 'Hypothèses d\'exploitation', 'Valeurs modifiables — les prévisions se recalculent')
  let prodFirst = 0, prodLast = -1, varFirst = 0, varLast = -1, fixFirst = 0, fixLast = -1, staffFirst = 0, staffLast = -1
  {
    let hr = 4
    if (premium) {
    hy.getCell(hr, 1).value = 'PRODUITS (chiffre d\'affaires)'
    hy.getCell(hr, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
    hr++
    headerRow(hy, hr, ['Produit / service', 'Unité', 'Quantité an 1', 'Prix an 1', 'Croissance volume (%/an)', 'Croissance prix (%/an)'])
    hr++
    prodFirst = hr
    for (const p of finance.assumptions.products) {
      hy.getCell(hr, 1).value = p.label
      hy.getCell(hr, 2).value = p.unit
      hy.getCell(hr, 3).value = Number(p.qty) || 0
      hy.getCell(hr, 4).value = Number(p.unitPrice) || 0
      hy.getCell(hr, 5).value = Number(p.volumeGrowth) || 0
      hy.getCell(hr, 6).value = Number(p.priceGrowth) || 0
      hr++
    }
    prodLast = hr - 1
    hr++
    }
    hy.getCell(hr, 1).value = 'CHARGES VARIABLES'
    hy.getCell(hr, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
    hr++
    headerRow(hy, hr, ['Charge', 'Mode', 'Quantité (an 1)', 'Prix unitaire', 'Croissance (%/an)', '% du CA'])
    hr++
    varFirst = hr
    for (const c of finance.assumptions.variableCosts) {
      hy.getCell(hr, 1).value = c.label
      hy.getCell(hr, 2).value = c.mode === 'PCT' ? '% du CA' : 'Qté × prix'
      hy.getCell(hr, 3).value = c.mode === 'QTY' ? Number(c.qty) || 0 : ''
      hy.getCell(hr, 4).value = c.mode === 'QTY' ? Number(c.unitPrice) || 0 : ''
      hy.getCell(hr, 5).value = c.mode === 'QTY' ? Number(c.growth) || 0 : ''
      hy.getCell(hr, 6).value = c.mode === 'PCT' ? Number(c.pct) || 0 : ''
      hr++
    }
    varLast = hr - 1
    hr++
    hy.getCell(hr, 1).value = 'CHARGES FIXES'
    hy.getCell(hr, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
    hr++
    headerRow(hy, hr, ['Charge', 'Montant annuel an 1', 'Croissance (%/an)'])
    hr++
    fixFirst = hr
    for (const c of finance.assumptions.fixedCosts) {
      hy.getCell(hr, 1).value = c.label
      hy.getCell(hr, 2).value = Number(c.annualAmount) || 0
      hy.getCell(hr, 3).value = Number(c.growth) || 0
      hr++
    }
    fixLast = hr - 1
    hr++
    hy.getCell(hr, 1).value = 'PERSONNEL'
    hy.getCell(hr, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
    hr++
    headerRow(hy, hr, ['Poste', 'Effectif', 'Salaire mensuel', 'Augmentation annuelle (%)'])
    hr++
    staffFirst = hr
    for (const s of finance.assumptions.staff) {
      hy.getCell(hr, 1).value = s.role
      hy.getCell(hr, 2).value = Number(s.count) || 0
      hy.getCell(hr, 3).value = Number(s.monthlySalary) || 0
      hy.getCell(hr, 4).value = Number(s.annualGrowth) || 0
      hr++
    }
    staffLast = hr - 1
    if (prodLast >= prodFirst) formatMoneyCols(hy, [4], prodFirst, prodLast)
    formatMoneyCols(hy, [2], fixFirst, fixLast)
    formatMoneyCols(hy, [3], staffFirst, staffLast)
    setWidths(hy, [52, 14, 18, 16, 22, 18])
  }

  // ------------------------------------------------------------------
  // Feuille 6 : Compte de résultat (une colonne par année, tout en formules, Premium)
  // ------------------------------------------------------------------
  if (premium) {
  const crs = wb.addWorksheet('Compte de résultat', { views: [{ showGridLines: false }] })
  titleBlock(crs, 'Compte de résultat prévisionnel', `${H} ans — formules actives`)
  crs.getCell(4, 1).value = 'Taux d\'impôt (%)'
  crs.getCell(4, 2).value = Number(finance.assumptions.taxRate) || 0
  crs.getCell(5, 1).value = 'Taux d\'actualisation (%)'
  crs.getCell(5, 2).value = Number(finance.assumptions.discountRate) || 0
  const TAX = '$B$4'
  const HDR = 7
  crs.getCell(HDR, 1).value = 'Rubrique'
  for (let y = 1; y <= H; y++) crs.getCell(HDR, 1 + y).value = `Année ${y}`
  headerStyle(crs.getRow(HDR))
  const col = (y: number) => colLetter(1 + y) // année 1 → colonne B

  let rowIdx = HDR + 1
  const putRow = (key: keyof typeof cr, label: string, values: Array<string | number>, bold = false) => {
    crs.getCell(rowIdx, 1).value = label
    for (let y = 1; y <= H; y++) {
      const v = values[y - 1]
      crs.getCell(rowIdx, 1 + y).value =
        typeof v === 'string' ? { formula: v } : v
    }
    if (bold) totalStyle(crs.getRow(rowIdx))
    cr[key] = rowIdx
    rowIdx++
  }
  const diff = (keys: Array<keyof typeof cr>, y: number) =>
    keys.map((k) => `${col(y)}${cr[k]}`).join('-')

  // CA
  putRow('CA', 'CHIFFRE D\'AFFAIRES', mapYears(H, (y) =>
    prodLast >= prodFirst
      ? `SUMPRODUCT(Hypothèses!$C$${prodFirst}:$C$${prodLast}*(1+Hypothèses!$E$${prodFirst}:$E$${prodLast}/100)^${y - 1}*Hypothèses!$D$${prodFirst}:$D$${prodLast}*(1+Hypothèses!$F$${prodFirst}:$F$${prodLast}/100)^${y - 1})`
      : 0), true)

  // Charges variables
  putRow('CV', 'Charges variables', mapYears(H, (y) => {
    const parts: string[] = []
    const hasQty = finance.assumptions.variableCosts.some((c) => c.mode === 'QTY')
    if (hasQty) {
      parts.push(`SUMPRODUCT(Hypothèses!$C$${varFirst}:$C$${varLast}*(1+Hypothèses!$E$${varFirst}:$E$${varLast}/100)^${y - 1}*Hypothèses!$D$${varFirst}:$D$${varLast}*(1+Hypothèses!$E$${varFirst}:$E$${varLast}/100)^${y - 1})`)
    }
    const hasPct = finance.assumptions.variableCosts.some((c) => c.mode === 'PCT')
    if (hasPct) {
      parts.push(`SUM(Hypothèses!$F$${varFirst}:$F$${varLast})*${col(y)}${cr.CA}/100`)
    }
    return parts.length > 0 ? parts.join('+') : 0
  }))

  putRow('MCV', 'Marge sur coûts variables', mapYears(H, (y) => diff(['CA', 'CV'], y)))
  putRow('CF', 'Charges fixes (exploitation + personnel)', mapYears(H, (y) => {
    const parts: string[] = []
    if (fixLast >= fixFirst) {
      parts.push(`SUMPRODUCT(Hypothèses!$B$${fixFirst}:$B$${fixLast}*(1+Hypothèses!$C$${fixFirst}:$C$${fixLast}/100)^${y - 1})`)
    }
    if (staffLast >= staffFirst) {
      parts.push(`SUMPRODUCT(Hypothèses!$B$${staffFirst}:$B$${staffLast}*Hypothèses!$C$${staffFirst}:$C$${staffLast}*12*(1+Hypothèses!$D$${staffFirst}:$D$${staffLast}/100)^${y - 1})`)
    }
    return parts.length > 0 ? parts.join('+') : 0
  }))
  putRow('EBE', 'EXCÉDENT BRUT D\'EXPLOITATION', mapYears(H, (y) => diff(['MCV', 'CF'], y)), true)

  // Amortissements
  const invFirstRow = 4
  const invLastRow = 3 + (finance.investments?.length ?? 0)
  putRow('AMO', 'Amortissements', mapYears(H, (y) =>
    invLastRow >= invFirstRow
      ? `SUMPRODUCT((Investissement!$E$${invFirstRow}:$E$${invLastRow}>=${y})*Investissement!$F$${invFirstRow}:$F$${invLastRow})`
      : 0))

  // Intérêts & capital via l'échéancier
  const hasEch = loans.length > 0
  putRow('INT', 'Intérêts sur emprunts', mapYears(H, (y) => (hasEch ? `SUMIF('Échéancier'!$A:$A,${y},'Échéancier'!$C:$C)` : 0)))
  putRow('EBT', 'Résultat avant impôt', mapYears(H, (y) => diff(['EBE', 'AMO', 'INT'], y)))
  putRow('TAX', 'Impôt sur les sociétés', mapYears(H, (y) => `MAX(0,${col(y)}${cr.EBT})*${TAX}/100`))
  putRow('NET', 'RÉSULTAT NET', mapYears(H, (y) => diff(['EBT', 'TAX'], y)), true)
  rowIdx++
  crs.getCell(rowIdx, 1).value = 'FLUX DE TRÉSORERIE'
  crs.getCell(rowIdx, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
  rowIdx++
  putRow('CAF', 'Capacité d\'autofinancement (CAF)', mapYears(H, (y) => `${col(y)}${cr.NET}+${col(y)}${cr.AMO}`))
  putRow('PRIN', 'Remboursement du capital emprunté', mapYears(H, (y) => (hasEch ? `SUMIF('Échéancier'!$A:$A,${y},'Échéancier'!$D:$D)` : 0)))
  putRow('FLUX', 'Flux net de trésorerie', mapYears(H, (y) => diff(['CAF', 'PRIN'], y)), true)
  const cumRowIdx = rowIdx
  putRow('CUM', 'Flux cumulé (avec mise de fonds initiale)', mapYears(H, (y) =>
    y === 1 ? `-(Investissement!C${invBesoin})+${col(1)}${cr.FLUX}` : `${col(y - 1)}${cumRowIdx}+${col(y)}${cr.FLUX}`))
  rowIdx++
  crs.getCell(rowIdx, 1).value = 'FLUX PROJET (pour VAN & TRI, avant financement)'
  crs.getCell(rowIdx, 1).font = { bold: true, size: 12, color: { argb: NAVY } }
  rowIdx++
  putRow('FCFD', 'Flux de trésorerie disponible (FCFD)', mapYears(H, (y) =>
    `(${col(y)}${cr.EBE}-${col(y)}${cr.AMO})*(1-${TAX}/100)+${col(y)}${cr.AMO}`))
  // Ligne spéciale TRI : mise de fonds à t=0 (col. B), puis flux années 1..H,
  // BFR final ajouté au dernier flux — IRR(B:G) est alors identique au moteur.
  crs.getCell(rowIdx, 1).value = 'Flux pour le TRI (mise de fonds à t=0, BFR final inclus)'
  cr.TRIRANGE = rowIdx
  crs.getCell(rowIdx, 2).value = { formula: `-(Investissement!C${invBesoin})` }
  for (let y = 1; y <= H; y++) {
    crs.getCell(rowIdx, 2 + y).value = { formula: `${col(y)}${cr.FCFD}${y === H ? `+Investissement!C${invBfr}` : ''}` }
  }
  rowIdx++

  for (let c = 2; c <= 1 + H; c++) formatMoneyCols(crs, [c], HDR + 1, rowIdx - 1)
  setWidths(crs, [46, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15])
  }

  // ------------------------------------------------------------------
  // Feuille 7 : Indicateurs (VAN & TRI en formules Excel natives, Premium)
  // ------------------------------------------------------------------
  if (premium) {
  const ind_ = wb.addWorksheet('Indicateurs', { views: [{ showGridLines: false }] })
  titleBlock(ind_, 'Indicateurs de rentabilité', 'VAN et TRI calculés par formules Excel natives à partir des feuilles précédentes')
  headerRow(ind_, 4, ['Indicateur', 'Valeur', 'Lecture'])
  {
    let nr = 5
    const fcfRange = `'Compte de résultat'!B${cr.FCFD}:${colLetter(1 + H)}${cr.FCFD}`
    const triRange = `'Compte de résultat'!B${cr.TRIRANGE}:${colLetter(2 + H)}${cr.TRIRANGE}`
    ind_.getCell(nr, 1).value = 'VAN — Valeur Actuelle Nette'
    ind_.getCell(nr, 2).value = { formula: `-(Investissement!C${invBesoin})+NPV('Compte de résultat'!$B$5/100,${fcfRange})+(Investissement!C${invBfr})/(1+'Compte de résultat'!$B$5/100)^${H}` }
    ind_.getCell(nr, 2).numFmt = MONEY_FMT
    ind_.getCell(nr, 3).value = `VAN positive : le projet crée de la valeur au taux d'actualisation retenu (${finance.assumptions.discountRate} %)`
    ind.VAN = nr
    nr++
    ind_.getCell(nr, 1).value = 'TRI — Taux de Rentabilité Interne (%)'
    ind_.getCell(nr, 2).value = { formula: `IF(ISERROR(IRR(${triRange})),"—",IRR(${triRange})*100)` }
    ind_.getCell(nr, 2).numFmt = '0.0'
    ind_.getCell(nr, 3).value = 'À comparer au coût du capital'
    ind.TRI = nr
    nr++
    ind_.getCell(nr, 1).value = 'Délai de récupération (ans)'
    ind_.getCell(nr, 2).value = comp.ratios.payback !== null ? Number(comp.ratios.payback.toFixed(2)) : '—'
    ind_.getCell(nr, 3).value = 'Calculé par le moteur financier GESCOM PROJECT (interpolation linéaire sur les flux projet)'
    nr++
    ind_.getCell(nr, 1).value = 'Seuil de rentabilité (année 1)'
    ind_.getCell(nr, 2).value = { formula: `('Compte de résultat'!B${cr.CF}+'Compte de résultat'!B${cr.AMO}+'Compte de résultat'!B${cr.INT})/(1-'Compte de résultat'!B${cr.CV}/'Compte de résultat'!B${cr.CA})` }
    ind_.getCell(nr, 2).numFmt = MONEY_FMT
    ind_.getCell(nr, 3).value = 'Chiffre d\'affaires couvrant la totalité des charges (année 1)'
    nr++
    ind_.getCell(nr, 1).value = 'Marge nette (année 1)'
    ind_.getCell(nr, 2).value = { formula: `'Compte de résultat'!B${cr.NET}/'Compte de résultat'!B${cr.CA}*100` }
    ind_.getCell(nr, 2).numFmt = '0.0"%"'
    ind_.getCell(nr, 3).value = 'Résultat net / chiffre d\'affaires'
    nr++
    ind_.getCell(nr, 1).value = 'Marge d\'EBE (année 1)'
    ind_.getCell(nr, 2).value = { formula: `'Compte de résultat'!B${cr.EBE}/'Compte de résultat'!B${cr.CA}*100` }
    ind_.getCell(nr, 2).numFmt = '0.0"%"'
    ind_.getCell(nr, 3).value = 'EBE / chiffre d\'affaires'
    nr++
    ind_.getCell(nr, 1).value = 'Autonomie financière'
    ind_.getCell(nr, 2).value = { formula: `IF(Financement!C${finTotal}=0,"—",(Financement!C${finTotal}-SUMIF(Financement!B:B,"Emprunt",Financement!C:C))/Financement!C${finTotal}*100)` }
    ind_.getCell(nr, 2).numFmt = '0.0"%"'
    ind_.getCell(nr, 3).value = 'Fonds propres et subventions / financement total'
    nr++
    setWidths(ind_, [36, 18, 66])
  }
  }

  // ------------------------------------------------------------------
  // Feuille 8 : Scénarios (Premium)
  // ------------------------------------------------------------------
  if (premium) {
  {
    const sc = wb.addWorksheet('Scénarios', { views: [{ showGridLines: false }] })
    titleBlock(sc, 'Analyse des scénarios', 'Pessimiste (volume −15 %, prix −10 %) · Réaliste · Optimiste (volume +10 %, prix +5 %)')
    headerRow(sc, 4, ['Scénario', 'CA année 1', 'Résultat net année 1', 'Résultat net moyen', 'Délai de récupération (ans)', 'VAN'])
    let sr = 5
    for (const s of comp.scenarios) {
      sc.getCell(sr, 1).value = s.name === 'OPTIMISTIC' ? 'Optimiste' : s.name === 'PESSIMISTIC' ? 'Pessimiste' : 'Réaliste'
      sc.getCell(sr, 2).value = Math.round(s.revenue1)
      sc.getCell(sr, 3).value = Math.round(s.netIncome1)
      sc.getCell(sr, 4).value = Math.round(s.netIncomeAvg)
      sc.getCell(sr, 5).value = s.payback !== null ? Number(s.payback.toFixed(2)) : '—'
      sc.getCell(sr, 6).value = Math.round(s.npv)
      sr++
    }
    formatMoneyCols(sc, [2, 3, 4, 6], 5, sr - 1)
    noteBlock(sc, sr + 1, 'Valeurs calculées par le moteur financier GESCOM PROJECT à partir des hypothèses enregistrées.')
    setWidths(sc, [16, 16, 20, 20, 26, 16])
  }
  }

  // ------------------------------------------------------------------
  // Feuille 9 : Plan d'action
  // ------------------------------------------------------------------
  if (tasks.length > 0) {
    const pa = wb.addWorksheet('Plan d\'action', { views: [{ showGridLines: false }] })
    titleBlock(pa, 'Plan d\'action & calendrier', `${tasks.length} activités`)
    headerRow(pa, 4, ['Phase', 'Activité', 'Responsable', 'Début', 'Fin', 'Statut', 'Avancement (%)'])
    let pr = 5
    for (const t of tasks) {
      pa.getCell(pr, 1).value = t.phase
      pa.getCell(pr, 2).value = t.title
      pa.getCell(pr, 3).value = t.responsible || '—'
      pa.getCell(pr, 4).value = t.startDate || '—'
      pa.getCell(pr, 5).value = t.endDate || '—'
      pa.getCell(pr, 6).value = taskStatusLabel(t.status)
      pa.getCell(pr, 7).value = Math.round(t.progress)
      pr++
    }
    setWidths(pa, [30, 52, 20, 12, 12, 12, 16])
  }

  // ------------------------------------------------------------------
  // Remplissage de la Synthèse (toutes les références sont connues)
  // ------------------------------------------------------------------
  titleBlock(syn, 'Synthèse du projet', `${project.name} — généré par GESCOM PROJECT`)
  {
    let r = 4
    addKv(syn, r++, 'Secteur d\'activité', project.sector || '—')
    addKv(syn, r++, 'Localisation', [project.region, project.country].filter(Boolean).join(', ') || '—')
    addKv(syn, r++, 'Devise', cur)
    r++
    addKv(syn, r++, 'Total investissements', { formula: `Investissement!C${invTotal}` }, MONEY_FMT)
    addKv(syn, r++, 'Fonds de roulement (BFR)', Number(finance.workingCapital) || 0, MONEY_FMT)
    addKv(syn, r++, 'BESOIN TOTAL DE FINANCEMENT', { formula: `Investissement!C${invBesoin}` }, MONEY_FMT, true)
    if (premium) {
      addKv(syn, r++, 'Financement total prévu', { formula: `Financement!C${finTotal}` }, MONEY_FMT)
      addKv(syn, r++, '  dont fonds propres', comp.totalEquity, MONEY_FMT)
      addKv(syn, r++, '  dont emprunts', comp.totalLoans, MONEY_FMT)
      addKv(syn, r++, '  dont subventions', comp.totalGrants, MONEY_FMT)
      addKv(syn, r++, 'Écart à financer', { formula: `Financement!C${finGap}` }, MONEY_FMT, true)
      r++
      addKv(syn, r++, 'CA année 1', { formula: `'Compte de résultat'!B${cr.CA}` }, MONEY_FMT)
      addKv(syn, r++, 'Résultat net année 1', { formula: `'Compte de résultat'!B${cr.NET}` }, MONEY_FMT, true)
      addKv(syn, r++, 'VAN (flux projet actualisés)', { formula: `Indicateurs!B${ind.VAN}` }, MONEY_FMT, true)
      addKv(syn, r++, 'TRI (%)', { formula: `Indicateurs!B${ind.TRI}` }, '0.0', true)
      addKv(syn, r++, 'Délai de récupération (ans)', comp.ratios.payback !== null ? Number(comp.ratios.payback.toFixed(2)) : '—', '0.00')
      addKv(syn, r++, 'Seuil de rentabilité (année 1)', Math.round(comp.ratios.breakEvenRevenue), MONEY_FMT)
      r++
      noteBlock(syn, r, 'Note : ce classeur contient des formules actives. Modifiez les hypothèses (feuilles Investissement, Financement, Hypothèses) : le compte de résultat, les flux et les indicateurs se recalculent automatiquement dans Excel.')
    } else {
      r++
      noteBlock(syn, r, 'Plan Gratuit : le plan de financement, la prévision des ventes, le compte de résultat et les indicateurs de rentabilité (VAN, TRI, scénarios) sont disponibles avec l\'abonnement Premium de GESCOM PROJECT.')
    }
  }

  // Police documentaire : Times New Roman, corps 12, sur toutes les cellules
  // (les cellules sans police explicite resteraient en Calibri 11).
  applyWorkbookFont(wb)

  const raw = await wb.xlsx.writeBuffer()
  return patchDefaultFont(Buffer.from(raw as ArrayBuffer))
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function safeParseFinance(json: string | null | undefined): FinanceData {
  try {
    const v = json ? JSON.parse(json) : {}
    return {
      investments: Array.isArray(v.investments) ? v.investments : [],
      workingCapital: Number(v.workingCapital) || 0,
      financing: Array.isArray(v.financing) ? v.financing : [],
      assumptions: {
        horizonYears: Number(v.assumptions?.horizonYears) || 5,
        discountRate: Number(v.assumptions?.discountRate) || 0,
        taxRate: Number(v.assumptions?.taxRate) || 0,
        products: Array.isArray(v.assumptions?.products) ? v.assumptions.products : [],
        variableCosts: Array.isArray(v.assumptions?.variableCosts) ? v.assumptions.variableCosts : [],
        fixedCosts: Array.isArray(v.assumptions?.fixedCosts) ? v.assumptions.fixedCosts : [],
        staff: Array.isArray(v.assumptions?.staff) ? v.assumptions.staff : [],
      },
    }
  } catch {
    return {
      investments: [], workingCapital: 0, financing: [],
      assumptions: { horizonYears: 5, discountRate: 0, taxRate: 0, products: [], variableCosts: [], fixedCosts: [], staff: [] },
    }
  }
}

function currencyLabel(c: string): string {
  return ['EUR', 'USD', 'CAD', 'CHF', 'MAD'].includes(c) ? c : 'FCFA'
}

// Convention documentaire GESCOM : Times New Roman, corps 12. Appliquée en
// post-traitement sur toutes les cellules du classeur, en conservant les
// attributs existants (gras, italique, couleur) et les tailles spécifiques
// (titres 16, en-têtes 10, notes 9) ; les autres cellules passent en 12.
function applyWorkbookFont(wb: ExcelJS.Workbook) {
  wb.eachSheet((ws) => {
    ws.eachRow({ includeEmpty: false }, (row) => {
      row.eachCell({ includeEmpty: false }, (cell) => {
        const f = cell.font ?? {}
        cell.font = {
          name: 'Times New Roman',
          size: f.size ?? 12,
          bold: f.bold,
          italic: f.italic,
          color: f.color,
        }
      })
    })
  })
}

// ExcelJS ne permet pas de redéfinir la police « par défaut » du classeur
// (entrée font 0 de styles.xml, restée Calibri 11 avec scheme="minor") :
// elle ne concerne que les cellules vides ou saisies après coup dans Excel.
// On la remplace aussi par Times New Roman 12 par simple retouche du zip,
// pour que tout le classeur — y compris les saisies futures — soit homogène.
async function patchDefaultFont(buf: Buffer): Promise<Buffer> {
  try {
    const zip = await JSZip.loadAsync(buf)
    const entry = zip.file('xl/styles.xml')
    if (!entry) return buf
    let xml = await entry.async('string')
    xml = xml.replace(
      /<font>(?:(?!<\/font>).)*?<scheme val="minor"\/>(?:(?!<\/font>).)*?<name val="Calibri"\/><\/font>/,
      '<font><color theme="1"/><family val="2"/><sz val="12"/><name val="Times New Roman"/></font>',
    )
    zip.file('xl/styles.xml', xml)
    return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })
  } catch {
    // Le patch cosmétique ne doit jamais faire échouer l'export.
    return buf
  }
}

function taskStatusLabel(s: string): string {
  return s === 'DONE' ? 'Terminé' : s === 'IN_PROGRESS' ? 'En cours' : s === 'BLOCKED' ? 'Bloqué' : 'À faire'
}

function colLetter(n: number): string {
  let s = ''
  while (n > 0) {
    const m = (n - 1) % 26
    s = String.fromCharCode(65 + m) + s
    n = Math.floor((n - 1) / 26)
  }
  return s
}

function mapYears(H: number, fn: (y: number) => string | number): Array<string | number> {
  return Array.from({ length: H }, (_, i) => fn(i + 1))
}

function titleBlock(ws: ExcelJS.Worksheet, title: string, subtitle: string) {
  ws.getCell(1, 1).value = title
  ws.getCell(1, 1).font = { bold: true, size: 16, color: { argb: NAVY } }
  ws.getCell(2, 1).value = subtitle
  ws.getCell(2, 1).font = { size: 10, color: { argb: 'FF64748B' }, italic: true }
  ws.getRow(1).height = 24
}

function noteBlock(ws: ExcelJS.Worksheet, row: number, text: string) {
  ws.getCell(row, 1).value = text
  ws.getCell(row, 1).font = { size: 9, italic: true, color: { argb: 'FF64748B' } }
  ws.getCell(row, 1).alignment = { wrapText: true, vertical: 'top' }
  ws.getRow(row).height = 42
}

function headerRow(ws: ExcelJS.Worksheet, row: number, headers: string[]) {
  headers.forEach((h, i) => {
    ws.getCell(row, i + 1).value = h
  })
  headerStyle(ws.getRow(row))
}

function headerStyle(row: ExcelJS.Row) {
  row.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 10 }
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: NAVY } }
    cell.alignment = { vertical: 'middle', wrapText: true }
  })
  row.height = 22
}

function totalStyle(row: ExcelJS.Row) {
  row.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: NAVY }, size: 10 }
    cell.border = { top: { style: 'thin', color: { argb: GOLD } } }
  })
}

function addKv(
  ws: ExcelJS.Worksheet, row: number, label: string,
  value: string | number | { formula: string }, numFmt?: string, bold = false,
) {
  ws.getCell(row, 1).value = label
  const c = ws.getCell(row, 2)
  c.value = value as ExcelJS.CellValue
  if (numFmt) c.numFmt = numFmt
  if (bold) {
    ws.getCell(row, 1).font = { bold: true, color: { argb: NAVY } }
    c.font = { bold: true, color: { argb: NAVY } }
  }
}

function formatMoneyCols(ws: ExcelJS.Worksheet, cols: number[], from: number, to: number) {
  for (let r = from; r <= to; r++) {
    for (const colNum of cols) {
      const cell = ws.getCell(r, colNum)
      if (typeof cell.value === 'number' || (cell.value && typeof cell.value === 'object' && 'formula' in (cell.value as object))) {
        cell.numFmt = MONEY_FMT
      }
    }
  }
}

function setWidths(ws: ExcelJS.Worksheet, widths: number[]) {
  widths.forEach((w, i) => {
    ws.getColumn(i + 1).width = w
  })
}
