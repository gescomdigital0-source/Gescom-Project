// GESCOM PROJECT – Génération DOCX (librairie docx)
// Document Word structuré et éditable : page de garde, table des matières,
// titres hiérarchisés, tableaux stylés, en-tête et pied de page numérotés.
import {
  AlignmentType, Document, Footer, Header, HeadingLevel, HorizontalPositionRelativeFrom,
  ImageRun, PageBreak, PageNumber, Packer, Paragraph, ShadingType, Table, TableCell,
  TableRow, TextRun, VerticalPositionRelativeFrom, WidthType, BorderStyle,
} from 'docx'
import type { Dossier, DossierTable } from '@/lib/exports/content'

const NAVY = '0F172A'
const GOLD = 'D4A72C'
const LIGHT = 'F1F5F9'
const GRAY = '64748B'

// Convention documentaire demandée : Times New Roman, corps 12, interligne 1,5.
const FONT = 'Times New Roman'
const BODY_SIZE = 24 // demi-points (docx) : 24 = 12 pt
const LINE_150 = 360 // interligne 1,5 (docx « line » en 240ᵉ de ligne : 360/240 = 1,5)

export async function generateDocx(dossier: Dossier, opts: {
  headerText: string
  footerText: string
  /** Image d'illustration (JPEG A4, voile bleu nuit) en fond de page de garde. */
  coverImage?: Buffer
}): Promise<Buffer> {
  const children: (Paragraph | Table)[] = []

  // Couleurs de la page de garde : adaptées au fond (image personnalisée
  // assombrie = texte clair ; fond clair par défaut = texte marine).
  const onImage = Boolean(opts.coverImage)
  const coverTitleColor = onImage ? 'FFFFFF' : NAVY
  const coverTextColor = onImage ? 'E2E8F0' : GRAY

  // Image de fond : ancrée à la première ligne de la page de garde, derrière
  // le texte, aux dimensions exactes d'une page A4 (794 × 1123 px @96 dpi).
  const coverBackground = opts.coverImage
    ? [new ImageRun({
        type: 'jpg',
        data: opts.coverImage,
        transformation: { width: 794, height: 1123 },
        floating: {
          horizontalPosition: { relative: HorizontalPositionRelativeFrom.PAGE, offset: 0 },
          verticalPosition: { relative: VerticalPositionRelativeFrom.PAGE, offset: 0 },
          behindDocument: true,
          allowOverlap: true,
          zIndex: 0,
        },
      })]
    : []

  // Page de garde
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        ...coverBackground,
        new TextRun({ text: 'GESCOM PROJECT', bold: true, color: GOLD, size: 22, font: FONT }),
      ],
    }),
    new Paragraph({ spacing: { before: 200 } }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: dossier.title, bold: true, color: coverTitleColor, size: 52, font: FONT })],
    }),
    new Paragraph({ spacing: { before: 240 } }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: dossier.subtitle, color: coverTextColor, size: 28, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: dossier.projectName, color: coverTextColor, size: 22, font: FONT })],
    }),
    new Paragraph({ spacing: { before: 2200 } }),
    ...(dossier.author
      ? [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: dossier.author, bold: true, color: onImage ? 'FFFFFF' : '1E293B', size: 24, font: FONT })],
        })]
      : []),
    ...(dossier.organization
      ? [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: dossier.organization, color: coverTextColor, size: 22, font: FONT })],
        })]
      : []),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `Dossier généré le ${dossier.date} — avec GESCOM PROJECT`, color: coverTextColor, size: 20, font: FONT })],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  )

  // Table des matières (statique, éditable dans Word)
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      children: [new TextRun({ text: 'Table des matières', bold: true, color: NAVY, font: FONT })],
    }),
    ...dossier.sections.map(
      (s) =>
        new Paragraph({
          spacing: { after: 120, line: LINE_150 },
          children: [new TextRun({ text: s.title, color: '334155', size: BODY_SIZE, font: FONT })],
        }),
    ),
    new Paragraph({ children: [new PageBreak()] }),
  )

  // Sections
  for (const section of dossier.sections) {
    children.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 360, after: 200 },
        children: [new TextRun({ text: section.title, bold: true, color: NAVY, size: 32, font: FONT })],
      }),
    )
    for (const block of section.blocks) {
      switch (block.type) {
        case 'heading':
          children.push(
            new Paragraph({
              heading: HeadingLevel.HEADING_2,
              spacing: { before: 240, after: 120 },
              children: [new TextRun({ text: block.text || '', bold: true, color: '334155', size: 26, font: FONT })],
            }),
          )
          break
        case 'paragraph':
          if (block.text) {
            children.push(
              new Paragraph({
                alignment: AlignmentType.JUSTIFIED,
                spacing: { after: 160, line: LINE_150 },
                children: [new TextRun({ text: block.text, size: BODY_SIZE, font: FONT })],
              }),
            )
          }
          break
        case 'bullets':
          if (block.text) {
            children.push(
              new Paragraph({
                spacing: { after: 80, line: LINE_150 },
                children: [new TextRun({ text: block.text, bold: true, size: BODY_SIZE, font: FONT })],
              }),
            )
          }
          for (const item of block.items || []) {
            children.push(
              new Paragraph({
                bullet: { level: 0 },
                spacing: { after: 60, line: LINE_150 },
                children: [new TextRun({ text: item, size: BODY_SIZE, font: FONT })],
              }),
            )
          }
          break
        case 'table':
          if (block.table) {
            // buildTable renvoie [titre?, tableau, note?] — à aplatir dans children
            children.push(...buildTable(block.table))
            children.push(new Paragraph({ spacing: { after: 160 } }))
          }
          break
      }
    }
  }

  const doc = new Document({
    creator: 'GESCOM PROJECT',
    title: dossier.title,
    description: dossier.subtitle,
    styles: {
      default: {
        document: {
          run: { font: FONT, size: BODY_SIZE, color: '1E293B' },
        },
        heading1: {
          run: { font: FONT, size: 32, bold: true, color: NAVY },
        },
        heading2: {
          run: { font: FONT, size: 26, bold: true, color: '334155' },
        },
      },
    },
    sections: [
      {
        properties: {},
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [new TextRun({ text: opts.headerText || 'GESCOM PROJECT', color: GRAY, size: 16, font: FONT })],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: opts.footerText ? `${opts.footerText}  —  ` : '', color: GRAY, size: 16, font: FONT }),
                  new TextRun({ children: ['Page ', PageNumber.CURRENT, ' sur ', PageNumber.TOTAL_PAGES], color: GRAY, size: 16, font: FONT }),
                ],
              }),
            ],
          }),
        },
        children,
      },
    ],
  })

  return Buffer.from(await Packer.toBuffer(doc))
}

function buildTable(table: DossierTable): (Table | Paragraph)[] {
  const nCols = table.headers.length
  const widthPct = Math.floor(100 / nCols)
  const isTotalRow = (r: string[]) => String(r[0] ?? '').startsWith('TOTAL') || String(r[0] ?? '').startsWith('RÉSULTAT')

  const headerRow = new TableRow({
    tableHeader: true,
    children: table.headers.map(
      (h) =>
        new TableCell({
          shading: { type: ShadingType.CLEAR, fill: NAVY },
          width: { size: widthPct, type: WidthType.PERCENTAGE },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [
            new Paragraph({
              children: [new TextRun({ text: String(h), bold: true, color: 'FFFFFF', size: BODY_SIZE, font: FONT })],
            }),
          ],
        }),
    ),
  })

  const bodyRows = table.rows.map(
    (row, ri) =>
      new TableRow({
        children: row.map(
          (cell) =>
            new TableCell({
              shading: isTotalRow(row)
                ? { type: ShadingType.CLEAR, fill: LIGHT }
                : ri % 2 === 1
                  ? { type: ShadingType.CLEAR, fill: 'F8FAFC' }
                  : undefined,
              width: { size: widthPct, type: WidthType.PERCENTAGE },
              margins: { top: 60, bottom: 60, left: 120, right: 120 },
              borders: {
                top: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
                bottom: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
                left: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
                right: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
              },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: String(cell ?? ''),
                      bold: isTotalRow(row),
                      color: isTotalRow(row) ? NAVY : '1E293B',
                      size: BODY_SIZE,
                      font: FONT,
                    }),
                  ],
                }),
              ],
            }),
        ),
      }),
  )

  // Un tableau peut être précédé de son titre et suivi d'une note : on
  // renvoie la liste d'éléments qui sera aplatie dans les children de la
  // section. (Un retour casté en Table unique faisait disparaître les
  // tableaux titrés du document généré.)
  const elements: (Table | Paragraph)[] = []
  if (table.title) {
    elements.push(
      new Paragraph({
        spacing: { before: 200, after: 100 },
        children: [new TextRun({ text: table.title, bold: true, color: '334155', size: BODY_SIZE, font: FONT })],
      }),
    )
  }
  elements.push(new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: [headerRow, ...bodyRows] }))
  if (table.note) {
    elements.push(
      new Paragraph({
        spacing: { before: 80 },
        children: [new TextRun({ text: table.note, italics: true, color: GRAY, size: 20, font: FONT })],
      }),
    )
  }
  return elements
}
