// GESCOM PROJECT – Génération PDF (pdfkit)
// Rendu professionnel : page de garde, table des matières avec numéros
// réels, en-têtes, pieds de page numérotés, sections, tableaux paginés.
import PDFDocument from 'pdfkit'
import type { Dossier, DossierTable } from '@/lib/exports/content'

const NAVY = '#0F172A'
const GOLD = '#D4A72C'
const LIGHT = '#F1F5F9'
const MID = '#94A3B8'
const TEXT = '#1E293B'

// Convention documentaire demandée : Times New Roman, corps 12, interligne 1,5.
// PDFKit utilise les polices standard PDF : « Times-Roman » est rendu comme
// Times New Roman par tous les lecteurs PDF (Acrobat, Word, navigateurs).
const FONT = 'Times-Roman'
const FONT_BOLD = 'Times-Bold'
const BODY_SIZE = 12
// Interligne 1,5 = interligne de base 18 pt pour un corps 12.
// Hauteur de ligne native de Times-Roman ≈ 0,942 em (11,3 pt à 12) ;
// l'écart à ajouter est donc 18 − 11,3 ≈ 6,7 pt.
const BODY_GAP = 6.7

const PAGE_W = 595.28 // A4
const PAGE_H = 841.89
const M = 56
const CONTENT_W = PAGE_W - M * 2

interface RenderOptions {
  footerText: string
  headerText: string
  includeCover: boolean
  includeToc: boolean
  /** Image d'illustration (JPEG A4 avec voile bleu nuit) en fond de page de garde. */
  coverImage?: Buffer
}

export async function generatePdf(dossier: Dossier, opts: RenderOptions): Promise<Buffer> {
  // Passe 1 : rendu de pagination (mêmes pages que le rendu final)
  const pass1 = await renderPass(dossier, opts, null)
  // Passe 2 : rendu final avec numéros de page réels dans la table des matières
  const pass2 = await renderPass(dossier, opts, pass1.sectionPages)
  return pass2.buffer
}

interface PassResult {
  buffer: Buffer
  sectionPages: Map<string, number>
}

function renderPass(dossier: Dossier, opts: RenderOptions, tocPages: Map<string, number> | null): Promise<PassResult> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: M, bottom: M, left: M, right: M },
      // bufferPages : les pages restent en mémoire jusqu'à doc.end() —
      // indispensable pour lire le numéro de page réel pendant le rendu
      // (table des matières) puis réécrire dans chaque page (pieds de page).
      bufferPages: true,
      info: { Title: dossier.title, Author: dossier.author || 'GESCOM PROJECT', Creator: 'GESCOM PROJECT' },
    })
    const chunks: Buffer[] = []
    doc.on('data', (c: Buffer) => chunks.push(c))
    doc.on('error', reject)
    const recorded = new Map<string, number>()

    let isCover = opts.includeCover

    doc.on('pageAdded', () => {
      if (isCover) return // pas d'en-tête sur la page de garde
      if (opts.headerText) {
        doc.font(FONT).fontSize(7.5).fillColor(MID)
          .text(opts.headerText, M, 26, { width: CONTENT_W, align: 'left' })
        doc.moveTo(M, 40).lineTo(PAGE_W - M, 40).strokeColor('#E2E8F0').lineWidth(0.5).stroke()
      }
    })

    // ---------------- Page de garde ----------------
    if (opts.includeCover) {
      if (opts.coverImage) {
        // Image d'illustration pleine page (déjà assombrie côté serveur) :
        // rendu personnalisé et professionnel, texte blanc par-dessus.
        doc.image(opts.coverImage, 0, 0, { width: PAGE_W, height: PAGE_H })
      } else {
        doc.rect(0, 0, PAGE_W, PAGE_H).fill(NAVY)
        doc.rect(0, PAGE_H - 120, PAGE_W, 120).fill('#1E293B')
      }
      doc.rect(M, 150, 90, 4).fill(GOLD)
      doc.font(FONT_BOLD).fontSize(10).fillColor(GOLD)
        .text('GESCOM PROJECT', M, 120, { width: CONTENT_W })
      doc.font(FONT_BOLD).fontSize(24).fillColor('#FFFFFF')
        .text(dossier.title, M, 185, { width: CONTENT_W, lineGap: 6 })
      doc.font(FONT).fontSize(13).fillColor('#CBD5E1')
        .text(dossier.subtitle, M, doc.y + 18, { width: CONTENT_W })
      doc.font(FONT).fontSize(11).fillColor('#94A3B8')
        .text(dossier.projectName, M, doc.y + 22, { width: CONTENT_W })
      doc.rect(M, PAGE_H - 262, CONTENT_W, 1).fill(GOLD)
      doc.font(FONT_BOLD).fontSize(11).fillColor('#FFFFFF')
      if (dossier.author) doc.text(dossier.author, M, PAGE_H - 242, { width: CONTENT_W })
      if (dossier.organization) {
        doc.font(FONT).fontSize(10).fillColor('#CBD5E1')
          .text(dossier.organization, M, doc.y + 6, { width: CONTENT_W })
      }
      doc.font(FONT).fontSize(9).fillColor('#94A3B8')
        .text(`Dossier généré le ${dossier.date}`, M, PAGE_H - 96, { width: CONTENT_W })
      doc.text('Généré avec GESCOM PROJECT — plateforme de structuration de projets', M, PAGE_H - 82, { width: CONTENT_W })
      doc.addPage()
      isCover = false
    }

    // ---------------- Table des matières ----------------
    if (opts.includeToc && dossier.sections.length > 0) {
      doc.font(FONT_BOLD).fontSize(18).fillColor(NAVY)
        .text('Table des matières', M, 70)
      doc.rect(M, doc.y + 10, 60, 3).fill(GOLD)
      for (const s of dossier.sections) {
        const pageNo = tocPages ? tocPages.get(s.id) : undefined
        const y = doc.y + 28
        doc.font(FONT).fontSize(BODY_SIZE).fillColor(TEXT)
          .text(s.title, M, y, { width: CONTENT_W - 50, ellipsis: true, height: 16, lineBreak: false })
        doc.font(FONT_BOLD).fontSize(BODY_SIZE).fillColor(GOLD)
          .text(pageNo ? String(pageNo) : '…', PAGE_W - M - 44, y, { width: 44, align: 'right', height: 16, lineBreak: false })
        doc.y = y + 6
      }
      doc.addPage()
    }

    // ---------------- Sections ----------------
    for (const section of dossier.sections) {
      if (doc.y > PAGE_H - M - 80) doc.addPage()
      if (!tocPages) {
        // Numéro de page réel de la section = nombre de pages créées à cet
        // instant (1-based). Si la couverture n'est pas numérotée, son numéro
        // est décalé d'un cran pour correspondre au pied de page imprimé.
        const absolute = doc.bufferedPageRange().count
        recorded.set(section.id, opts.includeCover ? absolute - 1 : absolute)
      }

      doc.font(FONT_BOLD).fontSize(16).fillColor(NAVY)
        .text(section.title, M, doc.y + 8, { width: CONTENT_W })
      doc.rect(M, doc.y + 6, 50, 3).fill(GOLD)
      doc.moveDown(1.4)

      for (const block of section.blocks) {
        switch (block.type) {
          case 'heading': {
            if (doc.y > PAGE_H - M - 60) doc.addPage()
            doc.font(FONT_BOLD).fontSize(13).fillColor('#334155')
              .text(block.text || '', M, doc.y + 10, { width: CONTENT_W })
            doc.moveDown(0.6)
            break
          }
          case 'paragraph': {
            const text = block.text || ''
            if (!text) break
            doc.font(FONT).fontSize(BODY_SIZE).fillColor(TEXT)
              .text(text, M, doc.y + 4, { width: CONTENT_W, align: 'justify', lineGap: BODY_GAP })
            doc.moveDown(0.7)
            break
          }
          case 'bullets': {
            if (block.text) {
              doc.font(FONT_BOLD).fontSize(BODY_SIZE).fillColor(TEXT)
                .text(block.text, M, doc.y + 4, { width: CONTENT_W })
              doc.moveDown(0.4)
            }
            for (const item of block.items || []) {
              const bulletY = doc.y + 3
              doc.circle(M + 4, bulletY + 5, 1.8).fill(GOLD)
              doc.font(FONT).fontSize(BODY_SIZE).fillColor(TEXT)
                .text(item, M + 16, bulletY, { width: CONTENT_W - 16, lineGap: BODY_GAP })
              doc.moveDown(0.25)
            }
            doc.moveDown(0.5)
            break
          }
          case 'table': {
            if (block.table) drawTable(doc, block.table)
            break
          }
        }
      }
      doc.moveDown(1.2)
    }

    // ---------------- Pieds de page avec numéros ----------------
    const range = doc.bufferedPageRange()
    for (let i = range.start; i < range.start + range.count; i++) {
      if (opts.includeCover && i === 0) continue
      doc.switchToPage(i)
      doc.moveTo(M, PAGE_H - 46).lineTo(PAGE_W - M, PAGE_H - 46).strokeColor('#E2E8F0').lineWidth(0.5).stroke()
      // Marge basse neutralisée le temps d'écrire le pied : à y ≈ 803, au-delà
      // de la limite de page (785), doc.text() déclencherait sinon un saut de
      // page parasite (document multiplié par deux, pages vides à la fin).
      const marginBottom = doc.page.margins.bottom
      doc.page.margins.bottom = 0
      doc.font(FONT).fontSize(7.5).fillColor(MID)
      if (opts.footerText) {
        doc.text(opts.footerText, M, PAGE_H - 38, { width: CONTENT_W / 2, lineBreak: false })
      }
      const human = opts.includeCover ? i : i + 1 // la couverture n'est pas numérotée
      doc.text(`Page ${human}`, PAGE_W - M - 60, PAGE_H - 38, { width: 60, align: 'right', lineBreak: false })
      doc.page.margins.bottom = marginBottom
    }

    doc.on('end', () => {
      resolve({ buffer: Buffer.concat(chunks), sectionPages: recorded })
    })
    doc.end()
  })
}

// ---------------- Tableau paginé ----------------
function drawTable(doc: PDFKit.PDFDocument, table: DossierTable) {
  const nCols = Math.max(1, table.headers.length)
  const fontSmall = 9 // tableaux : 9 pt (Times, plus compact) pour rester lisibles sur une page
  const padding = 4

  if (table.title) {
    doc.font(FONT_BOLD).fontSize(10).fillColor('#334155')
      .text(table.title, M, doc.y + 8, { width: CONTENT_W })
    doc.moveDown(0.4)
  }

  // Largeurs de colonnes pondérées par la longueur moyenne du contenu
  const weights = table.headers.map((h, i) => {
    const avgLen =
      table.rows.length > 0
        ? table.rows.reduce((s, r) => s + (r[i]?.length ?? 0), 0) / table.rows.length
        : 0
    return Math.max(4, avgLen + h.length)
  })
  const totalWeight = weights.reduce((a, b) => a + b, 0)
  const colWidths = weights.map((w) => (w / totalWeight) * CONTENT_W)

  const rowHeight = (cells: string[], isHeader = false) => {
    doc.font(isHeader ? FONT_BOLD : FONT).fontSize(fontSmall)
    return Math.max(
      isHeader ? 18 : 16,
      ...cells.map((c, i) =>
        doc.heightOfString(String(c ?? ''), { width: colWidths[i] - padding * 2 }) + padding * 2,
      ),
    )
  }

  let y = doc.y + 6
  const drawHeader = () => {
    const h = rowHeight(table.headers, true)
    doc.rect(M, y, CONTENT_W, h).fill(NAVY)
    doc.font(FONT_BOLD).fontSize(fontSmall).fillColor('#FFFFFF')
    let x = M
    table.headers.forEach((hd, i) => {
      doc.text(String(hd), x + padding, y + padding, { width: colWidths[i] - padding * 2 })
      x += colWidths[i]
    })
    y += h
  }
  drawHeader()

  table.rows.forEach((row, ri) => {
    const h = rowHeight(row)
    if (y + h > PAGE_H - M - 50) {
      doc.addPage()
      y = M
      drawHeader()
    }
    if (ri % 2 === 1) {
      doc.rect(M, y, CONTENT_W, h).fill(LIGHT)
    }
    const isTotalRow = String(row[0] ?? '').startsWith('TOTAL') || String(row[0] ?? '').startsWith('RÉSULTAT')
    doc.font(isTotalRow ? FONT_BOLD : FONT).fontSize(fontSmall).fillColor(isTotalRow ? NAVY : TEXT)
    let x = M
    row.forEach((cell, i) => {
      doc.text(String(cell ?? ''), x + padding, y + padding, { width: colWidths[i] - padding * 2 })
      x += colWidths[i]
    })
    doc.rect(M, y, CONTENT_W, h).lineWidth(0.5).stroke('#E2E8F0')
    y += h
  })

  doc.x = M
  doc.y = y + 14
}
