'use client'

// GESCOM PROJECT – Client API (fetch wrapper)
//
// Authentification hybride :
//  1. Token de session mémorisé dans localStorage et envoyé via l'en-tête
//     « Authorization: Bearer » — fonctionne même quand le navigateur bloque
//     les cookies (aperçu affiché dans une iframe, navigation privée stricte…).
//  2. Cookie httpOnly « gescom_session » — repli géré par le serveur.
export class ApiError extends Error {
  status: number
  // Charge utile JSON de la réponse (ex. { needsVerification: true, devCode })
  payload: Record<string, unknown> | null
  constructor(message: string, status: number, payload: Record<string, unknown> | null = null) {
    super(message)
    this.status = status
    this.payload = payload
  }
}

const TOKEN_KEY = 'gescom_session_token'

// Erreurs réseau : serveur momentanément injoignable (aperçu mis en veille,
// redémarrage du bac à sable, compilation lente au premier appel…).
const NETWORK_ERROR_MSG =
  'Impossible de joindre le serveur. L\'aperçu a peut-être été mis en veille : ' +
  'rechargez la page puis réessayez (votre travail est enregistré).'

// Statuts renvoyés par la passerelle quand l'application n'est pas encore
// prête derrière elle : on peut réessayer sans risque de doublon.
const RETRYABLE_STATUS = new Set([502, 503, 504])
const RETRY_DELAY_MS = 1500

async function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// fetch avec réessai automatique : 1 tentative de plus en cas d'erreur réseau
// ou de réponse 502/503/504 (passerelle). Les autres statuts sont renvoyés tels quels.
async function fetchResilient(url: string, init: RequestInit, retries = 1): Promise<Response> {
  try {
    const res = await fetch(url, init)
    if (RETRYABLE_STATUS.has(res.status) && retries > 0) {
      await delay(RETRY_DELAY_MS)
      return fetchResilient(url, init, retries - 1)
    }
    return res
  } catch (err) {
    if (retries > 0) {
      await delay(RETRY_DELAY_MS)
      return fetchResilient(url, init, retries - 1)
    }
    if (err instanceof TypeError) {
      // « Failed to fetch » : réseau/passerelle, pas une erreur applicative
      throw new ApiError(NETWORK_ERROR_MSG, 0)
    }
    throw err
  }
}

export function getToken(): string | null {
  try {
    return window.localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function setToken(token: string | null | undefined) {
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token)
    else window.localStorage.removeItem(TOKEN_KEY)
  } catch {
    // localStorage indisponible (navigation privée) : le cookie prend le relais
  }
}

// En-têtes d'authentification pour les appels fetch directs
export function authHeaders(): Record<string, string> {
  const token = getToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function handle<T>(res: Response): Promise<T> {
  if (res.status === 401) {
    // Token invalide ou expiré : on le retire pour repartir proprement.
    setToken(null)
    throw new ApiError('Session expirée. Veuillez vous reconnecter.', 401)
  }
  if (res.status === 0) {
    throw new ApiError(NETWORK_ERROR_MSG, 0)
  }
  const isJson = res.headers.get('content-type')?.includes('application/json')
  const data = isJson ? await res.json() : null
  if (!res.ok) {
    throw new ApiError(data?.error || `Erreur ${res.status}`, res.status, data ?? null)
  }
  return data as T
}

export async function apiGet<T>(url: string): Promise<T> {
  const res = await fetchResilient(url, { credentials: 'include', headers: authHeaders() })
  return handle<T>(res)
}

export async function apiSend<T>(url: string, method: 'POST' | 'PATCH' | 'PUT' | 'DELETE', body?: unknown): Promise<T> {
  // Pas de réessai automatique ici : les mutations ne doivent pas être rejouées.
  const res = await fetchResilient(url, {
    method,
    credentials: 'include',
    headers: { ...authHeaders(), ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }, 0)
  return handle<T>(res)
}

// Téléchargement d'un fichier généré (POST) puis déclenchement du navigateur.
// Réessai automatique inclus : la génération peut être relancée sans risque
// (au pire un doublon dans la bibliothèque), et le premier appel après un
// redémarrage du serveur peut être lent (compilation) ou coupé par la passerelle.
export async function apiDownload(url: string, body: unknown, fallbackFilename: string): Promise<string> {
  const res = await fetchResilient(url, {
    method: 'POST',
    credentials: 'include',
    headers: { ...authHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (res.status === 401) {
    setToken(null)
    throw new ApiError('Session expirée. Veuillez vous reconnecter.', 401)
  }
  if (!res.ok) {
    const isJson = res.headers.get('content-type')?.includes('application/json')
    const data = isJson ? await res.json() : null
    // La charge utile est conservée (ex. payload { validation } du blocage
    // d'impression 403 : liste des anomalies à corriger).
    throw new ApiError(data?.error || `Erreur ${res.status}`, res.status, data ?? null)
  }
  const blob = await res.blob()
  const disposition = res.headers.get('content-disposition') || ''
  const match = /filename="?([^";]+)"?/.exec(decodeURIComponent(disposition))
  const filename = match ? match[1] : fallbackFilename
  const href = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = href
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(href), 4000)
  return filename
}
