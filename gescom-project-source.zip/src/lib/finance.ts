// GESCOM PROJECT – Moteur financier partagé (client & serveur)
// Toutes les valeurs monétaires sont en unités de la devise du projet.
// Les pourcentages sont saisis en base 100 (ex. 12 = 12 %).

import type {
  FinanceComputation,
  FinanceData,
  FinancialRatios,
  LoanScheduleYear,
  ScenarioResult,
  YearResult,
} from '@/lib/types'

const EMPTY: FinanceData = {
  investments: [],
  workingCapital: 0,
  financing: [],
  assumptions: {
    horizonYears: 5,
    discountRate: 12,
    taxRate: 25,
    products: [],
    variableCosts: [],
    fixedCosts: [],
    staff: [],
  },
}

export function normalizeFinance(raw: unknown): FinanceData {
  // Accepte indifféremment un objet déjà parsé ou une chaîne JSON brute
  // (colonne Project.finance stockée en String en base). Sans ce support,
  // buildDossier recevait une string et produisait un dossier vide à 0.
  let f: Partial<FinanceData> = {}
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object') f = parsed as Partial<FinanceData>
    } catch {
      f = {}
    }
  } else if (raw && typeof raw === 'object') {
    f = raw as Partial<FinanceData>
  }
  let a: Partial<FinanceData['assumptions']> = {}
  if (typeof f.assumptions === 'string') {
    try {
      const parsed = JSON.parse(f.assumptions)
      if (parsed && typeof parsed === 'object') a = parsed as Partial<FinanceData['assumptions']>
    } catch {
      a = {}
    }
  } else if (f.assumptions && typeof f.assumptions === 'object') {
    a = f.assumptions as Partial<FinanceData['assumptions']>
  }
  return {
    investments: Array.isArray(f.investments) ? f.investments : [],
    workingCapital: Number(f.workingCapital) || 0,
    financing: Array.isArray(f.financing) ? f.financing : [],
    assumptions: {
      horizonYears: clampInt(a.horizonYears, 1, 10, 5),
      discountRate: Number(a.discountRate) || 0,
      taxRate: Number(a.taxRate) || 0,
      products: Array.isArray(a.products) ? a.products : [],
      variableCosts: Array.isArray(a.variableCosts) ? a.variableCosts : [],
      fixedCosts: Array.isArray(a.fixedCosts) ? a.fixedCosts : [],
      staff: Array.isArray(a.staff) ? a.staff : [],
    },
  }
}

function clampInt(v: unknown, min: number, max: number, dflt: number): number {
  const n = Math.round(Number(v))
  if (!Number.isFinite(n)) return dflt
  return Math.min(max, Math.max(min, n))
}

// ---------------------------------------------------------------------------
// Échéanciers d'emprunt (méthode des annuités constantes)
// ---------------------------------------------------------------------------

export function loanAnnuity(principal: number, ratePct: number, years: number): number {
  const r = ratePct / 100
  if (years <= 0) return 0
  if (r <= 0) return principal / years
  return (principal * r) / (1 - Math.pow(1 + r, -years))
}

export function buildLoanSchedules(data: FinanceData, horizon: number): LoanScheduleYear[] {
  const out: LoanScheduleYear[] = []
  for (const loan of data.financing) {
    if (loan.type !== 'LOAN') continue
    const P = Number(loan.amount) || 0
    if (P <= 0) continue
    const r = (Number(loan.rate) || 0) / 100
    const n = Math.max(1, Math.round(Number(loan.termYears) || horizon))
    let balance = P
    const annuity = loanAnnuity(P, Number(loan.rate) || 0, n)
    for (let y = 1; y <= Math.min(n, horizon); y++) {
      const interest = balance * r
      let principal = annuity - interest
      if (y === n) principal = balance // solde final exact
      const closing = Math.max(0, balance - principal)
      out.push({
        year: y,
        source: loan.source,
        openingBalance: balance,
        interest,
        principal,
        annuity: interest + principal,
        closingBalance: closing,
      })
      balance = closing
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// Calculs annuels
// ---------------------------------------------------------------------------

const g = (base: number, growthPct: number, yearIdx0: number) =>
  base * Math.pow(1 + (growthPct || 0) / 100, yearIdx0)

interface Modifiers {
  volumeFactor: number
  priceFactor: number
}

export function computeFinance(input: FinanceData | unknown, withScenarios = true): FinanceComputation {
  const data = normalizeFinance(input)
  const A = data.assumptions
  const horizon = clampInt(A.horizonYears, 1, 10, 5)

  const investments = data.investments.map((i) => ({ ...i, amount: Number(i.amount) || 0 }))
  const totalInvestment = investments.reduce((s, i) => s + (Number(i.amount) || 0), 0)
  const totalWorkingCapital = Number(data.workingCapital) || 0
  const totalNeeds = totalInvestment + totalWorkingCapital

  const equity = data.financing.filter((f) => f.type === 'EQUITY').reduce((s, f) => s + (Number(f.amount) || 0), 0)
  const loans = data.financing.filter((f) => f.type === 'LOAN').reduce((s, f) => s + (Number(f.amount) || 0), 0)
  const grants = data.financing.filter((f) => f.type === 'GRANT').reduce((s, f) => s + (Number(f.amount) || 0), 0)
  const totalFinancing = data.financing.reduce((s, f) => s + (Number(f.amount) || 0), 0)

  // Amortissements : linéaire, seulement pour les années ≤ durée
  const depByYear: number[] = new Array(horizon).fill(0)
  for (const inv of investments) {
    if (inv.depreciable && inv.depYears > 0 && inv.amount > 0) {
      const annual = inv.amount / inv.depYears
      for (let y = 1; y <= Math.min(inv.depYears, horizon); y++) depByYear[y - 1] += annual
    }
  }

  const loanSchedule = buildLoanSchedules(data, horizon)
  const interestByYear: number[] = new Array(horizon).fill(0)
  const principalByYear: number[] = new Array(horizon).fill(0)
  for (const row of loanSchedule) {
    interestByYear[row.year - 1] += row.interest
    principalByYear[row.year - 1] += row.principal
  }

  const taxRate = Math.min(100, Math.max(0, Number(A.taxRate) || 0))

  function runYears(mod: Modifiers): YearResult[] {
    const rows: YearResult[] = []
    let cumulative = -(totalInvestment + totalWorkingCapital) // mise de fonds initiale (flux projet)
    for (let y = 1; y <= horizon; y++) {
      const idx = y - 1
      // Chiffre d'affaires
      let revenue = 0
      for (const p of A.products) {
        const qty = g((Number(p.qty) || 0) * mod.volumeFactor, Number(p.volumeGrowth) || 0, idx)
        const price = g((Number(p.unitPrice) || 0) * mod.priceFactor, Number(p.priceGrowth) || 0, idx)
        revenue += qty * price
      }
      // Charges variables
      let variableCosts = 0
      for (const c of A.variableCosts) {
        if (c.mode === 'PCT') {
          variableCosts += revenue * ((Number(c.pct) || 0) / 100)
        } else {
          const qty = g((Number(c.qty) || 0) * mod.volumeFactor, Number(c.growth) || 0, idx)
          const price = g(Number(c.unitPrice) || 0, Number(c.growth) || 0, idx)
          variableCosts += qty * price
        }
      }
      // Charges fixes : exploitation + personnel
      let fixedCosts = 0
      for (const c of A.fixedCosts) {
        fixedCosts += g(Number(c.annualAmount) || 0, Number(c.growth) || 0, idx)
      }
      for (const s of A.staff) {
        fixedCosts += g((Number(s.count) || 0) * (Number(s.monthlySalary) || 0) * 12, Number(s.annualGrowth) || 0, idx)
      }

      const depreciation = depByYear[idx]
      const interest = interestByYear[idx]
      const ebitda = revenue - variableCosts - fixedCosts
      const ebt = ebitda - depreciation - interest
      const tax = Math.max(0, ebt) * (taxRate / 100)
      const netIncome = ebt - tax
      const principal = principalByYear[idx]
      const caf = netIncome + depreciation
      const freeCashFlow = caf - principal
      cumulative += freeCashFlow

      rows.push({
        year: y,
        revenue,
        variableCosts,
        fixedCosts,
        ebitda,
        depreciation,
        interest,
        ebt,
        tax,
        netIncome,
        principalRepayment: principal,
        caf,
        freeCashFlow,
        cumulativeFCF: cumulative,
      })
    }
    return rows
  }

  const years = runYears({ volumeFactor: 1, priceFactor: 1 })

  // ---------------------------------------------------------------------------
  // Indicateurs de rentabilité (flux projet, avant financement)
  // ---------------------------------------------------------------------------

  const unleveredFCF: number[] = years.map((r) => {
    const ebit = r.ebitda - r.depreciation
    return ebit * (1 - taxRate / 100) + r.depreciation
  })
  const initialOutlay = totalInvestment + totalWorkingCapital
  const discount = Math.max(0, Number(A.discountRate) || 0) / 100

  let npv = -initialOutlay
  unleveredFCF.forEach((f, i) => {
    npv += f / Math.pow(1 + discount, i + 1)
  })
  if (totalWorkingCapital > 0) npv += totalWorkingCapital / Math.pow(1 + discount, horizon) // récupération du BFR

  const irr = computeIrr(unleveredFCF, initialOutlay, totalWorkingCapital > 0 ? totalWorkingCapital : 0, horizon)
  const payback = computePayback(unleveredFCF, initialOutlay)

  // Seuil de rentabilité (année 1) : CF / taux de marge sur coûts variables
  const y1 = years[0]
  const marginRate = y1 && y1.revenue > 0 ? 1 - y1.variableCosts / y1.revenue : 0
  const breakEvenRevenue =
    y1 && marginRate > 0 ? (y1.fixedCosts + y1.depreciation + y1.interest) / marginRate : 0
  const breakEvenYear = years.find((r) => r.revenue >= breakEvenRevenue && breakEvenRevenue > 0)?.year ?? (breakEvenRevenue > 0 ? 0 : 1)

  const avgNet = years.length ? years.reduce((s, r) => s + r.netIncome, 0) / years.length : 0
  const y1DebtService = y1 ? y1.interest + y1.principalRepayment : 0
  const ratios: FinancialRatios = {
    netMargin: y1 && y1.revenue > 0 ? (y1.netIncome / y1.revenue) * 100 : 0,
    ebitdaMargin: y1 && y1.revenue > 0 ? (y1.ebitda / y1.revenue) * 100 : 0,
    roi: totalInvestment > 0 ? (avgNet / totalInvestment) * 100 : 0,
    autonomyRate: totalFinancing > 0 ? ((equity + grants) / totalFinancing) * 100 : 0,
    dscr: y1DebtService > 0 && y1 ? y1.ebitda / y1DebtService : null,
    payback,
    npv,
    irr,
    breakEvenRevenue,
    breakEvenYear,
  }

  // ---------------------------------------------------------------------------
  // Scénarios
  // ---------------------------------------------------------------------------

  const scenarios: ScenarioResult[] = []
  if (withScenarios) {
    const defs: Array<{ name: ScenarioResult['name']; label: string; mod: Modifiers }> = [
      { name: 'PESSIMISTIC', label: 'Pessimiste (volume −15 %, prix −10 %)', mod: { volumeFactor: 0.85, priceFactor: 0.9 } },
      { name: 'REALISTIC', label: 'Réaliste', mod: { volumeFactor: 1, priceFactor: 1 } },
      { name: 'OPTIMISTIC', label: 'Optimiste (volume +10 %, prix +5 %)', mod: { volumeFactor: 1.1, priceFactor: 1.05 } },
    ]
    for (const d of defs) {
      const ys = runYears(d.mod)
      const fcf = ys.map((r) => {
        const ebit = r.ebitda - r.depreciation
        return ebit * (1 - taxRate / 100) + r.depreciation
      })
      scenarios.push({
        name: d.name,
        label: d.label,
        revenue1: ys[0]?.revenue ?? 0,
        netIncome1: ys[0]?.netIncome ?? 0,
        netIncomeAvg: ys.length ? ys.reduce((s, r) => s + r.netIncome, 0) / ys.length : 0,
        payback: computePayback(fcf, initialOutlay),
        npv: npvOf(fcf, initialOutlay, discount, totalWorkingCapital, horizon),
      })
    }
  }

  return {
    years,
    loanSchedule,
    totalInvestment,
    totalWorkingCapital,
    totalNeeds,
    totalFinancing,
    totalEquity: equity,
    totalLoans: loans,
    totalGrants: grants,
    financingGap: totalNeeds - totalFinancing,
    ratios,
    scenarios,
  }
}

function npvOf(fcf: number[], initialOutlay: number, rate: number, workingCapital: number, horizon: number): number {
  let v = -initialOutlay
  fcf.forEach((f, i) => {
    v += f / Math.pow(1 + rate, i + 1)
  })
  if (workingCapital > 0) v += workingCapital / Math.pow(1 + rate, horizon)
  return v
}

export function computePayback(unleveredFCF: number[], initialOutlay: number): number | null {
  let cumulative = -initialOutlay
  for (let i = 0; i < unleveredFCF.length; i++) {
    const prev = cumulative
    cumulative += unleveredFCF[i]
    if (cumulative >= 0 && prev < 0) {
      // interpolation linéaire dans l'année
      const frac = unleveredFCF[i] > 0 ? -prev / unleveredFCF[i] : 0
      return i + frac
    }
    if (cumulative >= 0) return i // déjà positif
  }
  return null
}

// TRI par dichotomie (robuste, pas de dérivées)
export function computeIrr(
  fcf: number[],
  initialOutlay: number,
  terminalRecovery: number,
  horizon: number,
): number | null {
  const flows = [...fcf]
  if (terminalRecovery > 0 && flows.length > 0) flows[flows.length - 1] += terminalRecovery
  const npvAt = (rate: number) => {
    let v = -initialOutlay
    flows.forEach((f, i) => {
      v += f / Math.pow(1 + rate, i + 1)
    })
    return v
  }
  let lo = 0
  let hi = 5 // 500 %
  const fLo = npvAt(lo)
  const fHi = npvAt(hi)
  if (!Number.isFinite(fLo) || !Number.isFinite(fHi) || fLo * fHi > 0) return null
  for (let iter = 0; iter < 200; iter++) {
    const mid = (lo + hi) / 2
    const fMid = npvAt(mid)
    if (Math.abs(fMid) < 1e-4) return mid * 100
    if (fLo * fMid <= 0) hi = mid
    else lo = mid
  }
  return ((lo + hi) / 2) * 100
}

// Progression du projet basée sur les sections renseignées (0..100)
export function computeProjectProgress(project: {
  idea?: string
  description?: string
  overview?: string
  analysis?: string
  finance?: string
  objectives?: string
  tasksCount?: number
  docsCount?: number
}): number {
  let score = 0
  const filled = (v?: string) => Boolean(v && v.trim().length > 0)
  const nonEmptyJson = (v?: string) => {
    if (!v) return false
    try {
      const parsed = JSON.parse(v)
      return parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0
    } catch {
      return false
    }
  }
  if (filled(project.idea)) score += 10
  if (filled(project.description)) score += 10
  if (nonEmptyJson(project.objectives) && project.objectives !== '[]') score += 10
  if (nonEmptyJson(project.overview)) score += 15
  if (nonEmptyJson(project.analysis)) score += 20
  if (nonEmptyJson(project.finance)) score += 20
  if ((project.tasksCount ?? 0) > 0) score += 10
  if ((project.docsCount ?? 0) > 0) score += 5
  return Math.min(100, score)
}
