// GESCOM PROJECT – Pays et moyens de paiement de l'abonnement Premium
//
// Chaque payeur renseigne son pays dans le tunnel de paiement ; l'application
// lui présente alors les opérateurs Mobile Money disponibles dans ce pays,
// plus la carte bancaire (Visa / Mastercard) proposée partout — c'est le
// moyen utilisé par les abonnés en Europe et dans le reste du monde.
//
// L'encaissement réel est opéré par FedaPay (agrégateur, Togo) : le choix
// final de l'opérateur est confirmé sur la page de paiement sécurisée.

export type PaymentMethodKind = 'MOBILE_MONEY' | 'CARD'

export interface PaymentOperator {
  id: string
  label: string
  kind: PaymentMethodKind
}

export interface PayerCountry {
  code: string // code ISO 3166-1 alpha-2 (envoyé à FedaPay)
  name: string
  dial: string // indicatif téléphonique international
  zone: 'AFRIQUE' | 'EUROPE' | 'INTERNATIONAL'
  operators: PaymentOperator[]
}

const CARD: PaymentOperator = { id: 'CARD', label: 'Carte bancaire (Visa, Mastercard)', kind: 'CARD' }

const mm = (id: string, label: string): PaymentOperator => ({ id, label, kind: 'MOBILE_MONEY' })

export const PAYER_COUNTRIES: PayerCountry[] = [
  // ---- Zone UEMOA ----
  { code: 'BJ', name: 'Bénin', dial: '+229', zone: 'AFRIQUE', operators: [mm('MTN_MOMO', 'MTN MoMo'), mm('MOOV_MONEY', 'Moov Money'), mm('CELTIIS_CASH', 'Celtiis Cash'), CARD] },
  { code: 'TG', name: 'Togo', dial: '+228', zone: 'AFRIQUE', operators: [mm('T_MONEY', 'T-Money (Togocom)'), mm('FLOOZ', 'Flooz by Moov'), CARD] },
  { code: 'CI', name: "Côte d'Ivoire", dial: '+225', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('MTN_MOMO', 'MTN MoMo'), mm('MOOV_MONEY', 'Moov Money'), mm('WAVE', 'Wave'), CARD] },
  { code: 'SN', name: 'Sénégal', dial: '+221', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('WAVE', 'Wave'), mm('FREE_MONEY', 'Free Money'), mm('EXPRESSO', 'Expresso Cash'), CARD] },
  { code: 'BF', name: 'Burkina Faso', dial: '+226', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('MOOV_MONEY', 'Moov Money'), mm('CORIS_MONEY', 'Coris Money'), CARD] },
  { code: 'ML', name: 'Mali', dial: '+223', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('MOOV_MONEY', 'Moov Money'), mm('SAMA_MONEY', 'Sama Money'), CARD] },
  { code: 'NE', name: 'Niger', dial: '+227', zone: 'AFRIQUE', operators: [mm('AIRTEL_MONEY', 'Airtel Money'), mm('ZAMANI_CASH', 'Zamani Cash (Moov)'), CARD] },
  { code: 'GN', name: 'Guinée', dial: '+224', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('MTN_MOMO', 'MTN MoMo'), CARD] },
  // ---- Zone CEMAC ----
  { code: 'CM', name: 'Cameroun', dial: '+237', zone: 'AFRIQUE', operators: [mm('MTN_MOMO', 'MTN MoMo'), mm('ORANGE_MONEY', 'Orange Money'), CARD] },
  { code: 'GA', name: 'Gabon', dial: '+241', zone: 'AFRIQUE', operators: [mm('AIRTEL_MONEY', 'Airtel Money'), mm('MOOV_MONEY', 'Moov Money'), CARD] },
  { code: 'CG', name: 'Congo', dial: '+242', zone: 'AFRIQUE', operators: [mm('MTN_MOMO', 'MTN MoMo'), mm('AIRTEL_MONEY', 'Airtel Money'), mm('MOOV_MONEY', 'Moov Money'), CARD] },
  { code: 'TD', name: 'Tchad', dial: '+235', zone: 'AFRIQUE', operators: [mm('AIRTEL_MONEY', 'Airtel Money'), mm('MOOV_MONEY', 'Moov Money'), CARD] },
  { code: 'CF', name: 'République centrafricaine', dial: '+236', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), mm('TELECEL_MONEY', 'Telecel Money'), CARD] },
  { code: 'GQ', name: 'Guinée équatoriale', dial: '+240', zone: 'AFRIQUE', operators: [mm('ORANGE_MONEY', 'Orange Money'), CARD] },
  // ---- Autres pays africains ----
  { code: 'CD', name: 'RD Congo', dial: '+243', zone: 'AFRIQUE', operators: [mm('M_PESA', 'M-Pesa (Vodacom)'), mm('ORANGE_MONEY', 'Orange Money'), mm('AIRTEL_MONEY', 'Airtel Money'), CARD] },
  { code: 'NG', name: 'Nigeria', dial: '+234', zone: 'AFRIQUE', operators: [CARD] },
  { code: 'RW', name: 'Rwanda', dial: '+250', zone: 'AFRIQUE', operators: [mm('MTN_MOMO', 'MTN MoMo'), mm('AIRTEL_MONEY', 'Airtel Money'), CARD] },
  { code: 'MG', name: 'Madagascar', dial: '+261', zone: 'AFRIQUE', operators: [mm('MVOLA', 'MVola'), mm('ORANGE_MONEY', 'Orange Money'), mm('AIRTEL_MONEY', 'Airtel Money'), CARD] },
  // ---- Europe et reste du monde : carte bancaire ----
  { code: 'FR', name: 'France', dial: '+33', zone: 'EUROPE', operators: [CARD] },
  { code: 'BE', name: 'Belgique', dial: '+32', zone: 'EUROPE', operators: [CARD] },
  { code: 'CH', name: 'Suisse', dial: '+41', zone: 'EUROPE', operators: [CARD] },
  { code: 'LU', name: 'Luxembourg', dial: '+352', zone: 'EUROPE', operators: [CARD] },
  { code: 'DE', name: 'Allemagne', dial: '+49', zone: 'EUROPE', operators: [CARD] },
  { code: 'ES', name: 'Espagne', dial: '+34', zone: 'EUROPE', operators: [CARD] },
  { code: 'IT', name: 'Italie', dial: '+39', zone: 'EUROPE', operators: [CARD] },
  { code: 'PT', name: 'Portugal', dial: '+351', zone: 'EUROPE', operators: [CARD] },
  { code: 'NL', name: 'Pays-Bas', dial: '+31', zone: 'EUROPE', operators: [CARD] },
  { code: 'GB', name: 'Royaume-Uni', dial: '+44', zone: 'EUROPE', operators: [CARD] },
  { code: 'US', name: 'États-Unis / Canada', dial: '+1', zone: 'INTERNATIONAL', operators: [CARD] },
  { code: 'XX', name: 'Autre pays', dial: '+', zone: 'INTERNATIONAL', operators: [CARD] },
]

export function findCountry(code: string): PayerCountry | undefined {
  return PAYER_COUNTRIES.find((c) => c.code === code)
}

/** Libellé lisible d'une méthode enregistrée (historique, factures). */
export function methodLabel(operatorId: string, country?: PayerCountry): string {
  if (operatorId === 'CARD') return 'Carte bancaire'
  const op = country?.operators.find((o) => o.id === operatorId)
  return op ? op.label : operatorId
}
