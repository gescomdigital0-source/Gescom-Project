// GESCOM PROJECT – Constantes de référence

export const SECTORS = [
  'Agriculture & Élevage',
  'Agroalimentaire',
  'Commerce & Distribution',
  'Restauration & Hôtellerie',
  'Services & Conseil',
  'Transport & Logistique',
  'Bâtiment & Travaux Publics',
  'Technologie & Numérique',
  'Éducation & Formation',
  'Santé & Bien-être',
  'Artisanat & Production',
  'Énergie & Environnement',
  'Finance & Microfinance',
  'Communication & Médias',
  'Autre',
]

export const PROJECT_TYPES = [
  'Création d\'entreprise',
  'Extension d\'activité',
  'Diversification',
  'Reprise d\'entreprise',
  'Projet associatif',
  'Projet institutionnel',
  'Projet académique',
]

export const COUNTRIES = [
  'Cameroun', 'Côte d\'Ivoire', 'Sénégal', 'Gabon', 'Congo', 'RD Congo',
  'Bénin', 'Togo', 'Burkina Faso', 'Mali', 'Guinée', 'Niger', 'Tchad',
  'RCA', 'France', 'Belgique', 'Canada', 'Suisse', 'Maroc', 'Tunisie', 'Algérie',
]

export const CURRENCIES = [
  { code: 'XAF', label: 'Franc CFA (XAF)', symbol: 'FCFA' },
  { code: 'XOF', label: 'Franc CFA (XOF)', symbol: 'FCFA' },
  { code: 'EUR', label: 'Euro (EUR)', symbol: '€' },
  { code: 'USD', label: 'Dollar US (USD)', symbol: '$' },
  { code: 'CAD', label: 'Dollar canadien (CAD)', symbol: '$' },
  { code: 'CHF', label: 'Franc suisse (CHF)', symbol: 'CHF' },
  { code: 'MAD', label: 'Dirham marocain (MAD)', symbol: 'MAD' },
]

export const REGIONS: Record<string, string[]> = {
  'Cameroun': ['Adamaoua', 'Centre', 'Douala / Littoral', 'Est', 'Extrême-Nord', 'Nord', 'Nord-Ouest', 'Ouest', 'Sud', 'Sud-Ouest'],
  'Côte d\'Ivoire': ['Abidjan', 'Yamoussoukro', 'Bouaké', 'San-Pédro', 'Korhogo', 'Daloa'],
  'Sénégal': ['Dakar', 'Thiès', 'Saint-Louis', 'Ziguinchor', 'Kaolack', 'Tambacounda'],
  'Gabon': ['Libreville', 'Port-Gentil', 'Franceville', 'Oyem'],
  'Congo': ['Brazzaville', 'Pointe-Noire', 'Dolisie'],
  'RD Congo': ['Kinshasa', 'Lubumbashi', 'Goma', 'Bukavu', 'Kisangani'],
}

export const LEGAL_FORMS = [
  'Entreprise individuelle',
  'GIE (Groupement d\'Intérêt Économique)',
  'SARL (Société à Responsabilité Limitée)',
  'SARL U (Société à Responsabilité Limitée Unipersonnelle)',
  'SAS (Société par Actions Simplifiée)',
  'SA (Société Anonyme)',
  'Coopérative',
  'Association',
  'En cours de définition',
]

export const PROJECT_STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Brouillon',
  ONGOING: 'En cours',
  COMPLETED: 'Terminé',
  ARCHIVED: 'Archivé',
}

// Classes Tailwind des badges de statut (partagées : liste, tableau de bord, espace projet)
export const PROJECT_STATUS_BADGE: Record<string, string> = {
  DRAFT: 'bg-slate-100 text-slate-700 border-slate-200',
  ONGOING: 'bg-amber-50 text-amber-800 border-amber-200',
  COMPLETED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  ARCHIVED: 'bg-gray-100 text-gray-500 border-gray-200',
}

export const TASK_STATUS_LABELS: Record<string, string> = {
  TODO: 'À faire',
  IN_PROGRESS: 'En cours',
  DONE: 'Terminé',
  BLOCKED: 'Bloqué',
}

export const INVESTMENT_CATEGORIES = [
  { value: 'TERRAIN', label: 'Terrain & aménagements' },
  { value: 'BATIMENT', label: 'Bâtiments & construction' },
  { value: 'EQUIPEMENT', label: 'Équipements' },
  { value: 'MATERIEL', label: 'Matériel & outillage' },
  { value: 'FRAIS_ETABLISSEMENT', label: 'Frais d\'établissement' },
  { value: 'AUTRE', label: 'Autres investissements' },
]

export const EXPORT_SECTIONS = [
  { id: 'overview', label: 'Présentation générale du projet' },
  { id: 'market', label: 'Étude de marché' },
  { id: 'strategy', label: 'Analyse stratégique (SWOT & PESTEL)' },
  { id: 'feasibility', label: 'Étude de faisabilité' },
  { id: 'organization', label: 'Organisation & ressources humaines' },
  { id: 'investment', label: 'Plan d\'investissement' },
  { id: 'financing', label: 'Plan de financement' },
  { id: 'financials', label: 'Études financières prévisionnelles' },
  { id: 'indicators', label: 'Indicateurs de rentabilité' },
  { id: 'risks', label: 'Analyse des risques' },
  { id: 'actionplan', label: 'Plan d\'action & calendrier' },
  { id: 'annexes', label: 'Annexes' },
]

export const PRESENTATION_AUDIENCES = [
  { value: 'INVESTOR', label: 'Investisseurs' },
  { value: 'BANK', label: 'Banques & organismes de financement' },
  { value: 'PARTNER', label: 'Partenaires & collaborateurs' },
  { value: 'ACADEMIC', label: 'Soutenance académique' },
]

export const PRESENTATION_THEMES = [
  { value: 'NAVY_GOLD', label: 'Bleu nuit & or', primary: '0F172A', accent: 'D4A72C' },
  { value: 'EMERALD', label: 'Émeraude', primary: '064E3B', accent: '10B981' },
  { value: 'BURGUNDY', label: 'Bordeaux', primary: '4C1D1D', accent: 'B91C1C' },
]

// Couleurs de graphiques cohérentes (bleu nuit / or / complémentaires élégants)
export const CHART_COLORS = ['#0F172A', '#D4A72C', '#475569', '#94A3B8', '#B0880F', '#1E3A5F', '#64748B', '#E2C044']
