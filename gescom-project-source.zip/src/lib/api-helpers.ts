// GESCOM PROJECT – Helpers communs des routes API
import { getSessionUser, unauthorized, logActivity } from '@/lib/auth'
import type { SessionUser } from '@/lib/types'

export { unauthorized, logActivity }

// Exécute le handler avec l'utilisateur authentifié, ou renvoie 401.
export async function withUser(
  req: Request,
  fn: (user: SessionUser) => Promise<Response>,
): Promise<Response> {
  try {
    const user = await getSessionUser(req)
    if (!user) return unauthorized()
    return await fn(user)
  } catch (err) {
    console.error('[API] Erreur :', err)
    return Response.json(
      { error: err instanceof Error ? err.message : 'Erreur interne du serveur.' },
      { status: 500 },
    )
  }
}

export async function readJson<T>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T
  } catch {
    return {} as T
  }
}

export function badRequest(message: string) {
  return Response.json({ error: message }, { status: 400 })
}

export function notFound(message = 'Ressource introuvable.') {
  return Response.json({ error: message }, { status: 404 })
}

// Vérifie que le projet appartient bien à l'utilisateur (isolation des données)
export function projectBelongsTo<T extends { userId: string }>(project: T, userId: string): boolean {
  return project.userId === userId
}
