// GESCOM PROJECT – Langue de l'interface (français par défaut, anglais en 2e langue)
//
// État global minimaliste (useSyncExternalStore) persisté dans localStorage.
// La traduction proprement dite est assurée par LanguageLayer (traduction du
// DOM rendu via le dictionnaire FR→EN) : les composants restent inchangés.
'use client'

import { useSyncExternalStore } from 'react'

export type Locale = 'fr' | 'en'

const STORAGE_KEY = 'gescom_locale'

function readInitial(): Locale {
  if (typeof window === 'undefined') return 'fr'
  try {
    const v = window.localStorage.getItem(STORAGE_KEY)
    return v === 'en' ? 'en' : 'fr'
  } catch {
    return 'fr'
  }
}

let current: Locale = typeof window === 'undefined' ? 'fr' : readInitial()
const listeners = new Set<() => void>()

export function getLocale(): Locale {
  return current
}

// Instantané serveur (hydratation) : toujours français
export function getServerLocale(): Locale {
  return 'fr'
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb)
  return () => listeners.delete(cb)
}

export function setLocale(next: Locale): void {
  if (next === current) return
  current = next
  try {
    window.localStorage.setItem(STORAGE_KEY, next)
  } catch {
    // stockage indisponible : la langue reste valable pour la session
  }
  if (typeof document !== 'undefined') {
    document.documentElement.lang = next === 'en' ? 'en' : 'fr'
  }
  listeners.forEach((cb) => cb())
}

export function useLocale(): [Locale, (l: Locale) => void] {
  const locale = useSyncExternalStore(subscribe, getLocale, getServerLocale)
  return [locale, setLocale]
}
