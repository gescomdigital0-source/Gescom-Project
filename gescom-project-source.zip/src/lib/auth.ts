// GESCOM PROJECT – Authentification : hachage scrypt, sessions, cookies
import { db } from '@/lib/db'
import crypto from 'crypto'
import type { SessionUser, UserPrefs } from '@/lib/types'
import { effectivePlan } from '@/lib/plans'
import type { User } from '@prisma/client'

export const SESSION_COOKIE = 'gescom_session'
const SESSION_DURATION_DAYS = 30

// ---------------------------------------------------------------------------
// Mots de passe (scrypt, comparable à bcrypt mais sans dépendance externe)
// ---------------------------------------------------------------------------

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const candidate = crypto.scryptSync(password, salt, 64)
  const expected = Buffer.from(hash, 'hex')
  return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected)
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

export async function createSession(userId: string, userAgent: string): Promise<{ token: string; expiresAt: Date }> {
  const token = crypto.randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DURATION_DAYS * 24 * 60 * 60 * 1000)
  await db.session.create({
    data: { token, userId, userAgent: userAgent.slice(0, 200), expiresAt },
  })
  return { token, expiresAt }
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true as const,
    sameSite: 'lax' as const,
    secure: false, // environnement de préproduction en HTTP
    path: '/',
    expires: expiresAt,
  }
}

// Extrait le token de session : en-tête Authorization: Bearer (prioritaire,
// fonctionne même quand le navigateur bloque les cookies, ex. aperçu en iframe)
// puis cookie httpOnly (repli pour la navigation classique).
export function extractToken(req: Request): string | null {
  const auth = req.headers.get('authorization') || ''
  if (auth.toLowerCase().startsWith('bearer ')) {
    const bearer = auth.slice(7).trim()
    if (bearer) return bearer
  }
  const cookieHeader = req.headers.get('cookie') || ''
  const match = cookieHeader
    .split(';')
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${SESSION_COOKIE}=`))
  if (!match) return null
  const token = match.slice(SESSION_COOKIE.length + 1)
  return token || null
}

export async function getSessionUser(req: Request): Promise<SessionUser | null> {
  const token = extractToken(req)
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => null)
    return null
  }
  return toSessionUser(session.user)
}

export function toSessionUser(user: User): SessionUser {
  let prefs: UserPrefs = {} as UserPrefs
  try {
    prefs = JSON.parse(user.prefs || '{}')
  } catch {
    prefs = {} as UserPrefs
  }
  // Plan effectif : un Premium dont la date d'expiration est passée est traité
  // comme Gratuit partout (gating finance, exports, UI), sans effacer l'historique.
  const plan = effectivePlan(user.plan, user.planExpiresAt)
  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    emailVerified: user.emailVerified,
    plan,
    planExpiresAt: plan === 'PREMIUM' && user.planExpiresAt ? user.planExpiresAt.toISOString() : null,
    organization: user.organization,
    jobTitle: user.jobTitle,
    phone: user.phone,
    prefs,
  }
}

// Réponse 401 standardisée
export function unauthorized() {
  return Response.json({ error: 'Session expirée ou non authentifiée. Veuillez vous reconnecter.' }, { status: 401 })
}

// Journal d'activité
export async function logActivity(
  userId: string,
  type: string,
  message: string,
  projectId?: string | null,
) {
  await db.activity.create({
    data: { userId, type, message, projectId: projectId ?? null },
  })
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function passwordIssue(password: string): string | null {
  if (!password || password.length < 8) return 'Le mot de passe doit contenir au moins 8 caractères.'
  if (!/[a-zA-Z]/.test(password)) return 'Le mot de passe doit contenir au moins une lettre.'
  if (!/[0-9]/.test(password)) return 'Le mot de passe doit contenir au moins un chiffre.'
  return null
}
