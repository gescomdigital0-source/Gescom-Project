// GESCOM PROJECT – Envoi d'e-mails transactionnels (vérification du compte)
//
// La configuration SMTP est lue dans l'ordre suivant :
//   1. la base de données (onglet « E-mail » des Paramètres, rôle ADMIN –
//      clés SystemSetting « smtp.* ») : permet de brancher un vrai serveur
//      d'envoi sans toucher au serveur ni redéployer ;
//   2. les variables d'environnement (.env) :
//        SMTP_HOST   – serveur SMTP (ex. smtp.gmail.com)
//        SMTP_PORT   – port (465 recommandé, ou 587)
//        SMTP_SECURE – « true » si TLS direct (port 465)
//        SMTP_USER   – identifiant SMTP (souvent l'adresse e-mail d'envoi)
//        SMTP_PASS   – mot de passe / mot de passe d'application
//        SMTP_FROM   – expéditeur affiché (ex. « GESCOM PROJECT <no-reply@gescom.pro> »)
//
// Tant qu'aucune configuration n'est trouvée, la plateforme fonctionne en
// « mode démonstration » : le code est affiché à l'écran (bandeau de l'écran
// de vérification) et journalisé côté serveur.
import nodemailer from 'nodemailer'
import { db } from '@/lib/db'
import type { CodePurpose } from '@/lib/verification'

export type SmtpConfig = {
  host: string
  port: number
  secure: boolean
  user: string
  pass: string
  from: string
}

const SETTING_KEYS = ['host', 'port', 'secure', 'user', 'pass', 'from'] as const

export async function getSmtpSetting(key: (typeof SETTING_KEYS)[number]): Promise<string | null> {
  const row = await db.systemSetting.findUnique({ where: { key: `smtp.${key}` } })
  return row?.value ?? null
}

export async function setSmtpSetting(key: (typeof SETTING_KEYS)[number], value: string): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: `smtp.${key}` },
    create: { key: `smtp.${key}`, value },
    update: { value },
  })
}

export async function clearSmtpSettings(): Promise<void> {
  await db.systemSetting.deleteMany({ where: { key: { startsWith: 'smtp.' } } })
}

// Résout la configuration active : base de données d'abord, puis .env.
// Renvoie null si elle est incomplète (mode démonstration).
export async function resolveSmtpConfig(): Promise<SmtpConfig | null> {
  const [host, port, secure, user, pass, from] = await Promise.all(SETTING_KEYS.map(getSmtpSetting))
  const resolvedHost = (host || process.env.SMTP_HOST || '').trim()
  const resolvedUser = (user || process.env.SMTP_USER || '').trim()
  const resolvedPass = pass || process.env.SMTP_PASS || ''
  if (!resolvedHost || !resolvedUser || !resolvedPass) return null
  const resolvedPort = Number(port || process.env.SMTP_PORT || 587) || 587
  const resolvedSecure = secure !== null && secure !== ''
    ? secure === 'true'
    : process.env.SMTP_SECURE === 'true' || resolvedPort === 465
  return {
    host: resolvedHost,
    port: resolvedPort,
    secure: resolvedSecure,
    user: resolvedUser,
    pass: resolvedPass,
    from: (from || process.env.SMTP_FROM || `GESCOM PROJECT <${resolvedUser}>`).trim(),
  }
}

// « Les e-mails partent-ils réellement ? » (config DB ou .env complète).
export async function smtpConfigured(): Promise<boolean> {
  return (await resolveSmtpConfig()) !== null
}

function createTransport(cfg: SmtpConfig) {
  return nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure,
    auth: { user: cfg.user, pass: cfg.pass },
  })
}

function verificationEmailHtml(code: string, minutes: number, purpose: CodePurpose): string {
  const isReset = purpose === 'PASSWORD_RESET'
  const title = isReset ? 'Réinitialisation de votre mot de passe' : 'Vérification de votre adresse e-mail'
  const intro = isReset
    ? 'Vous avez demandé la réinitialisation de votre mot de passe sur GESCOM PROJECT. Saisissez le code à 6 chiffres ci-dessous dans l\'écran de réinitialisation, puis choisissez votre nouveau mot de passe.'
    : 'Bienvenue sur GESCOM PROJECT\u00a0! Pour activer votre compte, saisissez le code à 6 chiffres ci-dessous dans l\'écran de vérification.'
  const digits = code
    .split('')
    .map(
      (d) =>
        `<td style="padding:0 4px;"><div style="width:52px;height:64px;line-height:64px;text-align:center;background:#0f172a;color:#f5c542;font-size:32px;font-weight:700;border-radius:10px;font-family:Arial,sans-serif;">${d}</div></td>`,
    )
    .join('')
  return `<!doctype html>
<html lang="fr"><body style="margin:0;padding:0;background:#f1f5f9;">
<div style="max-width:560px;margin:0 auto;padding:32px 16px;font-family:Arial,Helvetica,sans-serif;color:#0f172a;">
  <div style="background:#0f172a;border-radius:16px 16px 0 0;padding:24px 28px;display:flex;align-items:center;">
    <div style="width:40px;height:40px;background:#d4a72c;border-radius:10px;line-height:40px;text-align:center;font-weight:900;font-size:20px;color:#0f172a;margin-right:12px;">G</div>
    <div>
      <div style="color:#ffffff;font-weight:700;font-size:16px;">GESCOM PROJECT</div>
      <div style="color:#94a3b8;font-size:12px;">De l'idée au dossier finançable</div>
    </div>
  </div>
  <div style="background:#ffffff;border-radius:0 0 16px 16px;padding:28px;border:1px solid #e2e8f0;border-top:none;">
    <h1 style="margin:0 0 12px;font-size:20px;">${title}</h1>
    <p style="margin:0 0 18px;font-size:14px;line-height:22px;color:#334155;">
      ${intro}
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px;"><tr>${digits}</tr></table>
    <p style="margin:0 0 6px;font-size:13px;color:#334155;">
      Ce code est valable <strong>${minutes} minutes</strong>. Il est à usage unique.
    </p>
    <p style="margin:0 0 18px;font-size:13px;color:#64748b;">
      ${isReset
        ? "Vous n'êtes pas à l'origine de cette demande&nbsp;? Ignorez cet e-mail&nbsp;: votre mot de passe reste inchangé."
        : "Vous n'êtes pas à l'origine de cette demande&nbsp;? Ignorez simplement cet e-mail&nbsp;: aucun compte ne sera activé sans ce code."}
    </p>
    <p style="margin:0;font-size:12px;color:#94a3b8;">L'équipe GESCOM PROJECT</p>
  </div>
</div>
</body></html>`
}

function verificationEmailText(code: string, minutes: number, purpose: CodePurpose): string {
  const head = purpose === 'PASSWORD_RESET'
    ? 'GESCOM PROJECT – Réinitialisation de votre mot de passe'
    : 'GESCOM PROJECT – Vérification de votre adresse e-mail'
  const action = purpose === 'PASSWORD_RESET'
    ? `Pour réinitialiser votre mot de passe, saisissez le code à 6 chiffres : ${code}`
    : `Bienvenue ! Pour activer votre compte, saisissez le code à 6 chiffres : ${code}`
  return [
    head,
    '',
    action,
    '',
    `Ce code est valable ${minutes} minutes et à usage unique.`,
    "Vous n'êtes pas à l'origine de cette demande ? Ignorez cet e-mail.",
    '',
    "L'équipe GESCOM PROJECT",
  ].join('\n')
}

export type MailResult = { delivered: boolean; reason?: 'SMTP_NON_CONFIGURE' | 'SMTP_ERREUR' }

// Message renvoyé aux utilisateurs quand le SMTP est configuré mais que
// l'envoi échoue (identifiants invalides, réseau…). Dans ce cas le code n'est
// JAMAIS exposé dans la réponse (sécurité) : seul l'administrateur corrige la
// configuration depuis Paramètres → E-mail.
export const MAIL_FAILURE_MESSAGE =
  "L'envoi de l'e-mail a échoué côté serveur (configuration de messagerie). Réessayez dans quelques minutes : si le problème persiste, contactez l'administrateur de la plateforme."

// Envoie le code de vérification.
//  • SMTP non configuré (mode démonstration) : delivered:false + SMTP_NON_CONFIGURE,
//    l'API expose alors le code dans la réponse pour terminer le parcours.
//  • SMTP configuré mais envoi en échec : delivered:false + SMTP_ERREUR,
//    l'API ne doit PAS exposer le code (sécurité) mais renvoyer une erreur claire.
export async function sendVerificationEmail(
  email: string,
  code: string,
  minutes: number,
  purpose: CodePurpose = 'SIGNUP',
): Promise<MailResult> {
  const cfg = await resolveSmtpConfig()
  if (!cfg) {
    console.log(`[mailer] SMTP non configuré (mode démonstration) – code ${purpose} pour ${email} : ${code}`)
    return { delivered: false, reason: 'SMTP_NON_CONFIGURE' }
  }
  try {
    await createTransport(cfg).sendMail({
      from: cfg.from,
      to: email,
      subject:
        purpose === 'PASSWORD_RESET'
          ? `GESCOM PROJECT – Code de réinitialisation de votre mot de passe : ${code}`
          : `GESCOM PROJECT – Votre code de vérification : ${code}`,
      text: verificationEmailText(code, minutes, purpose),
      html: verificationEmailHtml(code, minutes, purpose),
    })
    return { delivered: true }
  } catch (err) {
    console.error('[mailer] Échec de l\'envoi du code :', err)
    return { delivered: false, reason: 'SMTP_ERREUR' }
  }
}

// E-mail de test (onglet E-mail des Paramètres, rôle ADMIN) : vérifie que la
// configuration saisie fonctionne réellement avant de l'activer en production.
export async function sendTestEmail(
  to: string,
  cfgOverride?: Partial<SmtpConfig>,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const base = cfgOverride
    ? ({
        host: cfgOverride.host ?? '',
        port: Number(cfgOverride.port ?? 587) || 587,
        secure: cfgOverride.secure ?? Number(cfgOverride.port ?? 587) === 465,
        user: cfgOverride.user ?? '',
        pass: cfgOverride.pass ?? '',
        from: cfgOverride.from || `GESCOM PROJECT <${cfgOverride.user ?? ''}>`,
      } as SmtpConfig)
    : await resolveSmtpConfig()
  if (!base || !base.host || !base.user || !base.pass) {
    return { ok: false, error: 'La configuration SMTP est incomplète (serveur, identifiant et mot de passe requis).' }
  }
  try {
    await createTransport(base).sendMail({
      from: base.from,
      to,
      subject: 'GESCOM PROJECT – E-mail de test (configuration SMTP)',
      text: [
        'Félicitations !',
        '',
        'Cet e-mail de test confirme que la configuration SMTP de GESCOM PROJECT fonctionne.',
        'Les codes d\'activation et de réinitialisation partiront désormais directement',
        "dans la boîte mail de vos utilisateurs.",
        '',
        "L'équipe GESCOM PROJECT",
      ].join('\n'),
      html: `<!doctype html><html lang="fr"><body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">
<div style="max-width:560px;margin:0 auto;padding:32px 16px;color:#0f172a;">
  <div style="background:#0f172a;border-radius:16px 16px 0 0;padding:24px 28px;">
    <div style="color:#ffffff;font-weight:700;font-size:16px;">GESCOM PROJECT</div>
    <div style="color:#94a3b8;font-size:12px;">De l'idée au dossier finançable</div>
  </div>
  <div style="background:#ffffff;border-radius:0 0 16px 16px;padding:28px;border:1px solid #e2e8f0;border-top:none;">
    <h1 style="margin:0 0 12px;font-size:20px;color:#15803d;">✓ Configuration e-mail validée</h1>
    <p style="margin:0 0 12px;font-size:14px;line-height:22px;color:#334155;">
      Cet e-mail de test confirme que la configuration SMTP fonctionne.
      Les codes d'activation et de réinitialisation partiront désormais
      <strong>directement dans la boîte mail de vos utilisateurs</strong>.
    </p>
    <p style="margin:0;font-size:12px;color:#94a3b8;">L'équipe GESCOM PROJECT</p>
  </div>
</div></body></html>`,
    })
    return { ok: true }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return { ok: false, error: message.slice(0, 400) }
  }
}
