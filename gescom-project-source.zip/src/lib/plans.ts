// GESCOM PROJECT – Définition des abonnements et des verrous de fonctionnalités
//
// Deux plans :
//  • GRATUIT (0 FCFA)  : création de projet, analyses de base (SWOT, PESTEL,
//    marché, concurrence, faisabilité, synthèse), plan d'investissement,
//    plan d'action, documents (contenu allégé).
//    Verrouillé : évaluation des risques, plan de financement,
//    prévision des ventes, compte de résultat (+ indicateurs, scénarios,
//    graphiques qui en découlent).
//  • PREMIUM : accès à tout le contenu du projet.

import { groupNumber } from '@/lib/format'

export type PlanId = 'FREE' | 'PREMIUM'

export const PLAN_LABELS: Record<PlanId, string> = {
  FREE: 'Gratuit',
  PREMIUM: 'Premium',
}

// Tarifs affichés (FCFA) — modifiables ici, un seul endroit.
export const PREMIUM_PRICE_MONTHLY = 5_000 // FCFA / mois
export const PREMIUM_PRICE_YEARLY = 45_000 // FCFA / an (2 mois offerts)

// Parité fixe FCFA (XOF) / Euro : 1 € = 655,957 FCFA.
// Sert à afficher les montants en euro pour les payeurs hors zone franc (carte bancaire).
export const FCFA_PER_EUR = 655.957

export function fcfaToEur(fcfa: number): number {
  return Math.round((fcfa / FCFA_PER_EUR) * 100) / 100
}

/** « 7,62 € » — montant euro arrondi au centime, séparateur de milliers « . » (convention GESCOM). */
export function formatEur(fcfa: number): string {
  return `${groupNumber(fcfaToEur(fcfa), 2)} €`
}

// Durées d'abonnement encaissées via Mobile Money (FedaPay).
export type BillingPeriod = 'MONTHLY' | 'YEARLY'

export const PLAN_PRICING: Record<BillingPeriod, { amount: number; months: number; label: string; detail: string }> = {
  MONTHLY: {
    amount: PREMIUM_PRICE_MONTHLY,
    months: 1,
    label: 'Mensuel',
    detail: '1 mois d\u2019accès Premium',
  },
  YEARLY: {
    amount: PREMIUM_PRICE_YEARLY,
    months: 12,
    label: 'Annuel',
    detail: '12 mois d\u2019accès Premium (2 mois offerts)',
  },
}

export function isBillingPeriod(value: unknown): value is BillingPeriod {
  return value === 'MONTHLY' || value === 'YEARLY'
}

// Date d'expiration obtenue après un paiement : prolonge l'abonnement actif
// s'il n'est pas encore échu (renouvellement anticipé), sinon repart de maintenant.
export function computePremiumExpiry(billing: BillingPeriod, currentExpiry?: Date | string | null): Date {
  const months = PLAN_PRICING[billing].months
  const now = new Date()
  const base = currentExpiry && new Date(currentExpiry) > now ? new Date(currentExpiry) : now
  const expiry = new Date(base)
  expiry.setMonth(expiry.getMonth() + months)
  return expiry
}

// Plan effectif : un abonnement Premium dont la date d'expiration est passée
// retombe sur Gratuit (la DB conserve PREMIUM pour l'historique).
export function effectivePlan(plan: string | null | undefined, planExpiresAt?: Date | string | null): PlanId {
  if (plan !== 'PREMIUM') return 'FREE'
  if (planExpiresAt && new Date(planExpiresAt) <= new Date()) return 'FREE'
  return 'PREMIUM'
}

// Fonctionnalités verrouillées pour le plan gratuit.
export type FeatureKey =
  | 'ai'           // Assistant IA d'amélioration des idées (toutes les rubriques)
  | 'risks'        // Évaluation des risques du projet
  | 'financing'    // Plan de financement
  | 'sales'        // Prévision des ventes (produits / chiffre d'affaires)
  | 'financials'   // Compte de résultat & flux de trésorerie
  | 'indicators'   // Indicateurs de rentabilité (VAN, TRI…)
  | 'scenarios'    // Analyse de scénarios
  | 'charts'       // Graphiques financiers

export const FEATURE_LABELS: Record<FeatureKey, string> = {
  ai: 'Assistant IA d\'amélioration des idées',
  risks: 'Évaluation des risques du projet',
  financing: 'Plan de financement',
  sales: 'Prévision des ventes',
  financials: 'Compte de résultat & flux de trésorerie',
  indicators: 'Indicateurs de rentabilité (VAN, TRI…)',
  scenarios: 'Analyse de scénarios',
  charts: 'Graphiques financiers',
}

// Sections d'export (dossier PDF/DOCX/PPTX) réservées au plan Premium.
// Identifiants = clés de DossierSection dans src/lib/exports/content.ts.
export const PREMIUM_EXPORT_SECTIONS: ReadonlySet<string> = new Set([
  'financing',   // 7. Plan de financement
  'financials',  // 8. Études financières prévisionnelles (ventes + compte de résultat)
  'indicators',  // 9. Indicateurs de rentabilité
  'risks',       // 10. Analyse des risques
])

export function isFeatureLocked(plan: string | null | undefined, feature: FeatureKey): boolean {
  return (plan || 'FREE') !== 'PREMIUM'
}

export function isPremium(plan: string | null | undefined): boolean {
  return (plan || 'FREE') === 'PREMIUM'
}

export function normalizePlan(plan: string | null | undefined): PlanId {
  return plan === 'PREMIUM' ? 'PREMIUM' : 'FREE'
}

// Comparatif affiché dans Paramètres → Abonnement.
export const PLAN_FEATURES: Array<{ label: string; free: boolean; premium: boolean }> = [
  { label: 'Projets illimités, aperçu & objectifs', free: true, premium: true },
  { label: 'Analyse SWOT, PESTEL, marché, concurrence', free: true, premium: true },
  { label: 'Faisabilité & synthèse stratégique', free: true, premium: true },
  { label: "Plan d'investissement", free: true, premium: true },
  { label: "Plan d'action & calendrier", free: true, premium: true },
  { label: 'Documents PDF & Word (contenu de base)', free: true, premium: true },
  { label: "Assistant IA : amélioration intelligente à chaque étape", free: false, premium: true },
  { label: 'Évaluation des risques du projet', free: false, premium: true },
  { label: 'Plan de financement', free: false, premium: true },
  { label: 'Prévision des ventes', free: false, premium: true },
  { label: 'Compte de résultat & flux de trésorerie', free: false, premium: true },
  { label: 'Indicateurs de rentabilité (VAN, TRI, seuil…)', free: false, premium: true },
  { label: 'Scénarios & graphiques financiers', free: false, premium: true },
  { label: 'Exports Excel & PowerPoint complets', free: false, premium: true },
]
