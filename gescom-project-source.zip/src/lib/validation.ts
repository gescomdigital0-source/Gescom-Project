// GESCOM PROJECT – Moteur de validation automatique des projets
//
// Gescom Project agit comme un expert en évaluation de projets
// d'investissement : il calcule les trois indicateurs de rentabilité
// (VAN, TRI, IP), contrôle la conformité de chaque partie du dossier,
// identifie précisément les zones à corriger avec des recommandations
// concrètes, et attribue le statut de validation du projet.
//
// Règle fondamentale (cahier des charges §3) : le projet est considéré
// comme financièrement rentable dès qu'AU MOINS UN des trois indicateurs
// satisfait son critère de rentabilité.
//
// Aucune donnée n'est stockée : le rapport est recalculé à chaque demande,
// donc chaque correction de l'utilisateur relance automatiquement les contrôles.
import { computeFinance, normalizeFinance } from '@/lib/finance'
import { fmtCurrency, groupNumber } from '@/lib/format'
import type { AnalysisData, FinanceData, OverviewData } from '@/lib/types'

// ---------------------------------------------------------------------------
// Types du rapport de validation
// ---------------------------------------------------------------------------

export type ValidationStatus = 'VALIDE' | 'A_CORRIGER' | 'NON_RENTABLE' | 'INCOMPLET'
export type IndicatorKey = 'VAN' | 'TRI' | 'IP'
export type IndicatorStatus = 'FAVORABLE' | 'EQUILIBRE' | 'DEFAVORABLE' | 'NON_CALCULE'
export type ProblemSeverity = 'BLOQUANT' | 'MAJEUR' | 'MINEUR'
export type FixModule = 'analysis' | 'finance' | 'action-plan' | 'premium'

export interface IndicatorResult {
  key: IndicatorKey
  label: string
  value: number | null // VAN en devise, TRI en %, IP en ratio
  formatted: string // valeur prête à afficher (« 1.250.000 FCFA », « 12,4 % », « 1,18 »)
  criterion: string // critère de validation (« VAN > 0 », « TRI > 8 % »…)
  status: IndicatorStatus
  explanation: string // lecture professionnelle de l'indicateur
}

export interface ValidationProblem {
  code: string // identifiant stable du contrôle (ex. MARKET_DEMANDE)
  severity: ProblemSeverity
  sectionId: string // section concernée (ex. 'market')
  sectionLabel: string
  problem: string // problème détecté
  why: string // pourquoi ce n'est pas conforme
  recommendation: string // recommandation concrète et professionnelle
  fixModule: FixModule // module où corriger
}

export interface SectionCheck {
  id: string
  label: string
  status: 'CONFORME' | 'A_CORRIGER'
  filledRatio: number // % de contrôles satisfaits dans la section
  problems: ValidationProblem[]
}

export interface ValidationReport {
  status: ValidationStatus
  statusLabel: string
  decision: string // décision finale de Gescom Project (phrase complète)
  canExport: boolean // impression/export de la version définitive autorisé
  rentabilityFavorable: boolean // au moins un indicateur favorable
  discountRatePct: number
  indicators: IndicatorResult[]
  sections: SectionCheck[]
  problems: ValidationProblem[] // anomalies triées : BLOQUANT > MAJEUR > MINEUR
  counts: {
    sectionsTotal: number
    sectionsConformes: number
    anomalies: number // total des anomalies détectées
    correctionsRestantes: number // anomalies obligatoires (BLOQUANT + MAJEUR)
  }
  conformityRate: number // taux global de conformité (0–100)
}

// ---------------------------------------------------------------------------
// Entrée du moteur
// ---------------------------------------------------------------------------

export interface ValidationInput {
  name: string
  currency: string
  overview: string // JSON (OverviewData)
  objectives: string // JSON (string[])
  analysis: string // JSON (AnalysisData)
  finance: string // JSON (FinanceData)
  tasksCount: number
  premium: boolean // la rentabilité (VAN/TRI/IP) est réservée au plan Premium
}

function safeJson<T>(json: string | null | undefined, fallback: T): T {
  if (!json) return fallback
  try {
    return { ...fallback, ...JSON.parse(json) } as T
  } catch {
    return fallback
  }
}

function safeArray<T>(json: string | null | undefined): T[] {
  if (!json) return []
  try {
    const v = JSON.parse(json)
    return Array.isArray(v) ? (v as T[]) : []
  } catch {
    return []
  }
}

const EPS = 1e-9

// ---------------------------------------------------------------------------
// Contrôles de conformité (cahier des charges §4)
// ---------------------------------------------------------------------------

const MIN_SUMMARY = 150
const MIN_FIELD = 60 // paragraphes d'analyse (marché, faisabilité)
const MIN_SHORT = 20 // champs courts (vision, mission…)

interface SectionBuilder {
  id: string
  label: string
  problems: ValidationProblem[]
  checks: number // nombre total de contrôles de la section
  passed: number // contrôles satisfaits
}

function newSection(id: string, label: string): SectionBuilder {
  return { id, label, problems: [], checks: 0, passed: 0 }
}

// Ajoute un contrôle : satisfait → passed++, sinon → anomalie enregistrée.
function check(
  sec: SectionBuilder,
  ok: boolean,
  code: string,
  severity: ProblemSeverity,
  problem: string,
  why: string,
  recommendation: string,
  fixModule: FixModule,
): boolean {
  sec.checks++
  if (ok) {
    sec.passed++
    return true
  }
  sec.problems.push({ code, severity, sectionId: sec.id, sectionLabel: sec.label, problem, why, recommendation, fixModule })
  return false
}

const hasText = (s: string | undefined, min: number): boolean =>
  typeof s === 'string' && s.trim().length >= min

// ---------------------------------------------------------------------------
// Moteur principal
// ---------------------------------------------------------------------------

export function validateProject(input: ValidationInput): ValidationReport {
  const overview = safeJson<OverviewData>(input.overview, {
    legalForm: '', location: '', promoter: '', startDate: '', summary: '', vision: '', mission: '', values: '',
  })
  const analysis = safeJson<AnalysisData>(input.analysis, {
    swot: { strengths: [], weaknesses: [], opportunities: [], threats: [] },
    pestel: { politique: '', economique: '', socioculturel: '', technologique: '', ecologique: '', legal: '' },
    market: { demande: '', offre: '', segments: '', tendances: '', cible: '', zones: '', conclusion: '' },
    competitors: [], needs: [], risks: [],
    feasibility: { technique: '', economique: '', juridique: '', organisationnelle: '', commerciale: '', verdict: '' },
    synthesis: '', recommendations: '',
  })
  const objectives = safeArray<string>(input.objectives)
  const finance: FinanceData = normalizeFinance(input.finance)
  const comp = computeFinance(finance)

  const A = finance.assumptions
  const revenue1 = comp.years[0]?.revenue ?? 0
  const discountPct = Math.max(0, Number(A.discountRate) || 0)

  // Hypothèses suffisantes pour évaluer la rentabilité (sinon projet incomplet)
  const financeComplete =
    comp.totalInvestment > 0 && comp.totalNeeds > 0 && revenue1 > 0 && A.products.length > 0

  const sections: SectionBuilder[] = []

  // ------------------------------------------------------------------
  // 1. Présentation générale du projet
  // ------------------------------------------------------------------
  {
    const sec = newSection('overview', 'Présentation générale du projet')
    check(sec, hasText(overview.summary, MIN_SUMMARY), 'OVERVIEW_SUMMARY', 'MAJEUR',
      hasText(overview.summary, 1)
        ? 'Résumé exécutif trop court (moins de ' + MIN_SUMMARY + ' caractères).'
        : 'Résumé exécutif absent.',
      'Le résumé exécutif est la première lecture du financeur : un projet sans résumé consistant ne permet pas de saisir l\'activité, le marché et l\'opportunité en quelques lignes.',
      'Rédiger un résumé exécutif d\'au moins ' + MIN_SUMMARY + ' caractères présentant l\'activité, la clientèle visée, l\'avantage concurrentiel et l\'objectif de financement.',
      'analysis')
    check(sec, hasText(overview.promoter, 2), 'OVERVIEW_PROMOTER', 'MAJEUR',
      'Identité du porteur de projet non renseignée.',
      'Un dossier professionnel identifie sans ambiguïté le promoteur et sa responsabilité juridique.',
      'Indiquer le nom du porteur de projet dans la présentation générale.',
      'analysis')
    check(sec, hasText(overview.legalForm, 2), 'OVERVIEW_LEGAL_FORM', 'MAJEUR',
      'Forme juridique non précisée.',
      'La forme juridique conditionne le régime fiscal, la responsabilité et la capacité à contracter : un dossier de financement sans statut juridique n\'est pas exploitable.',
      'Préciser la forme juridique envisagée (ex. SARL, SA, GIE, entreprise individuelle).',
      'analysis')
    check(sec, hasText(overview.location, 2), 'OVERVIEW_LOCATION', 'MAJEUR',
      'Localisation du projet non renseignée.',
      'La localisation détermine le marché accessible, les coûts logistiques et les autorisations nécessaires.',
      'Indiquer la ville / région et le pays d\'implantation du projet.',
      'analysis')
    check(sec, hasText(overview.startDate, 1), 'OVERVIEW_START_DATE', 'MINEUR',
      'Date prévisionnelle de démarrage non renseignée.',
      'Le calendrier de démarrage permet au financeur de situer le besoin de financement dans le temps.',
      'Indiquer la date prévisionnelle de démarrage de l\'activité.',
      'analysis')
    check(sec, hasText(overview.vision, MIN_SHORT) && hasText(overview.mission, MIN_SHORT), 'OVERVIEW_VISION_MISSION', 'MINEUR',
      'Vision et/ou mission de l\'entreprise absentes ou trop courtes.',
      'La vision et la mission montrent la direction stratégique du projet : leur absence fragilise la crédibilité du dossier.',
      'Décrire la vision (où aller) et la mission (comment y arriver) de l\'entreprise.',
      'analysis')
    check(sec, objectives.length >= 2, 'OVERVIEW_OBJECTIVES', 'MAJEUR',
      'Objectifs du projet insuffisants (moins de 2 objectifs définis).',
      'Des objectifs clés et mesurables structurent le plan d\'action et permettent d\'évaluer la réussite du projet.',
      'Définir au moins 2 objectifs précis et mesurables (ex. produire 9.000 poulets par cycle ; atteindre 6.500.000 FCFA de CA la première année).',
      'analysis')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 2. Étude de marché
  // ------------------------------------------------------------------
  {
    const sec = newSection('market', 'Étude de marché')
    const m = analysis.market
    const fields: Array<{ key: keyof typeof m; code: string; label: string; rec: string }> = [
      { key: 'demande', code: 'MARKET_DEMANDE', label: 'analyse de la demande', rec: 'Ajouter une estimation de la clientèle cible et de la demande (volume, croissance, saisonnalité).' },
      { key: 'offre', code: 'MARKET_OFFRE', label: 'analyse de l\'offre existante', rec: 'Décrire l\'offre concurrentielle actuelle : volumes disponibles, qualité, prix pratiqués.' },
      { key: 'segments', code: 'MARKET_SEGMENTS', label: 'segments de clientèle', rec: 'Décrire les segments de clientèle visés (bouchers, supermarchés, particuliers…).' },
      { key: 'tendances', code: 'MARKET_TENDANCES', label: 'tendances du marché', rec: 'Indiquer les tendances du secteur (consommation, réglementation, importations…).' },
      { key: 'cible', code: 'MARKET_CIBLE', label: 'clientèle cible', rec: 'Préciser la clientèle cible et sa localisation.' },
      { key: 'zones', code: 'MARKET_ZONES', label: 'zone de chalandise', rec: 'Délimiter la zone géographique de commercialisation.' },
      { key: 'conclusion', code: 'MARKET_CONCLUSION', label: 'conclusion de l\'étude', rec: 'Conclure sur l\'écart demande / offre justifiant le projet.' },
    ]
    for (const f of fields) {
      check(sec, hasText(m[f.key], MIN_FIELD), f.code, 'MAJEUR',
        'Absence de données sur la ' + f.label + '.',
        'Une étude de marché professionnelle justifie l\'existence d\'une demande suffisante ; sans ' + f.label + ', le chiffre d\'affaires prévisionnel n\'est pas crédible.',
        f.rec,
        'analysis')
    }
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 3. Analyse de la concurrence
  // ------------------------------------------------------------------
  {
    const sec = newSection('competition', 'Analyse de la concurrence')
    const comps = analysis.competitors.filter((c) => c && c.name && c.name.trim())
    check(sec, comps.length >= 2, 'COMPETITORS_COUNT', 'MAJEUR',
      'Concurrents insuffisamment identifiés (moins de 2 concurrents décrits).',
      'La connaissance des concurrents directs et indirects conditionne le positionnement et la stratégie commerciale.',
      'Ajouter au moins 2 concurrents avec leurs forces et faiblesses.',
      'analysis')
    const complete = comps.filter((c) => hasText(c.strengths, 5) && hasText(c.weaknesses, 5) && hasText(c.positioning, 5))
    check(sec, comps.length > 0 && complete.length === comps.length, 'COMPETITORS_DETAIL', 'MINEUR',
      'Certaines fiches concurrents sont incomplètes (forces, faiblesses ou positionnement manquants).',
      'Un concurrent sans forces/faiblesses identifiées ne permet pas de construire un avantage concurrentiel défendable.',
      'Compléter forces, faiblesses et positionnement pour chaque concurrent.',
      'analysis')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 4. Stratégie commerciale & marketing (SWOT + synthèse)
  // ------------------------------------------------------------------
  {
    const sec = newSection('strategy', 'Stratégie commerciale & marketing')
    const sw = analysis.swot
    const quads: Array<{ key: keyof typeof sw; label: string; code: string }> = [
      { key: 'strengths', label: 'forces', code: 'SWOT_STRENGTHS' },
      { key: 'weaknesses', label: 'faiblesses', code: 'SWOT_WEAKNESSES' },
      { key: 'opportunities', label: 'opportunités', code: 'SWOT_OPPORTUNITIES' },
      { key: 'threats', label: 'menaces', code: 'SWOT_THREATS' },
    ]
    for (const q of quads) {
      check(sec, (sw[q.key] || []).length >= 2, q.code, 'MAJEUR',
        'Matrice SWOT incomplète : moins de 2 ' + q.label + ' identifiées.',
        'Le SWOT est le socle de la stratégie : sans ' + q.label + ', le positionnement du projet n\'est pas démontré.',
        'Renseigner au moins 2 ' + q.label + ' dans la matrice SWOT.',
        'analysis')
    }
    check(sec, hasText(analysis.synthesis, MIN_FIELD), 'STRATEGY_SYNTHESIS', 'MINEUR',
      'Synthèse stratégique absente ou trop courte.',
      'La synthèse stratégique montre comment le projet transforme son analyse en avantage durable.',
      'Rédiger une synthèse d\'au moins ' + MIN_FIELD + ' caractères reliant SWOT, marché et positionnement.',
      'analysis')
    check(sec, hasText(analysis.recommendations, 40), 'STRATEGY_RECO', 'MINEUR',
      'Recommandations stratégiques absentes.',
      'Les recommandations traduisent l\'analyse en décisions concrètes (cibles, canaux, prix, partenariats).',
      'Ajouter les recommandations stratégiques et commerciales clés.',
      'analysis')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 5. Organisation & ressources humaines
  // ------------------------------------------------------------------
  {
    const sec = newSection('organization', 'Organisation & ressources humaines')
    const staff = A.staff.filter((s) => s && s.role && String(s.role).trim())
    check(sec, staff.length >= 1, 'ORG_STAFF', 'MAJEUR',
      'Aucun membre du personnel renseigné.',
      'L\'organisation des ressources humaines (effectifs, rôles, masse salariale) est une donnée obligatoire d\'un dossier bancaire.',
      'Ajouter au moins un poste avec effectif et salaire mensuel dans le module Finance.',
      'finance')
    const salariesOk = staff.length === 0 || staff.every((s) => (Number(s.monthlySalary) || 0) > 0)
    check(sec, salariesOk, 'ORG_SALARIES', 'MAJEUR',
      'Salaires manquants ou nuls pour certains postes.',
      'Une masse salariale nulle ou incohérente fausse le compte de résultat et les charges fixes.',
      'Renseigner un salaire mensuel réaliste pour chaque poste.',
      'finance')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 6. Plan opérationnel & technique (faisabilité)
  // ------------------------------------------------------------------
  {
    const sec = newSection('feasibility', 'Plan opérationnel & technique')
    const f = analysis.feasibility
    const feas: Array<{ key: keyof typeof f; code: string; label: string }> = [
      { key: 'technique', code: 'FEAS_TECHNIQUE', label: 'faisabilité technique' },
      { key: 'economique', code: 'FEAS_ECO', label: 'faisabilité économique' },
      { key: 'juridique', code: 'FEAS_JURIDIQUE', label: 'faisabilité juridique' },
      { key: 'organisationnelle', code: 'FEAS_ORG', label: 'faisabilité organisationnelle' },
      { key: 'commerciale', code: 'FEAS_COMM', label: 'faisabilité commerciale' },
    ]
    for (const x of feas) {
      check(sec, hasText(f[x.key] as string, MIN_FIELD), x.code, 'MAJEUR',
        'La ' + x.label + ' n\'est pas renseignée.',
        'Un dossier professionnel démontre la maîtrise du projet sur tous les plans : sans ' + x.label + ', le risque d\'exécution n\'est pas couvert.',
        'Rédiger la ' + x.label + ' (au moins ' + MIN_FIELD + ' caractères : processus, équipements, autorisations, organisation).',
        'analysis')
    }
    check(sec, f.verdict === 'FAVORABLE' || f.verdict === 'RESERVE', 'FEAS_VERDICT', 'MINEUR',
      f.verdict ? 'Verdict de faisabilité défavorable.' : 'Verdict de faisabilité non prononcé.',
      'L\'étude de faisabilité doit aboutir à un verdict argumenté avant tout engagement de fonds.',
      f.verdict === 'DEFAVORABLE'
        ? 'Revoir les points qui rendent la faisabilité défavorable puis prononcer un nouveau verdict.'
        : 'Prononcer un verdict de faisabilité (favorable ou réservé) dans le module Analyse.',
      'analysis')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 7. Plan d'investissement
  // ------------------------------------------------------------------
  {
    const sec = newSection('investment', 'Plan d\'investissement')
    const inv = finance.investments.filter((i) => i && (Number(i.amount) || 0) > 0)
    check(sec, inv.length >= 1 && comp.totalInvestment > 0, 'INV_COUNT', 'BLOQUANT',
      'Aucun investissement renseigné.',
      'Sans investissement initial, aucun indicateur de rentabilité (VAN, TRI, IP) ne peut être calculé : le projet est inévaluable.',
      'Ajouter les postes d\'investissement avec leurs coûts réels (terrains, bâtiments, équipements, frais d\'établissement).',
      'finance')
    const labeled = finance.investments.filter((i) => i && hasText(i.label, 3))
    check(sec, finance.investments.length === 0 || labeled.length === finance.investments.length, 'INV_LABELS', 'MAJEUR',
      'Certains postes d\'investissement ne sont pas libellés.',
      'Un poste sans libellé est inexploitable pour un financeur qui veut auditer les coûts.',
      'Libeller précisément chaque poste (ex. « Construction poulailler 200 m² »).',
      'finance')
    const amortOk = finance.investments.every((i) => !i.depreciable || ((Number(i.depYears) || 0) >= 1))
    check(sec, amortOk, 'INV_AMORT', 'MINEUR',
      'Durée d\'amortissement manquante sur certains postes amortissables.',
      'L\'amortissement réduit le résultat imposable et alimente la capacité d\'autofinancement : une durée manquante fausse le compte de résultat.',
      'Renseigner la durée d\'amortissement (en années) des postes amortissables.',
      'finance')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 8. Plan de financement
  // ------------------------------------------------------------------
  {
    const sec = newSection('financing', 'Plan de financement')
    check(sec, finance.financing.length >= 1, 'FIN_COUNT', 'MAJEUR',
      'Aucune ressource de financement renseignée.',
      'Le plan de financement démontre la capacité à couvrir le besoin total : sans ressources, le projet ne peut pas démarrer.',
      'Ajouter les fonds propres, emprunts et subventions prévus.',
      'finance')
    check(sec, comp.financingGap <= EPS, 'FIN_GAP', 'MAJEUR',
      'Ressources de financement insuffisantes : écart à financer de ' + fmtCurrency(Math.max(0, comp.financingGap), input.currency) + '.',
      'Le financement prévu ne couvre pas le besoin total (investissements + fonds de roulement) : le projet ne peut pas être exécuté tel quel.',
      'Revoir le plan de financement : augmenter les fonds propres ou l\'emprunt pour couvrir le besoin total de ' + fmtCurrency(comp.totalNeeds, input.currency) + '.',
      'finance')
    check(sec, comp.totalFinancing <= 0 || comp.ratios.autonomyRate >= 15, 'FIN_AUTONOMY', 'MINEUR',
      'Part des fonds propres faible (' + groupNumber(comp.ratios.autonomyRate, 1) + ' % du financement).',
      'Les banques attendent une contribution personnelle du porteur (en général 15 à 30 %) : en dessous, le risque de refus augmente fortement.',
      'Renforcer les fonds propres (apport personnel, subventions) pour atteindre au moins 15 % du financement total.',
      'finance')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 9. Prévisions financières
  // ------------------------------------------------------------------
  {
    const sec = newSection('financials', 'Prévisions financières')
    const products = A.products.filter((p) => p && hasText(p.label, 2))
    check(sec, products.length >= 1, 'FIN_PRODUCTS', 'BLOQUANT',
      'Aucun produit / service prévu dans les hypothèses.',
      'Sans prévision de ventes (produits, quantités, prix), aucun chiffre d\'affaires ni indicateur de rentabilité ne peut être établi.',
      'Ajouter les produits/services avec quantité annuelle et prix unitaire dans le module Finance.',
      'finance')
    const prodOk = A.products.length === 0 || A.products.every((p) => (Number(p.qty) || 0) > 0 && (Number(p.unitPrice) || 0) > 0)
    check(sec, prodOk, 'FIN_PRODUCTS_VALUES', 'MAJEUR',
      'Quantités ou prix unitaires manquants sur certains produits.',
      'Un produit sans quantité ou sans prix ne génère pas de chiffre d\'affaires : la prévision est faussée.',
      'Renseigner quantité annuelle et prix unitaire pour chaque produit.',
      'finance')
    check(sec, revenue1 > 0, 'FIN_REVENUE', 'BLOQUANT',
      'Chiffre d\'affaires prévisionnel nul.',
      'Un CA nul rend le projet non évaluable : la VAN, le TRI et l\'IP seraient systématiquement défavorables.',
      'Vérifier les hypothèses de vente (produits, quantités, prix) pour générer un chiffre d\'affaires réaliste.',
      'finance')
    check(sec, A.variableCosts.length >= 1, 'FIN_VARIABLE_COSTS', 'MAJEUR',
      'Aucune charge variable renseignée.',
      'Sans charges variables (matières, production), la marge sur coûts variables et le seuil de rentabilité ne sont pas calculables.',
      'Ajouter les charges variables principales (ex. alimentation, achat de poussins, transport).',
      'finance')
    check(sec, A.fixedCosts.length >= 1 || A.staff.length >= 1, 'FIN_FIXED_COSTS', 'MAJEUR',
      'Aucune charge fixe renseignée.',
      'Les charges fixes (loyer, salaires, utilities) sont indispensables au compte de résultat et au calcul du seuil de rentabilité.',
      'Ajouter les charges fixes annuelles (ou le personnel, qui génère la masse salariale).',
      'finance')
    check(sec, (Number(A.discountRate) || 0) > 0, 'FIN_DISCOUNT_RATE', 'MINEUR',
      'Taux d\'actualisation non renseigné.',
      'Le taux d\'actualisation mesure le coût du capital : VAN et TRI n\'ont pas de lecture fiable sans lui.',
      'Renseigner le taux d\'actualisation (ex. taux directeur + prime de risque, souvent 8 à 12 %).',
      'finance')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 10. Analyse des risques
  // ------------------------------------------------------------------
  {
    const sec = newSection('risks', 'Analyse des risques')
    const risks = analysis.risks.filter((r) => r && hasText(r.label, 3))
    check(sec, risks.length >= 3, 'RISKS_COUNT', 'MAJEUR',
      'Risques insuffisamment analysés (moins de 3 risques identifiés).',
      'Un dossier professionnel cartographie les risques majeurs (marché, production, financier, réglementaire) et leurs parades.',
      'Ajouter au moins 3 risques avec probabilité, impact et mesures d\'atténuation.',
      'analysis')
    const mitigated = risks.filter((r) => hasText(r.mitigation, 15))
    check(sec, risks.length === 0 || mitigated.length === risks.length, 'RISKS_MITIGATION', 'MAJEUR',
      'Mesures d\'atténuation manquantes sur certains risques.',
      'Un risque sans mesure d\'atténuation laisse le financeur face à un risque non maîtrisé.',
      'Décrire les mesures concrètes pour réduire chaque risque (assurance, contrats, stocks de sécurité…).',
      'analysis')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 11. Plan d'action
  // ------------------------------------------------------------------
  {
    const sec = newSection('actionplan', 'Plan d\'action & calendrier')
    check(sec, input.tasksCount >= 5, 'PLAN_TASKS', 'MINEUR',
      'Plan d\'action trop léger (moins de 5 activités).',
      'Le plan d\'action démontre la capacité d\'exécution : moins de 5 activités, il ne couvre ni la mise en place ni le démarrage.',
      'Détailler les phases de mise en œuvre (études, travaux, équipements, production, commercialisation) avec dates et responsables.',
      'action-plan')
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // 12. Rentabilité & viabilité économique (VAN, TRI, IP)
  // ------------------------------------------------------------------
  let indicators: IndicatorResult[] = []
  let rentabilityFavorable = false
  {
    const sec = newSection('rentability', 'Rentabilité & viabilité économique')
    if (!financeComplete) {
      check(sec, false, 'RENT_DATA', 'BLOQUANT',
        'Hypothèses financières insuffisantes pour évaluer la rentabilité.',
        'La VAN, le TRI et l\'IP exigent un investissement initial et des flux de trésorerie cohérents : investissement et prévision de ventes sont indispensables.',
        'Compléter le plan d\'investissement et les prévisions de ventes (produits, quantités, prix) dans le module Finance.',
        'finance')
    } else if (!input.premium) {
      check(sec, false, 'RENT_PREMIUM', 'BLOQUANT',
        'Validation de la rentabilité réservée à l\'abonnement Premium.',
        'L\'évaluation automatique de la rentabilité (VAN, TRI, IP) et la validation finale du dossier sont des fonctions Premium : le projet ne peut pas être validé sans elles.',
        'Activer l\'abonnement Premium pour débloquer l\'analyse de rentabilité et la validation du projet.',
        'premium')
    } else {
      const npv = comp.ratios.npv
      const irr = comp.ratios.irr
      const ip = comp.totalNeeds > 0 ? (npv + comp.totalNeeds) / comp.totalNeeds : 0

      const vanStatus: IndicatorStatus = npv > EPS ? 'FAVORABLE' : Math.abs(npv) <= EPS ? 'EQUILIBRE' : 'DEFAVORABLE'
      const triStatus: IndicatorStatus = irr === null ? 'NON_CALCULE' : irr > discountPct + EPS ? 'FAVORABLE' : Math.abs(irr - discountPct) <= EPS ? 'EQUILIBRE' : 'DEFAVORABLE'
      const ipStatus: IndicatorStatus = ip > 1 + EPS ? 'FAVORABLE' : Math.abs(ip - 1) <= EPS ? 'EQUILIBRE' : 'DEFAVORABLE'

      indicators = [
        {
          key: 'VAN',
          label: 'Valeur Actuelle Nette (VAN)',
          value: npv,
          formatted: fmtCurrency(npv, input.currency),
          criterion: 'VAN > 0',
          status: vanStatus,
          explanation:
            vanStatus === 'FAVORABLE'
              ? 'Après récupération de l\'investissement initial et actualisation des flux au taux de ' + groupNumber(discountPct, 1) + ' %, le projet crée de la valeur.'
              : vanStatus === 'EQUILIBRE'
                ? 'Le projet rembourse exactement l\'investissement et le taux exigé : rentabilité à l\'équilibre.'
                : 'À taux de ' + groupNumber(discountPct, 1) + ' %, les flux actualisés ne couvrent pas l\'investissement initial : le projet détruit de la valeur.',
        },
        {
          key: 'TRI',
          label: 'Taux de Rentabilité Interne (TRI)',
          value: irr,
          formatted: irr === null ? '—' : groupNumber(irr, 1) + ' %',
          criterion: 'TRI > ' + groupNumber(discountPct, 1) + ' % (taux d\'actualisation)',
          status: triStatus,
          explanation:
            triStatus === 'NON_CALCULE'
              ? 'TRI non calculable : les flux de trésorerie ne permettent pas de trouver un taux annulant la VAN (flux insuffisants ou négatifs).'
              : triStatus === 'FAVORABLE'
                ? 'Le projet rapporte ' + groupNumber(Math.max(0, (irr ?? 0) - discountPct), 1) + ' points de plus que le taux d\'actualisation exigé.'
                : triStatus === 'EQUILIBRE'
                  ? 'Le TRI est égal au taux d\'actualisation : rentabilité à l\'équilibre.'
                  : 'Le TRI est inférieur au taux d\'actualisation exigé (' + groupNumber(discountPct, 1) + ' %) : le projet rapporte moins que le coût des ressources.',
        },
        {
          key: 'IP',
          label: 'Indice de Profitabilité (IP)',
          value: ip,
          formatted: groupNumber(ip, 2),
          criterion: 'IP > 1',
          status: ipStatus,
          explanation:
            ipStatus === 'FAVORABLE'
              ? 'Chaque franc investi rapporte ' + groupNumber(ip, 2) + ' franc de valeur actuelle : le projet est créateur de valeur.'
              : ipStatus === 'EQUILIBRE'
                ? 'La valeur actuelle des flux est exactement égale à l\'investissement : rentabilité à l\'équilibre.'
                : 'Chaque franc investi ne rapporte que ' + groupNumber(ip, 2) + ' franc de valeur actuelle : la valeur actuelle des flux est inférieure à l\'investissement initial.',
        },
      ]

      // Règle fondamentale : au moins un indicateur favorable → avis favorable
      rentabilityFavorable = indicators.some((i) => i.status === 'FAVORABLE')

      if (rentabilityFavorable) {
        sec.checks++
        sec.passed++
      } else {
        check(sec, false, 'RENT_NEGATIVE', 'MAJEUR',
          'Rentabilité insuffisante : ' + indicators.map((i) => i.key + ' ' + (i.status === 'EQUILIBRE' ? 'à l\'équilibre' : 'défavorable')).join(', ') + '.',
          'Aucun des trois indicateurs ne satisfait son critère de rentabilité : en l\'état, le projet ne crée pas de valeur et ne peut pas être validé.',
          'Revoir les hypothèses : augmenter le chiffre d\'affaires (volumes, prix de vente), réduire les charges (coûts variables, charges fixes) ou optimiser le plan d\'investissement, puis recalculer.',
          'finance')
      }
    }
    sections.push(sec)
  }

  // ------------------------------------------------------------------
  // Statut global, taux de conformité et décision
  // ------------------------------------------------------------------
  const allProblems = sections.flatMap((s) => s.problems)
  const severityRank: Record<ProblemSeverity, number> = { BLOQUANT: 0, MAJEUR: 1, MINEUR: 2 }
  allProblems.sort((a, b) => severityRank[a.severity] - severityRank[b.severity])

  const mandatoryProblems = allProblems.filter((p) => p.severity !== 'MINEUR')
  const essentialMissing =
    !hasText(overview.summary, 40) || !financeComplete

  let status: ValidationStatus
  if (essentialMissing) {
    status = 'INCOMPLET'
  } else if (!rentabilityFavorable) {
    status = 'NON_RENTABLE'
  } else if (allProblems.length > 0) {
    // Règle Gescom Project : s'il reste UNE SEULE anomalie ou correction —
    // même un simple avertissement — le projet n'est PAS validé. Un projet
    // validé est un projet entièrement conforme, sans aucune réserve.
    status = 'A_CORRIGER'
  } else {
    status = 'VALIDE'
  }

  const sectionsTotal = sections.length
  const sectionsConformes = sections.filter((s) => s.problems.length === 0).length
  const conformityRate = Math.round(
    sections.reduce((sum, s) => sum + (s.checks > 0 ? (s.passed / s.checks) * 100 : 0), 0) / sectionsTotal,
  )

  const statusLabel: Record<ValidationStatus, string> = {
    VALIDE: 'Projet validé',
    A_CORRIGER: 'Projet à corriger',
    NON_RENTABLE: 'Projet non rentable',
    INCOMPLET: 'Projet incomplet',
  }

  const decision: Record<ValidationStatus, string> = {
    VALIDE:
      'Aucune anomalie ni correction en attente : toutes les exigences sont satisfaites et le critère de rentabilité financière est favorable. Le projet est validé par Gescom Project, automatiquement confirmé « Terminé », et l\'exportation du dossier définitif (PDF et Word) est autorisée.',
    A_CORRIGER:
      mandatoryProblems.length > 0
        ? mandatoryProblems.length + ' anomalie(s) obligatoire(s) et ' + (allProblems.length - mandatoryProblems.length) + ' avertissement(s) restent à corriger. Tant qu\'une seule anomalie ou correction subsiste, le projet ne peut être ni validé ni confirmé « Terminé » et l\'impression définitive reste bloquée. Le rapport de diagnostic reste téléchargeable à tout moment.'
        : allProblems.length + ' correction(s) restent à apporter : tant qu\'une seule anomalie ou correction subsiste — même un simple avertissement — le projet ne peut être ni validé ni confirmé « Terminé », et l\'impression définitive reste bloquée. Le rapport de diagnostic reste téléchargeable à tout moment.',
    NON_RENTABLE:
      'Aucun des trois indicateurs financiers (VAN, TRI, IP) ne satisfait son critère de rentabilité. Le projet doit être soumis à des corrections : révisez les hypothèses de chiffre d\'affaires, de charges et d\'investissement, puis relancez l\'analyse.',
    INCOMPLET:
      'Des informations essentielles (résumé exécutif, investissement, prévisions de ventes) sont manquantes et empêchent une évaluation fiable. Complétez les modules concernés puis relancez l\'analyse.',
  }

  return {
    status,
    statusLabel: statusLabel[status],
    decision: decision[status],
    canExport: status === 'VALIDE',
    rentabilityFavorable,
    discountRatePct: discountPct,
    indicators,
    sections: sections.map((s) => ({
      id: s.id,
      label: s.label,
      status: s.problems.length === 0 ? 'CONFORME' : 'A_CORRIGER',
      filledRatio: s.checks > 0 ? Math.round((s.passed / s.checks) * 100) : 100,
      problems: s.problems,
    })),
    problems: allProblems,
    counts: {
      sectionsTotal,
      sectionsConformes,
      anomalies: allProblems.length,
      // Toutes les anomalies (y compris les avertissements) bloquent désormais
      // la validation : le nombre de corrections restantes est donc le total.
      correctionsRestantes: allProblems.length,
    },
    conformityRate,
  }
}
