'use client'

// GESCOM PROJECT – État global de navigation (zustand)
import { create } from 'zustand'
import type { SessionUser } from '@/lib/types'
import type { BillingPeriod } from '@/lib/plans'

export type View =
  | 'dashboard'
  | 'projects'
  | 'new-project'
  | 'analysis'
  | 'finance'
  | 'action-plan'
  | 'validation'
  | 'documents'
  | 'presentation'
  | 'settings'

export const VIEW_TITLES: Record<View, string> = {
  dashboard: 'Tableau de bord',
  projects: 'Mes projets',
  'new-project': 'Nouveau projet',
  analysis: 'Analyse',
  finance: 'Finance',
  'action-plan': "Plan d'action",
  validation: 'Validation & rentabilité',
  documents: 'Documents',
  presentation: 'Présentation',
  settings: 'Paramètres',
}

// Les vues qui nécessitent un projet ouvert
export const PROJECT_VIEWS: View[] = ['analysis', 'finance', 'action-plan', 'validation', 'documents', 'presentation']

// ---------------------------------------------------------------------------
// Historique de navigation (flèches « retour » / « avant » de la barre du haut)
// Chaque entrée mémorise l'écran visité ET le projet qui y était ouvert, comme
// une page web : « retour » ramène donc sur l'écran précédent avec le même
// projet, et « avant » permet d'y revenir après un retour.
// ---------------------------------------------------------------------------
export interface NavEntry {
  view: View
  projectId: string | null
}

// Taille maximale des piles retour / avant (anti-fuite mémoire).
const NAV_STACK_LIMIT = 50

interface AppState {
  user: SessionUser | null
  view: View
  activeProjectId: string | null
  navHistory: NavEntry[] // écrans précédents (le plus récent en dernier)
  navFuture: NavEntry[] // écrans « avant » après un retour (le plus proche en dernier)
  // Tunnel d'abonnement Premium (formulaire + choix du moyen de paiement) :
  // ouvert depuis les boutons « Passer à Premium » de toute l'application.
  checkoutBilling: BillingPeriod | null // null = tunnel fermé
  openCheckout: (billing?: BillingPeriod) => void
  closeCheckout: () => void
  setUser: (u: SessionUser | null) => void
  navigate: (v: View) => void
  openProject: (projectId: string, view?: View) => void
  goBack: () => void
  goForward: () => void
}

// Empile l'écran courant dans l'historique et vide le chemin « avant »
// (comme dans un navigateur : une nouvelle navigation efface le futur).
function pushPast(state: AppState): Pick<AppState, 'navHistory' | 'navFuture'> {
  return {
    navHistory: [
      ...state.navHistory,
      { view: state.view, projectId: state.activeProjectId },
    ].slice(-NAV_STACK_LIMIT),
    navFuture: [],
  }
}

export const useApp = create<AppState>((set) => ({
  user: null,
  view: 'dashboard',
  activeProjectId: null,
  navHistory: [],
  navFuture: [],
  checkoutBilling: null,
  openCheckout: (billing) => set({ checkoutBilling: billing ?? 'MONTHLY' }),
  closeCheckout: () => set({ checkoutBilling: null }),
  setUser: (user) => set({ user }),
  navigate: (view) =>
    set((state) => {
      if (view === state.view) return state // même écran : rien à empiler
      return { view, ...pushPast(state) }
    }),
  openProject: (projectId, view) =>
    set((state) => {
      const target = view ?? 'analysis'
      if (target === state.view && projectId === state.activeProjectId) {
        return state // même écran et même projet : rien à empiler
      }
      return { activeProjectId: projectId, view: target, ...pushPast(state) }
    }),
  goBack: () =>
    set((state) => {
      if (state.navHistory.length === 0) return state
      const previous = state.navHistory[state.navHistory.length - 1]
      return {
        view: previous.view,
        activeProjectId: previous.projectId,
        navHistory: state.navHistory.slice(0, -1),
        navFuture: [
          ...state.navFuture,
          { view: state.view, projectId: state.activeProjectId },
        ].slice(-NAV_STACK_LIMIT),
      }
    }),
  goForward: () =>
    set((state) => {
      if (state.navFuture.length === 0) return state
      const next = state.navFuture[state.navFuture.length - 1]
      return {
        view: next.view,
        activeProjectId: next.projectId,
        navHistory: [
          ...state.navHistory,
          { view: state.view, projectId: state.activeProjectId },
        ].slice(-NAV_STACK_LIMIT),
        navFuture: state.navFuture.slice(0, -1),
      }
    }),
}))
