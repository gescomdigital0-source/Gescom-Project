// GESCOM PROJECT – Dictionnaire FR → EN de l'interface (modules projet)
// Analyse, Finance, Plan d'action, Documents, Présentation + utilitaires.
export const MODULES_DICT: Record<string, string> = {
  // ---- Utilitaires (client-api, useProjectData) ----
  "Impossible de joindre le serveur. L'aperçu a peut-être été mis en veille : rechargez la page puis réessayez (votre travail est enregistré).":
    'Unable to reach the server. The preview may have been put to sleep: reload the page and try again (your work is saved).',
  "L'aperçu a peut-être été mis en veille :": 'The preview may have been put to sleep:',
  'rechargez la page puis réessayez (votre travail est enregistré).':
    'reload the page and try again (your work is saved).',
  'Erreur de chargement.': 'Loading error.',
  'Sauvegarde échouée': 'Save failed',
  'Enregistrement momentanément impossible (serveur peut-être en veille).':
    'Saving temporarily unavailable (server may be asleep).',
  'Vos modifications restent affichées et seront envoyées au prochain essai.':
    'Your changes remain displayed and will be sent on the next attempt.',
  'Changement de statut échoué': 'Status change failed',
  'Impossible de changer le statut en «': 'Failed to change status to «',

  // ---- Module Analyse : onglets ----
  'Marché': 'Market',
  'Concurrence': 'Competition',
  'Faisabilité': 'Feasibility',
  'suivez les onglets de gauche à droite (Aperçu → SWOT → PESTEL → Marché → Concurrence → Risques → Faisabilité → Synthèse). Sur chaque champ, le bouton':
    'follow the tabs from left to right (Overview → SWOT → PESTEL → Market → Competition → Risks → Feasibility → Summary). On each field, the button',
  'insère un texte adapté à votre secteur («': 'inserts text tailored to your sector («',
  '») : remplacez les éléments entre [crochets] par vos propres observations et chiffres. Tout est enregistré automatiquement.':
    '») : replace the [bracketed] items with your own observations and figures. Everything is saved automatically.',
  'Défini à la création du projet': 'Set at project creation',
  'Ex. Zone industrielle de Douala': 'e.g. Douala industrial zone',
  'Ex. Fermes semi-industrielles locales': 'e.g. Local semi-industrial farms',
  // Placeholders générés (templates « Ajouter une ${label}… »)
  'Ajouter une force…': 'Add a strength…',
  'Ajouter une faiblesse…': 'Add a weakness…',
  'Ajouter une opportunité…': 'Add an opportunity…',
  'Ajouter une menace…': 'Add a threat…',
  'Ajouter un segment…': 'Add a segment…',
  'Ajouter un besoin…': 'Add a need…',
  'Ajouter un concurrent…': 'Add a competitor…',
  'Ajouter un risque…': 'Add a risk…',
  'Listez les actions recommandées avant le lancement (enquête terrain, contrats, formations…)':
    'List the recommended actions before launch (field survey, contracts, training…)',

  // ---- Module Analyse : aperçu ----
  'Aperçu général': 'General overview',
  'Idée, porteur, localisation': 'Idea, owner, location',
  'Porteur du projet': 'Project owner',
  'Nom du porteur': "Owner's name",
  'Nom et qualité du porteur': "Owner's name and role",
  'Forme juridique envisagée': 'Planned legal form',
  'Choisir une forme juridique': 'Choose a legal form',
  'Date prévisionnelle de démarrage': 'Planned start date',
  'Pays du projet': 'Project country',
  'Région / ville du projet': 'Project region / city',
  'Objectifs clés': 'Key objectives',
  'Aucun objectif défini. Ajoutez des objectifs mesurables.':
    'No objective defined. Add measurable objectives.',
  'Où voulez-vous être dans 5 ans ?': 'Where do you want to be in 5 years?',
  'Quelle valeur créez-vous, pour qui, comment ?': 'What value do you create, for whom, how?',

  // ---- Module Analyse : SWOT ----
  'Forces, faiblesses, opportunités, menaces': 'Strengths, weaknesses, opportunities, threats',
  'Avantages internes dont vous disposez': 'Internal advantages you have',
  'Limites internes à corriger ou assumer': 'Internal limitations to fix or own',
  'Facteurs externes favorables à saisir': 'Favorable external factors to seize',
  'Risques externes à anticiper': 'External risks to anticipate',
  'Opportunités': 'Opportunities',
  'Forces': 'Strengths',
  'Faiblesses': 'Weaknesses',
  'Menaces': 'Threats',

  // ---- Module Analyse : PESTEL ----
  'PESTEL = le scan de votre environnement extérieur': 'PESTEL = a scan of your external environment',
  ': tout ce que vous ne contrôlez pas mais qui influence votre projet. Pour chaque dimension, lisez les':
    ': everything you do not control but that influences your project. For each dimension, read the',
  'questions à vous poser': 'questions to ask yourself',
  'Questions à vous poser :': 'Questions to ask yourself:',
  'Politique': 'Political',
  'Économique': 'Economic',
  'Socioculturel': 'Sociocultural',
  'Technologique': 'Technological',
  'Écologique': 'Environmental',
  'Légal': 'Legal',
  'Stabilité, politiques publiques, subventions, taxes': 'Stability, public policies, subsidies, taxes',
  'Climat, ressources, gestion des déchets, normes': 'Climate, resources, waste management, standards',
  'Démographie, habitudes de consommation, culture': 'Demographics, consumption habits, culture',
  'Innovations, équipements disponibles, digitalisation': 'Innovations, available equipment, digitalization',
  'Réglementations, licences, normes sanitaires, fiscalité': 'Regulations, licenses, health standards, taxation',
  'Autorisations, licences, réglementation applicable': 'Permits, licenses, applicable regulations',

  // ---- Module Analyse : marché ----
  'Étude de marché documentée': 'Documented market study',
  'Analyse de la demande': 'Demand analysis',
  'Clientèle cible': 'Target customers',
  'Décrivez chaque segment (ménages, professionnels, institutions…)':
    'Describe each segment (households, professionals, institutions…)',
  'Segments de clientèle': 'Customer segments',
  'Volume, saisonnalité, évolution. Notez vos hypothèses : elles devront être validées par une enquête terrain.':
    'Volume, seasonality, trends. Note your assumptions: they must be validated by a field survey.',
  'Zone de chalandise': 'Catchment area',
  'Zone géographique desservie, distances, logistique': 'Geographic area served, distances, logistics',
  'Tendances du marché': 'Market trends',
  'Évolutions de consommation, digitalisation, réglementations': 'Consumption shifts, digitalization, regulations',
  'Besoins identifiés': 'Identified needs',
  'Ajouter un besoin': 'Add a need',
  'Insérer des besoins types du secteur': 'Insert sector-typical needs',
  'Segments prioritaires et premiers clients visés': 'Priority segments and first target customers',

  // ---- Module Analyse : concurrence ----
  'Concurrence analysée': 'Competition analyzed',
  'Ajouter un concurrent': 'Add a competitor',
  'Insérer des concurrents types': 'Insert typical competitors',
  'Type de concurrence': 'Competition type',
  'Votre positionnement face à ce concurrent': 'Your positioning against this competitor',
  'Qualité, transparence, ancrage local…': 'Quality, transparency, local roots…',
  'Aucun concurrent renseigné. Identifiez vos concurrents directs et indirects, ou insérez des concurrents types du secteur ci-dessous pour partir d\u2019une base à adapter.':
    'No competitor entered. Identify your direct and indirect competitors, or insert typical sector competitors below to start from an adaptable base.',
  "Aucun concurrent renseigné. Identifiez vos concurrents directs et indirects, ou insérez des concurrents types du secteur ci-dessous pour partir d'une base à adapter.":
    'No competitor entered. Identify your direct and indirect competitors, or insert typical sector competitors below to start from an adaptable base.',

  // ---- Module Analyse : risques ----
  "Identifiez vos risques, évaluez leur probabilité et leur impact, et décrivez vos mesures d'atténuation grâce au registre de criticité (probabilité × impact).":
    'Identify your risks, assess their likelihood and impact, and describe your mitigation measures with the criticality register (likelihood × impact).',
  'La criticité se calcule automatiquement :': 'Criticality is computed automatically:',
  'probabilité × impact': 'likelihood × impact',
  'Intitulé du risque': 'Risk title',
  'Catégorie (sanitaire, financier, commercial…)': 'Category (health, financial, commercial…)',
  'Ajouter un risque': 'Add a risk',
  'Insérer des risques types du secteur': 'Insert sector-typical risks',
  "Mesures d'atténuation prévues…": 'Planned mitigation measures…',
  "Mesures d'atténuation": 'Mitigation measures',
  'Registre des risques avec criticité /25': 'Risk register with criticality /25',
  "Mesures d'atténuation par risque": 'Mitigation measures per risk',
  '0/6 dimensions renseignées': '0/6 dimensions filled in',
  '1/6 dimensions renseignées': '1/6 dimensions filled in',
  '2/6 dimensions renseignées': '2/6 dimensions filled in',
  '3/6 dimensions renseignées': '3/6 dimensions filled in',
  '4/6 dimensions renseignées': '4/6 dimensions filled in',
  '5/6 dimensions renseignées': '5/6 dimensions filled in',
  '6/6 dimensions renseignées': '6/6 dimensions filled in',
  'Risques avec mesures': 'Risks with measures',
  '. Triez vos actions d\u2019atténuation en priorisant les risques critiques.':
    '. Sort your mitigation actions by prioritizing critical risks.',
  ". Triez vos actions d'atténuation en priorisant les risques critiques.":
    '. Sort your mitigation actions by prioritizing critical risks.',
  'Faible': 'Low',
  'Moyenne': 'Medium',
  'Moyen': 'Medium',
  'Élevée': 'High',
  'Élevé': 'High',
  'Critique': 'Critical',
  'Probabilité': 'Likelihood',
  'Impact': 'Impact',
  'Criticité': 'Criticality',

  // ---- Module Analyse : faisabilité & synthèse ----
  'Le marché justifie-t-il le lancement ? Conditions de succès.':
    'Does the market justify the launch? Success conditions.',
  'Faisabilité commerciale': 'Commercial feasibility',
  'Faisabilité technique': 'Technical feasibility',
  'Technologies, compétences, équipements nécessaires et disponibles':
    'Technologies, skills, equipment needed and available',
  'Faisabilité économique': 'Economic feasibility',
  'Coûts, marges, seuil de rentabilité, sensibilité': 'Costs, margins, break-even point, sensitivity',
  'Faisabilité organisationnelle': 'Organizational feasibility',
  'Équipe, partenaires, processus de gestion': 'Team, partners, management processes',
  'Faisabilité juridique': 'Legal feasibility',
  'Verdict de faisabilité': 'Feasibility verdict',
  'Favorable — poursuivre le projet': 'Favorable — proceed with the project',
  'Favorable sous réserves': 'Favorable with reservations',
  'Défavorable — revoir le projet': 'Unfavorable — revise the project',
  'Réorientation nécessaire': 'Reorientation needed',
  'Projet viable au stade actuel': 'Project viable at current stage',
  "Conclure l'étude de faisabilité": 'Conclude the feasibility study',
  'Synthèse': 'Summary',
  'Synthèse stratégique': 'Strategic summary',
  'Synthèse & recommandations': 'Summary & recommendations',
  'Résumez les conclusions de vos analyses : attractivité du marché, positionnement, risques majeurs…':
    'Summarize your analysis conclusions: market attractiveness, positioning, major risks…',
  'Résumé exécutif': 'Executive summary',
  'Synthèse complète du projet : activité, marché, besoins de financement, résultats attendus… (utilisé en première page du dossier)':
    "Complete project summary: activity, market, financing needs, expected results… (used on the dossier's first page)",
  "État de l'analyse": 'Analysis status',
  'Matrice SWOT complétée': 'SWOT matrix completed',
  'Analyse PESTEL renseignée': 'PESTEL analysis filled in',
  'Accès aux clients, canaux de vente, concurrence': 'Access to customers, sales channels, competition',
  'Comment remplir cette partie :': 'How to fill in this section:',
  'proches de votre situation puis adaptez le texte (remplacez les éléments entre [crochets] par vos propres observations). Le bouton':
    'close to your situation then adapt the text (replace the [bracketed] items with your own observations). The button',
  'insère un paragraphe complet à reprendre.': 'inserts a complete paragraph for you to adapt.',
  'Insérer un exemple à adapter': 'Insert an example to adapt',
  'Insérer un modèle à compléter': 'Insert a template to fill in',
  'Insérer un modèle': 'Insert a template',
  'Tout ajouter': 'Add all',
  "Aucun élément — cliquez sur un exemple ci-dessous pour l'insérer.":
    'No item — click an example below to insert one.',
  'Exemples à adapter :': 'Examples to adapt:',
  'Pré-remplir les champs vides': 'Pre-fill empty fields',
  'Abordables': 'Affordable',
  'Étude de marché :': 'Market study:',

  // ---- Module Finance : onglets & produits ----
  'Hypothèses': 'Assumptions',
  'Exploitation': 'Operations',
  'Investissement': 'Investment',
  'Financement': 'Financing',
  'Prévisions': 'Forecasts',
  'Résultats': 'Results',
  'Risques': 'Risks',
  'Indicateurs': 'Indicators',
  'Scénarios': 'Scenarios',
  'Graphiques': 'Charts',
  "Produits — chiffre d'affaires prévisionnel": 'Products — forecast revenue',
  'Déclarez vos produits ou services (quantités, prix, croissances annuelles) pour construire le chiffre d\u2019affaires prévisionnel et débloquer tout le module financier.':
    'Declare your products or services (quantities, prices, annual growth) to build the forecast revenue and unlock the whole finance module.',
  "Déclarez vos produits ou services (quantités, prix, croissances annuelles) pour construire le chiffre d'affaires prévisionnel et débloquer tout le module financier.":
    'Declare your products or services (quantities, prices, annual growth) to build the forecast revenue and unlock the whole finance module.',
  'Ajouter un produit': 'Add a product',
  'Produit / service': 'Product / service',
  'Qté an 1': 'Qty year 1',
  'Prix %/an': 'Price %/yr',
  'Volume %/an': 'Volume %/yr',
  'Croissance %/an': 'Growth %/yr',
  "Quantités et prix de l'année 1, avec croissances annuelles.":
    'Year-1 quantities and prices, with annual growth.',
  'Données financières manquantes': 'Missing financial data',
  "Renseignez d'abord vos produits et charges dans l'onglet « Exploitation ».":
    'Enter your products and costs in the “Operations” tab first.',

  // ---- Module Finance : investissement & financement ----
  "Programme d'investissement": 'Investment program',
  'Total investissements': 'Total investments',
  'Aucun investissement saisi.': 'No investment entered.',
  'Fonds de roulement (BFR)': 'Working capital (WCR)',
  "Trésorerie nécessaire pour financer le cycle d'exploitation avant encaissements (stocks, premiers achats…).":
    'Cash needed to fund the operating cycle before collections (inventory, first purchases…).',
  'Montant/an': 'Amount/year',
  'Fonds propres': 'Equity',
  'Emprunt': 'Loan',
  'Emprunts': 'Loans',
  'Subventions': 'Subsidies',
  'Subvention': 'Subsidy',
  'Sources : fonds propres, emprunts, subventions': 'Sources: equity, loans, subsidies',
  'Fonds propres, emprunts (annuités constantes calculées automatiquement) et subventions.':
    'Equity, loans (constant annuities computed automatically) and subsidies.',
  'Ajouter une source': 'Add a source',
  'Besoin total de financement': 'Total financing need',
  'Financement couvert': 'Financing covered',
  "Alerte sur l'écart à financer": 'Alert on the funding gap',
  'Écart à financer': 'Funding gap',
  'Échéancier de remboursement': 'Repayment schedule',
  'Échéanciers de remboursement automatiques': 'Automatic repayment schedules',
  "Structurez vos sources de financement (fonds propres, emprunts, subventions), calculez l'écart à financer et générez les échéanciers de remboursement automatiques.":
    'Structure your funding sources (equity, loans, subsidies), compute the funding gap and generate automatic repayment schedules.',
  'Annuité': 'Annuity payment',
  'Intérêts': 'Interest',
  'Intérêts sur emprunts': 'Loan interest',
  'Capital remboursé': 'Principal repaid',
  'Capital début': 'Opening principal',
  'Taux annuel (%)': 'Annual rate (%)',
  'Durée (ans)': 'Term (years)',
  'Trésorerie début': 'Opening cash',
  'Trésorerie fin': 'Closing cash',
  'Amortissements': 'Depreciation',
  'EBE': 'EBITDA',
  "Marge d'EBE (an 1)": 'EBITDA margin (year 1)',
  'Structure de financement': 'Financing structure',
  'Répartition du financement': 'Financing breakdown',

  // ---- Module Finance : compte de résultat & trésorerie ----
  'Compte de résultat prévisionnel': 'Forecast income statement',
  'Compte de résultat sur 1 à 10 ans': 'Income statement over 1 to 10 years',
  'Visualisez le compte de résultat prévisionnel sur tout l\u2019horizon (CA, marge, EBE, résultat net) ainsi que les flux de trésorerie année par année.':
    'View the forecast income statement over the whole horizon (revenue, margin, EBITDA, net income) and the cash flows year by year.',
  "Visualisez le compte de résultat prévisionnel sur tout l'horizon (CA, marge, EBE, résultat net) ainsi que les flux de trésorerie année par année.":
    'View the forecast income statement over the whole horizon (revenue, margin, EBITDA, net income) and the cash flows year by year.',
  'Chiffre d\u2019affaires minimum couvrant toutes les charges (année 1).':
    'Minimum revenue covering all costs (year 1).',
  "Chiffre d'affaires minimum couvrant toutes les charges (année 1).":
    'Minimum revenue covering all costs (year 1).',
  'Charges fixes': 'Fixed costs',
  'Charges variables': 'Variable costs',
  'Charges fixes (exploit. + personnel)': 'Fixed costs (operations + staff)',
  'Ajouter une charge fixe': 'Add a fixed cost',
  'Ajouter une charge variable': 'Add a variable cost',
  'Ajouter un poste': 'Add a line item',
  'Ajouter une ligne': 'Add a line',
  'Indépendantes du volume (loyer, assurance, énergie de base…).':
    'Independent of volume (rent, insurance, base energy…).',
  'Proportionnelles au volume (qté × prix) ou au chiffre d\u2019affaires (%).':
    'Proportional to volume (qty × price) or to revenue (%).',
  'Proportionnelles au volume (qté × prix) ou au chiffre d\'affaires (%).':
    'Proportional to volume (qty × price) or to revenue (%).',
  'Inclus dans les charges fixes du compte de résultat.':
    "Included in the income statement's fixed costs.",
  'Marge sur coûts variables': 'Contribution margin',
  'Seuil de rentabilité': 'Break-even point',
  'Seuil de rentabilité et marges': 'Break-even point and margins',
  'Structure des coûts (année 1)': 'Cost structure (year 1)',
  'Structure des charges': 'Cost breakdown',
  'CA (an 1)': 'Revenue (year 1)',
  'Marge nette (an 1)': 'Net margin (year 1)',
  'Résultat net (an 1)': 'Net income (year 1)',
  'Résultat net': 'Net income',
  'RÉSULTAT NET': 'NET INCOME',
  'Résultat avant impôt': 'Pre-tax income',
  'Impôts': 'Taxes',
  'Impôt sur les sociétés': 'Corporate income tax',
  "Taux d'impôt (%)": 'Tax rate (%)',
  'CA, charges et résultat net': 'Revenue, costs and net income',
  'Évolution du CA et du résultat': 'Revenue and income trends',
  'Flux de trésorerie': 'Cash flow',
  'Flux de trésorerie cumulés': 'Cumulative cash flows',
  'Flux net de trésorerie': 'Net cash flow',
  'Flux de trésorerie et CAF': 'Cash flow and CAF',
  'CAF = résultat net + amortissements. Flux net = CAF − remboursement du capital emprunté.':
    'CAF = net income + depreciation. Net flow = CAF − loan principal repayment.',
  'Salaire/mois': 'Salary/month',
  'Personnel': 'Staff',

  // ---- Module Finance : indicateurs ----
  'VAN, TRI, délai de récupération': 'NPV, IRR, payback period',
  'VAN, TRI, délai de récupération, seuil de rentabilité, marges et DSCR : les indicateurs qui convainquent banquiers et investisseurs.':
    'NPV, IRR, payback, break-even, margins and DSCR: the indicators that convince bankers and investors.',
  "Taux d'actualisation (%)": 'Discount rate (%)',
  'Horizon (années)': 'Horizon (years)',
  'Valeur actuelle nette des flux du projet. Positive : le projet crée de valeur.':
    "Net present value of the project's flows. Positive: the project creates value.",
  'Taux de rentabilité interne : rendement annuel implicite du projet.':
    "Internal rate of return: the project's implicit annual yield.",
  'Délai de récupération': 'Payback period',
  "Nombre d'années nécessaires pour retrouver la mise de fonds initiale.":
    'Number of years needed to recover the initial outlay.',
  'DSCR (an 1)': 'DSCR (year 1)',
  'DSCR (capacité de remboursement)': 'DSCR (debt service coverage)',
  "(avant financement) avec récupération du BFR en fin d'horizon. Le DSCR mesure la capacité de remboursement : EBE / (intérêts + capital remboursé) de l'année 1. Tous ces calculs sont identiques dans les documents exportés.":
    '(before financing) with working capital recovery at the end of the horizon. DSCR measures repayment capacity: EBITDA / (interest + principal repaid) in year 1. All these calculations are identical in the exported documents.',
  'VAN, TRI et délai de récupération sont calculés sur les': 'NPV, IRR and payback are computed on the',
  'flux du projet': 'project flows',
  'Comment sont calculés la VAN et le TRI ?': 'How are NPV and IRR computed?',
  'Récupération': 'Payback',
  'Mise de fonds initiale récupérée': 'Initial outlay recovered',
  'VAN (valeur actuelle nette)': 'NPV (net present value)',
  'TRI (taux de rentabilité interne)': 'IRR (internal rate of return)',

  // ---- Module Finance : scénarios & graphiques ----
  'Testez la robustesse de votre projet : scénario pessimiste, réaliste et optimiste avec impact direct sur le CA, le résultat net et la VAN.':
    "Test your project's robustness: pessimistic, realistic and optimistic scenarios with direct impact on revenue, net income and NPV.",
  'Le moteur recalcule intégralement les prévisions selon trois hypothèses de volume et de prix.':
    'The engine fully recomputes the forecasts under three volume and price assumptions.',
  'Scénarios pessimiste / réaliste / optimiste': 'Pessimistic / realistic / optimistic scenarios',
  'Réaliste': 'Realistic',
  'Optimiste': 'Optimistic',
  'Pessimiste': 'Pessimistic',
  'Résultat net moyen par scénario': 'Average net income per scenario',
  'Résultat net moyen': 'Average net income',
  'Tableau comparatif exportable': 'Exportable comparison table',
  'Scénario': 'Scenario',
  'Suivez l\u2019évolution de votre chiffre d\u2019affaires, de votre EBE et de votre résultat net avec des graphiques clairs, prêts à présenter.':
    'Track your revenue, EBITDA and net income over time with clear, presentation-ready charts.',
  "Suivez l'évolution de votre chiffre d'affaires, de votre EBE et de votre résultat net avec des graphiques clairs, prêts à présenter.":
    'Track your revenue, EBITDA and net income over time with clear, presentation-ready charts.',
  "Renseignez vos hypothèses dans l'onglet « Exploitation » pour afficher les graphiques.":
    'Enter your assumptions in the “Operations” tab to display the charts.',
  'Comparaison CA, résultat net et VAN': 'Revenue, net income and NPV comparison',
  'Prévisions financières': 'Financial forecasts',
  'Défavorable': 'Unfavorable',
  'Favorable': 'Favorable',

  // ---- Module Plan d'action ----
  'Calendrier de mise en œuvre': 'Implementation schedule',
  'Calendrier (Gantt)': 'Schedule (Gantt)',
  'Aucune activité datée. Renseignez des dates de début et de fin pour visualiser le calendrier.':
    'No dated activity. Enter start and end dates to display the schedule.',
  'Nouvelle activité': 'New activity',
  'Ajouter une activité': 'Add an activity',
  'Activité ajoutée': 'Activity added',
  'Activité mise à jour': 'Activity updated',
  "Intitulé de l'activité *": 'Activity title *',
  'Ex. Construction du poulailler': 'e.g. Building the poultry house',
  'Ex. Phase 1 – Montage': 'e.g. Phase 1 – Setup',
  "Aucune activité. Cliquez sur « Ajouter une activité » pour construire votre plan d'action.":
    'No activity. Click “Add an activity” to build your action plan.',
  'éléments': 'items',
  'Ajouter une tâche': 'Add a task',
  'Nouvelle tâche': 'New task',
  'Tâche': 'Task',
  'Tâches': 'Tasks',
  'Avancement du projet': 'Project progress',
  'Phases du projet': 'Project phases',

  // ---- Module Documents ----
  'Sections du dossier': 'Dossier sections',
  'Sélectionnez les sections à inclure. Les données proviennent des modules réellement remplis.':
    'Select the sections to include. Data comes from the modules actually filled in.',
  'Business plan & étude de faisabilité': 'Business plan & feasibility study',
  'Dossier finalisé prêt à imprimer': 'Finished dossier ready to print',
  'Inclure la page de garde': 'Include cover page',
  'Inclure la table des matières': 'Include table of contents',
  'Page de garde & en-têtes': 'Cover page & headers',
  'Page de titre': 'Title page',
  'Titre du dossier': 'Dossier title',
  "Texte d'en-tête (pages intérieures)": 'Header text (inner pages)',
  'Texte de pied de page': 'Footer text',
  'Personnalisez le document avant génération.': 'Customize the document before generation.',
  'Générer & télécharger': 'Generate & download',
  'Génération…': 'Generating…',
  'Document généré ✅': 'Document generated ✅',
  'Échec de génération': 'Generation failed',
  'Génération impossible.': 'Generation failed.',
  'Document indisponible.': 'Document unavailable.',
  'Document supprimé': 'Document deleted',
  'Bibliothèque de documents': 'Document library',
  'Aucun document généré pour ce projet. Lancez une génération ci-dessus.':
    'No document generated for this project yet. Start a generation above.',
  'Tableurs financiers avec formules actives': 'Financial spreadsheets with active formulas',
  'Document éditable structuré': 'Structured editable document',
  'Le fichier .pptx est généré côté serveur à partir de vos données réelles, ajouté à la bibliothèque du projet, puis téléchargé. Il reste entièrement modifiable dans PowerPoint.':
    'The .pptx file is generated server-side from your real data, added to the project library, then downloaded. It remains fully editable in PowerPoint.',
  'Les documents sont générés à partir des données enregistrées. Le classeur Excel conserve des formules actives (VAN, TRI, compte de résultat) recalculables dans Excel.':
    'Documents are generated from saved data. The Excel workbook keeps active formulas (NPV, IRR, income statement) that recalculate in Excel.',
  'Le fichier Excel garde-t-il les formules ?': 'Does the Excel file keep formulas?',
  'Oui : hypothèses, compte de résultat, flux, VAN (=NPV) et TRI (=IRR) sont des formules Excel natives. Modifiez les hypothèses dans les feuilles et tout se recalcule.':
    'Yes: assumptions, income statement, flows, NPV and IRR are native Excel formulas. Edit the assumptions in the sheets and everything recalculates.',
  'Mes données de marché sont-elles fiables ?': 'Are my market data reliable?',
  'Inclus dans le dossier et la présentation générés': 'Included in the generated dossier and presentation',
  'Inclus dans les documents exportés': 'Included in exported documents',
  'Page de garde': 'Cover page',
  'En-tête': 'Header',
  'Pied de page': 'Footer',
  'Taille': 'Size',
  'Date': 'Date',
  'Format': 'Format',
  'Excel (formules actives)': 'Excel (active formulas)',
  'Word (document éditable)': 'Word (editable document)',
  'PowerPoint (présentation)': 'PowerPoint (presentation)',
  'PDF (dossier complet)': 'PDF (complete dossier)',
  'Voir la version imprimable': 'See the printable version',
  'Aperçu': 'Preview',

  // ---- Module Présentation ----
  'Paramètres de la présentation': 'Presentation settings',
  'Plan de la présentation': 'Presentation outline',
  'Plan des diapositives (aperçu)': 'Slide outline (preview)',
  'Nom du présentateur': 'Presenter name',
  'Audience cible': 'Target audience',
  'Audience': 'Audience',
  'Merci de votre attention': 'Thank you for your attention',
  'Générer la présentation': 'Generate presentation',
  'diapositive(s)': 'slide(s)',
  'diapositives seront générées pour l’audience «': 'slides will be generated for audience «',
  "Accent sur l'opportunité de marché, la rentabilité (VAN, TRI) et la vision de croissance.":
    'Focus on the market opportunity, profitability (NPV, IRR) and growth vision.',
  'Accent sur le besoin de financement, les garanties de remboursement (DSCR) et la prudence des hypothèses.':
    'Focus on the financing need, repayment guarantees (DSCR) and conservative assumptions.',
  "Accent sur l'organisation, le plan d'action et les complémentarités à construire.":
    'Focus on the organization, the action plan and the synergies to build.',
  "Accent sur la démarche méthodologique complète, de l'idée aux résultats.":
    'Focus on the complete methodology, from idea to results.',
  'Générer la présentation PowerPoint': 'Generate the PowerPoint presentation',
  'Généré avec GESCOM PROJECT': 'Generated with GESCOM PROJECT',
  'Activités': 'Activities',
  'Écart à financer :': 'Funding gap:',
  'Qté × prix': 'Qty × price',
  'Paramètres généraux': 'General settings',
  "Biens durables nécessaires au démarrage. Les durées d'amortissement alimentent le compte de résultat.":
    'Durable assets needed at startup. Depreciation periods feed the income statement.',
  'Diapositives': 'Slides',
  'onglet Présentation': 'Presentation tab',
  'Thème': 'Theme',
  'Diapositive': 'Slide',
  'Intitulé': 'Title',

  // ---- Divers & erreurs serveur fréquentes ----
  'Projet non trouvé.': 'Project not found.',
  'Projet non trouvé': 'Project not found',
  'Accès refusé : cette section est réservée à l\u2019abonnement Premium.':
    'Access denied: this section is reserved for Premium subscribers.',
  'Accès refusé : cette section est réservée à l\'abonnement Premium.':
    'Access denied: this section is reserved for Premium subscribers.',
  'Réponse inattendue du serveur.': 'Unexpected server response.',
}
