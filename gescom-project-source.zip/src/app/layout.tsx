import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/gescom/ThemeProvider";

export const metadata: Metadata = {
  title: "GESCOM PROJECT — De l'idée au dossier finançable",
  description:
    "Votre idée mérite un grand avenir ! Concevez facilement un Business Plan complet, structuré et professionnel, de l'idée initiale jusqu'aux prévisions financières. Avec Gescom Project, entreprenez avec méthode, confiance et ambition.",
  keywords: ["GESCOM PROJECT", "business plan", "étude de marché", "prévisions financières", "SaaS", "gestion de projet"],
  icons: {
    icon: [{ url: "/favicon.png", type: "image/png" }],
    apple: [{ url: "/logo.png" }],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground font-sans">
        <ThemeProvider>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
