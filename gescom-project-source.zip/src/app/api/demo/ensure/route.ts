import { db } from '@/lib/db'
import { hashPassword, logActivity } from '@/lib/auth'
import {
  DEMO_ADMIN,
  DEMO_ANALYSIS,
  DEMO_DOCPREFS,
  DEMO_FINANCE,
  DEMO_OVERVIEW,
  DEMO_PROJECT,
  DEMO_TASKS,
  DEMO_USER,
} from '@/lib/demo-data'

// Crée de façon idempotente le compte de démonstration et son projet complet.
// Appelé au chargement de l'écran de connexion ; sans effet si déjà présent.
export async function POST() {
  try {
    let demo = await db.user.findUnique({ where: { email: DEMO_USER.email } })
    if (!demo) {
      demo = await db.user.create({
        data: {
          email: DEMO_USER.email,
          passwordHash: hashPassword(DEMO_USER.password),
          firstName: DEMO_USER.firstName,
          lastName: DEMO_USER.lastName,
          phone: DEMO_USER.phone,
          jobTitle: DEMO_USER.jobTitle,
          organization: DEMO_USER.organization,
          prefs: JSON.stringify({
            language: 'fr',
            country: 'Cameroun',
            currency: 'XAF',
            dateFormat: 'DD/MM/YYYY',
            timezone: 'Africa/Douala',
            theme: 'light',
            notifInApp: true,
            notifEmail: false,
            notifDeadlines: true,
          }),
        },
      })
      await createDemoProject(demo.id)
    } else if ((await db.project.count({ where: { userId: demo.id } })) === 0) {
      await createDemoProject(demo.id)
    }

    let admin = await db.user.findUnique({ where: { email: DEMO_ADMIN.email } })
    if (!admin) {
      admin = await db.user.create({
        data: {
          email: DEMO_ADMIN.email,
          passwordHash: hashPassword(DEMO_ADMIN.password),
          firstName: DEMO_ADMIN.firstName,
          lastName: DEMO_ADMIN.lastName,
          role: DEMO_ADMIN.role,
        },
      })
    }

    return Response.json({ ok: true })
  } catch (err) {
    console.error('[demo/ensure]', err)
    return Response.json({ ok: false }, { status: 500 })
  }
}

async function createDemoProject(userId: string) {
  const project = await db.project.create({
    data: {
      userId,
      name: DEMO_PROJECT.name,
      idea: DEMO_PROJECT.idea,
      description: DEMO_PROJECT.description,
      sector: DEMO_PROJECT.sector,
      type: DEMO_PROJECT.type,
      country: DEMO_PROJECT.country,
      region: DEMO_PROJECT.region,
      currency: DEMO_PROJECT.currency,
      status: DEMO_PROJECT.status,
      objectives: JSON.stringify(DEMO_PROJECT.objectives),
      overview: JSON.stringify(DEMO_OVERVIEW),
      analysis: JSON.stringify(DEMO_ANALYSIS),
      finance: JSON.stringify(DEMO_FINANCE),
      docPrefs: JSON.stringify(DEMO_DOCPREFS),
    },
  })
  await db.task.createMany({
    data: DEMO_TASKS.map((t, i) => ({
      projectId: project.id,
      phase: t.phase,
      title: t.title,
      responsible: t.responsible,
      startDate: t.startDate,
      endDate: t.endDate,
      status: t.status,
      progress: t.progress,
      order: i,
    })),
  })
  await logActivity(userId, 'CREATE', `Projet de démonstration créé : ${DEMO_PROJECT.name}`, project.id)
  return project
}
