import { db } from '@/lib/db'
import { withUser, readJson, logActivity } from '@/lib/api-helpers'
import { toSessionUser } from '@/lib/auth'
import { normalizePlan, PLAN_LABELS, isBillingPeriod, computePremiumExpiry } from '@/lib/plans'

// Gestion de l'abonnement du compte connecté.
// POST { plan: 'FREE' | 'PREMIUM', billing?: 'MONTHLY' | 'YEARLY' }
//  • PREMIUM avec billing → activation simulée (démo) d'une durée définie
//  • PREMIUM sans billing → activation illimitée (démo / accord manuel)
//  • FREE → retour au plan gratuit (expiration effacée)
// L'encaissement réel passe par /api/account/plan/checkout (FedaPay).
export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{ plan?: string; billing?: string }>(req)
    const plan = normalizePlan(body.plan)

    let planExpiresAt: Date | null = null
    if (plan === 'PREMIUM' && isBillingPeriod(body.billing)) {
      // Activation simulée : durée limitée, comme un vrai abonnement
      planExpiresAt = computePremiumExpiry(body.billing, user.planExpiresAt)
    }

    const fresh = await db.user.update({
      where: { id: user.id },
      data: { plan, planExpiresAt },
    })
    try {
      await logActivity(user.id, 'ACCOUNT', plan === 'PREMIUM'
        ? planExpiresAt
          ? `Abonnement Premium activé (simulation, valable jusqu'au ${planExpiresAt.toLocaleDateString('fr-FR')}).`
          : 'Abonnement Premium activé (paiement simulé, démo).'
        : 'Abonnement repassé en Gratuit.')
    } catch { /* journalisation best effort */ }
    return Response.json({ user: toSessionUser(fresh), planLabel: PLAN_LABELS[plan] })
  })
}
