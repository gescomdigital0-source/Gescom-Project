import { db } from '@/lib/db'
import { withUser, readJson } from '@/lib/api-helpers'
import { toSessionUser } from '@/lib/auth'
import { isPaymentsConfigured, paymentCurrency } from '@/lib/payments/fedapay'
import { confirmPayment } from '@/lib/payments/activate'
import { PLAN_PRICING } from '@/lib/plans'

// GESCOM PROJECT – Historique des paiements Mobile Money du compte connecté,
// plus état de configuration de l'encaissement (pour afficher le bon bouton).
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const payments = await db.payment.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 15,
      select: {
        id: true,
        reference: true,
        provider: true,
        billing: true,
        amount: true,
        currency: true,
        status: true,
        paidAt: true,
        createdAt: true,
      },
    })
    return Response.json({
      payments: payments.map((p) => ({
        ...p,
        paidAt: p.paidAt ? p.paidAt.toISOString() : null,
        createdAt: p.createdAt.toISOString(),
      })),
      configured: isPaymentsConfigured(),
      currency: paymentCurrency(),
      pricing: {
        MONTHLY: PLAN_PRICING.MONTHLY.amount,
        YEARLY: PLAN_PRICING.YEARLY.amount,
      },
    })
  })
}

// Vérification au retour du navigateur : ?ref=<référence interne>.
// Si le webhook FedaPay n'est pas encore passé, on interroge directement
// FedaPay ; si la transaction est approuvée, l'abonnement est activé ici.
export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{ reference?: string }>(req)
    const reference = typeof body.reference === 'string' ? body.reference.trim() : ''
    if (!reference) {
      return Response.json({ error: 'Référence de paiement manquante.' }, { status: 400 })
    }

    const payment = await db.payment.findFirst({
      where: { userId: user.id, reference },
    })

    // Paiement inconnu ou déjà confirmé : renvoie l'état courant de l'abonnement
    let outcome: string = payment?.status === 'SUCCEEDED' ? 'activated' : payment ? 'pending' : 'unknown'
    if (payment && payment.status !== 'SUCCEEDED' && payment.providerRef) {
      try {
        outcome = await confirmPayment(payment.providerRef)
      } catch (err) {
        console.error('[Paiement] Vérification au retour impossible :', err)
        outcome = 'pending' // l'utilisateur rechargera ; le webhook reste fiable
      }
    }

    const fresh = await db.user.findUniqueOrThrow({ where: { id: user.id } })
    const latest = reference
      ? await db.payment.findUnique({ where: { reference }, select: { status: true, paidAt: true } })
      : null
    return Response.json({
      outcome,
      payment: latest ? { status: latest.status, paidAt: latest.paidAt?.toISOString() ?? null } : null,
      user: toSessionUser(fresh),
    })
  })
}
