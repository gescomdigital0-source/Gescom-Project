import { db } from '@/lib/db'
import { withUser, readJson, badRequest, logActivity } from '@/lib/api-helpers'
import { isBillingPeriod, PLAN_PRICING } from '@/lib/plans'
import { appBaseUrl, createCheckout, isPaymentsConfigured, paymentCurrency } from '@/lib/payments/fedapay'
import { findCountry } from '@/lib/payments-methods'

// GESCOM PROJECT – Démarrage d'un paiement d'abonnement (FedaPay).
// POST { billing, firstName, lastName, email, phone, country, method }
// Le tunnel d'abonnement (CheckoutDialog) collecte les informations du payeur
// et le moyen de paiement : opérateurs Mobile Money du pays choisi, ou carte
// bancaire pour les payeurs en Europe et dans le reste du monde.
// Crée un enregistrement de paiement en attente puis renvoie l'URL de la page
// FedaPay où le paiement est finalisé en toute sécurité.
// Si aucune clé FEDAPAY_SECRET_KEY n'est configurée, renvoie 503 avec le
// message d'aide correspondant (le mode démo simulé reste disponible côté UI).
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{
      billing?: string
      firstName?: string
      lastName?: string
      email?: string
      phone?: string
      country?: string
      method?: string
    }>(req)
    if (!isBillingPeriod(body.billing)) {
      return badRequest('Durée d’abonnement invalide (choisissez Mensuel ou Annuel).')
    }
    const billing = body.billing
    const pricing = PLAN_PRICING[billing]

    // Informations du payeur : saisies dans le tunnel, sinon celles du compte.
    const country = findCountry(String(body.country || ''))
    if (!country) {
      return badRequest('Sélectionnez votre pays pour afficher les moyens de paiement disponibles.')
    }
    const firstName = String(body.firstName || '').trim().slice(0, 80) || user.firstName
    const lastName = String(body.lastName || '').trim().slice(0, 80) || user.lastName
    const email = String(body.email || '').trim().slice(0, 160) || user.email
    if (!EMAIL_RE.test(email)) {
      return badRequest('Adresse e-mail invalide : le reçu et la confirmation y seront envoyés.')
    }
    const phoneRaw = String(body.phone || '').replace(/[^0-9+\s]/g, '').trim()
    const digits = phoneRaw.replace(/[^0-9]/g, '')
    if (digits.length < 8 || digits.length > 15) {
      return badRequest('Numéro de téléphone invalide (8 à 15 chiffres, indicatif compris).')
    }
    // Numéro complet : indicatif du pays + numéro national, sans espaces.
    const phone = phoneRaw.startsWith('+') ? phoneRaw.replace(/\s+/g, '') : `${country.dial === '+' ? '+' : country.dial}${digits}`
    const method = String(body.method || '').trim().slice(0, 40) || 'CARD'
    if (!country.operators.some((o) => o.id === method)) {
      return badRequest('Moyen de paiement indisponible dans le pays sélectionné.')
    }

    if (!isPaymentsConfigured()) {
      return Response.json(
        {
          error: 'L’encaissement n’est pas encore configuré sur le serveur (clé FEDAPAY_SECRET_KEY manquante).',
          configNeeded: true,
        },
        { status: 503 },
      )
    }

    // Référence interne unique du paiement, suivie sur toute la chaîne
    const reference = `GESCOM-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`

    const payment = await db.payment.create({
      data: {
        userId: user.id,
        reference,
        provider: 'FEDAPAY',
        billing,
        amount: pricing.amount,
        currency: paymentCurrency(),
        status: 'PENDING',
        payerName: `${firstName} ${lastName}`.trim(),
        payerEmail: email,
        payerPhone: phone,
        payerCountry: country.code,
        payerMethod: method,
      },
    })

    try {
      const checkout = await createCheckout({
        reference,
        amount: pricing.amount,
        description: `GESCOM PROJECT – Abonnement Premium ${pricing.label} (${pricing.amount} FCFA)`,
        callbackUrl: `${appBaseUrl()}/?payment=return&ref=${reference}`,
        customer: {
          firstName,
          lastName,
          email,
          phone,
          country: country.code,
        },
        billing,
      })

      await db.payment.update({
        where: { id: payment.id },
        data: { providerRef: checkout.providerRef },
      })

      try {
        await logActivity(user.id, 'PAYMENT', `Paiement initié : Premium ${pricing.label} (${pricing.amount} FCFA), ${country.name}, réf. ${reference}.`)
      } catch { /* journalisation best effort */ }

      return Response.json({
        paymentUrl: checkout.paymentUrl,
        reference,
        amount: pricing.amount,
        currency: paymentCurrency(),
      })
    } catch (err) {
      await db.payment.update({
        where: { id: payment.id },
        data: { status: 'FAILED' },
      }).catch(() => null)
      return Response.json(
        { error: err instanceof Error ? err.message : 'Impossible d’initier le paiement. Réessayez.' },
        { status: 502 },
      )
    }
  })
}
