import { db } from '@/lib/db'
import { withUser, readJson, logActivity } from '@/lib/api-helpers'
import { toSessionUser } from '@/lib/auth'

// Mise à jour du profil utilisateur
export async function PATCH(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<Record<string, unknown>>(req)
    const data: Record<string, string> = {}
    for (const k of ['firstName', 'lastName', 'phone', 'jobTitle', 'organization'] as const) {
      if (typeof body[k] === 'string') data[k] = (body[k] as string).trim().slice(0, 200)
    }
    if (data.firstName === '' || data.lastName === '') {
      return Response.json({ error: 'Le prénom et le nom ne peuvent pas être vides.' }, { status: 400 })
    }
    const updated = await db.user.update({ where: { id: user.id }, data })
    await logActivity(user.id, 'UPDATE', 'Profil utilisateur mis à jour')
    return Response.json({ user: toSessionUser(updated) })
  })
}
