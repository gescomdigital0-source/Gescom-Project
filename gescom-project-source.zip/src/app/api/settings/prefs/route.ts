import { db } from '@/lib/db'
import { withUser, readJson } from '@/lib/api-helpers'
import { toSessionUser } from '@/lib/auth'
import type { UserPrefs } from '@/lib/types'

const VALID_PREFS: Record<keyof UserPrefs, 'string' | 'boolean'> = {
  language: 'string',
  country: 'string',
  currency: 'string',
  dateFormat: 'string',
  timezone: 'string',
  theme: 'string',
  notifInApp: 'boolean',
  notifEmail: 'boolean',
  notifDeadlines: 'boolean',
}

// Mise à jour des préférences générales
export async function PATCH(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<Partial<UserPrefs>>(req)
    let prefs: UserPrefs
    try {
      prefs = JSON.parse((await db.user.findUnique({ where: { id: user.id }, select: { prefs: true } }))?.prefs || '{}')
    } catch {
      prefs = {} as UserPrefs
    }
    for (const [k, kind] of Object.entries(VALID_PREFS)) {
      const v = (body as Record<string, unknown>)[k]
      if (typeof v === kind) {
        ;(prefs as Record<string, unknown>)[k] = v
      }
    }
    const updated = await db.user.update({ where: { id: user.id }, data: { prefs: JSON.stringify(prefs) } })
    return Response.json({ user: toSessionUser(updated) })
  })
}
