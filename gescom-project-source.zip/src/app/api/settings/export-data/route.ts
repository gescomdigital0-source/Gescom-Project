import { db } from '@/lib/db'
import { withUser } from '@/lib/api-helpers'

// Export complet des données de l'utilisateur au format JSON (portabilité)
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const projects = await db.project.findMany({
      where: { userId: user.id },
      include: { tasks: { orderBy: { order: 'asc' } }, documents: { select: { id: true, name: true, format: true, createdAt: true } } },
      orderBy: { createdAt: 'asc' },
    })
    const payload = {
      exportedAt: new Date().toISOString(),
      format: 'GESCOM-PROJECT-EXPORT-v1',
      user: {
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        jobTitle: user.jobTitle,
        organization: user.organization,
        role: user.role,
        prefs: user.prefs,
      },
      projects: projects.map((p) => ({
        name: p.name,
        idea: p.idea,
        description: p.description,
        sector: p.sector,
        type: p.type,
        country: p.country,
        region: p.region,
        currency: p.currency,
        status: p.status,
        objectives: JSON.parse(p.objectives || '[]'),
        overview: JSON.parse(p.overview || '{}'),
        analysis: JSON.parse(p.analysis || '{}'),
        finance: JSON.parse(p.finance || '{}'),
        docPrefs: JSON.parse(p.docPrefs || '{}'),
        tasks: p.tasks.map((t) => ({
          phase: t.phase, title: t.title, responsible: t.responsible,
          startDate: t.startDate, endDate: t.endDate, status: t.status, progress: t.progress,
        })),
        documents: p.documents,
        createdAt: p.createdAt,
      })),
      activities: await db.activity.count({ where: { userId: user.id } }),
    }
    const json = JSON.stringify(payload, null, 2)
    return new Response(json, {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="gescom-export-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    })
  })
}
