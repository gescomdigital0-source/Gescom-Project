import { db } from '@/lib/db'
import { withUser, notFound } from '@/lib/api-helpers'

type Params = { params: Promise<{ id: string }> }

// Téléchargement (ou re-téléchargement) d'un document généré
export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const doc = await db.generatedDocument.findUnique({ where: { id }, include: { project: { select: { userId: true, name: true } } } })
    if (!doc || doc.project.userId !== user.id) return notFound('Document introuvable.')
    if (!doc.data) return notFound('Le contenu du document n\'est plus disponible. Régénérez-le.')

    const buf = Buffer.from(doc.data)
    const ext = doc.format.toLowerCase()
    const mimes: Record<string, string> = {
      pdf: 'application/pdf',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    }
    return new Response(new Uint8Array(buf), {
      headers: {
        'Content-Type': mimes[ext] || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(doc.name)}"`,
        'Content-Length': String(buf.length),
      },
    })
  })
}

export async function DELETE(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const doc = await db.generatedDocument.findUnique({ where: { id }, include: { project: { select: { userId: true } } } })
    if (!doc || doc.project.userId !== user.id) return notFound('Document introuvable.')
    await db.generatedDocument.delete({ where: { id } })
    return Response.json({ ok: true })
  })
}
