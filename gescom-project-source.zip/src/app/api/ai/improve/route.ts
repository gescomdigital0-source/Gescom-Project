// GESCOM PROJECT – Générateur intelligent d'amélioration des idées
// POST /api/ai/improve
// Corps : { target: string, value?: unknown, projectId?: string, context?: object }
//  • target   : clé de la rubrique (src/lib/ai-targets.ts) ;
//  • value    : contenu actuel de la rubrique (texte, liste ou objets) ;
//  • projectId: si fourni, le contexte est construit depuis les données réelles
//               du projet (vérification de propriété) ;
//  • context  : sinon, mini-contexte fourni par le client (assistant de création).
import { db } from '@/lib/db'
import { withUser, readJson, notFound, badRequest } from '@/lib/api-helpers'
import { isAiTarget } from '@/lib/ai-targets'
import { isPremium } from '@/lib/plans'
import { buildProjectContext, callAiImprove } from '@/lib/ai'

// Limiteur de charge en mémoire : 25 demandes par utilisateur sur 5 minutes.
// Suffisant pour un usage réel de saisie, dissuasif pour un usage automatisé.
const WINDOW_MS = 5 * 60_000
const MAX_PER_WINDOW = 25
const hits = new Map<string, number[]>()

function rateLimited(userId: string): boolean {
  const now = Date.now()
  const list = (hits.get(userId) || []).filter((t) => now - t < WINDOW_MS)
  if (list.length >= MAX_PER_WINDOW) return true
  list.push(now)
  hits.set(userId, list)
  return false
}

const cutCtx = (s: unknown, n: number): string => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, n)

export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{ target?: string; value?: unknown; projectId?: string; context?: Record<string, unknown> }>(req)
    if (!isAiTarget(body.target || '')) {
      return badRequest('Rubrique à améliorer inconnue.')
    }

    // Assistant IA réservé à l'abonnement Premium (verrou serveur).
    if (!isPremium(user.plan)) {
      return Response.json(
        {
          error: 'L\'assistant IA est réservé à l\'abonnement Premium. Passez à Premium pour analyser et enrichir chaque rubrique de votre business plan.',
          upgrade: true,
        },
        { status: 403 },
      )
    }

    if (rateLimited(user.id)) {
      return Response.json(
        { error: 'Trop de demandes envoyées à l\'assistant IA. Patientez quelques instants avant de réessayer.' },
        { status: 429 },
      )
    }

    let context = ''
    if (body.projectId) {
      const project = await db.project.findUnique({
        where: { id: body.projectId },
        include: { tasks: { orderBy: [{ order: 'asc' }, { createdAt: 'asc' }] } },
      })
      if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')
      context = buildProjectContext(project, project.tasks)
    } else if (body.context && typeof body.context === 'object') {
      // Assistant de création : le projet n'existe pas encore, contexte fourni par le client.
      const c = body.context
      const lines = [
        c.name && `Nom du projet : ${cutCtx(c.name, 140)}`,
        c.idea && `Idée du projet : ${cutCtx(c.idea, 500)}`,
        c.sector && `Secteur d'activité : ${cutCtx(c.sector, 90)}`,
        c.type && `Type de projet : ${cutCtx(c.type, 90)}`,
        c.region && `Région/Ville : ${cutCtx(c.region, 80)}`,
        c.country && `Pays : ${cutCtx(c.country, 60)}`,
        c.currency && `Devise : ${cutCtx(c.currency, 10)}`,
      ].filter(Boolean)
      context = lines.join('\n')
    }

    try {
      const improvement = await callAiImprove({ targetKey: body.target as string, value: body.value, context })
      return Response.json(improvement)
    } catch (err) {
      console.error('[ai-improve] Échec de la génération :', err)
      const timeout = err instanceof Error && err.message === 'timeout'
      return Response.json(
        {
          error: timeout
            ? 'L\'assistant IA met trop de temps à répondre. Réessayez dans quelques instants.'
            : 'L\'assistant IA est momentanément indisponible. Réessayez dans quelques instants.',
        },
        { status: 502 },
      )
    }
  })
}
