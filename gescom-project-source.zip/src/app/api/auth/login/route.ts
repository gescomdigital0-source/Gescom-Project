import { db } from '@/lib/db'
import {
  createSession,
  verifyPassword,
  sessionCookieOptions,
  toSessionUser,
  logActivity,
} from '@/lib/auth'
import { readJson, badRequest } from '@/lib/api-helpers'
import { issueCode } from '@/lib/verification'
import { sendVerificationEmail } from '@/lib/mailer'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await readJson<{ email?: string; password?: string }>(req)
    const email = (body.email || '').trim().toLowerCase()
    const password = body.password || ''
    const ua = req.headers.get('user-agent') || ''

    const user = await db.user.findUnique({ where: { email } })
    if (!user || !verifyPassword(password, user.passwordHash)) {
      await db.loginEvent.create({ data: { email, success: false, userAgent: ua.slice(0, 200) } })
      return badRequest('E-mail ou mot de passe incorrect.')
    }

    // Compte jamais vérifié : la connexion est bloquée et un nouveau code
    // est envoyé (si le délai anti-spam le permet), afin de ramener
    // l'utilisateur vers l'écran de vérification sans impasse.
    if (!user.emailVerified) {
      const issued = await issueCode(email, 'SIGNUP')
      let devCode: string | undefined
      let delivered = false
      if (issued.ok) {
        const mail = await sendVerificationEmail(email, issued.code, issued.minutes)
        delivered = mail.delivered
        devCode = mail.delivered ? undefined : issued.code
      }
      return Response.json(
        {
          error: issued.ok
            ? 'Votre compte n\'est pas encore vérifié : un nouveau code à 6 chiffres vient de vous être envoyé par e-mail.'
            : 'Votre compte n\'est pas encore vérifié. Consultez votre boîte mail ou demandez un nouveau code.',
          needsVerification: true,
          email,
          delivered,
          devCode,
        },
        { status: 403 },
      )
    }

    const { token, expiresAt } = await createSession(user.id, ua)
    await db.loginEvent.create({ data: { email, success: true, userAgent: ua.slice(0, 200), userId: user.id } })
    await logActivity(user.id, 'AUTH', `Connexion de ${user.firstName} ${user.lastName}`)

    const res = NextResponse.json({ user: toSessionUser(user), token })
    res.cookies.set('gescom_session', token, sessionCookieOptions(expiresAt))
    return res
  } catch (err) {
    console.error('[login]', err)
    return Response.json({ error: 'Connexion impossible. Réessayez.' }, { status: 500 })
  }
}
