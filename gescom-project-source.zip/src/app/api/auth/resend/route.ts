// GESCOM PROJECT – Renvoi d'un code de vérification e-mail
//
// Génère un nouveau code à 6 chiffres et le renvoie par e-mail :
//  • purpose = SIGNUP (par défaut)  → activation du compte à l'inscription ;
//  • purpose = PASSWORD_RESET       → réinitialisation du mot de passe oublié.
// Un délai anti-spam de 60 secondes est appliqué entre deux envois (429).
import { db } from '@/lib/db'
import { isValidEmail } from '@/lib/auth'
import { readJson, badRequest } from '@/lib/api-helpers'
import { issueCode, type CodePurpose } from '@/lib/verification'
import { sendVerificationEmail, MAIL_FAILURE_MESSAGE } from '@/lib/mailer'

export async function POST(req: Request) {
  try {
    const body = await readJson<{ email?: string; purpose?: string }>(req)
    const email = (body.email || '').trim().toLowerCase()
    const purpose: CodePurpose = body.purpose === 'PASSWORD_RESET' ? 'PASSWORD_RESET' : 'SIGNUP'

    if (!isValidEmail(email)) return badRequest('Adresse e-mail invalide.')

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return badRequest('Aucun compte n\'existe avec cette adresse e-mail.')

    if (purpose === 'SIGNUP' && user.emailVerified) {
      return badRequest('Ce compte est déjà vérifié : vous pouvez vous connecter directement.')
    }

    const issued = await issueCode(email, purpose)
    if (!issued.ok) {
      return Response.json(
        { error: issued.error, retryAfterSeconds: issued.retryAfterSeconds },
        { status: 429 },
      )
    }
    const mail = await sendVerificationEmail(email, issued.code, issued.minutes, purpose)
    if (mail.reason === 'SMTP_ERREUR') {
      return Response.json({ error: MAIL_FAILURE_MESSAGE }, { status: 502 })
    }

    return Response.json({
      ok: true,
      delivered: mail.delivered,
      message: mail.delivered
        ? `Nouveau code envoyé à ${email}. Il est valable ${issued.minutes} minutes.`
        : 'Nouveau code généré (mode démonstration : SMTP non configuré).',
      devCode: mail.reason === 'SMTP_NON_CONFIGURE' ? issued.code : undefined,
      retryAfterSeconds: 60,
    })
  } catch (err) {
    console.error('[resend]', err)
    return Response.json({ error: 'Renvoi impossible. Réessayez.' }, { status: 500 })
  }
}
