import { withUser } from '@/lib/api-helpers'
import { db } from '@/lib/db'
import { toSessionUser, extractToken } from '@/lib/auth'

export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const fresh = await db.user.findUnique({ where: { id: user.id } })
    if (!fresh) return Response.json({ user: null }, { status: 401 })
    // Renvoie aussi le token pour que le client puisse le mémoriser
    // (utile quand les cookies sont bloqués, ex. aperçu en iframe)
    return Response.json({ user: toSessionUser(fresh), token: extractToken(req) })
  })
}
