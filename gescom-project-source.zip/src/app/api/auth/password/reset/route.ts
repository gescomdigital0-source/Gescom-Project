// GESCOM PROJECT – Mot de passe oublié (étape 2 : code + nouveau mot de passe)
//
// Vérifie le code à 6 chiffres (usage PASSWORD_RESET), met à jour le mot de
// passe et révoque toutes les sessions existantes du compte : si quelqu'un
// était connecté avec l'ancien mot de passe, il est déconnecté partout.
import { db } from '@/lib/db'
import { hashPassword, isValidEmail, passwordIssue, logActivity } from '@/lib/auth'
import { readJson, badRequest } from '@/lib/api-helpers'
import { checkCode } from '@/lib/verification'

export async function POST(req: Request) {
  try {
    const body = await readJson<{ email?: string; code?: string; password?: string }>(req)
    const email = (body.email || '').trim().toLowerCase()
    const code = (body.code || '').replace(/\D/g, '') // chiffres uniquement
    const password = body.password || ''

    if (!isValidEmail(email)) return badRequest('Adresse e-mail invalide.')
    if (code.length !== 6) return badRequest('Veuillez saisir le code à 6 chiffres reçu par e-mail.')
    const issue = passwordIssue(password)
    if (issue) return badRequest(issue)

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return badRequest('Aucun compte n\'existe avec cette adresse e-mail.')

    const result = await checkCode(email, 'PASSWORD_RESET', code)
    if (!result.ok) return badRequest(result.error)

    await db.user.update({ where: { id: user.id }, data: { passwordHash: hashPassword(password) } })
    // Sécurité : déconnecter toutes les sessions ouvertes avec l'ancien mot de passe.
    await db.session.deleteMany({ where: { userId: user.id } })
    await logActivity(user.id, 'AUTH', 'Mot de passe réinitialisé via le code e-mail (toutes les sessions révoquées)')

    return Response.json({ ok: true, message: 'Mot de passe réinitialisé. Vous pouvez vous connecter avec votre nouveau mot de passe.' })
  } catch (err) {
    console.error('[password/reset]', err)
    return Response.json({ error: 'Réinitialisation impossible. Réessayez.' }, { status: 500 })
  }
}
