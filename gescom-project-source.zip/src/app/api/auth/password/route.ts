import { db } from '@/lib/db'
import { hashPassword, verifyPassword } from '@/lib/auth'
import { readJson, badRequest, withUser, logActivity } from '@/lib/api-helpers'

export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{ currentPassword?: string; newPassword?: string }>(req)
    const current = body.currentPassword || ''
    const next = body.newPassword || ''

    const dbUser = await db.user.findUnique({ where: { id: user.id } })
    if (!dbUser) return badRequest('Utilisateur introuvable.')
    if (!verifyPassword(current, dbUser.passwordHash)) {
      return badRequest('Le mot de passe actuel est incorrect.')
    }
    if (next.length < 8 || !/[a-zA-Z]/.test(next) || !/[0-9]/.test(next)) {
      return badRequest('Le nouveau mot de passe doit contenir au moins 8 caractères, une lettre et un chiffre.')
    }
    if (verifyPassword(next, dbUser.passwordHash)) {
      return badRequest('Le nouveau mot de passe doit être différent de l\'actuel.')
    }

    await db.user.update({ where: { id: user.id }, data: { passwordHash: hashPassword(next) } })
    // Sécurité : révoquer toutes les autres sessions
    await db.session.deleteMany({ where: { userId: user.id, NOT: { token: '' } } })
    await logActivity(user.id, 'AUTH', 'Changement de mot de passe (toutes les sessions révoquées)')
    return Response.json({ ok: true, message: 'Mot de passe modifié. Veuillez vous reconnecter.' })
  })
}
