// GESCOM PROJECT – Mot de passe oublié (étape 1 : envoi du code de réinitialisation)
//
// Un code à 6 chiffres est envoyé à l'adresse indiquée SI un compte vérifié
// existe. La réponse reste volontairement identique que le compte existe ou
// non, afin de ne pas révéler quelles adresses sont inscrites (anti-énumération).
// Le code n'est exposé dans la réponse que pour le mode démonstration
// (SMTP non configuré), afin que le parcours reste testable.
import { db } from '@/lib/db'
import { isValidEmail } from '@/lib/auth'
import { readJson } from '@/lib/api-helpers'
import { issueCode } from '@/lib/verification'
import { sendVerificationEmail, MAIL_FAILURE_MESSAGE } from '@/lib/mailer'

const GENERIC_MESSAGE =
  'Si un compte existe avec cette adresse, un code à 6 chiffres vient d\'être envoyé. Vérifiez votre boîte mail.'

export async function POST(req: Request) {
  try {
    const body = await readJson<{ email?: string }>(req)
    const email = (body.email || '').trim().toLowerCase()

    if (!isValidEmail(email)) {
      return Response.json({ ok: true, message: 'Adresse e-mail invalide.', invalid: true }, { status: 400 })
    }

    const user = await db.user.findUnique({ where: { email } })

    // Adresse inconnue ou compte jamais vérifié : même réponse générique,
    // sauf pour le compte non vérifié que l'on oriente vers l'activation.
    if (!user) {
      return Response.json({ ok: true, message: GENERIC_MESSAGE, delivered: true })
    }

    if (!user.emailVerified) {
      const issued = await issueCode(email, 'SIGNUP')
      const mail = issued.ok ? await sendVerificationEmail(email, issued.code, issued.minutes) : null
      if (mail?.reason === 'SMTP_ERREUR') {
        return Response.json({ error: MAIL_FAILURE_MESSAGE }, { status: 502 })
      }
      return Response.json({
        ok: true,
        needsVerification: true,
        email,
        delivered: mail ? mail.delivered : false,
        message: 'Ce compte n\'est pas encore activé : un code d\'activation vient de vous être envoyé.',
        devCode: mail && mail.reason === 'SMTP_NON_CONFIGURE' && issued.ok ? issued.code : undefined,
      })
    }

    const issued = await issueCode(email, 'PASSWORD_RESET')
    if (!issued.ok) {
      return Response.json(
        { error: issued.error, retryAfterSeconds: issued.retryAfterSeconds },
        { status: 429 },
      )
    }
    const mail = await sendVerificationEmail(email, issued.code, issued.minutes)
    if (mail.reason === 'SMTP_ERREUR') {
      return Response.json({ error: MAIL_FAILURE_MESSAGE }, { status: 502 })
    }

    return Response.json({
      ok: true,
      email,
      delivered: mail.delivered,
      message: GENERIC_MESSAGE,
      devCode: mail.reason === 'SMTP_NON_CONFIGURE' ? issued.code : undefined,
    })
  } catch (err) {
    console.error('[password/forgot]', err)
    return Response.json({ error: 'Demande impossible. Réessayez.' }, { status: 500 })
  }
}
