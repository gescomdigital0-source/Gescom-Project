// GESCOM PROJECT – Activation du compte (étape 2 : vérification du code e-mail)
//
// Vérifie le code à 6 chiffres saisi par l'utilisateur. En cas de succès :
//  • le compte est marqué « e-mail vérifié » (et devient actif) ;
//  • une session est ouverte immédiatement (cookie + Bearer), comme après une
//    connexion classique : l'utilisateur arrive directement sur son espace.
import { db } from '@/lib/db'
import {
  createSession,
  sessionCookieOptions,
  toSessionUser,
  logActivity,
  isValidEmail,
} from '@/lib/auth'
import { readJson, badRequest } from '@/lib/api-helpers'
import { checkCode } from '@/lib/verification'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await readJson<{ email?: string; code?: string }>(req)
    const email = (body.email || '').trim().toLowerCase()
    const code = (body.code || '').replace(/\D/g, '') // chiffres uniquement

    if (!isValidEmail(email)) return badRequest('Adresse e-mail invalide.')
    if (code.length !== 6) return badRequest('Veuillez saisir le code à 6 chiffres reçu par e-mail.')

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return badRequest('Aucun compte n\'existe avec cette adresse e-mail.')

    const result = await checkCode(email, 'SIGNUP', code)
    if (!result.ok) return badRequest(result.error)

    if (!user.emailVerified) {
      await db.user.update({ where: { id: user.id }, data: { emailVerified: true } })
      await logActivity(user.id, 'AUTH', `Adresse e-mail vérifiée – compte activé pour ${user.firstName} ${user.lastName}`)
    }

    const fresh = await db.user.findUnique({ where: { id: user.id } })
    if (!fresh) return badRequest('Compte introuvable.')

    const ua = req.headers.get('user-agent') || ''
    const { token, expiresAt } = await createSession(fresh.id, ua)

    const res = NextResponse.json({ user: toSessionUser(fresh), token })
    res.cookies.set('gescom_session', token, sessionCookieOptions(expiresAt))
    return res
  } catch (err) {
    console.error('[verify]', err)
    return Response.json({ error: 'Vérification impossible. Réessayez.' }, { status: 500 })
  }
}
