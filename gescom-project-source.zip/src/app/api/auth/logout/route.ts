import { db } from '@/lib/db'
import { extractToken } from '@/lib/auth'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  // Le token peut arriver via l'en-tête Authorization (client à token) ou le cookie.
  const token = extractToken(req)
  if (token) {
    await db.session.deleteMany({ where: { token } })
  }
  const res = NextResponse.json({ ok: true })
  res.cookies.set('gescom_session', '', { httpOnly: true, path: '/', maxAge: 0 })
  return res
}
