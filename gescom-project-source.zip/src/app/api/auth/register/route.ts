// GESCOM PROJECT – Création de compte (étape 1 : inscription)
//
// Le compte est créé mais reste INACTIF tant que son propriétaire n'a pas
// confirmé son adresse e-mail avec le code à 6 chiffres qui lui est envoyé.
// Aucune session n'est ouverte ici : la connexion n'est possible qu'après
// vérification (POST /api/auth/verify).
import { db } from '@/lib/db'
import {
  hashPassword,
  isValidEmail,
  passwordIssue,
  verifyPassword,
  logActivity,
} from '@/lib/auth'
import { readJson, badRequest } from '@/lib/api-helpers'
import { issueCode } from '@/lib/verification'
import { sendVerificationEmail, MAIL_FAILURE_MESSAGE } from '@/lib/mailer'

interface Body {
  email?: string
  password?: string
  firstName?: string
  lastName?: string
  phone?: string
  organization?: string
  jobTitle?: string
}

export async function POST(req: Request) {
  try {
    const body = await readJson<Body>(req)
    const email = (body.email || '').trim().toLowerCase()
    const password = body.password || ''
    const firstName = (body.firstName || '').trim()
    const lastName = (body.lastName || '').trim()

    if (!isValidEmail(email)) return badRequest('Adresse e-mail invalide.')
    const issue = passwordIssue(password)
    if (issue) return badRequest(issue)
    if (!firstName || !lastName) return badRequest('Veuillez renseigner votre prénom et votre nom.')

    const existing = await db.user.findUnique({ where: { email } })

    // Compte déjà vérifié : pas de nouvelle inscription possible, mais on
    // guide l'utilisateur vers la connexion ou la réinitialisation du mot
    // de passe (c'est le blocage le plus fréquent à la « création de compte »).
    if (existing && existing.emailVerified) {
      return Response.json(
        {
          error:
            'Un compte existe déjà avec cette adresse e-mail. Connectez-vous avec votre mot de passe, ou réinitialisez-le via « Mot de passe oublié ? » si vous ne le retrouvez plus.',
          accountExists: true,
        },
        { status: 400 },
      )
    }

    // Compte existant mais jamais vérifié : on renvoie simplement un code
    // (le mot de passe saisi doit correspondre, pour éviter les détournements).
    if (existing) {
      if (!verifyPassword(password, existing.passwordHash)) {
        return badRequest('Un compte non vérifié existe déjà avec cette adresse : connectez-vous avec le mot de passe choisi à l\'inscription.')
      }
      const issued = await issueCode(email, 'SIGNUP')
      if (!issued.ok) return badRequest(issued.error)
      const mail = await sendVerificationEmail(email, issued.code, issued.minutes)
      if (mail.reason === 'SMTP_ERREUR') {
        return Response.json({ error: MAIL_FAILURE_MESSAGE }, { status: 502 })
      }
      return Response.json({
        needsVerification: true,
        email,
        delivered: mail.delivered,
        message: `Un compte non vérifié existait déjà : un nouveau code vient d'être envoyé à ${email}.`,
        devCode: mail.reason === 'SMTP_NON_CONFIGURE' ? issued.code : undefined,
      })
    }

    const user = await db.user.create({
      data: {
        email,
        passwordHash: hashPassword(password),
        firstName,
        lastName,
        phone: (body.phone || '').trim(),
        organization: (body.organization || '').trim(),
        jobTitle: (body.jobTitle || '').trim(),
        emailVerified: false,
        prefs: JSON.stringify({
          language: 'fr',
          country: 'Cameroun',
          currency: 'XAF',
          dateFormat: 'DD/MM/YYYY',
          timezone: 'Africa/Douala',
          theme: 'light',
          notifInApp: true,
          notifEmail: false,
          notifDeadlines: true,
        }),
      },
    })

    // Génération et envoi du code à 6 chiffres.
    const issued = await issueCode(email, 'SIGNUP')
    if (!issued.ok) {
      await db.user.delete({ where: { id: user.id } }).catch(() => null)
      return badRequest(issued.error)
    }
    const mail = await sendVerificationEmail(email, issued.code, issued.minutes)
    if (mail.reason === 'SMTP_ERREUR') {
      return Response.json({ error: MAIL_FAILURE_MESSAGE }, { status: 502 })
    }

    await logActivity(user.id, 'AUTH', `Inscription de ${firstName} ${lastName} – en attente de vérification de l'adresse e-mail`)

    return Response.json({
      needsVerification: true,
      email,
      delivered: mail.delivered,
      message: `Compte créé : un code à 6 chiffres a été envoyé à ${email}. Il est valable ${issued.minutes} minutes.`,
      // Mode démonstration (SMTP non configuré) : le code est renvoyé pour
      // permettre de terminer le parcours. Il disparaît dès qu'un serveur
      // SMTP est configuré.
      devCode: mail.reason === 'SMTP_NON_CONFIGURE' ? issued.code : undefined,
    })
  } catch (err) {
    console.error('[register]', err)
    return Response.json({ error: 'Impossible de créer le compte. Réessayez.' }, { status: 500 })
  }
}
