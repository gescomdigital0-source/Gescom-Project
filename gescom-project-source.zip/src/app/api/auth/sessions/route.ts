import { db } from '@/lib/db'
import { readJson, withUser } from '@/lib/api-helpers'

// Liste des sessions actives + historique des connexions
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const sessions = await db.session.findMany({
      where: { userId: user.id, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
      select: { id: true, userAgent: true, createdAt: true, expiresAt: true, token: true },
    })
    const cookieHeader = req.headers.get('cookie') || ''
    const currentToken =
      cookieHeader
        .split(';')
        .map((c) => c.trim())
        .find((c) => c.startsWith('gescom_session='))
        ?.slice('gescom_session='.length) || ''
    const logins = await db.loginEvent.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: { id: true, email: true, success: true, createdAt: true, userAgent: true },
    })
    return Response.json({
      sessions: sessions.map((s) => ({ ...s, current: s.token === currentToken, token: undefined })),
      logins,
    })
  })
}

// Révoquer une session (id) ou toutes les autres
export async function DELETE(req: Request) {
  return withUser(req, async (user) => {
    const { id, others } = await readJson<{ id?: string; others?: boolean }>(req)
    if (others) {
      const cookieHeader = req.headers.get('cookie') || ''
      const currentToken =
        cookieHeader
          .split(';')
          .map((c) => c.trim())
          .find((c) => c.startsWith('gescom_session='))
          ?.slice('gescom_session='.length) || ''
      await db.session.deleteMany({ where: { userId: user.id, NOT: { token: currentToken } } })
      return Response.json({ ok: true, message: 'Toutes les autres sessions ont été révoquées.' })
    }
    if (id) {
      const session = await db.session.findUnique({ where: { id } })
      if (!session || session.userId !== user.id) {
        return Response.json({ error: 'Session introuvable.' }, { status: 404 })
      }
      await db.session.delete({ where: { id } })
      return Response.json({ ok: true, message: 'Session révoquée.' })
    }
    return Response.json({ error: 'Requête invalide.' }, { status: 400 })
  })
}
