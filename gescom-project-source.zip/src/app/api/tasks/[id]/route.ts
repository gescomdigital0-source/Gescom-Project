import { db } from '@/lib/db'
import { withUser, readJson, notFound } from '@/lib/api-helpers'

type Params = { params: Promise<{ id: string }> }

async function ownedTask(id: string, userId: string) {
  const task = await db.task.findUnique({ where: { id }, include: { project: { select: { userId: true } } } })
  if (!task || task.project.userId !== userId) return null
  return task
}

export async function PATCH(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const task = await ownedTask(id, user.id)
    if (!task) return notFound('Tâche introuvable.')

    const body = await readJson<Record<string, unknown>>(req)
    const data: Record<string, string | number> = {}
    for (const k of ['phase', 'title', 'responsible', 'startDate', 'endDate', 'status'] as const) {
      if (typeof body[k] === 'string') data[k] = body[k] as string
    }
    if (typeof body.progress === 'number') {
      data.progress = Math.min(100, Math.max(0, body.progress))
    }
    const updated = await db.task.update({ where: { id }, data })
    return Response.json({ task: updated })
  })
}

export async function DELETE(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const task = await ownedTask(id, user.id)
    if (!task) return notFound('Tâche introuvable.')
    await db.task.delete({ where: { id } })
    return Response.json({ ok: true })
  })
}
