import crypto from 'crypto'
import { confirmPayment } from '@/lib/payments/activate'

// GESCOM PROJECT – Webhook FedaPay : confirmation des paiements Mobile Money.
//
// FedaPay poste ici les événements { name: 'transaction.approved' | …, data }.
// Sécurité : on ne fait JAMAIS confiance au corps du message. L'identifiant de
// transaction est re-vérifié par un appel API authentifié (source de vérité) :
// seul FedaPay, en possession du statut réel, peut déclencher l'activation.
// Optionnel : FEDAPAY_WEBHOOK_SECRET vérifie l'en-tête X-FEDAPAY-SIGNATURE
// (HMAC SHA-256, format FedaPay/Stripe : t=horodatage,s=signature).
//
// Le webhook se configure dans le tableau de bord FedaPay :
//   URL       : https://<votre-domaine>/api/payments/webhook
//   Événement : transaction.approved (et transaction.declined / canceled)

function verifySignature(payload: string, header: string | null): boolean {
  const secret = process.env.FEDAPAY_WEBHOOK_SECRET
  if (!secret) return true // pas de secret configuré → la re-vérification API protège
  if (!header) return false
  const parts = Object.fromEntries(
    header.split(',').map((p) => p.split('=').map((s) => s.trim()) as [string, string]),
  )
  const timestamp = parts.t
  const signatures = [parts.s, parts.v1, parts.signature].filter(Boolean) as string[]
  if (!signatures.length) return false
  const candidates = [
    timestamp ? `${timestamp}.${payload}` : payload, // format FedaPay/Stripe
    payload, // signature du corps brut
  ]
  return signatures.some((sig) =>
    candidates.some((c) => {
      const h = crypto.createHmac('sha256', secret).update(c).digest('hex')
      try {
        return crypto.timingSafeEqual(Buffer.from(h), Buffer.from(sig))
      } catch {
        return false
      }
    }),
  )
}

interface FedaPayEvent {
  name?: string
  data?: { id?: number | string; status?: string }
}

export async function POST(req: Request) {
  try {
    const payload = await req.text()
    if (!verifySignature(payload, req.headers.get('x-fedapay-signature'))) {
      return Response.json({ error: 'Signature webhook invalide.' }, { status: 401 })
    }

    let event: FedaPayEvent
    try {
      event = JSON.parse(payload) as FedaPayEvent
    } catch {
      return Response.json({ error: 'Corps webhook illisible.' }, { status: 400 })
    }

    const providerRef = event.data?.id != null ? String(event.data.id) : null
    if (!providerRef) {
      // Événement sans transaction identifiée : acquitté sans traitement
      return Response.json({ received: true, ignored: true })
    }

    const outcome = await confirmPayment(providerRef)

    // 200 dans tous les cas identifiables : FedaPay n'insiste pas inutilement ;
    // seule une erreur technique (exception) renvoie 500 et déclenche un nouvel essai.
    return Response.json({ received: true, outcome })
  } catch (err) {
    console.error('[Webhook FedaPay] Erreur :', err)
    return Response.json({ error: 'Erreur interne du webhook.' }, { status: 500 })
  }
}
