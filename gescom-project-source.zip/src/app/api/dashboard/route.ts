import { db } from '@/lib/db'
import { withUser } from '@/lib/api-helpers'
import { computeProjectProgress } from '@/lib/finance'

// Statistiques du tableau de bord
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const projects = await db.project.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: 'desc' },
      include: { _count: { select: { tasks: true, documents: true } } },
    })

    const active = projects.filter((p) => p.status !== 'ARCHIVED')
    const stats = {
      total: projects.length,
      ongoing: active.filter((p) => p.status === 'ONGOING').length,
      completed: active.filter((p) => p.status === 'COMPLETED').length,
      drafts: active.filter((p) => p.status === 'DRAFT').length,
      archived: projects.length - active.length,
    }

    const withProgress = projects.map((p) => ({
      id: p.id,
      name: p.name,
      status: p.status,
      sector: p.sector,
      currency: p.currency,
      updatedAt: p.updatedAt,
      progress: computeProjectProgress({
        idea: p.idea,
        description: p.description,
        overview: p.overview,
        analysis: p.analysis,
        finance: p.finance,
        objectives: p.objectives,
        tasksCount: p._count.tasks,
        docsCount: p._count.documents,
      }),
    }))

    const activities = await db.activity.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 12,
      include: { project: { select: { name: true } } },
    })

    // Alertes du plan d'action : tâches en retard (date de fin dépassée, non terminées)
    const today = new Date().toISOString().slice(0, 10)
    const overdueTasks = await db.task.findMany({
      where: {
        project: { userId: user.id },
        status: { in: ['TODO', 'IN_PROGRESS', 'BLOCKED'] },
        endDate: { not: '', lt: today },
      },
      take: 8,
      orderBy: { endDate: 'asc' },
      include: { project: { select: { id: true, name: true } } },
    })

    const bySector: Record<string, number> = {}
    for (const p of projects) {
      const s = p.sector || 'Non catégorisé'
      bySector[s] = (bySector[s] || 0) + 1
    }

    return Response.json({
      stats,
      recentProjects: withProgress.slice(0, 6),
      bySector,
      activities: activities.map((a) => ({
        id: a.id,
        type: a.type,
        message: a.message,
        createdAt: a.createdAt,
        projectName: a.project?.name ?? null,
      })),
      overdueTasks: overdueTasks.map((t) => ({
        id: t.id,
        title: t.title,
        endDate: t.endDate,
        projectId: t.project.id,
        projectName: t.project.name,
        status: t.status,
      })),
    })
  })
}
