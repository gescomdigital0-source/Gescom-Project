import { db } from '@/lib/db'
import { withUser, readJson, notFound, logActivity } from '@/lib/api-helpers'
import { buildDossier, buildDiagnosticDossier } from '@/lib/exports/content'
import { generatePdf } from '@/lib/exports/pdf'
import { generateDocx } from '@/lib/exports/docx'
import { generateXlsx } from '@/lib/exports/xlsx'
import { generatePptx } from '@/lib/exports/pptx'
import { PRESENTATION_THEMES } from '@/lib/constants'
import { isPremium } from '@/lib/plans'
import { validateProject } from '@/lib/validation'
import { applyAutoStatus } from '@/lib/validation-auto'
import { slugify } from '@/lib/format'
import { toNodeBuffer } from '@/lib/exports/images'
import sharp from 'sharp'

type Params = { params: Promise<{ id: string }> }

const FORMATS = ['PDF', 'DOCX', 'XLSX', 'PPTX', 'DIAGNOSTIC'] as const
type Format = (typeof FORMATS)[number]

interface Body {
  format?: string
  sections?: string[]
  audience?: 'INVESTOR' | 'BANK' | 'PARTNER' | 'ACADEMIC'
  theme?: string
}

// Génère un document réel (PDF, DOCX, XLSX, PPTX) à partir des données
// enregistrées du projet, le stocke dans la bibliothèque et le renvoie.
export async function POST(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, include: { tasks: { orderBy: [{ order: 'asc' }, { createdAt: 'asc' }] } } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const body = await readJson<Body>(req)
    const format = (body.format || 'PDF').toUpperCase() as Format
    if (!FORMATS.includes(format)) {
      return Response.json({ error: 'Format non pris en charge. Formats disponibles : PDF, DOCX, XLSX, PPTX, DIAGNOSTIC.' }, { status: 400 })
    }
    // Plan d'abonnement : le plan Gratuit produit des documents allégés
    // (sans risques, financement, ventes, compte de résultat, indicateurs).
    const premium = isPremium(user.plan)

    // Identité visuelle du projet : logo (présentation) + image d'illustration
    // (fond de couverture). Une image illisible ne bloque jamais la génération.
    const { logo, cover } = await loadProjectImages(project.id)

    // ------------------------------------------------------------------
    // Validation obligatoire avant impression du dossier définitif.
    // Le rapport de diagnostic, lui, reste imprimable à tout moment.
    // ------------------------------------------------------------------
    if (format === 'PDF' || format === 'DOCX') {
      const report = validateProject({
        name: project.name,
        currency: project.currency || 'XAF',
        overview: project.overview,
        objectives: project.objectives,
        analysis: project.analysis,
        finance: project.finance,
        tasksCount: project.tasks.length,
        premium,
      })
      if (!report.canExport) {
        return Response.json(
          {
            error:
              report.status === 'INCOMPLET'
                ? 'Impression bloquée : des informations essentielles sont manquantes. Complétez le projet puis relancez la validation.'
                : report.status === 'NON_RENTABLE'
                  ? 'Impression bloquée : le projet n\'est pas financièrement rentable (VAN, TRI, IP défavorables). Consultez le rapport de diagnostic.'
                  : 'Impression bloquée : le projet n\'est pas encore validé. Corrigez les anomalies détectées puis relancez la validation.',
            validation: report,
          },
          { status: 403 },
        )
      }
      // Projet validé (zéro anomalie) : confirmation automatique du statut
      // « Terminé ». La fonction gère aussi la rétrogradation si des
      // anomalies réapparaissent sur un projet déjà terminé.
      await applyAutoStatus(user.id, id, project.status, report)
    }

    let buffer: Buffer
    let filename: string
    const dateTag = new Date().toISOString().slice(0, 10)
    const slug = slugify(project.name)

    try {
      if (format === 'DIAGNOSTIC') {
        // Rapport de diagnostic & de validation : imprimable même sans validation
        // (cahier des charges §7), pour travailler avec la liste des corrections.
        const report = validateProject({
          name: project.name,
          currency: project.currency || 'XAF',
          overview: project.overview,
          objectives: project.objectives,
          analysis: project.analysis,
          finance: project.finance,
          tasksCount: project.tasks.length,
          premium,
        })
        const dossier = buildDiagnosticDossier(report, project)
        // La règle de statut automatique s'applique aussi ici : un projet
        // « Terminé » qui présenterait une anomalie repasse « En cours ».
        await applyAutoStatus(user.id, id, project.status, report)
        buffer = await generatePdf(dossier, {
          footerText: 'Rapport de diagnostic — GESCOM PROJECT',
          headerText: `Diagnostic de validation — ${project.name}`,
          includeCover: true,
          includeToc: false,
          coverImage: cover?.data,
        })
        filename = `diagnostic-${slug}-${dateTag}.pdf`
      } else if (format === 'XLSX') {
        buffer = await generateXlsx(project, project.tasks, { premium })
        filename = `etude-financiere-${slug}-${dateTag}.xlsx`
      } else if (format === 'PPTX') {
        const audience = body.audience || 'INVESTOR'
        const themeDef = PRESENTATION_THEMES.find((t) => t.value === body.theme) || PRESENTATION_THEMES[0]
        const dossier = buildDossier({ project, tasks: project.tasks, premium })
        buffer = await generatePptx(dossier, {
          audience,
          themePrimary: themeDef.primary,
          themeAccent: themeDef.accent,
          author: dossier.author,
          organization: dossier.organization,
          logo,
        })
        filename = `presentation-${slug}-${dateTag}.pptx`
      } else {
        const docPrefs = safeParseDocPrefs(project.docPrefs)
        const dossier = buildDossier({ project, tasks: project.tasks, premium }, body.sections)
        if (format === 'PDF') {
          buffer = await generatePdf(dossier, {
            footerText: docPrefs.footerText || 'Généré avec GESCOM PROJECT',
            headerText: docPrefs.headerText || project.name,
            includeCover: docPrefs.includeCover !== false,
            includeToc: docPrefs.includeToc !== false,
            coverImage: cover?.data,
          })
          filename = `dossier-${slug}-${dateTag}.pdf`
        } else {
          buffer = await generateDocx(dossier, {
            headerText: docPrefs.headerText || project.name,
            footerText: docPrefs.footerText || 'Généré avec GESCOM PROJECT',
            coverImage: cover?.data,
          })
          filename = `dossier-${slug}-${dateTag}.docx`
        }
      }
    } catch (err) {
      console.error('[export] Échec de génération :', err)
      return Response.json({ error: 'La génération du document a échoué. Vérifiez les données du projet et réessayez.' }, { status: 500 })
    }

    // Stockage dans la bibliothèque de documents du projet.
    // En cas d'échec (ex. base momentanément en lecture seule), on renvoie
    // quand même le document généré : le téléchargement ne doit jamais être
    // bloqué par un problème de stockage secondaire.
    let documentId = ''
    try {
      const stored = await db.generatedDocument.create({
        data: {
          projectId: project.id,
          name: filename,
          format,
          audience: format === 'PPTX' ? (body.audience || 'INVESTOR') : '',
          sections: JSON.stringify(body.sections || []),
          size: buffer.length,
          data: new Uint8Array(buffer),
        },
      })
      documentId = stored.id
    } catch (storageErr) {
      console.error('[export] Stockage en bibliothèque impossible, le document est tout de même renvoyé :', storageErr)
    }
    try {
      await logActivity(user.id, 'EXPORT', `Document ${format} généré : ${filename}`, project.id)
    } catch (logErr) {
      console.error('[export] Journalisation impossible :', logErr)
    }

    const mimes: Record<Format, string> = {
      PDF: 'application/pdf',
      DOCX: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      XLSX: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      PPTX: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      DIAGNOSTIC: 'application/pdf',
    }
    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': mimes[format],
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': String(buffer.length),
        'X-Document-Id': documentId,
      },
    })
  })
}

// Chargement des images d'identité visuelle du projet.
// ⚠️ Les images stockées sont DÉJÀ finalisées à l'upload (logo normalisé PNG
// ≤ 800 px ; couverture recadrée A4 1240×1754 avec son voile bleu nuit).
// Il ne faut donc PAS les re-traiter ici : un second voile à 78 % rendrait
// la photo quasiment invisible (couverture uniformément bleu nuit) et un
// second ré-encodage dégraderait inutilement l'image. On lit simplement les
// dimensions du logo pour le placement PowerPoint.
async function loadProjectImages(projectId: string): Promise<{
  logo?: { data: Buffer; width: number; height: number }
  cover?: { data: Buffer }
}> {
  const result: { logo?: { data: Buffer; width: number; height: number }; cover?: { data: Buffer } } = {}
  try {
    const assets = await db.projectAsset.findMany({ where: { projectId } })
    for (const asset of assets) {
      try {
        const data = toNodeBuffer(asset.data)
        if (asset.kind === 'LOGO') {
          const meta = await sharp(data).metadata()
          result.logo = { data, width: meta.width ?? 800, height: meta.height ?? 800 }
        } else if (asset.kind === 'COVER') {
          result.cover = { data }
        }
      } catch (imgErr) {
        console.error(`[export] Image ${asset.kind} illisible, ignorée :`, imgErr)
      }
    }
  } catch (err) {
    console.error('[export] Chargement des images de marque impossible :', err)
  }
  return result
}

function safeParseDocPrefs(json: string | null | undefined) {
  try {
    const v = json ? JSON.parse(json) : {}
    return {
      coverTitle: typeof v.coverTitle === 'string' ? v.coverTitle : '',
      coverSubtitle: typeof v.coverSubtitle === 'string' ? v.coverSubtitle : '',
      author: typeof v.author === 'string' ? v.author : '',
      organization: typeof v.organization === 'string' ? v.organization : '',
      includeCover: v.includeCover !== false,
      includeToc: v.includeToc !== false,
      headerText: typeof v.headerText === 'string' ? v.headerText : '',
      footerText: typeof v.footerText === 'string' ? v.footerText : '',
    }
  } catch {
    return { coverTitle: '', coverSubtitle: '', author: '', organization: '', includeCover: true, includeToc: true, headerText: '', footerText: '' }
  }
}
