import { db } from '@/lib/db'
import { withUser, readJson, notFound, badRequest, logActivity } from '@/lib/api-helpers'
import { computeProjectProgress } from '@/lib/finance'
import { validateProject } from '@/lib/validation'
import { isPremium } from '@/lib/plans'

type Params = { params: Promise<{ id: string }> }

async function getOwnedProject(id: string, userId: string) {
  const project = await db.project.findUnique({
    where: { id },
    include: { _count: { select: { tasks: true, documents: true } } },
  })
  if (!project || project.userId !== userId) return null
  return project
}

export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const p = await getOwnedProject(id, user.id)
    if (!p) return notFound('Projet introuvable ou accès refusé.')
    return Response.json({
      project: {
        ...p,
        tasksCount: p._count.tasks,
        docsCount: p._count.documents,
        progress: computeProjectProgress({
          idea: p.idea,
          description: p.description,
          overview: p.overview,
          analysis: p.analysis,
          finance: p.finance,
          objectives: p.objectives,
          tasksCount: p._count.tasks,
          docsCount: p._count.documents,
        }),
        _count: undefined,
      },
    })
  })
}

// Mise à jour des informations générales (nom, statut, secteur…)
export async function PATCH(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const p = await getOwnedProject(id, user.id)
    if (!p) return notFound('Projet introuvable ou accès refusé.')

    const body = await readJson<Record<string, unknown>>(req)
    const allowed = ['name', 'idea', 'description', 'sector', 'type', 'country', 'region', 'currency', 'status'] as const
    const data: Record<string, string> = {}
    for (const k of allowed) {
      if (typeof body[k] === 'string') {
        if (k === 'name' && !(body[k] as string).trim()) return badRequest('Le nom du projet ne peut pas être vide.')
        data[k] = body[k] as string
      }
    }
    if (data.status && !['DRAFT', 'ONGOING', 'COMPLETED', 'ARCHIVED'].includes(data.status)) {
      return badRequest('Statut invalide.')
    }

    // ------------------------------------------------------------------
    // Règle Gescom Project : un projet ne peut être marqué « Terminé »
    // que s'il a été VALIDÉ par le moteur de validation (dossier complet
    // et rentabilité confirmée). Non validé / à corriger ⇒ le projet
    // reste « En cours ». Brouillon et Archivé ne sont pas concernés.
    // ------------------------------------------------------------------
    if (data.status === 'COMPLETED') {
      const full = await db.project.findUnique({
        where: { id },
        include: { tasks: { select: { id: true } } },
      })
      const report = validateProject({
        name: full?.name ?? p.name,
        currency: full?.currency || p.currency || 'XAF',
        overview: full?.overview ?? p.overview,
        objectives: full?.objectives ?? p.objectives,
        analysis: full?.analysis ?? p.analysis,
        finance: full?.finance ?? p.finance,
        tasksCount: full?.tasks.length ?? 0,
        premium: isPremium(user.plan),
      })
      if (report.status !== 'VALIDE') {
        return Response.json(
          {
            error:
              `Impossible de confirmer ce projet comme « Terminé » : il n'est pas encore validé par Gescom Project `
              + `(statut actuel : ${report.statusLabel.toLowerCase()}). `
              + `Corrigez les anomalies détectées puis relancez la validation — en attendant, le projet reste « En cours ».`,
            validation: report,
          },
          { status: 403 },
        )
      }
      // Projet validé : la confirmation « Terminé » est autorisée.
    }

    const updated = await db.project.update({ where: { id }, data })
    await logActivity(user.id, 'UPDATE', `Projet mis à jour : ${updated.name}`, id)
    return Response.json({ ok: true })
  })
}

export async function DELETE(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const p = await getOwnedProject(id, user.id)
    if (!p) return notFound('Projet introuvable ou accès refusé.')
    await db.project.delete({ where: { id } })
    await logActivity(user.id, 'DELETE', `Projet supprimé : ${p.name}`)
    return Response.json({ ok: true })
  })
}
