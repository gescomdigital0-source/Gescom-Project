// GESCOM PROJECT – Recherche locale contextuelle d'un projet (pays / région)
//
// POST /api/projects/[id]/research
// Corps : { location?: string } — la région/ville à utiliser si l'utilisateur
// vient de la saisir (sinon celle enregistrée dans l'aperçu est utilisée).
//
// La recherche web + synthèse IA est réservée à l'abonnement Premium
// (verrou serveur), limitée en charge (10 demandes / 5 minutes / utilisateur)
// et strictement cantonnée aux projets de l'utilisateur.
import { db } from '@/lib/db'
import { withUser, readJson, notFound, badRequest } from '@/lib/api-helpers'
import { isPremium } from '@/lib/plans'
import { runCountryResearch } from '@/lib/research'

// Limiteur de charge en mémoire : 10 demandes par utilisateur sur 5 minutes
// (opération plus lourde que l'assistant IA : 5 recherches web + synthèse).
const WINDOW_MS = 5 * 60_000
const MAX_PER_WINDOW = 10
const hits = new Map<string, number[]>()

function rateLimited(userId: string): boolean {
  const now = Date.now()
  const list = (hits.get(userId) || []).filter((t) => now - t < WINDOW_MS)
  if (list.length >= MAX_PER_WINDOW) return true
  list.push(now)
  hits.set(userId, list)
  return false
}

type Params = { params: Promise<{ id: string }> }

export async function POST(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params

    // Fonctionnalité Premium (verrou serveur, cohérent avec l'assistant IA).
    if (!isPremium(user.plan)) {
      return Response.json(
        {
          error: "La recherche locale (études par pays et par ville) est réservée à l'abonnement Premium. Passez à Premium pour obtenir marché, réglementation, fiscalité, financements et concurrence propres à votre zone.",
          upgrade: true,
        },
        { status: 403 },
      )
    }

    if (rateLimited(user.id)) {
      return Response.json(
        { error: 'Trop de recherches envoyées. Patientez quelques instants avant de relancer.' },
        { status: 429 },
      )
    }

    const project = await db.project.findUnique({ where: { id } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const body = await readJson<{ location?: string }>(req).catch(() => ({}) as { location?: string })
    const country = (project.country || '').trim()
    const savedLocation = (() => {
      try {
        const o = JSON.parse(project.overview || '{}')
        return typeof o?.location === 'string' ? o.location.trim() : ''
      } catch {
        return ''
      }
    })()
    const location = ((body.location || '').trim() || savedLocation || (project.region || '').trim())

    if (!country) {
      return badRequest("Choisissez d'abord le pays du projet, puis relancez la recherche.")
    }
    if (!location) {
      return badRequest("Choisissez ou saisissez d'abord la région / ville du projet (Aperçu général), puis relancez la recherche.")
    }

    let legalForm = ''
    try {
      const o = JSON.parse(project.overview || '{}')
      if (typeof o?.legalForm === 'string') legalForm = o.legalForm
    } catch {
      /* aperçu illisible : on continue sans forme juridique */
    }

    try {
      const result = await runCountryResearch({
        name: project.name,
        sector: project.sector,
        country,
        location,
        idea: project.idea || '',
        legalForm,
      })
      return Response.json(result)
    } catch (err) {
      console.error('[research] Échec de la recherche locale :', err)
      const timeout = err instanceof Error && err.message === 'timeout'
      return Response.json(
        {
          error: timeout
            ? 'La recherche locale met trop de temps à aboutir. Réessayez dans quelques instants.'
            : 'La recherche locale est momentanément indisponible. Réessayez dans quelques instants.',
        },
        { status: 502 },
      )
    }
  })
}
