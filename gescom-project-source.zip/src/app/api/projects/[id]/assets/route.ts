// GESCOM PROJECT – Identité visuelle du projet (logo + image d'illustration)
// GET    : liste des images du projet (aperçus + métadonnées)
// POST   : upload multipart (file + kind=logo|cover), normalisation via sharp
// DELETE : suppression (?kind=logo|cover)
import { db } from '@/lib/db'
import { withUser, notFound, logActivity, badRequest } from '@/lib/api-helpers'
import { prepareCover, prepareLogo, toNodeBuffer } from '@/lib/exports/images'

type Params = { params: Promise<{ id: string }> }

const KINDS: Record<'logo' | 'cover', 'LOGO' | 'COVER'> = { logo: 'LOGO', cover: 'COVER' }
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024 // 5 Mo
const ALLOWED_MIME = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/svg+xml'])

export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { id: true, userId: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const rows = await db.projectAsset.findMany({
      where: { projectId: id },
      select: { kind: true, mimeType: true, size: true, updatedAt: true },
    })
    const byKind = new Map(rows.map((r) => [r.kind, r]))
    return Response.json({
      assets: {
        logo: assetInfo(id, byKind.get('LOGO')),
        cover: assetInfo(id, byKind.get('COVER')),
      },
    })
  })
}

export async function POST(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { id: true, userId: true, name: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    let form: FormData
    try {
      form = await req.formData()
    } catch {
      return badRequest('Requête invalide : envoyez un formulaire multipart avec un fichier image.')
    }
    const file = form.get('file')
    const kindRaw = String(form.get('kind') || '')
    const kind = KINDS[kindRaw as 'logo' | 'cover']
    if (!kind) return badRequest('Type d\'image invalide (attendu : logo ou cover).')
    if (!(file instanceof File)) return badRequest('Aucun fichier image reçu.')
    if (file.size > MAX_UPLOAD_BYTES) {
      return badRequest('Image trop volumineuse (5 Mo maximum).')
    }
    const mime = (file.type || '').toLowerCase()
    if (!ALLOWED_MIME.has(mime)) {
      return badRequest('Format d\'image non pris en charge. Utilisez PNG, JPG, WebP ou GIF.')
    }

    const input = toNodeBuffer(new Uint8Array(await file.arrayBuffer()))
    let processed: { data: Buffer; mimeType: string; width: number; height: number }
    try {
      if (kind === 'LOGO') {
        const logo = await prepareLogo(input)
        processed = { ...logo, mimeType: 'image/png' }
      } else {
        const cover = await prepareCover(input)
        processed = { ...cover, mimeType: 'image/jpeg' }
      }
    } catch {
      return badRequest('Impossible de lire cette image. Essayez un fichier PNG ou JPG.')
    }

    const saved = await db.projectAsset.upsert({
      where: { projectId_kind: { projectId: id, kind } },
      create: { projectId: id, kind, mimeType: processed.mimeType, size: processed.data.length, data: new Uint8Array(processed.data) },
      update: { mimeType: processed.mimeType, size: processed.data.length, data: new Uint8Array(processed.data) },
      select: { kind: true, mimeType: true, size: true, updatedAt: true },
    })
    await logActivity(
      user.id, 'UPDATE',
      kind === 'LOGO' ? 'Logo mis à jour pour l\'identité visuelle' : 'Image d\'illustration mise à jour pour la couverture',
      id,
    )
    return Response.json({ asset: assetInfo(id, saved) })
  })
}

export async function DELETE(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { id: true, userId: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const kindRaw = new URL(req.url).searchParams.get('kind') || ''
    const kind = KINDS[kindRaw as 'logo' | 'cover']
    if (!kind) return badRequest('Type d\'image invalide (attendu : logo ou cover).')

    await db.projectAsset.deleteMany({ where: { projectId: id, kind } })
    await logActivity(user.id, 'UPDATE', kind === 'LOGO' ? 'Logo supprimé' : 'Image d\'illustration supprimée', id)
    return Response.json({ ok: true })
  })
}

// Métadonnées exposées au client (jamais les octets) + URL d'aperçu
// avec version (cache-bust) pour rafraîchir l'affichage après upload.
function assetInfo(projectId: string, row: { kind: string; mimeType: string; size: number; updatedAt: Date } | undefined) {
  if (!row) return null
  return {
    kind: row.kind.toLowerCase(),
    url: `/api/projects/${projectId}/assets/${row.kind.toLowerCase()}?v=${encodeURIComponent(row.updatedAt.toISOString())}`,
    mimeType: row.mimeType,
    size: row.size,
    updatedAt: row.updatedAt.toISOString(),
  }
}
