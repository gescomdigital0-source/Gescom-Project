// GESCOM PROJECT – Service des images d'identité visuelle
// GET /api/projects/[id]/assets/[kind] → octets de l'image (logo | cover).
// L'authentification passe par le cookie httpOnly en repli : fonctionne
// pour les aperçus <img> comme pour les appels fetch avec Bearer.
import { db } from '@/lib/db'
import { withUser, notFound } from '@/lib/api-helpers'
import { toNodeBuffer } from '@/lib/exports/images'

type Params = { params: Promise<{ id: string; kind: string }> }

export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id, kind } = await params
    const normalized = kind === 'logo' ? 'LOGO' : kind === 'cover' ? 'COVER' : ''
    if (!normalized) return notFound('Image introuvable.')
    const project = await db.project.findUnique({ where: { id }, select: { id: true, userId: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const asset = await db.projectAsset.findUnique({
      where: { projectId_kind: { projectId: id, kind: normalized } },
      select: { mimeType: true, data: true },
    })
    if (!asset) return notFound('Aucune image enregistrée pour ce projet.')

    const data = toNodeBuffer(asset.data)
    return new Response(new Uint8Array(data), {
      headers: {
        'Content-Type': asset.mimeType,
        'Content-Length': String(data.length),
        'Cache-Control': 'private, no-store',
      },
    })
  })
}
