import { db } from '@/lib/db'
import { withUser, notFound, logActivity } from '@/lib/api-helpers'

type Params = { params: Promise<{ id: string }> }

// Duplication complète d'un projet (sections + tâches)
export async function POST(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const source = await db.project.findUnique({ where: { id }, include: { tasks: true } })
    if (!source || source.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const copy = await db.project.create({
      data: {
        userId: user.id,
        name: `${source.name} (copie)`,
        idea: source.idea,
        description: source.description,
        sector: source.sector,
        type: source.type,
        country: source.country,
        region: source.region,
        currency: source.currency,
        status: 'DRAFT',
        objectives: source.objectives,
        overview: source.overview,
        analysis: source.analysis,
        finance: source.finance,
        docPrefs: source.docPrefs,
      },
    })
    if (source.tasks.length > 0) {
      await db.task.createMany({
        data: source.tasks.map((t) => ({
          projectId: copy.id,
          phase: t.phase,
          title: t.title,
          responsible: t.responsible,
          startDate: t.startDate,
          endDate: t.endDate,
          status: 'TODO',
          progress: 0,
          order: t.order,
        })),
      })
    }
    // Identité visuelle : le logo et l'image d'illustration suivent la copie.
    const assets = await db.projectAsset.findMany({ where: { projectId: source.id } })
    if (assets.length > 0) {
      await db.projectAsset.createMany({
        data: assets.map((a) => ({
          projectId: copy.id,
          kind: a.kind,
          mimeType: a.mimeType,
          size: a.size,
          data: a.data,
        })),
      })
    }
    await logActivity(user.id, 'CREATE', `Projet dupliqué depuis : ${source.name}`, copy.id)
    return Response.json({ project: { id: copy.id, name: copy.name } })
  })
}
