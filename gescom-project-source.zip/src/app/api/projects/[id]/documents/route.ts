import { db } from '@/lib/db'
import { withUser, notFound } from '@/lib/api-helpers'

type Params = { params: Promise<{ id: string }> }

// Bibliothèque de documents générés du projet
export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { userId: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable.')
    const documents = await db.generatedDocument.findMany({
      where: { projectId: id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, name: true, format: true, audience: true, size: true, createdAt: true },
    })
    return Response.json({ documents })
  })
}
