// GESCOM PROJECT – API de validation automatique d'un projet
//
// GET /api/projects/[id]/validation
// Recalcule à chaque appel le rapport complet de validation : indicateurs de
// rentabilité (VAN, TRI, IP), contrôles de conformité section par section,
// zones à corriger avec recommandations, statut et décision finale.
// Aucun stockage : après chaque correction de l'utilisateur, un nouvel appel
// reflète immédiatement l'état du projet.
import { db } from '@/lib/db'
import { withUser, notFound } from '@/lib/api-helpers'
import { validateProject } from '@/lib/validation'
import { applyAutoStatus } from '@/lib/validation-auto'
import { isPremium } from '@/lib/plans'

type Params = { params: Promise<{ id: string }> }

export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({
      where: { id },
      include: { tasks: { select: { id: true } } },
    })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const report = validateProject({
      name: project.name,
      currency: project.currency || 'XAF',
      overview: project.overview,
      objectives: project.objectives,
      analysis: project.analysis,
      finance: project.finance,
      tasksCount: project.tasks.length,
      premium: isPremium(user.plan),
    })

    // Règles Gescom Project : un projet validé (zéro anomalie) est
    // automatiquement confirmé « Terminé » ; à l'inverse, un projet qui
    // présente une anomalie ou une correction ne doit pas rester « Terminé »
    // — il repasse automatiquement « En cours ». Le rapport reflète l'état
    // AVANT application de la règle ; projectStatus renvoie le statut réel
    // après coup.
    const auto = await applyAutoStatus(user.id, id, project.status, report)

    return Response.json({
      report,
      autoCompleted: auto.promoted,
      autoDemoted: auto.demoted,
      projectStatus: auto.status,
    })
  })
}
