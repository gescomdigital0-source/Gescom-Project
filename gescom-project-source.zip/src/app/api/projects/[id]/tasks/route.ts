import { db } from '@/lib/db'
import { withUser, readJson, notFound, badRequest, logActivity } from '@/lib/api-helpers'

type Params = { params: Promise<{ id: string }> }

export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { userId: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable.')
    const tasks = await db.task.findMany({ where: { projectId: id }, orderBy: [{ order: 'asc' }, { createdAt: 'asc' }] })
    return Response.json({ tasks })
  })
}

export async function POST(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { userId: true, name: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable.')

    const body = await readJson<{
      phase?: string
      title?: string
      responsible?: string
      startDate?: string
      endDate?: string
      status?: string
      progress?: number
    }>(req)
    const title = (body.title || '').trim()
    if (!title) return badRequest('L\'intitulé de la tâche est obligatoire.')

    const maxOrder = await db.task.aggregate({ where: { projectId: id }, _max: { order: true } })
    const task = await db.task.create({
      data: {
        projectId: id,
        phase: (body.phase || '').trim(),
        title,
        responsible: (body.responsible || '').trim(),
        startDate: body.startDate || '',
        endDate: body.endDate || '',
        status: ['TODO', 'IN_PROGRESS', 'DONE', 'BLOCKED'].includes(body.status || '') ? body.status! : 'TODO',
        progress: Math.min(100, Math.max(0, Number(body.progress) || 0)),
        order: (maxOrder._max.order ?? -1) + 1,
      },
    })
    await logActivity(user.id, 'TASK', `Tâche ajoutée au plan d'action : ${title}`, id)
    return Response.json({ task })
  })
}
