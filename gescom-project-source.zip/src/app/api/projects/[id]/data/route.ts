import { db } from '@/lib/db'
import { withUser, readJson, notFound, logActivity } from '@/lib/api-helpers'
import { isPremium } from '@/lib/plans'
import { normalizeFinance } from '@/lib/finance'
import { validateProject } from '@/lib/validation'
import { applyAutoStatus } from '@/lib/validation-auto'
import type { AnalysisData } from '@/lib/types'

type Params = { params: Promise<{ id: string }> }

// Mise à jour des sections de données structurées du projet :
// objectives, overview, analysis, finance, docPrefs (JSON sérialisés)
export async function PATCH(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({ where: { id }, select: { id: true, userId: true, name: true, analysis: true, finance: true } })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')

    const body = await readJson<Record<string, unknown>>(req)
    const premium = isPremium(user.plan)
    const data: Record<string, string> = {}
    for (const key of ['objectives', 'overview', 'analysis', 'finance', 'docPrefs'] as const) {
      if (key in body) {
        const v = body[key]
        if (v === null || v === undefined) {
          data[key] = key === 'objectives' ? '[]' : '{}'
        } else if (typeof v === 'string') {
          data[key] = v // déjà sérialisé côté client
        } else {
          data[key] = JSON.stringify(v)
        }
      }
    }
    // Plan GRATUIT : les contenus réservés au Premium ne peuvent pas être
    // créés ni modifiés via l'API. Les valeurs déjà enregistrées (ex. d'un
    // ancien abonnement Premium) sont conservées telles quelles : rien n'est
    // supprimé, elles seront de nouveau visibles après réactivation.
    if (!premium) {
      const storedAnalysis = safeParse<AnalysisData>(project.analysis, {})
      const storedFinance = normalizeFinance(project.finance)
      if (data.analysis) {
        const parsed = safeParse<AnalysisData>(data.analysis, {})
        parsed.risks = storedAnalysis.risks ?? []
        data.analysis = JSON.stringify(parsed)
      }
      if (data.finance) {
        const parsed = normalizeFinance(data.finance)
        parsed.financing = storedFinance.financing ?? []
        parsed.assumptions.products = storedFinance.assumptions.products ?? []
        data.finance = JSON.stringify(parsed)
      }
    }
    if (Object.keys(data).length === 0) {
      return Response.json({ ok: true, message: 'Aucune donnée à mettre à jour.' })
    }
    await db.project.update({ where: { id }, data })

    // ------------------------------------------------------------------
    // Relance automatique des contrôles après chaque correction (cahier
    // des charges §6) : si la sauvegarde rend le projet entièrement
    // conforme (zéro anomalie), il est validé et automatiquement confirmé
    // « Terminé » ; à l'inverse, si la sauvegarde introduit une anomalie
    // sur un projet « Terminé », il repasse automatiquement « En cours ».
    // ------------------------------------------------------------------
    let autoCompleted = false
    let autoDemoted = false
    try {
      const full = await db.project.findUnique({
        where: { id },
        select: {
          status: true,
          name: true,
          currency: true,
          overview: true,
          objectives: true,
          analysis: true,
          finance: true,
          _count: { select: { tasks: true } },
        },
      })
      if (full) {
        const report = validateProject({
          name: full.name,
          currency: full.currency || 'XAF',
          overview: full.overview,
          objectives: full.objectives,
          analysis: full.analysis,
          finance: full.finance,
          tasksCount: full._count.tasks,
          premium,
        })
        const auto = await applyAutoStatus(user.id, id, full.status, report)
        autoCompleted = auto.promoted
        autoDemoted = auto.demoted
      }
    } catch (valErr) {
      // La revalidation ne doit jamais empêcher l'enregistrement.
      console.error('[data] Revalidation après sauvegarde impossible :', valErr)
    }

    return Response.json({ ok: true, savedAt: new Date().toISOString(), autoCompleted, autoDemoted })
  })
}

function safeParse<T>(json: string | null | undefined, fallback: Partial<T>): Partial<T> {
  if (!json) return fallback
  try {
    const v = JSON.parse(json)
    return v && typeof v === 'object' ? v : fallback
  } catch {
    return fallback
  }
}

// Lecture des sections structurées
export async function GET(req: Request, { params }: Params) {
  return withUser(req, async (user) => {
    const { id } = await params
    const project = await db.project.findUnique({
      where: { id },
      select: { id: true, userId: true, objectives: true, overview: true, analysis: true, finance: true, docPrefs: true },
    })
    if (!project || project.userId !== user.id) return notFound('Projet introuvable ou accès refusé.')
    return Response.json({
      objectives: project.objectives,
      overview: project.overview,
      analysis: project.analysis,
      finance: project.finance,
      docPrefs: project.docPrefs,
    })
  })
}
