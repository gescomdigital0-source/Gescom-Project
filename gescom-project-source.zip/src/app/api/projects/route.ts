import { db } from '@/lib/db'
import { withUser, readJson, badRequest, logActivity } from '@/lib/api-helpers'
import { computeProjectProgress } from '@/lib/finance'

// Liste des projets de l'utilisateur (isolation stricte des données)
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    const projects = await db.project.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: 'desc' },
      include: { _count: { select: { tasks: true, documents: true } } },
    })
    return Response.json({
      projects: projects.map((p) => ({
        id: p.id,
        name: p.name,
        idea: p.idea,
        description: p.description,
        sector: p.sector,
        type: p.type,
        country: p.country,
        region: p.region,
        currency: p.currency,
        status: p.status,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
        tasksCount: p._count.tasks,
        docsCount: p._count.documents,
        progress: computeProjectProgress({
          idea: p.idea,
          description: p.description,
          overview: p.overview,
          analysis: p.analysis,
          finance: p.finance,
          objectives: p.objectives,
          tasksCount: p._count.tasks,
          docsCount: p._count.documents,
        }),
      })),
    })
  })
}

// Création d'un projet (assistant pas-à-pas)
export async function POST(req: Request) {
  return withUser(req, async (user) => {
    const body = await readJson<{
      name?: string
      idea?: string
      description?: string
      sector?: string
      type?: string
      country?: string
      region?: string
      currency?: string
      objectives?: string[]
    }>(req)

    const name = (body.name || '').trim()
    if (!name) return badRequest('Le nom du projet est obligatoire.')

    const project = await db.project.create({
      data: {
        userId: user.id,
        name,
        idea: (body.idea || '').trim(),
        description: (body.description || '').trim(),
        sector: body.sector || '',
        type: body.type || '',
        country: body.country || '',
        region: body.region || '',
        currency: body.currency || user.prefs?.currency || 'XAF',
        status: 'DRAFT',
        objectives: JSON.stringify(Array.isArray(body.objectives) ? body.objectives : []),
      },
    })
    await logActivity(user.id, 'CREATE', `Nouveau projet créé : ${name}`, project.id)
    return Response.json({ project: { id: project.id, name: project.name } })
  })
}
