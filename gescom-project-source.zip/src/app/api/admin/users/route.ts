import { db } from '@/lib/db'
import { withUser, readJson, notFound } from '@/lib/api-helpers'
import { normalizePlan } from '@/lib/plans'

// Administration : gestion des utilisateurs (réservé au rôle ADMIN)
export async function GET(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    const users = await db.user.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, email: true, firstName: true, lastName: true, role: true,
        plan: true,
        organization: true, createdAt: true,
        _count: { select: { projects: true } },
      },
    })
    return Response.json({ users: users.map((u) => ({ ...u, projectsCount: u._count.projects, _count: undefined })) })
  })
}

export async function PATCH(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    const body = await readJson<{ id?: string; role?: string; plan?: string }>(req)
    const data: { role?: string; plan?: string } = {}
    if (body.role) {
      if (!['USER', 'ADMIN'].includes(body.role)) {
        return Response.json({ error: 'Requête invalide.' }, { status: 400 })
      }
      if (body.id === user.id) {
        return Response.json({ error: 'Vous ne pouvez pas modifier votre propre rôle.' }, { status: 400 })
      }
      data.role = body.role
    }
    if (body.plan !== undefined) {
      data.plan = normalizePlan(body.plan)
    }
    if (!body.id || Object.keys(data).length === 0) {
      return Response.json({ error: 'Requête invalide.' }, { status: 400 })
    }
    await db.user.update({ where: { id: body.id }, data })
    return Response.json({ ok: true })
  })
}

export async function DELETE(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    const body = await readJson<{ id?: string }>(req)
    if (!body.id) return Response.json({ error: 'Requête invalide.' }, { status: 400 })
    if (body.id === user.id) {
      return Response.json({ error: 'Vous ne pouvez pas supprimer votre propre compte.' }, { status: 400 })
    }
    await db.user.delete({ where: { id: body.id } })
    return Response.json({ ok: true })
  })
}
