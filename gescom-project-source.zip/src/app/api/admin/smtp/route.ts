// GESCOM PROJECT – Configuration SMTP des e-mails transactionnels (ADMIN)
//
// GET    : état de la configuration (mot de passe jamais renvoyé, masqué)
// PUT    : enregistre la configuration dans la base (clés SystemSetting smtp.*)
//          un mot de passe vide conserve la valeur déjà enregistrée
// POST   : envoie un e-mail de test avec les valeurs fournies (le mot de passe
//          vide signifie « celui déjà enregistré ») – permet de valider avant
//          d'enregistrer
// DELETE : efface la configuration enregistrée (retour au mode démonstration
//          si aucun .env n'est présent)
import { withUser, readJson, notFound, badRequest } from '@/lib/api-helpers'
import {
  resolveSmtpConfig, getSmtpSetting, setSmtpSetting, clearSmtpSettings, sendTestEmail,
  type SmtpConfig,
} from '@/lib/mailer'
import { isValidEmail } from '@/lib/auth'

async function maskedStatus() {
  const cfg = await resolveSmtpConfig()
  const dbPass = await getSmtpSetting('pass')
  return {
    configured: cfg !== null,
    source: dbPass !== null ? 'db' : process.env.SMTP_HOST ? 'env' : null,
    host: (await getSmtpSetting('host')) ?? process.env.SMTP_HOST ?? '',
    port: Number((await getSmtpSetting('port')) ?? process.env.SMTP_PORT ?? 587),
    secure:
      (await getSmtpSetting('secure')) ?? process.env.SMTP_SECURE ?? (cfg ? String(cfg.secure) : 'false'),
    user: (await getSmtpSetting('user')) ?? process.env.SMTP_USER ?? '',
    from: (await getSmtpSetting('from')) ?? process.env.SMTP_FROM ?? (cfg ? cfg.from : ''),
    hasPassword: cfg !== null,
  }
}

export async function GET(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    return Response.json(await maskedStatus())
  })
}

interface SmtpBody {
  host?: string
  port?: number | string
  secure?: boolean | string
  user?: string
  pass?: string
  from?: string
}

function validate(body: SmtpBody): { error: string } | { host: string; port: number; secure: boolean; user: string } {
  const host = (body.host || '').trim()
  const user = (body.user || '').trim()
  const port = Number(body.port ?? 587)
  if (!host) return { error: 'Le serveur SMTP est requis (ex. smtp.gmail.com).' }
  if (!user) return { error: "L'identifiant SMTP (adresse e-mail d'envoi) est requis." }
  if (!Number.isInteger(port) || port < 1 || port > 65535) return { error: 'Le port SMTP est invalide (1–65535).' }
  // TLS dérivé du port si non renseigné explicitement (465 = TLS direct).
  const secure =
    body.secure === undefined || body.secure === null || body.secure === ''
      ? port === 465
      : typeof body.secure === 'string'
        ? body.secure === 'true'
        : Boolean(body.secure)
  return { host, port, secure, user }
}

export async function PUT(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    const body = await readJson<SmtpBody>(req)
    const valid = validate(body)
    if ('error' in valid) return badRequest(valid.error)

    // Mot de passe vide : on conserve celui déjà enregistré en base (s'il existe).
    const existingPass = await getSmtpSetting('pass')
    const pass = (body.pass || '').trim() || existingPass || ''
    if (!pass) {
      return badRequest(
        "Le mot de passe SMTP est requis lors du premier enregistrement (mot de passe d'application pour Gmail).",
      )
    }
    await setSmtpSetting('host', valid.host)
    await setSmtpSetting('port', String(valid.port))
    await setSmtpSetting('secure', String(valid.secure))
    await setSmtpSetting('user', valid.user)
    await setSmtpSetting('pass', pass)
    if ((body.from || '').trim()) await setSmtpSetting('from', (body.from || '').trim())

    return Response.json(await maskedStatus())
  })
}

export async function POST(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    const body = await readJson<SmtpBody & { to?: string }>(req)
    const valid = validate(body)
    if ('error' in valid) return badRequest(valid.error)

    const to = ((body.to || '').trim() || user.email).toLowerCase()
    if (!isValidEmail(to)) return badRequest('Adresse e-mail de test invalide.')

    // Le mot de passe vide dans le formulaire = « celui déjà enregistré ».
    const savedPass = (await getSmtpSetting('pass')) || process.env.SMTP_PASS || ''
    const pass = (body.pass || '').trim() || savedPass
    const cfg: Partial<SmtpConfig> = {
      host: valid.host,
      port: valid.port,
      secure: valid.secure,
      user: valid.user,
      pass,
      from: (body.from || '').trim() || `GESCOM PROJECT <${valid.user}>`,
    }
    const result = await sendTestEmail(to, cfg)
    if (!result.ok) {
      return Response.json(
        {
          error: `Échec de l'envoi du test : ${result.error}`,
          hint: 'Vérifiez le serveur, le port (465 = TLS direct, 587 = STARTTLS), l\'identifiant et le mot de passe d\'application.',
        },
        { status: 502 },
      )
    }
    return Response.json({ ok: true, to })
  })
}

export async function DELETE(req: Request) {
  return withUser(req, async (user) => {
    if (user.role !== 'ADMIN') return notFound('Accès réservé aux administrateurs.')
    await clearSmtpSettings()
    return Response.json(await maskedStatus())
  })
}
