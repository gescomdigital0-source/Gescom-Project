import { GescomApp } from '@/components/gescom/GescomApp'

export default function Home() {
  return <GescomApp />
}
